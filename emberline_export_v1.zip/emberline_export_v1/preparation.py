"""Évaluation de l'état de préparation pour chaque objectif à venir (ordre chronologique).

Pour chaque objectif : un score global 0-100 (le « curseur »), composé de
  - la PERFORMANCE : temps estimé comparé au temps visé (course à pied avec temps visé), mélangé au volume réellement
    accompli par rapport à ce qu'il faudrait à ce stade de la préparation ; sans temps visé, le volume seul compte ;
  - la FORME du jour (indice de fatigue de l'analyse physiologique), dont le poids grandit à l'approche de la course
    (0 à 42 jours ou plus, 50 % le jour J) : loin de la course, la forme n'est pas un obstacle durable.
Tout est déterministe (aucune donnée aléatoire) et ne dépend pas de la période glissante choisie.
Lancé par analysis.build_analysis ; ne doit jamais faire échouer la génération (erreurs capturées par l'appelant).
"""
import math
from datetime import date

import planner as PLN

LEVELS_PREP = [(80, "excellent", "Très bien engagé"), (65, "bon", "Sur la bonne voie"), (50, "moyen", "À consolider"),
               (35, "retard", "En retard sur le plan"), (0, "faible", "À reconstruire")]
LEVELS_RACE = [(80, "excellent", "Prêt à performer"), (65, "bon", "Bien préparé"), (50, "moyen", "Un peu juste"),
               (35, "retard", "Fragile"), (0, "faible", "Préparation insuffisante")]
PHASE_SHORT = {"reprise": "reprise", "developpement": "développement", "intensification": "intensification",
               "specifique": "phase spécifique", "affutage": "affûtage", "jour_j": "jour de course"}
RIEGEL = 1.06
PERF_PTS = [(0.97, 100), (1.00, 90), (1.03, 75), (1.06, 58), (1.10, 38), (1.15, 18), (1.25, 0)]    # rapport temps estimé / temps visé -> note


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def _interp(r):
    if r <= PERF_PTS[0][0]: return float(PERF_PTS[0][1])
    for (x0, y0), (x1, y1) in zip(PERF_PTS, PERF_PTS[1:]):
        if r <= x1: return y0 + (y1 - y0) * (r - x0) / (x1 - x0)
    return 0.0


def _fmt_t(s):
    s = int(round(s)); h, m, sec = s // 3600, s % 3600 // 60, s % 60
    return f"{h}h{m:02d}'{sec:02d}" if h else f"{m}'{sec:02d}"       # même format que le reste du tableau de bord (3h32'44)


def _fmt_h(h):
    return f"{h:.1f}".replace(".", ",") + " h"


def _fmt_date(s):
    return f"{s[8:10]}/{s[5:7]}/{s[0:4]}"


def _pred_time(preds, dist):
    """Temps estimé (s) sur `dist` km à partir de la prédiction la plus proche (Riegel) ; None si aucune prédiction."""
    c = [p for p in preds or [] if p.get("ret") and p.get("dist")]
    if not c or not dist: return None
    p = min(c, key=lambda q: abs(math.log(dist / q["dist"])))
    return p["ret"] * (dist / p["dist"]) ** RIEGEL


def _pace_ref(preds):
    """Allure de référence (min/km) : prédiction 10 km ou la plus proche, sinon 6,0."""
    c = [p for p in preds or [] if p.get("ret") and p.get("dist")]
    if not c: return 6.0
    p = min(c, key=lambda q: abs(q["dist"] - 10))
    return max(3.0, p["ret"] / 60.0 / p["dist"])


def _legs(g, o, preds):
    """Durée estimée de l'épreuve par discipline, en heures : {'run': h, ...}. Le temps visé (s'il existe) fixe le total."""
    sp = g.get("sport", "run"); pace = _pace_ref(preds)
    el_run = (g.get("run_elev") if sp in ("triathlon",) else g.get("elev")) or 0
    if sp == "run":
        t = _pred_time(preds, float(g.get("dist") or 0))
        legs = {"run": (t / 3600.0) if t else float(g.get("dist") or 0) * pace * 1.0 / 60.0}
    elif sp == "trail":
        eq = float(g.get("dist") or 0) + (g.get("elev") or 0) / 100.0
        legs = {"run": eq * max(6.0, pace * 1.15) / 60.0}
    elif sp == "swim":
        legs = {"swim": float(g.get("dist") or 0) * 20.0 / 60.0}
    elif sp == "bike":
        legs = {"bike": float(g.get("dist") or 0) / 26.0 + (g.get("elev") or 0) / 1000.0}
    else:                                                                   # triathlon, duathlon, aquathlon, swimrun
        sw, bk, rn = float(g.get("swim") or 0), float(g.get("bike") or 0), float(g.get("run") or 0)
        sr = str(g.get("format") or "").startswith("sr_")
        legs = {}
        if sw > 0: legs["swim"] = sw * (25.0 if sr else 20.0) / 60.0
        if bk > 0: legs["bike"] = bk / 28.0 + (g.get("bike_elev") or 0) / 1000.0
        if rn > 0: legs["run"] = (rn + (g.get("run_elev") or 0) / 100.0) * max(5.5, pace * 1.1) / 60.0 * (1.1 if sr else 1.0)
        if not legs: legs = {"run": float(g.get("dist") or 0) * pace / 60.0}
    tot = sum(legs.values()) or 1e-9
    ts = g.get("target_s")
    if ts and ts > 0:
        k = (ts / 3600.0) / tot
        legs = {d: h * k for d, h in legs.items()}
    return legs


def _hist(acts, T, lo, hi):
    """Heures par discipline (run/bike/swim) entre T-hi et T-lo jours, et plus longue séance (h) par discipline."""
    tot, longest = {"run": 0.0, "bike": 0.0, "swim": 0.0}, {"run": 0.0, "bike": 0.0, "swim": 0.0}
    for a in acts:
        try:
            age = (T - date.fromisoformat(a["d"])).days
        except (KeyError, ValueError, TypeError):
            continue
        if not (lo <= age < hi): continue
        s = a.get("s"); d = "run" if s in ("run", "trail") else s if s in tot else None
        if not d: continue
        h = (a.get("m") or 0) / 60.0
        tot[d] += h; longest[d] = max(longest[d], h)
    return tot, longest


def _level(score, close):
    for th, k, lab in (LEVELS_RACE if close else LEVELS_PREP):
        if score >= th: return k, lab
    return "faible", (LEVELS_RACE if close else LEVELS_PREP)[-1][2]


def _text(o, ev):
    """Texte court : situation + performance/volume + forme et conseil."""
    dl, ph = o["days_left"], o["phase"]
    n = f"{dl} jour{'s' if dl > 1 else ''}"
    head = {"jour_j": "C'est aujourd'hui.", }.get(ph) or f"Dans {n} ({PHASE_SHORT.get(ph, ph)})."
    p1 = ""
    if ev.get("pred_s") and o.get("target_s"):
        gap = ev["pred_s"] - o["target_s"]
        if ev["r_eff"] <= 1.0:
            p1 = f"Ton chrono estimé ({_fmt_t(ev['pred_s'])}) est déjà au niveau du temps visé ({_fmt_t(o['target_s'])})."
        else:
            tail = "il reste du temps pour le combler." if ev["r_eff"] <= 1.03 else "à combler d'ici là avec des séances spécifiques." if ev["r_eff"] <= 1.06 else "l'écart est important : il faudra une belle progression, ou un objectif plus réaliste."
            p1 = f"Ton chrono estimé ({_fmt_t(ev['pred_s'])}) est à {_fmt_t(abs(gap))} du temps visé ({_fmt_t(o['target_s'])}) : {tail}"
    if ev.get("spec") is not None:
        v = f"Volume récent : {_fmt_h(ev['wk_h'])} par semaine, pour environ {_fmt_h(ev['need_h'])} attendues à ce stade."
        p1 = (p1 + " " + v) if p1 else v + " Évaluation fondée sur le volume d'entraînement, faute de temps visé chiffré."
    p2 = ""
    f = ev.get("form")
    if f is None:
        p2 = "Forme non évaluée (pas assez de données de récupération)."
    else:
        close = dl <= 14
        if f >= 75: p2 = f"Forme bonne ({f}/100)" + (" : garde cette fraîcheur, n'ajoute rien de superflu." if close else " : profites-en pour charger intelligemment.")
        elif f >= 55: p2 = f"Forme correcte ({f}/100)" + (" : veille au sommeil et évite les séances dures." if close else ".")
        else: p2 = f"Forme basse ({f}/100)" + (" : ménage-toi, la fraîcheur se construit maintenant." if close else " : elle remontera avec du repos, rien d'inquiétant à cette distance.")
    return " ".join(x for x in (head, p1, ev.get("cap_txt"), p2) if x)


def evaluer(acts, T, goals, preds, st):
    """Liste (ordre chronologique) des objectifs à venir avec score de préparation. Retourne [] sans objectif."""
    out = []
    objs = [o for o in PLN.analyse_objectifs(goals, T) if o["days_left"] >= 0]
    form = None if not st or st.get("strain") is None else int(100 - st["strain"])
    for o in objs:
        g = next((x for x in goals if x.get("id", x.get("label")) == o["id"] and x.get("date") == o["date"]), None) or {}
        dl = o["days_left"]
        legs = _legs(g, o, preds); H = max(sum(legs.values()), 0.2)
        taper = o["phase"] in ("affutage", "jour_j")
        lo, hi = (7, 35) if taper else (0, 28)
        tot, _ = _hist(acts, T, lo, hi); _, longest = _hist(acts, T, 7 if taper else 0, 42)
        pw = max(o.get("prep_weeks") or 8, 6) * 7
        ramp = 1.0 if taper else 0.45 + 0.55 * (1 - min(dl, pw) / pw)
        need_tot = _clamp(3.0 + 1.1 * H, 3.0, 18.0)
        vol = lng = 0.0; wk = 0.0
        for d, h in legs.items():
            share = h / H
            need_d = need_tot * share
            act_d = tot.get(d, 0.0) / 4.0
            wk += act_d
            vol += share * _clamp(act_d / max(need_d * ramp, 0.05))
            cap = 4.5 if d == "bike" else 3.0
            need_l = _clamp(0.7 * h, 0.4, cap)
            lng += share * _clamp(longest.get(d, 0.0) / max(need_l * ramp, 0.05))
        spec = 100.0 * (0.65 * vol + 0.35 * lng)
        pred_s = _pred_time(preds, float(g.get("dist") or 0)) if g.get("sport", "run") == "run" and o.get("target_s") else None
        r_eff = perf_pred = None
        if pred_s:
            r = pred_s / o["target_s"]; r_eff = r - min(0.02, dl / 7.0 * 0.001)       # v5 : marge de progression réduite (2 % au plus)
            perf_pred = _interp(r_eff)
        perf = spec if perf_pred is None else 0.6 * perf_pred + 0.4 * spec       # v5 : le volume réellement accompli pèse davantage
        w_form = 0.5 * _clamp(1 - dl / 42.0) if form is not None else 0.0
        score = perf * (1 - w_form) + (form * w_form if form is not None else 0.0)
        cap_txt = None
        if g.get("sport", "run") in ("run", "trail") and float(g.get("dist") or 0) >= 21:          # v5 (audit C3) : pas de « très bien engagé » sans sortie longue
            dist = float(g.get("dist") or 0)
            l42 = max([a.get("km") or 0 for a in acts if a.get("s") in ("run", "trail") and 0 <= (T - date.fromisoformat(a["d"])).days < 42] or [0])
            if dl <= 42 and l42 < 0.7 * dist: cap = 55
            elif dl <= 84 and l42 < 0.5 * dist: cap = 60
            elif l42 < 0.4 * dist: cap = 70
            else: cap = None
            if cap is not None and score > cap:
                score = cap
                cap_txt = f"Score plafonné à {cap}/100 : ta plus longue sortie des 6 dernières semaines fait {l42:.1f} km".replace(".", ",") + f" pour une épreuve de {dist:.0f} km."
        have = bool(acts) and any(tot[d] > 0 or longest[d] > 0 for d in tot)
        ev = {"spec": round(spec), "wk_h": wk, "need_h": need_tot * ramp, "pred_s": pred_s, "r_eff": r_eff, "form": form, "cap_txt": cap_txt}
        if not acts or (not have and perf_pred is None):
            score, perf = None, None
        key, lab = _level(score, dl <= 14) if score is not None else (None, "Pas assez de données")
        out.append({"id": o["id"], "name": o["label"], "date": o["date"], "date_fr": _fmt_date(o["date"]), "days_left": dl, "sport": o.get("kind"), "cls": o.get("cls"),
                    "prio": o.get("prio"), "role": o.get("role"), "phase": o["phase"], "phase_label": PHASE_SHORT.get(o["phase"], o["phase"]),
                    "target": None if not o.get("target_s") else _fmt_t(o["target_s"]),
                    "score": None if score is None else int(round(score)), "perf": None if perf is None else int(round(perf)), "form": form,
                    "w_form": round(w_form, 2), "level": key, "label": lab,
                    "text": _text(o, ev) if score is not None else "Pas assez d'activités récentes pour évaluer cette préparation : la montre doit d'abord synchroniser quelques séances."})
    return out
