"""Adaptation du plan d'entraînement : affûtage progressif, courses rapprochées, bilan hebdomadaire en tâche de fond.

Module déterministe et sans dépendance (comme planner.py). Il ne dessine rien sur le dashboard : il règle la génération des séances.

1. AFFÛTAGE (taper_vol) : le volume baisse de façon exponentielle (rapide au début, plus lent ensuite) jusqu'à un plancher qui dépend de la
   distance et du rôle de la course (Mujika & Padilla 2003 : -40 à -60 % du volume, intensité et fréquence conservées).
2. COURSES RAPPROCHÉES (relier, legs_guard) : une course qui suit de près une autre voit son affûtage borné par la place disponible après la
   récupération de la précédente ; si la fenêtre de travail entre deux courses est inférieure à une semaine, la période est traitée en entretien
   (une séance clé par semaine au plus). Les jambes sont ménagées en musculation autour de chaque course.
3. BILAN HEBDOMADAIRE (revue) : chaque jour, les séances conseillées sont conservées dans garmin/plan_memory.json ; 7 jours plus tard, elles sont
   comparées à ce qui a réellement été fait. Le bilan règle la semaine suivante : séance clé manquée reprogrammée, séance clé régulièrement
   manquée remplacée par une plus accessible, volume ramené à ce qui est réellement tenu (jamais augmenté automatiquement).
Aucune lecture du fichier ne peut empêcher le dashboard de se générer : tout problème donne un bilan vide (comportement inchangé)."""
import json
import math
from datetime import date, timedelta
from pathlib import Path

KEEP_DAYS = 70
QUALITY = {"aerobe", "vo2", "spec", "long", "trail", "brick"}
KEY_TE = 3.3                      # effet d'entraînement à partir duquel une séance compte comme séance clé (identique à planner.historique)
ROLE_DEPTH = {"principal": 1.0, "secondaire": .75, "intermédiaire": .5, "préparatoire": .3}
SERRE_DAYS = 7                    # fenêtre de travail minimale entre la fin de récupération d'une course et le début de l'affûtage de la suivante


# =============================================================================================
# 1. AFFÛTAGE
# =============================================================================================
def close_factor(gap):
    """Profondeur relative de l'affûtage quand une autre course importante est à `gap` jours : 1 à 4 semaines ou plus, 0,6 à 14 jours, 0,4 à une semaine ou moins.
    Deux courses proches ne se préparent pas comme deux courses isolées : un affûtage complet de chaque côté ferait perdre de la forme entre les deux."""
    return round(min(1.0, max(0.4, 0.4 + 0.6 * (gap - 7) / 21.0)), 3)


def taper_floor(eq, role, close=1.0):
    """Volume plancher la veille de la course (1 = volume normal) : plus la course est longue, plus la baisse est profonde ; plus la course est secondaire
    ou proche d'une autre course importante (close < 1), plus elle est légère."""
    base = .65 if eq < 8 else .58 if eq < 16 else .52 if eq < 30 else .47 if eq < 46 else .45
    return round(1 - (1 - base) * ROLE_DEPTH.get(role, 1.0) * min(1.0, max(0.0, close)), 3)


def taper_vol(o):
    """Volume relatif du jour pendant l'affûtage de la course o (jours restants o['days_left'], durée o['taper_d'])."""
    floor = taper_floor(o.get("eq") or 10.0, o.get("role"), o.get("close", 1.0))
    n, d = max(int(o.get("taper_d") or 1), 1), max(int(o.get("days_left") or 0), 1)
    if n <= 1: return floor
    start = round(1 - (1 - floor) * .3, 3)                                   # premier jour : seulement 30 % de la baisse totale
    f = min(1.0, max(0.0, (n - d) / (n - 1)))                                # avancement dans l'affûtage : 0 au premier jour, 1 la veille
    shape = (1 - math.exp(-2.2 * f)) / (1 - math.exp(-2.2))
    return round(start - (start - floor) * shape, 2)


def sharpen_days(o):
    """Jours (J-n) où un bref rappel d'intensité est conseillé pendant l'affûtage : on garde la vivacité à volume réduit.
    Un seul pour un affûtage court (J-3), deux pour un affûtage long (J-9 et J-3) ; jamais dans les 48 dernières heures."""
    n = int(o.get("taper_d") or 0)
    return set() if n <= 3 else {3} if n <= 9 else {9, 3}


# =============================================================================================
# 2. COURSES RAPPROCHÉES
# =============================================================================================
def relier(objs):
    """Relie les courses voisines (objs triés par date, déjà enrichis par planner.analyse_objectifs : rôle, taper_d, rec_d, days_left).
    - 'close' : profondeur relative de l'affûtage (1 = course isolée) selon l'écart avec la course importante voisine, avant ou après ;
    - borne l'affûtage d'une course par la place restante après la récupération de la précédente (priorité A ou B) ;
    - marque 'serre' si la fenêtre de travail entre les deux est inférieure à SERRE_DAYS ;
    - ajoute 'prev' / 'next' (voisin le plus proche, écart en jours) pour les explications."""
    seq = sorted((o for o in objs if o.get("days_left") is not None and o["days_left"] >= -30), key=lambda o: (o["date"], o.get("eq", 0)))
    for o in seq: o["serre"], o["prev"], o["next"], o["window"], o["close"] = False, None, None, None, 1.0
    main = [o for o in seq if o["prio"] != "C"]                              # seules les courses importantes comptent pour la proximité
    for a, b in zip(main, main[1:]):
        f = close_factor(b["days_left"] - a["days_left"])
        for o in (a, b):
            if f < o["close"]: o["close"] = f
    for o in main:                                                           # affûtage plus court quand une autre course importante est proche (au moins 2 jours)
        if o["close"] < 1.0 and o["taper_d"] > 2: o["taper_d"] = max(2, int(round(o["taper_d"] * (0.5 + 0.5 * o["close"]))))
    for a, b in zip(seq, seq[1:]):
        gap = b["days_left"] - a["days_left"]
        a["next"] = {"label": b["label"], "gap": gap}
        b["prev"] = {"label": a["label"], "gap": gap}
        if b["days_left"] < 0 or a["prio"] == "C": continue                 # course passée, ou préparatoire sans coût de récupération
        room = gap - a["rec_d"]                                              # jours disponibles après la récupération de a
        if b["prio"] != "C" and b["taper_d"] > max(room - 2, 1): b["taper_d"] = max(room - 2, 1)
        work = room - b["taper_d"]                                           # fenêtre de travail réelle entre a et b
        b["window"] = work
        if b["prio"] != "C" and work < SERRE_DAYS: b["serre"] = True
    return objs


def legs_guard(objs):
    """Ménage les jambes en musculation : (plafond de FAF, texte) ou None. Veille et avant-veille d'une course, et début de récupération après une course."""
    for o in objs:
        dl = o.get("days_left")
        if dl is None or o.get("prio") == "C": continue
        if 0 <= dl <= 3: return (0.55 if dl <= 1 else 0.7, f"{o['label']} dans {dl} jour(s) : jambes à ménager")
        if dl < 0 and -dl <= max(1, o.get("rec_d", 0) // 2 + 1) and o.get("eq", 0) >= 8:
            return (0.55, f"{o['label']} il y a {-dl} jour(s) : jambes en récupération")
    return None


# =============================================================================================
# 3. MÉMOIRE ET BILAN HEBDOMADAIRE
# =============================================================================================
def load(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def log_from_cards(cards, fam, adj=None):
    """Séances conseillées aujourd'hui : {discipline: {f: famille, m: minutes, a: coefficient de volume déjà appliqué}} (musculation et disciplines bloquées exclues).
    Le coefficient 'a' permet au bilan de comparer la durée faite au volume de base, sans réajuster deux fois la même chose."""
    out = {}
    for c in cards:
        d = c.get("id")
        if d == "strength" and c.get("rec") and not c.get("blocked") and c.get("title"):
            out[d] = {"t": c["title"]}                    # titre seul : « Cette semaine » affiche la séance proposée ce jour-là (ignoré par la revue)
            continue
        if d not in ("run", "bike", "swim") or not c.get("rec") or c.get("blocked"): continue
        m = c.get("_dur") or 0
        if m > 0:
            a = (adj or {}).get(d, 1.0)
            out[d] = {"f": fam.get(d, "z2"), "m": int(round(m))}
            if c.get("title"): out[d]["t"] = c["title"]
            if a < 1.0: out[d]["a"] = a
    return out


def merge(data, today, log):
    """Ajoute le plan du jour (la première version du jour est conservée : une relance tardive ne réécrit pas le plan du matin) et purge l'ancien."""
    out = dict(data or {})
    k = today.isoformat()
    if k not in out and log: out[k] = log
    keep = {}
    sem = out.get("semaine")                             # schéma figé de « Cette semaine » (extras.week_plan) : gardé jusqu'au dimanche
    if isinstance(sem, dict):
        try:
            if 0 <= (today - date.fromisoformat(sem.get("start", ""))).days <= 6: keep["semaine"] = sem
        except (TypeError, ValueError):
            pass
    for d, v in out.items():
        try:
            if 0 <= (today - date.fromisoformat(d)).days <= KEEP_DAYS and isinstance(v, dict): keep[d] = v
        except ValueError:
            continue
    return dict(sorted(keep.items()))


def save(path, data):
    p = Path(path)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    tmp.replace(p)


def _disc(a):
    s = a.get("s")
    return "run" if s in ("run", "trail") else s


def revue(mem, acts, T):
    """Compare les séances conseillées des 14 derniers jours à ce qui a été fait. Retourne un dict (toujours exploitable, même vide) :
      missed  {disc: famille} séance clé conseillée il y a 1 à 7 jours, non faite dans les 2 jours suivants et non compensée depuis ;
      repeat  {famille: nombre} séances clés de cette famille manquées sur 14 jours ;
      ratio   {disc: durée faite / durée conseillée (médiane)} sur les jours où la discipline a été pratiquée (au moins 3 séances) ;
      adj     {disc: coefficient de volume 0,8 à 1} : ramène le volume à ce qui est réellement tenu, sans jamais l'augmenter ;
      planned / key_planned / key_done : volumes de contrôle."""
    out = {"missed": {}, "repeat": {}, "ratio": {}, "adj": {}, "planned": 0, "key_planned": 0, "key_done": 0, "usable": False}
    if not mem: return out
    by = {}
    for a in acts:
        d = _disc(a)
        if d in ("run", "bike", "swim") and a.get("d"): by.setdefault((d, a["d"]), []).append(a)
    iso = lambda n: (T + timedelta(days=n)).isoformat()
    ratios = {"run": [], "bike": [], "swim": []}
    lastmiss = {}
    for k in sorted(mem):
        try:
            age = (T - date.fromisoformat(k)).days
        except ValueError:
            continue
        if not 1 <= age <= 14 or not isinstance(mem[k], dict): continue
        for d, e in mem[k].items():
            if d not in ratios or not isinstance(e, dict): continue
            f, pm = e.get("f"), e.get("m") or 0
            out["planned"] += 1
            day = by.get((d, k), [])
            dm = sum(x.get("m") or 0 for x in day)
            if dm > 0 and pm > 0: ratios[d].append(dm / (pm / min(1.0, max(.5, e.get("a") or 1.0))))      # durée faite / durée de base (avant ajustement)
            if f not in QUALITY: continue
            win = [x for dd in (0, 1, 2) for x in by.get((d, (date.fromisoformat(k) + timedelta(days=dd)).isoformat()), []) if x["d"] <= T.isoformat()]
            if age <= 7: out["key_planned"] += 1
            known = [x for x in win if x.get("te") is not None]
            done = (any((x.get("te") or 0) >= KEY_TE for x in known) if known else any((x.get("m") or 0) >= .6 * pm for x in win))
            if done:
                if age <= 7: out["key_done"] += 1
                continue
            if age <= 2 and not win: continue                                  # la fenêtre de rattrapage (2 jours) n'est pas terminée
            out["repeat"][f] = out["repeat"].get(f, 0) + 1
            if age <= 7: lastmiss[d] = (k, f)
    for d, (k, f) in lastmiss.items():                                        # compensée : une séance clé a eu lieu après l'oubli
        later = [x for dd in range(1, 16) if iso(-dd) > k for x in by.get((d, iso(-dd)), []) if (x.get("te") or 0) >= KEY_TE]
        if not later: out["missed"][d] = f
    for d, r in ratios.items():
        if len(r) >= 3:
            r = sorted(r); med = r[len(r) // 2] if len(r) % 2 else (r[len(r) // 2 - 1] + r[len(r) // 2]) / 2
            out["ratio"][d] = round(med, 2)
            out["adj"][d] = round(min(1.0, max(0.8, med)), 2)
    out["usable"] = out["planned"] >= 3
    return out
