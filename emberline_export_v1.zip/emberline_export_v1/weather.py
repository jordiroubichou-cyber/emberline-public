"""Météo prévue (Open-Meteo, sans clé) : récupérée pendant la synchro, transformée en conseils pour la séance du jour.

  fetch(out_dir, acts_json)  appelé par sync_garmin.py : écrit garmin/weather.json (position arrondie à 0,1°, ≈ 10 km).
  advice(wx, T, acts, cards) appelé par build_dashboard.py : allures corrigées par la chaleur, hydratation, vent, pluie, froid.

Jamais bloquant : sans réseau ou sans position, rien n'est écrit et le dashboard reste identique."""
import json
import statistics
import urllib.request
from datetime import date, timedelta
from pathlib import Path

API = ("https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&timezone=auto&forecast_days=3"
       "&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation_probability,precipitation"
       "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max")


def _loc(out_dir, cfg=None):
    """Position approximative : config.WEATHER_LOC (lat, lon) si présent, sinon médiane des départs des sorties récentes."""
    if cfg and len(cfg) == 2: return round(float(cfg[0]), 1), round(float(cfg[1]), 1)
    try:
        acts = json.loads((Path(out_dir) / "data.json").read_text(encoding="utf-8")).get("activities") or []
    except (OSError, ValueError):
        return None
    P = [(a.get("startLatitude"), a.get("startLongitude")) for a in sorted(acts, key=lambda a: a.get("startTimeLocal") or "", reverse=True)[:30]]
    P = [(float(la), float(lo)) for la, lo in P if isinstance(la, (int, float)) and isinstance(lo, (int, float)) and (la or lo)]
    if len(P) < 2: return None
    return round(statistics.median(p[0] for p in P), 1), round(statistics.median(p[1] for p in P), 1)


def fetch(out_dir, cfg=None, timeout=12):
    out_dir = Path(out_dir)
    loc = _loc(out_dir, cfg)
    if not loc: print("Météo : position inconnue, prévision ignorée."); return None
    try:
        with urllib.request.urlopen(API.format(lat=loc[0], lon=loc[1]), timeout=timeout) as r:
            raw = json.loads(r.read().decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        print(f"Météo ignorée cette fois ({type(e).__name__})"); return None
    H, D = raw.get("hourly") or {}, raw.get("daily") or {}
    days = {}
    for i, d in enumerate(D.get("time") or []):
        hrs = [j for j, t in enumerate(H.get("time") or []) if t.startswith(d)]
        hv = lambda k: [(H.get(k) or [None] * 999)[j] for j in hrs]
        days[d] = {"tmax": (D.get("temperature_2m_max") or [None])[i], "tmin": (D.get("temperature_2m_min") or [None])[i],
                   "rain": (D.get("precipitation_sum") or [None])[i], "wind": (D.get("wind_speed_10m_max") or [None])[i],
                   "h": [{"h": int((H["time"][j])[11:13]), "t": a, "hum": b, "w": c, "pp": e}
                         for j, a, b, c, e in zip(hrs, hv("temperature_2m"), hv("relative_humidity_2m"), hv("wind_speed_10m"), hv("precipitation_probability"))]}
    rec = {"loc": list(loc), "days": days}
    (out_dir / "weather.json").write_text(json.dumps(rec, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"Météo : prévision sur {len(days)} jours enregistrée.")
    return rec


def load(src):
    try: return json.loads((Path(src) / "weather.json").read_text(encoding="utf-8"))
    except (OSError, ValueError): return None


def _easy_pace(acts, T):
    """allure habituelle des footings (s/km) sur 6 semaines, pour traduire la correction en secondes"""
    a0 = (T - timedelta(days=42)).isoformat()
    P = [a["m"] * 60 / a["km"] for a in acts if a.get("s") in ("run", "trail") and a.get("d", "") >= a0 and a.get("km", 0) >= 4 and a.get("m")]
    return statistics.median(P) if P else 330


def heat_pct(t, hum):
    """ralentissement conseillé (%) à effort égal : ≈ 0,4 % par °C au-dessus de 15 °C, majoré quand l'air est humide"""
    if t is None: return 0
    return round(max(0.0, t - 15) * 0.4 * (1 + max(0, (hum or 50) - 60) / 100), 1)


def _window(day, lo=6, hi=21):
    """heure la plus favorable de la journée (fraîche, peu de pluie, peu de vent)"""
    H = [h for h in day.get("h") or [] if lo <= h["h"] <= hi and h.get("t") is not None]
    if not H: return None
    return min(H, key=lambda h: abs((h["t"] or 0) - 14) * 1.0 + (h.get("pp") or 0) / 15 + (h.get("w") or 0) / 12)


def sweat_rate(acts, T):
    """perte hydrique habituelle (L/h) mesurée par la montre sur 60 jours (course, trail, vélo), None si moins de 5 séances"""
    a0 = (T - timedelta(days=60)).isoformat()
    R = [((a.get("x") or {}).get("watch") or {}).get("water") / 1000 / (a["m"] / 60) for a in acts
         if a.get("s") in ("run", "trail", "bike") and a.get("d", "") >= a0 and (a.get("m") or 0) >= 30 and ((a.get("x") or {}).get("watch") or {}).get("water")]
    return round(statistics.median(R), 2) if len(R) >= 5 else None


def advice(wx, T, acts, sports, heat_acc=None):
    """Conseils pour aujourd'hui et demain selon les disciplines prévues (sports : {date: set(sports)}).
    heat_acc : acclimatation à la chaleur mesurée par Garmin (%), qui atténue la correction d'allure."""
    if not wx or not wx.get("days"): return None
    out = {"days": {}}
    ep = _easy_pace(acts, T)
    sw = sweat_rate(acts, T)
    for k in (0, 1):
        d = (T + timedelta(days=k)).isoformat(); day = wx["days"].get(d)
        if not day: continue
        S = sports.get(d) or set()
        w = _window(day)
        t = w["t"] if w else day.get("tmax"); hum = w.get("hum") if w else None
        tips = []
        if "run" in S or "trail" in S:
            pct = heat_pct(t, hum)
            if heat_acc and heat_acc >= 50: pct = round(pct * 0.7, 1)          # acclimaté : environ un tiers de pénalité en moins
            if pct >= 2:
                tips.append(f"Chaleur : ralentis d'environ {pct:.0f} % à effort égal (≈ +{round(ep * pct / 100)} s/km sur tes footings) et cours plutôt vers {w['h']} h." if w else
                            f"Chaleur : ralentis d'environ {pct:.0f} % à effort égal (≈ +{round(ep * pct / 100)} s/km).")
        if (S & {"run", "trail", "bike"}) and ((t or 0) >= 22 or (day.get("tmax") or 0) >= 25):   # hydratation, acclimaté ou non
                fr = lambda v: f"{v:.1f}".replace(".", ",")
                tips.append(f"Tu perds environ {fr(sw)} L/h d'après ta montre : bois {fr(max(0.4, sw * 0.6))} à {fr(max(0.5, sw * 0.8))} L par heure d'effort, avec du sel au-delà d'une heure." if sw else
                            "Bois 0,5 à 0,8 L par heure d'effort, avec du sel au-delà d'une heure.")
        if "bike" in S and (day.get("wind") or 0) >= 25:
            tips.append(f"Vent jusqu'à {round(day['wind'])} km/h : roule à la FC ou aux sensations plutôt qu'à la vitesse, et pars face au vent.")
        if (S & {"run", "trail", "bike"}) and (day.get("rain") or 0) >= 2:
            dry = [h["h"] for h in day.get("h") or [] if 6 <= h["h"] <= 21 and (h.get("pp") or 0) < 30]
            tips.append(f"Pluie prévue ({round(day['rain'])} mm)" + (f" : créneau plus sec vers {dry[0]} h." if dry else " : prévois une veste, ou le home trainer pour le vélo."))
        if (S & {"run", "trail", "bike"}) and day.get("tmin") is not None and day["tmin"] <= 3:
            tips.append(f"Froid ({round(day['tmin'])} °C au plus bas) : échauffement plus long et plusieurs couches fines.")
        out["days"][d] = {"tmax": day.get("tmax"), "tmin": day.get("tmin"), "rain": day.get("rain"), "wind": day.get("wind"),
                          "best_h": w["h"] if w else None, "tips": tips[:3]}
    return out
