"""Zones d'intensité, nature des séances et forme actuelle en course à pied (révision v5, audit du 13/11/2026).

Ce module ne dépend que de config.py : planner.py, analysis.py et preparation.py l'utilisent sans dépendance circulaire.

1. ANCRES CARDIAQUES : FC au seuil (FC seuil course, mesurée par l'athlète) et FC max. La FC seuil est l'ancre principale
   (zones de Friel en % de la FC seuil), plus fiable qu'un pourcentage de la FC max.
2. NATURE D'UNE SÉANCE : séance structurée (fractionné, tempo, seuil, côtes : reconnue au nom), sortie longue, séance dure
   non structurée (FC moyenne ≥ 95 % de la FC seuil), zone grise (90-94 %), facile. Le Training Effect n'est plus utilisé pour
   décider qu'une séance est une séance clé (indicateur propriétaire, aucun seuil validé).
3. RÉPARTITION DE L'INTENSITÉ sur 28 jours (modèle polarisé ou pyramidal : la majorité du temps sous le premier seuil,
   Seiler 2010, Stöggl et Sperlich 2015).
4. FORME ACTUELLE : relation linéaire FC-allure sur tes sorties régulières des 60 derniers jours (sans fractionné ni relief),
   lue à la FC seuil pour obtenir l'allure seuil ; à défaut, une course récente ; à défaut, la VO2max de la montre (±5 %).
5. PRÉDICTIONS : une seule méthode, en fourchette. Le passage du 10 km au semi et au marathon utilise un exposant de Riegel
   augmenté quand le volume hebdomadaire et la sortie longue sont faibles : Riegel est trop optimiste au marathon pour les
   coureurs amateurs et le kilométrage améliore la prédiction (Vickers et Vertosick 2016). Les coefficients sont un choix
   d'expert (niveau de preuve C), signalé comme tel dans le tableau de bord.
"""
import math
import re
from datetime import date, timedelta

try:
    import config as C
except Exception:                                                               # noqa: BLE001  (tests sans config)
    C = None

# ---------------------------------------------------------------------------------------------
# reconnaissance des séances structurées (nom de la séance)
# ---------------------------------------------------------------------------------------------
ANA_RE = re.compile(r"vma|vo2|pma|\b\d+\s*[\"”″'’]{1,2}\s*/\s*\d+|30\s*/\s*30|\b\d+\s*[x×]\s*\(|\b\d+\s*[x×]\s*(100|150|200|300|400|500|600)\s*m?\b"
                    r"|\b\d+\s*[x×]\s*\d+\s*(?:['’:]|s\b)|fractionn|interval|sprint", re.I)
PCT_VMA_RE = re.compile(r"\d+\s*%\s*vma", re.I)
TEMPO_RE = re.compile(r"tempo|seuil|\d+\s*[x×]\s*\d{4}|allure (cible|spécifique|specifique|marathon|semi|10|course)|progressi|pyramid"
                      r"|\d+\s*[x×]\s*\d+\s*km|côte|cote|sweet ?spot|\bss\b|\d+\s*[x×]\s*\d+\s*min|cruise|fartlek|enchaînement|brick", re.I)
LONG_RUN_MIN, LONG_RUN_KM = 85, 16
LONG_NAME_RE = re.compile(r"sortie longue|long run|\blongue\b", re.I)
LONG_BIKE_MIN, LONG_SWIM_KM = 150, 2.8


def anchors(ath=None):
    """FC seuil course, FC seuil vélo (≈ 6 bpm sous la course faute de mesure), FC max."""
    ath = ath if ath is not None else (getattr(C, "ATHLETE", {}) if C else {})
    hm = ath.get("hr_max") or 190
    lr = ath.get("lthr_run") or round(0.91 * hm)
    lb = ath.get("lthr_bike") or (lr - 6)
    return {"hr_max": hm, "lthr_run": lr, "lthr_bike": lb, "measured": bool(ath.get("lthr_run"))}


# zones de Friel (course) en % de la FC seuil : nom, borne basse, borne haute
FRIEL_RUN = [("Z1", "Récupération", 0.00, 0.85), ("Z2", "Endurance fondamentale", 0.85, 0.90), ("Z3", "Tempo", 0.90, 0.95),
             ("Z4", "Seuil", 0.95, 1.00), ("Z5a", "Au-dessus du seuil", 1.00, 1.03), ("Z5b", "VO2max", 1.03, 1.07)]
# zones vélo (Coggan, en % de la FC seuil vélo) : sans capteur de puissance, la FC et le ressenti remplacent les watts
COGGAN_BIKE_HR = [("Z1", 0.00, 0.68), ("Z2", 0.69, 0.83), ("Z3", 0.84, 0.94), ("Z4", 0.95, 1.05), ("Z5", 1.06, 1.12)]


def hr(lthr, f):
    return int(round(lthr * f))


def run_hr_zones(anc):
    L = anc["lthr_run"]
    out = []
    for z, n, a, b in FRIEL_RUN:
        lo = hr(L, a) if a else None
        out.append({"z": z, "n": n, "lo": lo, "hi": min(hr(L, b), anc["hr_max"])})
    return out


EASY_RE = re.compile(r"\bz ?[12]\b|endurance|footing|facile|souple|décrassage|lignes droites|technique", re.I)
STRONG_RE = re.compile(r"vma|vo2|pma|seuil|tempo|fractionn|allure (cible|spécifique|specifique|course)|\b\d+\s*[x×]\s*\(", re.I)


def structured(nm):
    """Séance de qualité structurée, reconnue au nom (Garmin ou titre de séance Emberline). Un nom de séance facile
    (« Z2 », « endurance », « footing »…) n'est structuré que s'il contient aussi un marqueur fort (VMA, seuil, tempo…)."""
    nm = nm or ""
    if STRONG_RE.search(nm): return True
    return bool((PCT_VMA_RE.search(nm) or ANA_RE.search(nm) or TEMPO_RE.search(nm)) and not EASY_RE.search(nm))


def _class_detail(a):
    """Nature d'une sortie d'après son détail (v6) : séries détectées -> 'struct' ; sinon temps par zone FC (si le signal est fiable).
    None si le détail manque ou n'est pas fiable : la classification par FC moyenne et par nom prend alors le relais."""
    x = a.get("x") or {}
    if not x: return None
    if (x.get("st") or {}).get("kind") == "intervals": return "struct"
    z = x.get("zones")
    if not z or sum(z) < 600 or (x.get("rel") or {}).get("hr", 0) < 0.85: return None
    tot = sum(z); hard = (z[3] + z[4]) / tot; grey = z[2] / tot
    m, km = a.get("m") or 0, a.get("km") or 0
    if (z[3] + z[4]) >= 1200 or hard >= 0.35: return "hard"
    if km >= LONG_RUN_KM or m >= LONG_RUN_MIN: return "long"
    if grey + hard >= 0.4: return "grey"
    return "easy"


def run_class(a, anc=None):
    """Nature d'une sortie de course : 'struct' (séance de qualité structurée), 'hard' (dure sans structure), 'grey' (zone grise),
    'long' (sortie longue en endurance), 'easy'. Les étapes de multisport comptent comme course dure."""
    anc = anc or anchors()
    if a.get("multi") or a.get("race"): return "hard"
    k = _class_detail(a)                                   # v6 : contenu réel de la séance (séries, zones FC), s'il est fiable
    if k: return k
    if structured(a.get("nm")): return "struct"
    h, m, km = a.get("hr"), a.get("m") or 0, a.get("km") or 0
    L = anc["lthr_run"]
    named_long = bool(LONG_NAME_RE.search(a.get("nm") or "")) and m >= 60
    if h:
        if h >= 0.95 * L and m >= 15: return "hard"
        if km >= LONG_RUN_KM or m >= LONG_RUN_MIN or named_long: return "long"
        if h >= 0.90 * L: return "grey"
        return "easy"
    te = a.get("te") or 0
    if km >= LONG_RUN_KM or m >= LONG_RUN_MIN or named_long: return "long"
    if te >= 4.2: return "hard"
    if te >= 3.5: return "grey"
    return "easy"


def key_kind(a, anc=None):
    """'intense' (séance clé d'intensité), 'long' (sortie longue) ou None, pour la course, le vélo et la natation."""
    anc = anc or anchors()
    s = a.get("s")
    if s in ("run", "trail"):
        k = run_class(a, anc)
        return "intense" if k in ("struct", "hard") else "long" if k == "long" else None
    nm, m, h, te = a.get("nm") or "", a.get("m") or 0, a.get("hr"), a.get("te") or 0
    x = a.get("x") or {}
    if s in ("bike", "swim") and x:
        z = x.get("zones")
        if (x.get("st") or {}).get("kind") == "intervals": return "intense"
        if s == "bike" and z and sum(z) >= 600 and (x.get("rel") or {}).get("hr", 0) >= 0.85 and (z[3] + z[4]) >= 900: return "intense"
        sw = x.get("swim") or {}
        if s == "swim" and sw.get("sets"):
            short = [q for q in sw["sets"] if q.get("d") and q["d"] <= 200]
            if len(short) >= 6 and sw.get("rest", 0) >= 60: return "intense"   # séries courtes avec récupérations : séance de qualité
    if s == "bike":
        if m >= LONG_BIKE_MIN or (LONG_NAME_RE.search(nm) and m >= 90): return "long"
        if structured(nm) or (h and h >= 0.92 * anc["lthr_bike"] and m >= 30) or (not h and te >= 4.2): return "intense"
        return None
    if s == "swim":
        if structured(nm) or re.search(r"css|\d+\s*x\s*\d+", nm, re.I) or te >= 4.0: return "intense"
        if (a.get("km") or 0) >= LONG_SWIM_KM: return "long"
    return None


def intensity_split(acts, T, anc=None, n=28):
    """Répartition du temps de course sur n jours : facile (Z1-Z2 et sortie longue), zone grise (Z3), dur (Z4+ et séances structurées,
    comptées à moitié dures : échauffement et récupérations sont faciles). Retourne aussi les sorties « faciles » trop rapides."""
    anc = anc or anchors()
    lo = (T - timedelta(days=n - 1)).isoformat(); hi_ = T.isoformat()
    e = g = h = 0.0
    fast_easy = []
    for a in acts:
        if a.get("s") not in ("run", "trail") or not (lo <= a.get("d", "") <= hi_) or not a.get("m"): continue
        x = a.get("x") or {}; z = x.get("zones")
        if z and sum(z) >= 600 and (x.get("rel") or {}).get("hr", 0) >= 0.85:      # v6 : temps réel par zone (plus juste que la FC moyenne)
            tz = sum(z); m = a["m"]
            e += m * (z[0] + z[1]) / tz; g += m * z[2] / tz; h += m * (z[3] + z[4]) / tz
            if (z[2] + z[3] + z[4]) / tz >= 0.4 and re.search(r"endurance|footing|facile|lent|base", a.get("nm") or "", re.I): fast_easy.append(a)
            continue
        k = run_class(a, anc); m = a["m"]
        if k in ("easy", "long"): e += m
        elif k == "grey": g += m
        elif k == "struct": e += 0.5 * m; h += 0.5 * m
        else: h += m
        if k in ("grey", "hard") and re.search(r"endurance|footing|facile|lent|base", a.get("nm") or "", re.I): fast_easy.append(a)
    tot = e + g + h
    if tot <= 0: return None
    return {"easy": e / tot, "grey": g / tot, "hard": h / tot, "min": tot, "fast_easy": fast_easy, "n_fast_easy": len(fast_easy)}


# ---------------------------------------------------------------------------------------------
# forme actuelle (course à pied)
# ---------------------------------------------------------------------------------------------
def hr_pace_model(acts, T, anc=None, n=60):
    """Régression linéaire allure (s/km) ~ FC sur les sorties régulières récentes (≥ 20 min, ≥ 4 km, < 12 m de D+ par km,
    sans séance structurée ni étape de multisport). None si moins de 6 sorties ou relation trop faible (|r| < 0,6)."""
    anc = anc or anchors()
    lo = (T - timedelta(days=n)).isoformat(); hi_ = T.isoformat()
    pts = []
    for a in acts:
        if a.get("s") != "run" or not (lo <= a.get("d", "") <= hi_) or a.get("multi") or a.get("race"): continue
        if not a.get("hr") or (a.get("km") or 0) < 4 or (a.get("m") or 0) < 20: continue
        if (a.get("el") or 0) / a["km"] >= 12 or structured(a.get("nm")): continue
        pts.append((a["hr"], a["m"] * 60 / a["km"]))
    if len(pts) < 6: return None
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sxx = sum((x - mx) ** 2 for x in xs); syy = sum((y - my) ** 2 for y in ys)
    if sxx <= 0 or syy <= 0: return None
    r = sum((x - mx) * (y - my) for x, y in pts) / math.sqrt(sxx * syy)
    slopes = sorted((y2 - y1) / (x2 - x1) for i_, (x1, y1) in enumerate(pts) for (x2, y2) in pts[i_ + 1:] if x2 != x1)
    if not slopes: return None
    b = slopes[len(slopes) // 2]                                         # pente de Theil-Sen : robuste aux sorties atypiques (chaleur, fatigue)
    if b >= 0 or r > -0.6: return None
    res = sorted(y - b * x for x, y in pts)
    a_med = res[len(res) // 2]                                           # sortie typique : sert aux allures d'entraînement
    a_fit = res[int(0.3 * (len(res) - 1))]                               # tiers le plus rapide : forme quand tu es frais (prédictions)
    return {"a": a_med, "a_fit": a_fit, "b": b, "n": len(pts), "r": r, "hr_lo": min(xs), "hr_hi": max(xs)}


def pace_at(model, h, fit=False):
    return None if not model else (model["a_fit"] if fit else model["a"]) + model["b"] * h          # s/km


DANIELS_K = (0.000104, 0.182258, -4.6)


def daniels_time(vdot, D_km):
    """Temps (s) sur D_km pour une VDOT (formules de Daniels et Gilbert)."""
    if not vdot: return None
    D = D_km * 1000
    lo, hi = 60.0, 60 * 60 * 8.0
    for _ in range(60):
        t = (lo + hi) / 2; tm = t / 60
        v = D / tm
        vo2 = -4.60 + 0.182258 * v + 0.000104 * v * v
        pct = 0.8 + 0.1894393 * math.exp(-0.012778 * tm) + 0.2989558 * math.exp(-0.1932605 * tm)
        if vo2 / pct > vdot: lo = t
        else: hi = t
    return (lo + hi) / 2


RACE_NAME_RE = re.compile(r"\b(10 ?km|10 ?k|semi|marathon|corrida|dossard|compet|race|cross|ekiden)\b", re.I)


def recent_race(acts, T, races=None, n=180):
    """Meilleure course récente (fiche d'activité nommée comme une course, ou résultat saisi dans config.RACES), ramenée au 10 km."""
    lo = (T - timedelta(days=n)).isoformat(); best = None
    cands = []
    for r in (races if races is not None else (getattr(C, "RACES", []) if C else [])):
        try:
            if lo <= str(r["date"]) <= T.isoformat() and 3 <= float(r["dist_km"]) <= 43 and float(r["time_s"]) > 0:
                cands.append((float(r["dist_km"]), float(r["time_s"]), f"{r.get('name') or 'course'} · {str(r['date'])[8:10]}/{str(r['date'])[5:7]}"))
        except (KeyError, TypeError, ValueError):
            continue
    for a in acts:
        if a.get("s") != "run" or a.get("multi") or not (lo <= a.get("d", "") <= T.isoformat()): continue
        nm = a.get("nm") or ""
        if not RACE_NAME_RE.search(nm) or structured(nm) or not (3 <= (a.get("km") or 0) <= 43) or not a.get("m"): continue
        cands.append((a["km"], a["m"] * 60, f"{nm} · {a['d'][8:]}/{a['d'][5:7]}"))
    try:                                                   # v6 : efforts « course » mesurés dans les séances détaillées
        import detail_analysis as _DA
        for r in _DA.time_trials(acts, T, n):
            cands.append((r["dist_km"], r["time_s"], f"{r['name']} · {r['date'][8:10]}/{r['date'][5:7]}"))
    except Exception:  # noqa: BLE001
        pass
    for km, t, lab in cands:
        t10 = t * (10.0 / km) ** 1.06
        if best is None or t10 < best[0]: best = (t10, lab)
    return best


def fitness(acts, T, ath=None, vo2=None):
    """Forme actuelle : temps de référence sur 10 km, allure seuil, source et incertitude."""
    anc = anchors(ath)
    model = hr_pace_model(acts, T, anc)
    thr = pace_at(model, anc["lthr_run"], fit=True) if model else None
    race = recent_race(acts, T)
    if race:
        t10, src, unc, lab = race[0], "course", 0.025, f"course récente ({race[1]})"
        if thr is None: thr = t10 / 10 / 0.97
    elif model and anc["measured"]:
        t10, src, unc = thr * 0.97 * 10, "fc_allure", 0.04
        lab = f"relation FC-allure sur {model['n']} sorties régulières (r = {model['r']:.2f}) lue à ta FC seuil de {anc['lthr_run']} bpm".replace(".", ",")
    elif model:
        t10, src, unc = thr * 0.97 * 10, "fc_allure", 0.06
        lab = f"relation FC-allure sur {model['n']} sorties, FC seuil estimée à {anc['lthr_run']} bpm (à confirmer)"
    elif vo2:
        t10, src, unc = daniels_time(vo2, 10.0) / 0.95, "vo2_montre", 0.06
        lab = "VO2max de la montre, corrigée de 5 % (estimation peu précise)"
        thr = t10 / 10 / 0.97
    else:
        return {"t10": None, "src": None, "unc": None, "label": "pas assez de données", "thr": None, "model": None, "anc": anc}
    return {"t10": t10, "src": src, "unc": unc, "label": lab, "thr": thr, "model": model, "anc": anc}


def volume_markers(acts, T):
    """Volume hebdomadaire moyen (4 semaines) et plus longue sortie (42 jours) en course à pied."""
    lo28 = (T - timedelta(days=27)).isoformat(); lo42 = (T - timedelta(days=41)).isoformat(); t = T.isoformat()
    runs = [a for a in acts if a.get("s") in ("run", "trail") and a.get("d", "") <= t]
    km4 = sum(a.get("km") or 0 for a in runs if a["d"] >= lo28) / 4
    long42 = max([a.get("km") or 0 for a in runs if a["d"] >= lo42] or [0])
    return km4, long42


def riegel_k(D_km, km4, long42):
    """Exposant de Riegel selon la distance et l'entraînement (choix d'expert, voir l'en-tête)."""
    if D_km <= 12: return 1.06
    dv = max(0.0, min(1.0, 1 - km4 / 60.0)); dl = max(0.0, min(1.0, 1 - long42 / (30.0 if D_km > 30 else 18.0)))
    if D_km > 30: return 1.06 + 0.05 * dv + 0.03 * dl
    return 1.06 + 0.02 * dv + 0.01 * dl


def predict(fit, D_km, km4, long42):
    """Temps estimé (s) et fourchette sur D_km à partir de la forme actuelle."""
    if not fit or not fit.get("t10"): return None
    k = riegel_k(D_km, km4, long42)
    t = fit["t10"] * (D_km / 10.0) ** k
    u = fit["unc"] + (0.02 if D_km > 30 else 0.01 if D_km > 12 else 0.0)
    return {"t": t, "lo": t * (1 - u), "hi": t * (1 + u), "k": k}


def last_longest(acts, T, disc="run", n=30):
    """Plus longue sortie (km pour la course, min pour le vélo) des n derniers jours : garde-fou de progression (+10 % au plus,
    Frandsen et al. 2025, 5 205 coureurs : au-delà, risque de blessure de surcharge ×1,64)."""
    lo = (T - timedelta(days=n)).isoformat(); t = T.isoformat()
    if disc == "run":
        return max([a.get("km") or 0 for a in acts if a.get("s") in ("run", "trail") and lo <= a.get("d", "") < t and not a.get("multi")] or [0])      # étape de triathlon exclue : pas une référence d'entraînement
    if disc == "bike":
        return max([a.get("m") or 0 for a in acts if a.get("s") == "bike" and lo <= a.get("d", "") < t] or [0])
    return 0


def run_paces(fit):
    """Allures de course (min/km) déduites de la forme actuelle : facile, marathon, seuil, 10 km, VMA."""
    if not fit or not fit.get("thr"): return None
    thr = fit["thr"] / 60.0
    m = fit.get("model"); anc = fit["anc"]
    if m:
        e_hi = pace_at(m, 0.85 * anc["lthr_run"]) / 60.0        # haut de l'endurance fondamentale (Z1/Z2)
        e_lo = pace_at(m, 0.89 * anc["lthr_run"]) / 60.0
        easy = (min(e_lo, e_hi), max(e_lo, e_hi) + 0.25)
    else:
        easy = (thr * 1.20, thr * 1.32)
    return {"easy": easy, "mar": thr * 1.06, "semi": thr * 1.016, "thr": thr, "p10": thr * 0.97, "vma": thr * 0.90}


def swim_css(acts, T, fallback=90, n=120):
    """CSS estimée (s/100 m) : médiane des 5 allures moyennes les plus rapides en piscine (≥ 1 500 m, 120 derniers jours).
    Les allures moyennes incluent les récupérations : l'estimation reste prudente. Secours : valeur de config.py."""
    lo = (T - timedelta(days=n)).isoformat(); t = T.isoformat()
    pcs = sorted(a["m"] * 60 / (a["km"] * 10) for a in acts if a.get("s") == "swim" and lo <= a.get("d", "") <= t and (a.get("km") or 0) >= 1.5
                 and a.get("m") and not re.search(r"eau libre|open", a.get("nm") or "", re.I) and not a.get("multi"))
    if len(pcs) < 3:
        return {"css": fallback, "src": "config", "n": len(pcs)}
    top = pcs[:5]
    est = int(round(top[len(top) // 2]))
    return {"css": est, "src": "nages", "n": len(pcs)}
