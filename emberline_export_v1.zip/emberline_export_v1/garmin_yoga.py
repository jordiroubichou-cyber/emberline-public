#!/usr/bin/env python3
"""Ajoute une activité « Yoga » de 15 min sur Garmin Connect quand une séance de mobilité Emberline est terminée.
Lancé par le workflow « Mobilité vers Garmin » (déclenché par le dashboard à la fin du lecteur de séance).

Usage : python garmin_yoga.py --name "Emberline · Mobilité course" --start 2026-11-08T18:12:00 --dur 900 \
                              --tz Europe/Paris --desc "…" [--dry-run]
L'activité est créée comme une activité manuelle (type yoga, privée) ; une même séance n'est jamais ajoutée deux fois."""
import argparse, re, sys
from datetime import datetime, timedelta

from garmin_export import api, log


def payload(name, start, dur, tz, desc):
    return {
        "activityTypeDTO": {"typeKey": "yoga"},
        "accessControlRuleDTO": {"typeId": 2, "typeKey": "private"},
        "timeZoneUnitDTO": {"unitKey": tz},
        "activityName": name,
        "description": desc,
        "metadataDTO": {"autoCalcCalories": True},
        "summaryDTO": {"startTimeLocal": start.strftime("%Y-%m-%dT%H:%M:%S.000"), "distance": 0.0, "duration": float(dur)},
    }


def already_there(client, name, start):
    """Vrai si une activité du même nom existe déjà à ±20 min (double envoi)."""
    day = start.date().isoformat()
    try:
        lst = api(client, f"/activitylist-service/activities/search/activities?startDate={day}&endDate={day}&start=0&limit=40") or []
    except Exception as e:
        log(f"Vérification des doublons impossible ({type(e).__name__}) : on continue.")
        return False
    for a in lst if isinstance(lst, list) else []:
        if str(a.get("activityName", "")) != name:
            continue
        try:
            t = datetime.fromisoformat(str(a.get("startTimeLocal", ""))[:19])
        except ValueError:
            continue
        if abs((t - start).total_seconds()) < 20 * 60:
            return True
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--start", required=True, help="heure locale de début, AAAA-MM-JJTHH:MM(:SS)")
    ap.add_argument("--dur", default="900", help="durée en secondes")
    ap.add_argument("--tz", default="Europe/Paris")
    ap.add_argument("--desc", default="")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    if not re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d(:\d\d)?", a.start):
        raise SystemExit("Heure de début invalide (format AAAA-MM-JJTHH:MM:SS).")
    start = datetime.fromisoformat(a.start)
    dur = max(60, min(4 * 3600, int(float(a.dur or 900))))
    tz = a.tz if re.fullmatch(r"[A-Za-z_]+(/[A-Za-z_+\-0-9]+)*", a.tz or "") else "Europe/Paris"
    name = (a.name or "Emberline · Mobilité").strip()[:90]
    desc = (a.desc or "").strip()[:1800]
    body = payload(name, start, dur, tz, desc)
    log(f"**{name}** · yoga · {dur // 60} min · début {start:%d/%m/%Y %H:%M} ({tz})")
    if desc:
        log(desc)
    if a.dry_run:
        log("Mode test : rien n'a été envoyé.")
        return
    from sync_garmin import get_client
    client = get_client()
    if already_there(client, name, start):
        log("✓ Cette séance est déjà enregistrée sur Garmin Connect : rien à faire.")
        return
    try:
        res = api(client, "/activity-service/activity", method="POST", payload=body) or {}
    except Exception as e:
        r = getattr(e, "response", None) or getattr(getattr(e, "error", None), "response", None)
        txt = ""
        if r is not None:
            try: txt = r.text[:300]
            except Exception: pass
        log(f"✗ Garmin a refusé l'activité : {type(e).__name__} : {e} {txt}")
        sys.exit(1)
    aid = res.get("activityId") if isinstance(res, dict) else None
    if not aid:
        log(f"✗ Réponse inattendue de Garmin : {str(res)[:200]}")
        sys.exit(1)
    # le nom et la description sont parfois ignorés à la création : on les réapplique
    try:
        api(client, f"/activity-service/activity/{aid}", method="PUT",
            payload={"activityId": aid, "activityName": name, "description": desc})
    except Exception:
        pass
    log(f"✓ Activité yoga ajoutée sur Garmin Connect (id {aid}) : {name}, {dur // 60} min.")


if __name__ == "__main__":
    main()
