"""Musculation et douleurs : adaptations propres à la salle, exercice par exercice (stdlib uniquement, déterministe).

Principe : une douleur n'est mentionnée dans une séance de musculation que si au moins un de ses exercices sollicite la zone.
Chaque partie qui la mentionne propose une adaptation cohérente avec cette partie :
  - échauffement : activation / mobilité de la zone (aucune autre discipline n'est citée) ;
  - corps de la séance : consigne d'exécution par exercice concerné, puis exercice de remplacement si la douleur dépasse 3/10 ;
  - progression : règle de montée en charge.
Entrée : le bilan de pain.evaluer (pn["actives"]) ; sortie : annotations ajoutées aux séances (clé "pain") et aux exercices (clé "pain").
"""
import re

RANK = {"light": 1, "moderate": 2, "acute": 3}
LEVEL_FR = {"light": "gérable", "moderate": "modérée", "acute": "aiguë"}

SQ = r"^(?!.*mollet)(?=.*(squat|presse|hack|fentes?|bulgarian|step-up))"      # squats, presses, fentes, montées sur banc (pas les mollets à la presse)
OHP = r"^développé.*(militaire|arnold|vertical|épaules)"

# zone -> liste de règles (regex sur le nom, consigne d'exécution, exercice de remplacement, filtre de pathologie ou None)
RULES = {
    "genou": [
        (SQ, "Amplitude limitée à 60-70° de flexion, charge -20 %, descente lente sur 3 s, genou dans l'axe du pied.", "Hip Thrust barre ou Leg Curl couché (peu de flexion de genou sous charge)", None),
        (r"leg extension", "Amplitude de 90° à 40° seulement (sans verrouiller en fin d'extension), charge légère, tempo lent.", "Leg Curl assis", None),
        (r"leg curl|nordic|glute ham", "Amplitude sans gêne derrière le genou, charge modérée, tempo lent.", "Hip Thrust à la machine ou Smith machine", None),
    ],
    "hanche": [
        (r"adducteur", "Charge légère, amplitude courte et progressive, aucune douleur à l'aine.", "Gainage latéral lesté (stabilité du bassin sans cisaillement)", None),
        (SQ + r"|goblet", "Pieds à l'écartement le plus confortable, profondeur arrêtée avant le pincement de hanche, pas de rebond en bas.", "Leg Extension ou Presse à cuisses horizontale en amplitude réduite", None),
        (r"hip thrust|soulevé|good morning", "Amplitude confortable, bassin neutre, sans forcer l'extension complète en haut.", "Leg Curl couché", None),
    ],
    "cuisse": [
        (r"leg curl|nordic|glute ham|soulevé|good morning", "Charge -30 %, amplitude sans étirement douloureux, tempo lent, aucune série à l'échec.", "Hip Thrust à la machine ou Smith machine (tension en raccourcissement)", "post"),
        (r"hip thrust", "Charge modérée, pause d'une seconde en haut sans contracter à fond.", "Presse à cuisses horizontale, pieds hauts", "post"),
        (SQ + r"|leg extension|goblet", "Charge -20 %, amplitude sans gêne, tempo lent, pas d'à-coup en bas du mouvement.", "Leg Curl couché ou Hip Thrust barre", "ant"),
    ],
    "tibia": [
        (r"mollets|step-up", "Élévations lentes (3 s à la descente), charge modérée, appui complet du pied ; arrêt si la douleur tibiale dépasse 3/10.", "Mollets assis (moins de contrainte sur le tibia)", None),
    ],
    "mollet": [
        (r"mollets", "Charge -30 %, amplitude sans douleur, tempo lent, sans étirement forcé en bas.", "Mollets assis (soléaire, moins de contrainte sur le gastrocnémien)", None),
        (r"leg curl|nordic|glute ham|step-up|fentes marchées", "Charge modérée, amplitude sans tiraillement du mollet.", "Hip Thrust à la machine ou Smith machine", None),
    ],
    "cheville": [
        (r"mollets", "Élévations de talons lentes (3 s à la descente), charge -30 %, arrêt si la cheville ou le tendon d'Achille dépasse 3/10.", "Mollets assis (moins de tension sur le tendon d'Achille)", None),
        (r"^(?!.*mollet)(?=.*(squat|presse|hack))", "Talons bien appuyés, mobilité de cheville avant la série, charge -20 %, profondeur limitée si la cheville bloque.", "Presse à cuisses horizontale (cheville fixée)", None),
        (r"step-up|fentes|bulgarian", "Appui stable et à plat, montée sans rebond, genou et cheville dans l'axe.", "Presse à cuisses unilatérale", None),
    ],
    "pied": [
        (r"mollets|fentes|step-up|bulgarian|farmer", "Charge -20 %, pied entier posé à plat, chaussures stables ; évite les appuis sur l'avant-pied sous charge lourde.", "Presse à cuisses horizontale (pied entier posé) ou Mollets assis", None),
    ],
    "epaule": [
        (r"dips", "Descente limitée à 90° de coude, épaules basses et en arrière, sans balancer.", "Pushdown triceps à la corde", None),
        (OHP, "Amplitude arrêtée avant la douleur, coudes à 45° devant le tronc (plan de l'omoplate), charge -20 %.", "Développé couché prise neutre aux haltères (sans passage au-dessus de la tête)", None),
        (r"élévations latérales", "Montée jusqu'à la hauteur des épaules maximum, coudes légèrement fléchis, charge légère.", "Face Pull à la poulie haute (coiffe, sans élévation)", None),
        (r"^développé", "Coudes à 45° du tronc, descente arrêtée avant l'étirement douloureux, prise neutre si possible, charge -20 %.", "Développé couché prise neutre aux haltères en amplitude réduite", None),
        (r"[eé]cart|chest fly|pec deck", "Amplitude arrêtée avant l'étirement douloureux, coudes fléchis, charge légère.", "Développé couché prise neutre aux haltères en amplitude réduite", None),
        (r"tirage vertical|traction|pull-over|suspension", "Prise neutre ou plus étroite, épaules basses, amplitude confortable, pas de suspension passive complète.", "Tirage horizontal poulie basse prise neutre", None),
        (r"rowing|tirage horizontal", "Coudes près du corps, tirage arrêté avant la rotation d'épaule, charge -20 %.", "Tirage horizontal machine convergente (appui poitrine)", None),
        (r"face pull", "Charge très légère, rotation externe lente, coudes à hauteur d'épaule au maximum.", "Rowing Seal / Rowing sur banc incliné aux haltères, coudes serrés", None),
    ],
    "coude": [
        (r"barre au front|skullcrusher", "Charge -30 %, coudes fixes, descente lente sur 3 s, amplitude sans douleur.", "Pushdown triceps à la corde (prise neutre)", None),
        (r"extension triceps|pushdown", "Charge -30 %, prise neutre ou corde, coudes fixes, excentrique lent.", "Extension triceps unilatérale à la poulie, charge légère", None),
        (r"curl marteau", "Charge -30 %, coude contre le corps, excentrique lent sur 3 s.", "Curl pupitre à la machine (trajectoire guidée)", None),
        (r"curl", "Barre EZ ou prise un peu plus large, charge -30 %, sans balancer, excentrique lent.", "Curl marteau haltères (prise neutre, plus doux pour le coude)", None),
        (r"dips", "Descente limitée à 90° de coude, sans charge additionnelle.", "Chest Fly à la machine / Pec Deck", None),
        (r"traction|suspension", "Prise neutre, évite la suspension coude tendu, descente contrôlée.", "Tirage vertical prise neutre serrée", None),
    ],
    "poignet": [
        (r"wrist|poignet", "Charge très légère, amplitude sans douleur, tempo lent ; arrêt à 3/10.", "Curl marteau poulie basse avec corde (avant-bras en prise neutre)", None),
        (r"farmer|pinch|suspension|shrug", "Sangles pour soulager la prise, charge -30 %, poignet aligné sur l'avant-bras.", "Tirage vertical prise neutre serrée avec sangles", None),
        (r"curl", "Barre EZ ou haltères en prise neutre, poignet aligné sur l'avant-bras, charge -30 %.", "Curl marteau poulie basse avec corde", None),
        (r"^développé|dips|pushdown|extension triceps|barre au front", "Poignet empilé sur l'avant-bras (jamais cassé en arrière), bandes de poignet, prise neutre si possible.", "Développé couché convergente assis (prise neutre guidée)", None),
        (r"rowing|tirage|traction", "Sangles de tirage, prise neutre, poignet aligné sur l'avant-bras.", "Tirage horizontal machine convergente (poignets neutres)", None),
    ],
    "cervicales": [
        (r"shrug", "Charge modérée, épaules vers le haut sans les enrouler, nuque neutre.", "Face Pull à la poulie haute", None),
        (OHP, "Nuque neutre, regard devant, menton légèrement rentré, charge -20 %.", "Développé incliné haltères prise neutre", None),
        (r"squat barre|back squat|front squat|low bar|soulevé|farmer", "Nuque neutre, regard devant, charge -20 %, épaules loin des oreilles.", "Presse à cuisses horizontale", None),
        (r"traction|tirage vertical|face pull", "Nuque neutre, épaules basses, tirage sans projeter la tête en avant.", "Tirage horizontal poulie basse prise neutre", None),
    ],
    "dorsales": [
        (r"rowing barre|rowing t-bar|rowing buste|rowing haltère unilatéral", "Buste soutenu ou gainé, amplitude sans douleur intercostale, respiration contrôlée.", "Rowing Seal / Rowing sur banc incliné aux haltères (buste appuyé)", None),
        (r"squat barre|back squat|front squat|low bar|soulevé|good morning", "Dos neutre, gainage abdominal avant chaque série, charge -20 %, respiration contrôlée.", "Presse à cuisses horizontale (dos soutenu)", None),
        (r"^développé couché barre|^développé militaire", "Omoplates serrées, respiration contrôlée, descente arrêtée avant la douleur.", "Développé couché prise neutre aux haltères", None),
    ],
    "lombaires": [
        (r"back squat|low bar|squat barre|front squat \(squat avant|soulevé de terre", "Pas de charge lourde sur le dos : charge -30 %, dos neutre, gainage avant chaque série ; arrêt à 3/10.", "Presse à cuisses horizontale (dos soutenu)", None),
        (r"good morning", "Charge très légère, dos neutre, amplitude arrêtée avant la gêne lombaire.", "Leg Curl couché", None),
        (r"rowing barre|rowing t-bar|rowing buste|rowing haltère unilatéral", "Buste soutenu : appui poitrine ou banc incliné, dos neutre, charge -20 %.", "Rowing Seal / Rowing sur banc incliné aux haltères (buste appuyé)", None),
        (r"militaire debout|militaire strict", "Abdominaux et fessiers serrés, sans cambrer, charge -20 %.", "Développé militaire aux haltères assis (dos soutenu)", None),
        (r"hip thrust", "Bassin en légère rétroversion en haut, sans cambrer, menton rentré.", "Presse à cuisses horizontale, pieds hauts", None),
        (r"ab wheel|gainage dynamique", "Amplitude courte, bassin verrouillé, aucune cambrure.", "Gainage latéral lesté, charge légère", None),
        (r"fentes|bulgarian|farmer", "Buste droit, gainage serré, charge -20 %, pas de cambrure en fin de mouvement.", "Presse à cuisses unilatérale", None),
    ],
}
_COMP = {z: [(re.compile(rx, re.I), a, alt, f) for rx, a, alt, f in L] for z, L in RULES.items()}

# Échauffement ciblé, par protocole de pathologie : activation et mobilité de la zone, rien d'autre.
MW = {
    "itbs": "2 × 12 pas latéraux à l'élastique et 2 × 10 clamshell par côté pour réveiller le fessier moyen.",
    "fempat": "2 × 10 squats partiels contrôlés (amplitude sans douleur) et activation des fessiers.",
    "rotulien": "5 min de cardio très léger (rameur ou ergomètre), puis isométrie du quadriceps : 5 × 30-45 s, genou à 60°.",
    "pattedoie": "Mobilité du genou, puis activation des ischio-jambiers et des adducteurs : 2 × 10 ponts fessiers.",
    "periostite": "5 min de marche rapide ou de cardio léger, mobilité de cheville, 2 × 15 élévations de pointes de pied.",
    "fracture": "Aucune charge sur le tibia : mobilité douce de cheville et de hanche uniquement.",
    "achille": "Mobilité de cheville, puis 2 × 15 élévations de talons lentes (3 s à la descente).",
    "entorse": "Mobilité de cheville sans douleur et proprioception : appui sur une jambe 3 × 30 s.",
    "peroniers": "Activation des péroniers à l'élastique (2 × 15) et appui sur une jambe pour la proprioception.",
    "fascite": "Étirement du mollet et de la voûte plantaire, mobilisation de la plante du pied avec une balle.",
    "metatarsalgie": "Mobilité des orteils et du pied, puis 2 × 10 élévations de talons lentes à deux pieds.",
    "coiffe": "2 × 15 rotations externes à l'élastique léger, rétractions scapulaires et cercles de bras amples et lents.",
    "coude": "Mobilité du coude et du poignet, étirements doux des fléchisseurs et des extenseurs, puis 1 série d'échauffement très légère.",
    "poignet": "Mobilité du poignet, glissements nerveux doux, puis 1 série d'échauffement très légère en prise neutre.",
    "muscle": "Montée en charge très progressive et activation du muscle concerné : 2 séries légères à 40 % puis 60 % de la charge de travail.",
    "adducteurs": "Activation des adducteurs et du transverse, mobilité de hanche : 2 × 10 ponts fessiers, squeeze ballon 3 × 20 s.",
    "fessier": "2 × 12 ponts fessiers et pas latéraux à l'élastique pour activer le fessier moyen.",
    "rachis": "Mobilité douce du rachis (chat-vache, rotations thoraciques) et respiration profonde.",
    "lombalgie": "Mobilité du bassin et de la colonne, respiration abdominale, puis 2 × 8 'bird dog' lents.",
    "defaut": "Mobilité douce de la zone et 1 à 2 séries d'échauffement très légères avant la charge de travail.",
}


def zone_levels(pn):
    """{région: {"lv", "int", "z", "proto", "patho"}} : pour chaque zone, la douleur active la plus sévère."""
    out = {}
    for a in (pn or {}).get("actives", []):
        r = a.get("region")
        if r not in RULES or a.get("level") not in RANK: continue
        cur = out.get(r)
        if cur and (RANK[cur["lv"]], cur["int"]) >= (RANK[a["level"]], a["intensity"]): continue
        out[r] = {"lv": a["level"], "int": a["intensity"], "z": zone_name(r), "proto": a.get("proto") or "defaut", "patho": a.get("patho") or ""}
    return out


def zone_name(region):
    import pain
    return pain.REGIONS[region][0].split(" / ")[0].lower()


def _muscle_side(zone):
    """Cuisse : ischio-jambiers (post), quadriceps (ant) ou les deux (None) selon la pathologie déclarée."""
    return "post" if zone["patho"] == "ischio" else "ant" if zone["patho"] == "quadriceps" else None


def exercise_pain(name, zones):
    """-> {"lv", "txt", "z"} ou None : consigne si l'exercice sollicite une zone douloureuse."""
    hits = []
    for r, zone in zones.items():
        side = _muscle_side(zone) if r == "cuisse" else None
        for rx, adapt, alt, only in _COMP[r]:
            if not rx.search(name): continue
            if only and side and only != side: continue
            hits.append((RANK[zone["lv"]], zone, adapt, alt))
            break
    if not hits: return None
    hits.sort(key=lambda h: -h[0])
    parts, worst = [], hits[0][1]["lv"]
    for _, zone, adapt, alt in hits[:2]:
        lead = zone["z"].capitalize() if len(hits) > 1 else ""
        if zone["lv"] == "acute": t = f"Zone au repos strict : remplace par {alt}."
        elif zone["lv"] == "moderate": t = f"{adapt} Si la douleur dépasse 3/10 : {alt}."
        else: t = adapt
        parts.append((lead + " : " if lead else "") + t)
    return {"lv": worst, "txt": " ".join(parts), "z": "/".join(h[1]["z"] for h in hits[:2])}


def session_pain(s, zones):
    """Annotation d'une séance : renvoie None si aucun exercice ne sollicite une zone douloureuse."""
    hit = 0
    touched = {}
    for e in s["ex"]:
        p = exercise_pain(e["name"], zones)
        if p:
            e["pain"] = p; hit += 1
            for r, z in zones.items():
                if z["z"] in p["z"].split("/"): touched[r] = z
    if not hit: return None
    ordered = sorted(touched.values(), key=lambda z: (-RANK[z["lv"]], -z["int"], z["z"]))
    warm = [f"{z['z'].capitalize()} : {MW.get(z['proto'], MW['defaut'])}" for z in ordered]
    zl = " · ".join(f"{z['z']} {z['int']}/10" for z in ordered).capitalize()
    worst = ordered[0]["lv"]
    msg = f"{zl} : {hit} exercice{'s' if hit > 1 else ''} adapté{'s' if hit > 1 else ''} dans cette séance, échauffement ciblé ajouté."
    if worst == "acute": prog = "Aucune progression : les exercices marqués 🩹 sont remplacés tant que la zone est au repos strict."
    elif worst == "moderate": prog = "Pas d'augmentation de charge sur les exercices marqués 🩹 tant que la douleur dépasse 3/10 ; ajoute 30 s de repos entre les séries concernées."
    else: prog = "Monte la charge des exercices marqués 🩹 seulement si la douleur reste ≤ 3/10 pendant la séance et le lendemain ; sinon garde la même charge."
    return {"zones": ordered and [z["z"] for z in ordered], "lv": worst, "n": hit, "msg": msg, "warm": warm, "prog": prog}


def annotate(m, pn):
    """Ajoute à toutes les séances (30) leur annotation douleur. Retourne le texte de rappel de la séance proposée ("" si aucune)."""
    zones = zone_levels(pn)
    if not zones: return ""
    for t in m["types"].values():
        for s in t["sessions"]:
            s["pain"] = session_pain(s, zones)
    d = m["types"][m["default"]]["sessions"][m["types"][m["default"]]["today_n"] - 1]
    return (d.get("pain") or {}).get("msg", "")
