"""detail_analysis.py — lecture et analyse des données détaillées de chaque séance (Emberline v6).

Entrée : le détail normalisé de garmin_details (tours, intervalles typés, longueurs, séries de musculation, séries
temporelles, zones, météo, matériel) et la séance prévue (fichier Garmin de garmin/workouts/<date>/).
Sortie : pour chaque séance, un résumé compact « x » (structure réelle, qualité des séries, efficacité, dénivelé,
natation, musculation, fiabilité des capteurs) et, s'il existe une séance prévue, un verdict prévu / réalisé.
Sur l'historique : tendances (efficacité aérobie, découplage, CSS, tonnage, D+), meilleurs efforts, signaux de fatigue,
progression par famille de séance, charges de musculation, kilométrage du matériel.

Principe : chaque métrique n'est calculée que si la donnée est fiable (durée minimale, signal FC propre) ; sinon elle est
absente, jamais inventée. Toutes les fonctions sont protégées : une donnée inattendue renvoie None, pas d'exception.
"""
import json
import math
import re
from datetime import date, timedelta
from pathlib import Path

# ------------------------------------------------------------------------------------------------- utilitaires
def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def std(xs):
    xs = [x for x in xs if x is not None]
    if len(xs) < 2: return None
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def cv(xs):
    m, s = mean(xs), std(xs)
    return None if not m or s is None else s / m * 100


def nz(x, default=99.0):
    """valeur ou défaut si absente (attention : 0 est une vraie valeur)"""
    return default if x is None else x


def r1(x, n=1): return None if x is None else round(x, n)


def pace_s(v):
    """vitesse (m/s) -> allure (s/km)"""
    return None if not v or v <= 0 else 1000 / v


def fmt_pace(sk):
    if not sk: return "—"
    sk = int(round(sk)); return f"{sk // 60}'{sk % 60:02d}"


def fmt_dur(s):
    if s is None: return "—"
    s = int(round(s))
    if s >= 3600: return f"{s // 3600} h {s % 3600 // 60:02d}"
    if s >= 60: return f"{s // 60} min" + (f" {s % 60:02d}" if s % 60 and s < 600 else "")
    return f"{s} s"


def fmt_dist(m):
    if m is None: return "—"
    if m >= 1000 and abs(m / 1000 - round(m / 1000, 1)) < 0.06:
        k = round(m / 1000, 1); return (f"{int(k)}" if k == int(k) else f"{k}".replace(".", ",")) + " km"
    return f"{int(round(m))} m"


def nice_dist(m):
    """distance de répétition arrondie lisiblement : 398 -> 400, 1012 -> 1000, 52 -> 50"""
    if not m: return m
    step = 25 if m < 200 else 50 if m < 1000 else 100 if m < 3000 else 500
    return round(m / step) * step


def nice_time(s):
    if not s: return s
    step = 5 if s < 60 else 15 if s < 300 else 30 if s < 1200 else 60
    return round(s / step) * step


def group_label(items, key="d"):
    """[400,400,400,200,200] -> '3×400 m + 2×200 m' ; key='t' pour des durées"""
    out, cur, n = [], None, 0
    for it in items:
        v = nice_dist(it.get("d")) if key == "d" else nice_time(it.get("t"))
        if v == cur: n += 1
        else:
            if cur is not None: out.append((n, cur))
            cur, n = v, 1
    if cur is not None: out.append((n, cur))
    f = fmt_dist if key == "d" else fmt_dur
    return " + ".join((f"{n}×{f(v)}" if n > 1 else f(v)) for n, v in out), out


# ------------------------------------------------------------------------------------------------- contexte athlète
def ctx_of(ath, days=None, T=None):
    hrmax = float((ath or {}).get("hr_max") or 190)
    rhrs = []
    if days and T:
        for k in range(28):
            v = (days.get((T - timedelta(days=k)).isoformat()) or {}).get("rhr")
            if v: rhrs.append(v)
    rhr = sorted(rhrs)[len(rhrs) // 2] if rhrs else 50.0
    lthr = float((ath or {}).get("lthr_run") or hrmax * 0.91)
    lthr_b = float((ath or {}).get("lthr_bike") or lthr - 6)
    return {"hrmax": hrmax, "rhr": float(rhr), "lthr": lthr, "lthr_bike": lthr_b,
            "ftp": (ath or {}).get("ftp_w") if (ath or {}).get("power_meter") else None}


# ------------------------------------------------------------------------------------------------- fiabilité, charge
RESAMPLE = 5   # s entre deux points des séries (garmin_details.RESAMPLE_S)


def hr_quality(ser, ctx, fam):
    """part d'échantillons FC exploitables (0-1) + défauts repérés (signal perdu, plateau, verrouillage sur la cadence)"""
    hr = ser.get("hr") or []
    if len(hr) < 12: return None, []
    ok = [h for h in hr if h is not None and 35 <= h <= ctx["hrmax"] + 8]
    q = len(ok) / len(hr); flags = []
    if q < 0.85: flags.append("signal FC perdu par moments")
    flat = run = 0
    for i in range(1, len(hr)):
        if hr[i] is not None and hr[i] == hr[i - 1]: run += 1; flat = max(flat, run)
        else: run = 0
    if flat >= 36: flags.append("FC figée plus de 3 min"); q *= 0.8
    cad = ser.get("cad") or []
    if fam in ("run", "trail") and cad and len(cad) == len(hr):
        lock = sum(1 for h, c in zip(hr, cad) if h and c and c > 120 and abs(h - c) <= 2)
        hs = sorted(h for h in hr if h)
        med = hs[len(hs) // 2] if hs else 0
        # capteur poignet « accroché » à la cadence : FC collée à la cadence presque tout le temps, très haute sur une longue durée
        if lock > 0.6 * len(hr) and med >= 0.98 * ctx["lthr"] and len(hr) * RESAMPLE >= 2400:
            flags.append("FC probablement calée sur la cadence (capteur poignet)"); q *= 0.5
    return round(q, 2), flags


def trimp(ser, ctx):
    """TRIMP de Banister (homme) sur les séries temporelles : charge interne plus juste que FC moyenne × durée."""
    hr, t = ser.get("hr") or [], ser.get("t") or []
    if len(hr) < 12 or len(t) != len(hr): return None
    tot = 0.0
    for i in range(1, len(hr)):
        if hr[i] is None or t[i] is None or t[i - 1] is None: continue
        dt = min(30, max(0, t[i] - t[i - 1]))
        x = max(0.0, min(1.0, (hr[i] - ctx["rhr"]) / max(1.0, ctx["hrmax"] - ctx["rhr"])))
        tot += dt / 60 * x * 0.64 * math.exp(1.92 * x)
    return round(tot, 1)


def zones_from(det, ser, ctx, fam, hrq=None):
    """Temps par zone (s) : d'abord calculé sur les séries FC avec la FC seuil de l'app (zones de Friel, mêmes ancres que le reste
    du projet) ; zones Garmin en secours (elles reposent sur les réglages de la montre, qui peuvent différer)."""
    hr, t = ser.get("hr") or [], ser.get("t") or []
    if len(hr) >= 12 and (hrq is None or hrq >= 0.85):
        lt = ctx["lthr_bike"] if fam == "bike" else ctx["lthr"]
        out = [0] * 5
        for i in range(1, len(hr)):
            h = hr[i]
            if h is None or t[i] is None or t[i - 1] is None: continue
            r = h / lt; k = 0 if r < 0.85 else 1 if r < 0.90 else 2 if r < 0.95 else 3 if r < 1.0 else 4
            out[k] += min(30, t[i] - t[i - 1])
        if sum(out): return out
    z = det.get("zones") or []
    if z:
        out = [0] * 5
        for r in z:
            if 1 <= r["z"] <= 5: out[r["z"] - 1] += r["s"]
        if sum(out) > 0: return out
    return None


# ------------------------------------------------------------------------------------------------- structure (course, vélo)
WORK_IT = {"INTERVAL", "ACTIVE", "INTERVAL_ACTIVE", "RWD_RUN", "RUN"}
REST_IT = {"REST", "RECOVERY", "INTERVAL_REST", "INTERVAL_RECOVERY", "RWD_WALK", "RWD_STAND"}
EDGE_IT = {"WARMUP", "COOLDOWN", "INTERVAL_WARMUP", "INTERVAL_COOLDOWN"}


def _laps_with_start(laps):
    t0 = 0.0; out = []
    for l in laps:
        l = dict(l); l["t0"] = t0; t0 += l.get("t") or 0; out.append(l)
    return out


def structure(det, fam):
    """Structure réelle : séries (répétitions de travail) ou effort continu. Sources, dans l'ordre : intervalles typés,
    tours de la séance structurée (type d'intensité), puis segmentation sur la vitesse des tours manuels."""
    laps = _laps_with_start(det.get("laps") or [])
    typed = det.get("typed") or []
    work = []
    if typed and any((x.get("ty") or "").upper() == "INTERVAL_ACTIVE" for x in typed) and \
            any((x.get("ty") or "").upper() in REST_IT for x in typed):
        tl = _laps_with_start(typed)
        work = [x for x in tl if (x.get("ty") or "").upper() == "INTERVAL_ACTIVE"]
        rest = [x for x in tl if (x.get("ty") or "").upper() in REST_IT]
    elif laps and any((l.get("it") or "").upper() in WORK_IT for l in laps) and any((l.get("it") or "").upper() in REST_IT for l in laps):
        work = [l for l in laps if (l.get("it") or "").upper() in WORK_IT]
        rest = [l for l in laps if (l.get("it") or "").upper() in REST_IT]
    elif len(laps) >= 5:
        vs = [l.get("v") for l in laps if l.get("v")]
        if vs:
            med = sorted(vs)[len(vs) // 2]
            fast = [l for l in laps if (l.get("v") or 0) >= med * 1.12 and (l.get("t") or 0) >= 15]
            slow = [l for l in laps if 0 < (l.get("v") or 0) <= med * 0.92]
            alt = sum(1 for a, b in zip(laps, laps[1:]) if (a in fast) != (b in fast))
            if len(fast) >= 3 and slow and alt >= 2 * len(fast) - 2:
                work, rest = fast, slow
    if len(work) < 2:
        return {"kind": "steady"}
    ds = [w.get("d") or 0 for w in work]; ts = [w.get("t") or 0 for w in work]
    by_d = nz(cv(ds)) <= 12 and min(ds) > 0
    label, _ = group_label(work, "d" if by_d or (nz(cv(ds)) <= nz(cv(ts)) and min(ds) > 0) else "t")
    vs = [w.get("v") for w in work]
    hrs = [w.get("hr") for w in work]
    fade = None
    if len(vs) >= 3 and all(vs):
        a, b = mean(vs[:2]), mean(vs[-2:]); fade = (a - b) / a * 100
    drift = (mean(hrs[-2:]) - mean(hrs[:2])) if len(hrs) >= 3 and all(hrs) else None
    rec = []
    for w in work:
        nxt = next((r for r in rest if abs(r["t0"] - (w["t0"] + (w.get("t") or 0))) < 3), None)
        if nxt and w.get("hrmax") and nxt.get("hr"):
            rec.append(w["hrmax"] - nxt["hr"])
    return {"kind": "intervals", "label": label, "n": len(work),
            "reps": [{"d": r1(w.get("d"), 0), "t": r1(w.get("t"), 0), "v": w.get("v"), "hr": w.get("hr"), "hrmax": w.get("hrmax"),
                      "t0": round(w["t0"])} for w in work],
            "rest": [{"t": r1(r.get("t"), 0), "hr": r.get("hr")} for r in rest][:40],
            "v": r1(mean(vs), 3), "hr": r1(mean(hrs)), "cv": r1(cv(vs)), "fade": r1(fade), "drift": r1(drift),
            "rec": r1(mean(rec)), "rep_t": r1(mean(ts), 0), "rep_d": r1(mean(ds), 0)}


def outcome(st):
    """Qualité des séries : 'margin' (tenues avec marge), 'ok', 'struggle' (allure qui s'effondre ou FC qui dérive fort)."""
    if not st or st.get("kind") != "intervals": return None
    f, c, d = st.get("fade"), st.get("cv"), st.get("drift")
    if f is None: return None
    if f >= 6 or nz(c, 0) >= 7: return "struggle"
    if f <= 2.5 and nz(c) <= 4 and (d is None or d <= 6): return "margin"
    return "ok"


# ------------------------------------------------------------------------------------------------- course et trail
def _trim(ser, skip_s=600):
    t = ser.get("t") or []
    i0 = next((i for i, x in enumerate(t) if x is not None and x >= skip_s), len(t))
    return {k: v[i0:] for k, v in ser.items() if isinstance(v, list)}


def efficiency(ser, hrq):
    """Efficacité aérobie (m/min par battement) et découplage Pa:Hr entre les deux moitiés (sorties continues ≥ 40 min)."""
    if not ser or (hrq is not None and hrq < 0.85): return None, None
    s = _trim(ser)
    v = s.get("gap") if s.get("gap") and sum(1 for x in s["gap"] if x) > 0.8 * len(s["gap"]) else s.get("v")
    hr = s.get("hr")
    if not v or not hr or len(v) < 360: return None, None
    pairs = [(a, b) for a, b in zip(v, hr) if a and b and a > 0.8 and b > 80]
    if len(pairs) < 300: return None, None
    ef = mean([a * 60 for a, _ in pairs]) / mean([b for _, b in pairs])
    h = len(pairs) // 2
    e1 = mean([a for a, _ in pairs[:h]]) * 60 / mean([b for _, b in pairs[:h]])
    e2 = mean([a for a, _ in pairs[h:]]) * 60 / mean([b for _, b in pairs[h:]])
    return round(ef, 3), round((e1 - e2) / e1 * 100, 1)


BEST = (("400m", 400), ("1k", 1000), ("5k", 5000), ("10k", 10000), ("21k", 21097.5), ("42k", 42195))


def best_efforts(ser, avg_v=None):
    """meilleur temps glissant sur 400 m … marathon ; écarte les pointes GPS (trop rapides par rapport à la séance)"""
    d, t = ser.get("d") or [], ser.get("t") or []
    P = [(a, b) for a, b in zip(d, t) if a is not None and b is not None]
    if len(P) < 20: return {}
    out = {}
    for k, L in BEST:
        if P[-1][0] - P[0][0] < L * 0.995: continue
        j, best = 0, None
        for i in range(len(P)):
            while j < len(P) and P[j][0] - P[i][0] < L: j += 1
            if j >= len(P): break
            dt = P[j][1] - P[i][1]
            if dt > 0 and (best is None or dt < best): best = dt
        if best:
            v = L / best
            cap = (1.9 if L <= 1000 else 1.45) * avg_v if avg_v else 7.5
            if v < 7.5 and v <= cap: out[k] = round(best)        # au-delà : pointe GPS aberrante
    return out


def trail_metrics(det, ser, act):
    m = det.get("m") or {}
    km = (act.get("km") or 0) or ((m.get("distance") or 0) / 1000)
    up = m.get("elevationGain") if m.get("elevationGain") is not None else act.get("el")
    dn = m.get("elevationLoss")
    out = {"up": r1(up, 0), "dn": r1(dn, 0), "upkm": r1(up / km, 0) if up and km else None}
    alt, t, v, d = ser.get("alt") or [], ser.get("t") or [], ser.get("v") or [], ser.get("d") or []
    if len(alt) >= 60 and len(d) == len(alt):
        sm = [mean(alt[max(0, i - 3):i + 4]) for i in range(len(alt))]
        clim_up = clim_t = dn_v = 0.0; dn_n = 0; walk_t = tot = 0.0
        cad = ser.get("cad") or []
        for i in range(6, len(sm), 6):
            dd = (d[i] or 0) - (d[i - 6] or 0); dz = (sm[i] or 0) - (sm[i - 6] or 0); dt = (t[i] or 0) - (t[i - 6] or 0)
            if dt <= 0 or dd < 0: continue
            g = dz / dd if dd > 5 else 0; tot += dt
            if g >= 0.08: clim_up += dz; clim_t += dt
            if g <= -0.08 and v[i]: dn_v += v[i]; dn_n += 1
            c = cad[i] if i < len(cad) else None
            if (c is not None and 0 < c < 125) or (v[i] is not None and 0 < v[i] < 1.5 and g > 0.04): walk_t += dt
        if clim_t >= 120: out["vam"] = round(clim_up / clim_t * 3600)
        if dn_n >= 5: out["dn_pace"] = round(pace_s(dn_v / dn_n))
        if tot > 0: out["walk"] = round(walk_t / tot * 100)
    gs = m.get("avgGradeAdjustedSpeed")
    if gs: out["gap"] = round(pace_s(gs))
    if t and t[-1] and t[-1] >= 7200 and ser.get("hr"):
        hr = ser["hr"]; gv = ser.get("gap") or v
        n1 = next((i for i, x in enumerate(t) if x and x >= 3600), None); n2 = next((i for i, x in enumerate(t) if x and x >= t[-1] - 3600), None)
        if n1 and n2:
            e1 = (mean(gv[:n1]) or 0) * 60 / (mean(hr[:n1]) or 1); e2 = (mean(gv[n2:]) or 0) * 60 / (mean(hr[n2:]) or 1)
            if e1 > 0: out["dur"] = round((e2 - e1) / e1 * 100, 1)       # durabilité : efficacité de la dernière heure / première (en %)
    return {k: v for k, v in out.items() if v is not None}


def run_dyn(det):
    m = det.get("m") or {}
    g = lambda *ks: next((m[k] for k in ks if m.get(k) is not None), None)
    out = {"cad": g("averageRunCadence", "averageRunningCadenceInStepsPerMinute"), "gct": g("groundContactTime", "avgGroundContactTime"),
           "vo": g("verticalOscillation", "avgVerticalOscillation"), "sl": g("strideLength", "avgStrideLength"),
           "vr": g("verticalRatio", "avgVerticalRatio"), "pw": g("averagePower", "avgPower")}
    if out["sl"] and out["sl"] > 10: out["sl"] = out["sl"] / 100       # cm -> m
    return {k: r1(v, 2 if k == "sl" else 1) for k, v in out.items() if v}


# ------------------------------------------------------------------------------------------------- vélo
def _grades(ser, win=6):
    """pentes (dz/dd) par fenêtre de 30 s, avec altitude lissée"""
    alt, d, t = ser.get("alt") or [], ser.get("d") or [], ser.get("t") or []
    if len(alt) < 60 or len(d) != len(alt): return []
    sm = [mean(alt[max(0, i - 3):i + 4]) for i in range(len(alt))]
    out = []
    for i in range(win, len(sm), win):
        dd = (d[i] or 0) - (d[i - win] or 0); dz = (sm[i] or 0) - (sm[i - win] or 0); dt = (t[i] or 0) - (t[i - win] or 0)
        if dt > 0 and dd >= 0: out.append((i, dd, dz, dt, dz / dd if dd > 20 else 0.0))
    return out


def bike_metrics(det, ser, ctx, act=None):
    """Vélo (sans capteur de puissance) : dénivelé et montées, efficacité FC sur le plat seulement (la vitesse dépend du vent et de la
    pente : jamais utilisée seule comme indicateur de forme), dérive cardiaque sur le plat, cadence, roue libre, puissance si présente."""
    m = det.get("m") or {}
    tk = (det.get("type") or m.get("typeKey") or "").lower()
    alt = [a for a in (ser.get("alt") or []) if a is not None]
    indoor = "indoor" in tk or "virtual" in tk or (not det.get("trk") and (not alt or max(alt) - min(alt) < 3))
    km = ((act or {}).get("km") or 0) or ((m.get("distance") or 0) / 1000)
    up = m.get("elevationGain") if m.get("elevationGain") is not None else (act or {}).get("el")
    out = {"indoor": indoor, "cad": r1(m.get("averageBikeCadence") or m.get("averageBikingCadenceInRevPerMinute")),
           "up": r1(up, 0), "dn": r1(m.get("elevationLoss"), 0), "upkm": r1(up / km, 1) if up and km else None,
           "vmax": r1((m.get("maxSpeed") or 0) * 3.6, 1) or None,
           "vmov": r1(km * 1000 / m["movingDuration"] * 3.6, 1) if m.get("movingDuration") and km else None}
    G = _grades(ser) if not indoor else []
    v, hr, cad = ser.get("v") or [], ser.get("hr") or [], ser.get("cad") or []
    if G:
        cu = sum(dz for _, dd, dz, dt, g in G if g >= 0.04); ct = sum(dt for _, dd, dz, dt, g in G if g >= 0.04)
        if ct >= 180: out["vam"] = round(cu / ct * 3600); out["climb_min"] = round(ct / 60)
        # montées : enchaînements de fenêtres à ≥ 4 % totalisant ≥ 40 m de dénivelé
        n_cl, acc = 0, 0.0
        for _, dd, dz, dt, g in G:
            if g >= 0.04: acc += dz
            else:
                if acc >= 40: n_cl += 1
                acc = 0.0
        if acc >= 40: n_cl += 1
        out["climbs"] = n_cl
        flat = [i for i, dd, dz, dt, g in G if abs(g) < 0.02]
        pairs = [(v[i], hr[i]) for i in flat if i < len(v) and i < len(hr) and v[i] and hr[i] and v[i] > 4 and hr[i] > 80]
        if len(pairs) >= 40:
            out["ef_flat"] = round(mean([a * 3.6 for a, _ in pairs]) / mean([b for _, b in pairs]), 3)
            h = len(pairs) // 2
            e1 = mean([a for a, _ in pairs[:h]]) / mean([b for _, b in pairs[:h]]); e2 = mean([a for a, _ in pairs[h:]]) / mean([b for _, b in pairs[h:]])
            if (ser.get("t") or [0])[-1] >= 3600: out["dec"] = round((e1 - e2) / e1 * 100, 1)
    elif indoor and v and hr:
        pairs = [(a, b) for a, b in zip(v, hr) if a and b and a > 3 and b > 80]
        if len(pairs) >= 60: out["ef_flat"] = round(mean([a * 3.6 for a, _ in pairs]) / mean([b for _, b in pairs]), 3)
    if cad and v:
        moving = [(c, s) for c, s in zip(cad, v) if s is not None and s > 2]
        if len(moving) >= 60:
            out["coast"] = round(sum(1 for c, _ in moving if not c) / len(moving) * 100)
            ped = [c for c, _ in moving if c]
            if ped: out["low_cad"] = round(sum(1 for c in ped if c < 75) / len(ped) * 100)
    pw = ser.get("pw") or []
    if sum(1 for p in pw if p) > 0.7 * max(1, len(pw)) and len(pw) >= 60:
        roll = [mean(pw[max(0, i - 5):i + 1]) or 0 for i in range(len(pw))]
        np_ = (mean([x ** 4 for x in roll]) or 0) ** 0.25
        out["np"] = round(np_)
        if ctx.get("ftp"): out["if"] = round(np_ / ctx["ftp"], 2)
    return {k: v for k, v in out.items() if v is not None}


# ------------------------------------------------------------------------------------------------- natation
def swim_metrics(det):
    laps = det.get("laps") or []
    act = [l for l in laps if (l.get("d") or 0) > 0 and (l.get("it") or "").upper() not in REST_IT]
    rest = [l for l in laps if (l.get("d") or 0) == 0 or (l.get("it") or "").upper() in REST_IT]
    if not act: return {}
    label, groups = group_label(act, "d")
    sets = []
    for l in act:
        lens = l.get("lens") or []
        lt = [x.get("t") for x in lens if x.get("t")]
        sets.append({"d": r1(l.get("d"), 0), "t": r1(l.get("t"), 0), "p100": r1((l["t"] / l["d"] * 100) if l.get("t") and l.get("d") else None, 0),
                     "stroke": (l.get("stroke") or "").lower() or None, "swolf": l.get("swolf"), "spl": l.get("spl"),
                     "cv": r1(cv(lt)) if len(lt) >= 3 else None})
    tot_d = sum(l.get("d") or 0 for l in act); tot_t = sum(l.get("t") or 0 for l in act)
    sw = [s["swolf"] for s in sets if s["swolf"]]
    pool = (det.get("m") or {}).get("poolLength")
    strokes = {}
    for s in sets:
        if s["stroke"]: strokes[s["stroke"]] = strokes.get(s["stroke"], 0) + (s["d"] or 0)
    return {"label": label, "sets": sets[:40], "d": round(tot_d), "p100": r1(tot_t / tot_d * 100, 0) if tot_d else None,
            "swolf": r1(mean(sw)), "rest": round(sum(l.get("t") or 0 for l in rest)), "pool": pool, "strokes": strokes,
            "n": len(act)}


def css_from(swims):
    """CSS (s/100 m) : 200 / (t400 - t200) sur les meilleurs 400 m et 200 m continus des 120 derniers jours (séries détaillées)."""
    b400 = b200 = None
    for s in swims:
        for x in (s.get("sets") or []):
            d, t = x.get("d"), x.get("t")
            if not d or not t: continue
            if 380 <= d <= 420: b400 = t * 400 / d if b400 is None else min(b400, t * 400 / d)
            if 190 <= d <= 210: b200 = t * 200 / d if b200 is None else min(b200, t * 200 / d)
    if b400 and b200 and b400 > b200 * 1.7:
        css = (b400 - b200) / 2
        if 60 <= css <= 200: return round(css)
    return None


# ------------------------------------------------------------------------------------------------- musculation
GROUPS = (("legs", r"SQUAT|LUNGE|DEADLIFT|LEG_|CALF|HIP_RAISE|STEP_UP|OLYMPIC|PLYO|HIP_STAB|SLED|GLUTE|BOX_JUMP|LEG"),
          ("push", r"BENCH|SHOULDER_PRESS|PUSH_UP|TRICEP|CHEST|DIP|LATERAL_RAISE|FLYE|FLY|PRESS"),
          ("pull", r"ROW|PULL_UP|PULL|CHIN|CURL|SHRUG|LAT_|REVERSE_FLY|FACE"),
          ("core", r"CRUNCH|PLANK|SIT_UP|CORE|ABS|HIP_SWING|LEG_RAISE|RUSSIAN|BRIDGE|CARRY"))


def group_of(cat):
    c = (cat or "").upper()
    if "LEG_RAISE" in c: return "core"
    for g, rx in GROUPS:
        if re.search(rx, c): return g
    return "other"


def strength_metrics(det):
    sets = [s for s in det.get("sets") or [] if (s.get("ty") or "ACTIVE").upper() == "ACTIVE" and (s.get("reps") or s.get("t"))]
    if not sets: return {}
    ex = {}
    for s in sets:
        k = s.get("cat") or "UNKNOWN"
        e = ex.setdefault(k, {"cat": k, "name": s.get("ex"), "sets": 0, "reps": 0, "kg": 0.0, "ton": 0.0, "e1rm": None, "detail": []})
        e["sets"] += 1; e["reps"] += int(s.get("reps") or 0); kg = s.get("kg") or 0
        e["kg"] = max(e["kg"], kg); e["ton"] += kg * int(s.get("reps") or 0)
        if kg and s.get("reps") and s["reps"] <= 12:
            est = kg * (1 + s["reps"] / 30); e["e1rm"] = max(e["e1rm"] or 0, est)
        e["detail"].append([int(s.get("reps") or 0), r1(kg)])
    groups = {}
    for e in ex.values():
        g = group_of(e["cat"]); groups[g] = groups.get(g, 0) + e["sets"]
        e["g"] = g; e["e1rm"] = r1(e["e1rm"]); e["ton"] = round(e["ton"]); e["kg"] = r1(e["kg"])
    L = sorted(ex.values(), key=lambda e: -e["sets"])
    dom = max(("push", "pull", "legs"), key=lambda g: groups.get(g, 0))
    ps = [s.get("p") for s in sets if s.get("p") is not None]
    known = sum(1 for s in sets if s.get("cat") and s.get("cat") not in ("UNKNOWN", "TOTAL_BODY", "CARDIO"))
    conf = round(min(1.0, (mean(ps) / 100 if ps else 0.6) * (known / len(sets))), 2)   # Garmin reconnaît mal certains exercices
    return {"ex": L[:14], "sets": len(sets), "ton": round(sum(e["ton"] for e in L)), "groups": groups, "conf": conf,
            "type": dom if groups.get(dom, 0) >= 3 and groups.get(dom, 0) >= 0.5 * len(sets) and conf >= 0.6 else None}


# ------------------------------------------------------------------------------------------------- analyse d'une séance
def blocks(ser, step_s=300, n_max=36):
    """Évolution dans le temps : vitesse moyenne (m/s), FC et altitude par bloc de 5 min (10 min au-delà de 3 h)."""
    t, v, hr, alt = ser.get("t") or [], ser.get("v") or [], ser.get("hr") or [], ser.get("alt") or []
    if len(t) < 24 or not v: return None
    tot = next((x for x in reversed(t) if x is not None), 0)
    if tot > 3 * 3600: step_s = 600
    if tot / step_s > n_max: step_s = int(math.ceil(tot / n_max / 60) * 60)
    out, cur, b = [], 0, {"v": [], "hr": [], "alt": []}
    for i, ti in enumerate(t):
        if ti is None: continue
        k = int(ti // step_s)
        if k != cur and b["v"]:
            out.append([cur * step_s // 60, r1(mean(b["v"]), 2), r1(mean(b["hr"]), 0), r1(mean(b["alt"]), 0)])
            b = {"v": [], "hr": [], "alt": []}
        cur = k
        if i < len(v) and v[i] is not None: b["v"].append(v[i])
        if i < len(hr) and hr[i] is not None: b["hr"].append(hr[i])
        if i < len(alt) and alt[i] is not None: b["alt"].append(alt[i])
    if b["v"]: out.append([cur * step_s // 60, r1(mean(b["v"]), 2), r1(mean(b["hr"]), 0), r1(mean(b["alt"]), 0)])
    return out if len(out) >= 3 else None


def _profile(ser, n=80):
    alt, d = ser.get("alt") or [], ser.get("d") or []
    if len(alt) < 30 or not any(alt): return None
    step = max(1, len(alt) // n); P = []
    for i in range(0, len(alt), step):
        a = mean(alt[i:i + step]); x = d[i] if i < len(d) else None
        if a is not None: P.append([r1(x, 0) if x is not None else i, r1(a, 0)])
    return P if len(P) >= 10 else None


def watch_block(m):
    """Ce que la montre mesure ou te demande en fin de séance (diagnostic du 19/11 : fenix 8) : effort et sensations saisis,
    conformité à l'entraînement, perte hydrique, Body Battery, puissance de course, stamina, allure ajustée à la pente."""
    g = lambda k: m.get(k) if isinstance(m.get(k), (int, float)) else None
    w = {"rpe": round(g("directWorkoutRpe") / 10, 1) if g("directWorkoutRpe") else None,        # stocké ×10 (20 = 2/10)
         "feel": g("directWorkoutFeel"), "comp": g("directWorkoutComplianceScore"),
         "water": g("waterEstimated"), "bb": g("differenceBodyBattery"), "rec_hr": g("recoveryHeartRate"),
         "pw": g("averagePower"), "np": g("normalizedPower"), "gap": g("avgGradeAdjustedSpeed"),
         "stam": [g("beginPotentialStamina"), g("endPotentialStamina")] if g("beginPotentialStamina") is not None and g("endPotentialStamina") is not None else None,
         "impact": g("impactLoad")}
    return {k: v for k, v in w.items() if v is not None} or None


def analyze(det, act, ctx):
    """Résumé « x » d'une séance détaillée. Ne lève jamais d'exception (bloc par bloc)."""
    x = {"fam": det.get("fam") or act.get("s")}
    fam = act.get("s") if act.get("s") in ("run", "trail", "bike", "swim", "strength") else det.get("fam")
    if fam == "run" and (det.get("type") or "").lower().find("trail") >= 0: fam = "trail"
    ser = det.get("ser") or {}
    m = det.get("m") or {}

    def safe(k, f):
        try:
            v = f()
            if v not in (None, {}, []): x[k] = v
        except Exception:  # noqa: BLE001
            pass
    q, flags = (None, [])
    try: q, flags = hr_quality(ser, ctx, fam)
    except Exception: pass  # noqa: BLE001
    x["rel"] = {"hr": q, "flags": flags, "gps": bool(det.get("trk"))}
    if det.get("wid"): x["wid"] = det["wid"]                     # entraînement Garmin suivi (associatedWorkoutId)
    safe("trimp", lambda: trimp(ser, ctx) if (q or 0) >= 0.7 else None)
    safe("zones", lambda: zones_from(det, ser, ctx, fam, q))
    safe("te", lambda: {k: m.get(src) for k, src in (("a", "trainingEffect"), ("an", "anaerobicTrainingEffect"), ("load", "activityTrainingLoad"))
                        if m.get(src) is not None} or None)
    if m.get("trainingEffectLabel"): x["te_lab"] = m["trainingEffectLabel"]
    safe("wx", lambda: det.get("wx") or None)
    safe("watch", lambda: watch_block(m))
    safe("gear", lambda: [g.get("name") for g in det.get("gear") or [] if g.get("name")] or None)
    if fam in ("run", "trail", "bike"):
        safe("st", lambda: structure(det, fam))
        if x.get("st", {}).get("kind") == "intervals": x["out"] = outcome(x["st"])
        if (x.get("st") or {}).get("kind") != "intervals" and fam != "bike":
            try:
                ef, dec = efficiency(ser, q)
                if ef: x["ef"] = ef
                if dec is not None and (act.get("m") or 0) >= 40: x["dec"] = dec
            except Exception: pass  # noqa: BLE001
        safe("prof", lambda: _profile(ser))
        safe("trk", lambda: det.get("trk") or None)
    if fam in ("run", "trail"):
        safe("best", lambda: best_efforts(ser, (act.get("km") or 0) * 1000 / (act["m"] * 60) if act.get("m") else None) if x["rel"].get("gps") or ser.get("d") else None)
        safe("dyn", lambda: run_dyn(det))
        safe("trail", lambda: trail_metrics(det, ser, act) if (fam == "trail" or (act.get("el") or 0) >= 250) else None)
    if fam == "bike": safe("bike", lambda: bike_metrics(det, ser, ctx, act))
    if fam in ("run", "trail", "bike"): safe("blk", lambda: blocks(ser))
    if fam == "swim": safe("swim", lambda: swim_metrics(det))
    if fam == "strength" or det.get("sets"): safe("str", lambda: strength_metrics(det))
    return x


# ------------------------------------------------------------------------------------------------- séance prévue
def _flat_steps(steps, out, reps=1):
    for s in steps or []:
        if not isinstance(s, dict): continue
        if s.get("type") == "RepeatGroupDTO" or (s.get("stepType") or {}).get("stepTypeKey") == "repeat":
            n = int(s.get("numberOfIterations") or s.get("endConditionValue") or 1)
            for _ in range(n): _flat_steps(s.get("workoutSteps"), out)
            continue
        kind = (s.get("stepType") or {}).get("stepTypeKey") or "other"
        cond = (s.get("endCondition") or {}).get("conditionTypeKey")
        val = s.get("endConditionValue")
        tt = (s.get("targetType") or {}).get("workoutTargetTypeKey")
        out.append({"k": kind, "c": cond, "v": val, "tt": tt if tt and tt != "no.target" else None,
                    "lo": s.get("targetValueOne"), "hi": s.get("targetValueTwo"), "desc": s.get("description") or ""})
    return out


def plan_struct(w):
    """Fichier Garmin d'une séance prévue -> structure comparable (séries de travail, durée, cibles)."""
    if not isinstance(w, dict): return None
    steps = []
    for seg in w.get("workoutSegments") or []:
        _flat_steps(seg.get("workoutSteps"), steps)
    if not steps: return None
    work = [s for s in steps if s["k"] in ("interval", "other", "active")]
    rec = [s for s in steps if s["k"] in ("recovery", "rest")]
    items = [{"d": s["v"] if s["c"] == "distance" else None, "t": s["v"] if s["c"] == "time" else None} for s in work]
    by_d = all(i["d"] for i in items) and items
    label = group_label(items, "d" if by_d else "t")[0] if items and (by_d or all(i["t"] for i in items)) else None
    tot_t = sum((s["v"] or 0) for s in steps if s["c"] == "time")
    tot_d = sum((s["v"] or 0) for s in steps if s["c"] == "distance")
    tg = [s for s in work if s["tt"]]
    allit = [{"d": s["v"] if s["c"] == "distance" else None, "t": s["v"] if s["c"] == "time" else None} for s in steps if s["k"] not in ("recovery", "rest")]
    label_all = group_label(allit, "d")[0] if allit and all(i["d"] for i in allit) else label
    sport = ((w.get("sportType") or {}).get("sportTypeKey") or "").lower()
    # séance « à séries » seulement si le travail fractionné pèse dans la séance (des lignes droites dans un footing n'en font pas une)
    rep = [a for a, b in zip(steps, steps[1:] + [None]) if a["k"] in ("interval", "other", "active") and b and b["k"] in ("recovery", "rest")]
    wt = sum((s["v"] or 0) for s in rep if s["c"] == "time") + sum((s["v"] or 0) / 4.0 for s in rep if s["c"] == "distance")
    at = sum((s["v"] or 0) for s in steps if s["c"] == "time") + sum((s["v"] or 0) / 4.0 for s in steps if s["c"] == "distance")
    heavy = len(rep) >= 2 and at > 0 and wt / at >= 0.15
    return {"sport": sport, "label": label, "n": len(work), "rec": len(rec), "intervals": len(work) >= 2 and bool(rec) and heavy,
            "t": tot_t, "d": tot_d, "est_s": w.get("estimatedDurationInSecs"), "est_m": w.get("estimatedDistanceInMeters"),
            "tt": tg[0]["tt"] if tg else None, "lo": tg[0]["lo"] if tg else None, "hi": tg[0]["hi"] if tg else None,
            "items": items, "all": allit, "label_all": label_all, "name": (w.get("workoutName") or "").replace("Emberline · ", ""),
            "ex": [s["desc"].split(" : ")[0] for s in work if " : " in s["desc"]] if sport == "strength_training" else []}


def load_plans(src, d):
    """Séances préparées pour la date d (garmin/workouts/<d>/) : {clé: structure}."""
    root = Path(src) / "workouts" / d
    out = {}
    try:
        ix = json.loads((root / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return out
    for k in (ix.get("items") or {}):
        try:
            p = plan_struct(json.loads((root / f"{k}.json").read_text(encoding="utf-8")))
            if p: p["coach"] = k in (ix.get("coach") or []); out[k] = p
        except (OSError, ValueError):
            continue
    return out


def _intensity_gap(plan, x, act):
    """+1 plus intense, -1 plus facile, 0 conforme, None inconnu (cible d'allure, de FC ou de puissance de la séance prévue)."""
    if not plan.get("tt") or plan.get("lo") is None: return None
    st = x.get("st") or {}
    lo, hi = sorted([float(plan["lo"]), float(plan["hi"] or plan["lo"])])
    if plan["tt"].startswith("pace") or plan["tt"].startswith("speed"):
        v = st.get("v") if st.get("kind") == "intervals" else (act["km"] * 1000 / (act["m"] * 60) if act.get("km") and act.get("m") else None)
        if not v: return None
        return 1 if v > hi * 1.03 else -1 if v < lo * 0.97 else 0
    if plan["tt"].startswith("heart"):
        h = st.get("hr") if st.get("kind") == "intervals" else act.get("hr")
        if not h: return None
        return 1 if h > hi + 4 else -1 if h < lo - 6 else 0
    return None


def compare(plan, x, act):
    """Verdict prévu / réalisé. codes : ok, harder, easier, partial, other, short, long."""
    if not plan: return None
    st, sw, sr = x.get("st") or {}, x.get("swim") or {}, x.get("str") or {}
    done_min = act.get("m") or 0
    plan_min = (plan.get("est_s") or plan.get("t") or 0) / 60
    res = {"plan": (plan.get("label_all") if act.get("s") == "swim" else None) or plan.get("label") or plan.get("name"), "name": plan.get("name")}
    if act.get("s") == "strength":
        want = {"strength-push": "push", "strength-pull": "pull", "strength-legs": "legs"}.get(plan.get("key"))
        got = sr.get("type")
        res["done"] = " · ".join(f"{e['sets']}×{(e['reps'] // max(1, e['sets']))} {e['cat'].replace('_', ' ').lower()}" for e in (sr.get("ex") or [])[:3]) or None
        n_plan = plan.get("n") or 0; n_done = sr.get("sets") or 0
        if (sr.get("conf") or 0) < 0.6:
            res.update(code="unk", label="Exercices mal reconnus par la montre : comparaison non faite", score=None, done=None)
        elif want and got and got != want: res.update(code="other", label=f"Faite autrement : séance {got} au lieu de {want}", score=30)
        elif n_plan and n_done and n_done < 0.7 * n_plan: res.update(code="partial", label=f"Partielle : {n_done} séries sur {n_plan}", score=round(100 * n_done / n_plan))
        else: res.update(code="ok", label="Conforme", score=90 if n_done else 70)
        return res
    if act.get("s") == "swim" and sw:
        res["done"] = sw.get("label")
        pd, dd = plan.get("d") or plan.get("est_m") or 0, sw.get("d") or 0
        same = (plan.get("label_all") or plan.get("label") or "") == (sw.get("label") or "")
        p_items = [nice_dist(i["d"]) for i in (plan.get("all") or plan.get("items") or []) if i.get("d")]
        d_items = [nice_dist(s["d"]) for s in sw.get("sets") or []]
        common = sum(min(p_items.count(v), d_items.count(v)) for v in set(p_items))
        sim = common / max(1, max(len(p_items), len(d_items)))
        if same or sim >= 0.8:
            code = "ok" if not pd or 0.85 <= dd / pd <= 1.2 else ("short" if dd < pd else "long")
        elif pd and dd < 0.6 * pd: code = "partial"
        else: code = "other"
        lab = {"ok": "Conforme", "short": "Plus courte que prévu", "long": "Plus longue que prévu", "partial": f"Partielle : {fmt_dist(dd)} sur {fmt_dist(pd)}",
               "other": f"Faite autrement : prévu {plan.get('label_all') or plan.get('label') or fmt_dist(pd)}, fait {sw.get('label')}"}[code]
        res.update(code=code, label=lab, score=round(100 * (0.5 * sim + 0.5 * (min(dd, pd) / max(dd, pd) if pd and dd else 0.5))))
        return res
    if plan.get("intervals"):
        if st.get("kind") != "intervals":
            res.update(done=f"{fmt_dur(done_min * 60)} en continu", code="other",
                       label=f"Faite autrement : prévu {plan.get('label')}, fait {fmt_dur(done_min * 60)} en continu", score=25)
            return res
        res["done"] = st.get("label")
        n_p, n_d = plan["n"], st["n"]
        size_p = mean([i["d"] for i in plan["items"] if i.get("d")]) if all(i.get("d") for i in plan["items"]) else None
        size_t = mean([i["t"] for i in plan["items"] if i.get("t")]) if all(i.get("t") for i in plan["items"]) else None
        err = abs(st["rep_d"] - size_p) / size_p if size_p and st.get("rep_d") else abs(st["rep_t"] - size_t) / size_t if size_t and st.get("rep_t") else 0.0
        if err > 0.35 or abs(n_d - n_p) > max(2, 0.5 * n_p):
            res.update(code="other", label=f"Faite autrement : prévu {plan.get('label')}, fait {st.get('label')}", score=round(40 * max(0, 1 - err)))
            return res
        if n_d < 0.8 * n_p:
            res.update(code="partial", label=f"Partielle : {n_d}/{n_p} répétitions", score=round(100 * n_d / n_p * (1 - err)))
            return res
        g = _intensity_gap(plan, x, act)
        code = "harder" if g == 1 else "easier" if g == -1 else "ok"
        res.update(code=code, label={"ok": "Conforme", "harder": "Plus intense que prévu", "easier": "Plus facile que prévu"}[code],
                   score=round(100 * min(1, n_d / n_p) * (1 - err) * (0.85 if g else 1)))
        return res
    res["done"] = (st.get("label") if st.get("kind") == "intervals" else f"{fmt_dur(done_min * 60)} en continu")
    if st.get("kind") == "intervals" and not plan.get("intervals") and (plan.get("n") or 0) <= 1:
        res.update(code="harder", label=f"Faite autrement : séries ({st.get('label')}) au lieu d'un effort continu", score=40)
        return res
    r = done_min / plan_min if plan_min else 1.0
    g = _intensity_gap(plan, x, act)
    if r < 0.7: code, lab = "short", f"Plus courte que prévu ({fmt_dur(done_min * 60)} sur {fmt_dur(plan_min * 60)})"
    elif r > 1.35: code, lab = "long", f"Plus longue que prévu ({fmt_dur(done_min * 60)} au lieu de {fmt_dur(plan_min * 60)})"
    elif g == 1: code, lab = "harder", "Plus intense que prévu"
    elif g == -1: code, lab = "easier", "Plus facile que prévu"
    else: code, lab = "ok", "Conforme"
    res.update(code=code, label=lab, score=round(100 * max(0, 1 - abs(1 - r)) * (0.85 if g else 1)))
    return res


PLAN_KEY = {"run": "run", "trail": "run", "bike": "bike", "swim": "swim"}


def match_plan(act, x, plans):
    """Séance prévue la plus probable pour cette activité, parmi les séances préparées ce jour-là."""
    s = act.get("s")
    if s in PLAN_KEY:
        p = plans.get(PLAN_KEY[s]); key = PLAN_KEY[s]
    elif s == "strength":
        got = (x.get("str") or {}).get("type")
        cands = [k for k in plans if k.startswith("strength-")]
        key = next((k for k in cands if plans[k].get("coach")), None) or (f"strength-{got}" if got and f"strength-{got}" in plans else (cands[0] if cands else None))
        p = plans.get(key) if key else None
    else:
        return None, None
    if p: p = dict(p, key=key)
    return key, p


# ------------------------------------------------------------------------------------------------- historique
def enrich(acts, details, src, ath, days, T, keep_ui_days=42, keep_lite_days=366):
    """Attache « x » (analyse détaillée) et « cmp » (prévu / réalisé) aux activités ; renvoie le bloc A['detail']."""
    ctx = ctx_of(ath, days, T)
    plans_cache, n = {}, 0
    ui = {}
    for a in acts:
        det = details.get(str(a.get("id"))) if a.get("id") is not None else None
        if not det: continue
        try:
            x = analyze(det, a, ctx)
        except Exception:  # noqa: BLE001
            continue
        a["x"] = x; n += 1
    try: routes(acts)                                             # parcours qui reviennent
    except Exception as e: print(f"Parcours non calculés ({type(e).__name__}: {e})")  # noqa: BLE001
    try: bricks(acts)                                             # enchaînements vélo → course
    except Exception as e: print(f"Enchaînements non calculés ({type(e).__name__}: {e})")  # noqa: BLE001
    try: sent = json.loads((Path(src) / "workouts" / "sent.json").read_text(encoding="utf-8"))
    except (OSError, ValueError): sent = {}
    for a in acts:                                                # prévu / réalisé (une course enchaînée fait partie de la séance vélo)
        x = a.get("x")
        if not x or (a.get("brick") and a["s"] in ("run", "trail")): continue
        try:
            se = sent.get(str(x.get("wid"))) if x.get("wid") else None    # entraînement suivi : la séance préparée ce jour-là, même faite un autre jour
            dp = se["d"] if se and se.get("d") else a["d"]
            if dp not in plans_cache: plans_cache[dp] = load_plans(src, dp)
            key, p = match_plan(a, x, plans_cache[dp])
            if se and se.get("k") in plans_cache[dp]: key, p = se["k"], dict(plans_cache[dp][se["k"]], key=se["k"])
            if p:
                c = compare(p, x, a)
                if c: c["key"] = key; a["cmp"] = c
        except Exception:  # noqa: BLE001
            pass
    for a in acts:
        if not a.get("x") or a.get("id") is None: continue
        if a["d"] >= (T - timedelta(days=keep_ui_days)).isoformat():
            ui[str(a["id"])] = ui_payload(a)                       # fiche complète : carte, graphes
        elif a["d"] >= (T - timedelta(days=keep_lite_days)).isoformat():
            ui[str(a["id"])] = ui_payload(a, lite=True)            # historique : chiffres, verdict, zones, tableaux
    k = load_scale(acts)                                          # charge estimée -> TRIMP réel, ramené à l'échelle de charge Garmin
    for a in acts:
        x = a.get("x") or {}
        if a.get("est") and x.get("trimp"):
            a["ld"] = round(x["trimp"] * k, 1); a["est"] = False; a["ld_src"] = "trimp"
    for a in acts:
        if a.get("x") and str(a.get("id")) in ui: ui[str(a["id"])]["ld"] = a.get("ld")
    return {"n": n, "acts": ui, "load_k": k}


def _cells(trk):
    """Empreinte d'un tracé : cases d'environ 450 m traversées (sert à reconnaître un parcours qui revient)."""
    return {(round(p[0] / 0.004), round(p[1] / 0.006)) for p in trk or [] if isinstance(p, (list, tuple)) and len(p) >= 2}


def routes(acts):
    """Parcours qui reviennent (course, trail, vélo) : même empreinte (Jaccard ≥ 0,6) et distance proche (± 20 %).
    Ajoute x["route"] : nombre de passages, rang, meilleur passage et passage précédent. Les tracés restent dans garmin/details/."""
    C = []
    L = sorted([a for a in acts if (a.get("x") or {}).get("trk") and a.get("km") and a.get("m") and a["s"] in ("run", "trail", "bike")],
               key=lambda a: (a["d"], a.get("t") or ""))
    for a in L:
        fp, fam = _cells(a["x"]["trk"]), ("bike" if a["s"] == "bike" else "run")
        if len(fp) < 4: continue
        best = None
        for c in C:
            if c["fam"] != fam or not (0.8 <= a["km"] / c["km"] <= 1.25): continue
            j = len(fp & c["fp"]) / max(1, len(fp | c["fp"]))
            if j >= 0.6 and (best is None or j > best[0]): best = (j, c)
        if best: best[1]["m"].append(a)
        else: C.append({"fam": fam, "fp": fp, "km": a["km"], "m": [a]})
    for ci, c in enumerate(C):
        if len(c["m"]) < 2: continue
        sp = lambda a: a["km"] * 1000 / (a["m"] * 60)
        km = round(sum(a["km"] for a in c["m"]) / len(c["m"]), 1)
        for i, a in enumerate(c["m"]):
            seen = c["m"][: i + 1]
            b = max(seen, key=sp); prev = c["m"][i - 1] if i else None
            a["x"]["route"] = {"id": ci, "n": len(c["m"]), "i": i + 1, "km": km, "rank": sorted(seen, key=sp, reverse=True).index(a) + 1,
                               "best": {"d": b["d"], "v": round(sp(b), 3), "m": round(b["m"], 1)},
                               "prev": {"d": prev["d"], "v": round(sp(prev), 3), "m": round(prev["m"], 1), "hr": prev.get("hr")} if prev else None,
                               "last": c["m"][-1]["d"]}
    return sum(1 for c in C if len(c["m"]) >= 2)


def bricks(acts):
    """Enchaînements vélo → course (moins de 20 min entre la fin du vélo et le départ de la course, même jour) : x["brick"]."""
    def mins(a):
        try: h, m = str(a.get("t") or "").split(":")[:2]; return int(h) * 60 + int(m)
        except ValueError: return None
    by = {}
    for a in acts: by.setdefault(a["d"], []).append(a)
    n = 0
    for d, L in by.items():
        L = sorted([a for a in L if mins(a) is not None], key=mins)
        for b, r in zip(L, L[1:]):
            if b["s"] != "bike" or r["s"] not in ("run", "trail"): continue
            gap = mins(r) - (mins(b) + (b.get("m") or 0))
            if not -3 <= gap <= 20: continue
            xb = b.get("x")
            blk = (r.get("x") or {}).get("blk") or []
            v10 = [q[1] for q in blk if q[0] < 10 and q[1]]
            vr = [q[1] for q in blk if q[0] >= 10 and q[1]]
            info = {"gap": max(0, round(gap)), "bike_km": round(b.get("km") or 0, 1), "bike_m": round(b.get("m") or 0)}
            if v10 and vr: info.update(v10=round(sum(v10) / len(v10), 3), vrest=round(sum(vr) / len(vr), 3))
            r["brick"] = info; b["brick"] = {"run": True}
            if r.get("x"): r["x"]["brick"] = info
            if xb: xb["brick"] = {"run": True, "run_km": round(r.get("km") or 0, 1)}
            n += 1
    return n


def _thin(L, n):
    """sous-échantillonne une liste de points (page plus légère ; le détail complet reste dans garmin/details/)"""
    if not L or len(L) <= n: return L
    k = len(L) / n
    return [L[int(i * k)] for i in range(n)] + [L[-1]]


def ui_payload(a, lite=False):
    """Données d'affichage compactes d'une séance détaillée (fiche de séance). lite : sans carte ni séries temporelles,
    pour l'historique au-delà de 6 semaines (taille de la page)."""
    x = a.get("x") or {}
    st = x.get("st") or {}
    p = {"id": str(a["id"]) if a.get("id") is not None else None, "d": a["d"], "t": a.get("t") or None, "s": a["s"], "nm": a.get("nm"), "m": a.get("m"), "km": a.get("km"), "hr": a.get("hr"), "el": a.get("el"),
         "cmp": a.get("cmp"), "out": x.get("out"), "zones": x.get("zones"), "te": x.get("te"), "te_lab": x.get("te_lab"),
         "ef": x.get("ef"), "dec": x.get("dec"), "trimp": x.get("trimp"), "rel": x.get("rel"), "wx": x.get("wx"),
         "gear": x.get("gear"), "dyn": x.get("dyn"), "trail": x.get("trail"), "bike": x.get("bike"), "best": x.get("best"),
         "prof": x.get("prof"), "trk": _thin(x.get("trk"), 220), "blk": x.get("blk"), "route": x.get("route"), "brick": x.get("brick"), "watch": x.get("watch")}
    if st.get("kind") == "intervals":
        p["st"] = {k: st.get(k) for k in ("label", "n", "cv", "fade", "drift", "rec", "v", "hr")}
        p["bars"] = [[r.get("v"), r.get("hr")] for r in st.get("reps") or []][:30]
    if x.get("swim"): p["swim"] = x["swim"]
    if x.get("str"): p["str"] = x["str"]
    p["coach"] = coach_lines(a)
    if lite:
        for k in ("prof", "trk", "blk", "bars"): p.pop(k, None)
    return {k: v for k, v in p.items() if v not in (None, [], {})}


def coach_lines(a):
    """2 ou 3 phrases : ce qui est bien, ce qui change pour la suite."""
    x, c = a.get("x") or {}, a.get("cmp") or {}
    L = []
    st, out = x.get("st") or {}, x.get("out")
    if out == "margin": L.append(f"Séries régulières ({st.get('label')}) : allure tenue jusqu'au bout ({fmt_pace(pace_s(st.get('v')))}/km en moyenne). La prochaine séance de ce type ajoute une répétition.")
    elif out == "struggle": L.append(f"L'allure a baissé de {r1(st.get('fade'), 0):.0f} % entre les premières et les dernières répétitions : la prochaine séance de ce type garde le même volume.")
    elif out == "ok" and st.get("label"): L.append(f"Séries {st.get('label')} correctement tenues (variation d'allure {r1(st.get('cv'), 0):.0f} %).")
    if x.get("dec") is not None:
        d = x["dec"]
        if d <= 5: L.append(f"Découplage cardiaque faible ({d:.0f} %) : très bonne endurance sur cette durée.".replace(".0 %", " %"))
        elif d >= 8: L.append(f"La FC a dérivé de {d:.0f} % à allure égale en seconde moitié : chaleur, fatigue ou allure un peu haute pour l'endurance.")
    t = x.get("trail") or {}
    if t.get("vam"): L.append(f"Vitesse ascensionnelle {t['vam']} m/h dans les montées" + (f", {t['walk']} % du temps en marche" if t.get("walk") else "") + ".")
    sw = x.get("swim") or {}
    if sw.get("label") and not c.get("code") in ("other",): L.append(f"Natation : {sw['label']}, {fmt_pace(sw.get('p100'))}/100 m en moyenne" + (f", SWOLF {sw['swolf']:.0f}" if sw.get("swolf") else "") + ".")
    sr = x.get("str") or {}
    if sr.get("ton"): L.append(f"Musculation : {sr['sets']} séries, " + f"{sr['ton']:,.0f}".replace(",", " ") + " kg soulevés au total.")
    if c.get("code") == "other": L.append("La charge réelle de cette séance est prise en compte pour la suite du plan, à la place de la séance prévue.")
    elif c.get("code") == "harder": L.append("Plus intense que prévu : la séance suivante est allégée si la fatigue le confirme.")
    elif c.get("code") == "partial": L.append("Séance écourtée : le volume manquant n'est pas rattrapé, la suite du plan reste inchangée.")
    return L[:3]


def trends(acts, T, weeks=8):
    """Tendances hebdomadaires sur 8 semaines à partir des séances détaillées."""
    mon = T - timedelta(days=T.weekday())
    W = []
    for k in range(weeks - 1, -1, -1):
        a0 = mon - timedelta(days=7 * k); a1 = a0 + timedelta(days=6)
        L = [a for a in acts if a.get("x") and a0.isoformat() <= a["d"] <= a1.isoformat()]
        runs = [a for a in L if a["s"] in ("run", "trail")]
        ef = mean([a["x"].get("ef") for a in runs if a["x"].get("ef") and (a["x"].get("rel") or {}).get("hr", 0) >= 0.85])
        dec = mean([a["x"].get("dec") for a in runs if a["x"].get("dec") is not None])
        swim = mean([(a["x"].get("swim") or {}).get("p100") for a in L if a["s"] == "swim"])
        swolf = mean([(a["x"].get("swim") or {}).get("swolf") for a in L if a["s"] == "swim"])
        ton = sum((a["x"].get("str") or {}).get("ton") or 0 for a in L)
        up = sum(a.get("el") or 0 for a in acts if a["s"] in ("run", "trail") and a0.isoformat() <= a["d"] <= a1.isoformat())
        z45 = sum(sum((a["x"].get("zones") or [0] * 5)[3:]) for a in L) / 60
        W.append({"w": a0.isoformat(), "ef": r1(ef, 3), "dec": r1(dec), "p100": r1(swim, 0), "swolf": r1(swolf), "ton": round(ton),
                  "up": round(up), "z45": round(z45)})
    return W


def best_curve(acts, T, days=90):
    out = {}
    for a in acts:
        if a["s"] not in ("run", "trail") or not a.get("x") or a["d"] < (T - timedelta(days=days)).isoformat(): continue
        for k, v in (a["x"].get("best") or {}).items():
            if k not in out or v < out[k]["t"]: out[k] = {"t": v, "d": a["d"]}
    return out


def _ef_ok(a):
    """sortie continue comparable : FC fiable, terrain roulant (< 15 m D+/km), pas de chaleur (< 24 °C), au moins 30 min"""
    x = a.get("x") or {}
    if a["s"] not in ("run", "trail") or not x.get("ef") or (x.get("rel") or {}).get("hr", 0) < 0.85: return False
    if (a.get("m") or 0) < 30: return False
    if a.get("km") and (a.get("el") or 0) / a["km"] >= 15: return False
    t = (x.get("wx") or {}).get("temp")
    return t is None or t < 24


def fatigue_signal(acts, T):
    """Efficacité aérobie des 7 derniers jours vs base des 8 semaines précédentes, à allure comparable (± 12 %), terrain roulant
    et hors chaleur. Signal faible : il ne pèse sur le plan que s'il est confirmé par le sommeil, la VFC ou le bilan (analysis)."""
    pool = [a for a in acts if _ef_ok(a) and a["d"] <= T.isoformat()]
    rec = [a for a in pool if a["d"] > (T - timedelta(days=7)).isoformat()]
    base = [a for a in pool if (T - timedelta(days=63)).isoformat() < a["d"] <= (T - timedelta(days=7)).isoformat()]
    if len(rec) < 2 or len(base) < 4: return None
    sp = lambda a: a["km"] / a["m"] if a.get("m") else 0
    ref = sorted(sp(a) for a in rec)[len(rec) // 2]
    base = [a for a in base if ref and abs(sp(a) - ref) / ref <= 0.12] or base
    if len(base) < 3: return None
    b = sorted(a["x"]["ef"] for a in base)[len(base) // 2]; r = mean([a["x"]["ef"] for a in rec])
    delta = (r - b) / b * 100
    fades = [a["x"].get("out") for a in acts if a.get("x") and (T - timedelta(days=10)).isoformat() < a["d"] <= T.isoformat() and a["x"].get("out")]
    return {"ef_delta": round(delta, 1), "n": len(rec), "nb": len(base), "struggles": fades.count("struggle"),
            "flag": delta <= -5 or (delta <= -3 and fades.count("struggle") >= 1)}


def load_scale(acts):
    """Facteur TRIMP -> échelle de charge Garmin, appris sur les séances où les deux existent (≥ 6) ; 1,0 sinon, borné 0,5-2."""
    r = [a["ld"] / a["x"]["trimp"] for a in acts if a.get("x") and a["x"].get("trimp") and not a.get("est") and a.get("ld_src") != "trimp"
         and (a.get("ld") or 0) > 5 and a["x"]["trimp"] > 5]
    if len(r) < 6: return 1.0
    r.sort(); return round(max(0.5, min(2.0, r[len(r) // 2])), 3)


def time_trials(acts, T, n=180):
    """Efforts « course » mesurés dans les séances (contre-la-montre, course non nommée) : meilleur effort couvrant ≥ 80 % de la
    sortie et ≥ 50 % du temps en zones 4-5. Servent de référence de forme, comme une course saisie."""
    out = []
    for a in acts:
        if a["s"] != "run" or not a.get("x") or a["d"] < (T - timedelta(days=n)).isoformat() or a["d"] > T.isoformat(): continue
        x = a["x"]; z = x.get("zones") or []
        if not z or sum(z) <= 0 or (z[3] + z[4]) / sum(z) < 0.5 or (x.get("rel") or {}).get("hr", 0) < 0.85: continue
        if (x.get("st") or {}).get("kind") == "intervals": continue
        for k, L in (("5k", 5.0), ("10k", 10.0), ("21k", 21.0975)):
            t = (x.get("best") or {}).get(k)
            if t and t >= 0.8 * (a.get("m") or 0) * 60 * (L / max(L, a.get("km") or L)):
                out.append({"date": a["d"], "name": f"effort mesuré {k.replace('k', ' km').replace('21 km', 'semi')}", "dist_km": L, "time_s": t})
    return out


def progression(acts, T, disc, fam_key):
    """Dernière séance de séries de la même discipline (21 jours) : 'margin' -> +1 répétition ; 'struggle' -> volume gardé.
    Garde-fous : FC fiable, pas de chaleur (≥ 24 °C : allure dégradée sans lien avec la forme), une seule hausse par 7 jours."""
    hist = sorted([a for a in acts if (T - timedelta(days=21)).isoformat() <= a["d"] < T.isoformat()
                   and a["s"] in ((disc,) if disc != "run" else ("run", "trail")) and (a.get("x") or {}).get("out")], key=lambda a: a["d"], reverse=True)
    if not hist: return None
    a = hist[0]; x = a["x"]
    hot = ((x.get("wx") or {}).get("temp") or 0) >= 24
    out = x["out"]
    if out == "struggle" and hot: out = "ok"                                    # chaleur : l'allure qui baisse ne dit rien de la forme
    if out == "margin":
        if (x.get("rel") or {}).get("hr", 1) < 0.85: out = "ok"
        if len(hist) >= 2 and hist[1]["x"].get("out") == "margin" and (_d(a["d"]) - _d(hist[1]["d"])).days < 7: out = "ok"   # déjà augmenté
    return {"out": out, "d": a["d"], "label": (x.get("st") or {}).get("label"), "hot": hot}


def _d(s): return date.fromisoformat(s)


KG_MAP = ((r"développé couché|bench", "BENCH_PRESS"), (r"développé (militaire|épaules)|overhead|shoulder", "SHOULDER_PRESS"),
          (r"squat", "SQUAT"), (r"soulevé de terre|deadlift", "DEADLIFT"), (r"traction|pull.?up|chin", "PULL_UP"),
          (r"rowing|row\b|tirage", "ROW"), (r"fente|lunge", "LUNGE"), (r"pompe|push.?up", "PUSH_UP"), (r"dips?", "DIP"),
          (r"curl", "CURL"), (r"hip thrust|pont", "HIP_RAISE"), (r"mollet|calf", "CALF_RAISE"), (r"presse|leg press", "LEG_PRESS"))


def kg_hint(name, acts, T):
    """Charge conseillée d'après la dernière séance détaillée du même exercice (progression si toutes les séries étaient pleines)."""
    cat = next((c for rx, c in KG_MAP if re.search(rx, name or "", re.I)), None)
    if not cat: return None
    for a in sorted(acts, key=lambda a: a["d"], reverse=True):
        if a["d"] >= T.isoformat() or a["d"] < (T - timedelta(days=35)).isoformat(): continue
        for e in ((a.get("x") or {}).get("str") or {}).get("ex") or []:
            if e.get("cat") == cat and e.get("kg"):
                reps = [r for r, k in e.get("detail") or [] if k == e["kg"]]
                full = len(reps) >= 2 and min(reps) >= max(reps) - 1
                step = 5.0 if group_of(cat) == "legs" else 2.5
                nxt = e["kg"] + step if full else e["kg"]
                return {"last": e["kg"], "reps": reps, "next": nxt, "d": a["d"], "e1rm": e.get("e1rm"),
                        "txt": f"dernière fois {('%g' % e['kg']).replace('.', ',')} kg × {'/'.join(map(str, reps))} → "
                               f"{'vise ' + ('%g' % nxt).replace('.', ',') + ' kg' if full else 'garde ' + ('%g' % nxt).replace('.', ',') + ' kg'}"}
    return None


def mob_demand(acts, today):
    """Zones les plus sollicitées par les séances des 48 dernières heures, d'après leur contenu réel (v6) : descentes, séries,
    durée assise à vélo, volume de nage, groupes musculaires. -> thème de mobilité et exercices à inclure en priorité."""
    T = _d(today); score = {"course": 0.0, "velo": 0.0, "nage": 0.0}; must, why = [], []
    for a in acts:
        if not ((T - timedelta(days=2)).isoformat() < a["d"] <= T.isoformat()): continue
        x = a.get("x") or {}; age = 1.0 if a["d"] == today else 0.7
        if a["s"] in ("run", "trail"):
            sc = (a.get("m") or 0) / 60
            dn = (x.get("trail") or {}).get("dn") or 0
            if dn >= 300: sc += dn / 400; must += ["quad_debout", "tibial"]; why.append(f"{int(dn)} m de descente")
            if (x.get("st") or {}).get("kind") == "intervals": sc += 0.8; must += ["mollet_mur", "soleaire"]; why.append("séries rapides")
            if (a.get("km") or 0) >= 18: must += ["flechisseur", "ischio_debout"]
            score["course"] += sc * age
        elif a["s"] == "bike":
            sc = (a.get("m") or 0) / 60 * 0.8
            if (a.get("m") or 0) >= 120: must += ["flechisseur", "canape", "chat_vache"]; why.append("longue position assise à vélo")
            if ((x.get("bike") or {}).get("climbs") or 0) >= 3: must += ["quad_debout"]
            score["velo"] += sc * age
        elif a["s"] == "swim":
            d = (x.get("swim") or {}).get("d") or (a.get("km") or 0) * 1000
            sc = d / 2000
            if d >= 2000: must += ["rotation_externe", "ouverture_thoracique"]; why.append(f"{fmt_dist(d)} de nage")
            score["nage"] += sc * age
        elif a["s"] == "strength":
            g = (x.get("str") or {}).get("groups") or {}
            if (g.get("legs") or 0) >= 4: must += ["pigeon", "ischio_sangle"]; score["course"] += 0.6 * age; why.append("séance jambes")
            if (g.get("push") or 0) >= 4: must += ["pec_porte"]
            if (g.get("pull") or 0) >= 4: must += ["ouverture_thoracique"]
    if not any(score.values()): return None
    th = max(score, key=score.get)
    seen = []
    for m in must:
        if m not in seen: seen.append(m)
    return {"theme": th, "must": seen[:4], "why": ", ".join(dict.fromkeys(why))[:120] or None, "score": {k: round(v, 2) for k, v in score.items()}}


def gear_km(acts, T):
    """Kilométrage par équipement (chaussures, vélo) sur les séances détaillées, alerte au-delà de 700 km pour des chaussures."""
    G = {}
    for a in acts:
        for g in ((a.get("x") or {}).get("gear") or []):
            e = G.setdefault(g, {"name": g, "km": 0.0, "n": 0, "last": a["d"], "run": a["s"] in ("run", "trail")})
            e["km"] += a.get("km") or 0; e["n"] += 1; e["last"] = max(e["last"], a["d"])
    out = sorted(G.values(), key=lambda e: -e["km"])
    for e in out:
        e["km"] = round(e["km"]); e["alert"] = e["run"] and e["km"] >= 700
    return out[:6]


def summary_block(acts, T, glob, cov, ath):
    """Bloc global A['detail'] : tendances, records, signaux, indicateurs Garmin, matériel, couverture."""
    swims = [(a.get("x") or {}).get("swim") for a in acts if a["s"] == "swim" and (a.get("x") or {}).get("swim")
             and a["d"] >= (T - timedelta(days=120)).isoformat()]
    g_last = glob.get(max(glob)) if glob else {}
    lt = (g_last or {}).get("lt_hr")
    cfg_lt = (ath or {}).get("lthr_run")
    out = {"trends": trends(acts, T), "best": best_curve(acts, T), "fatigue": fatigue_signal(acts, T), "css": css_from(swims),
           "garmin": g_last or {}, "gear": gear_km(acts, T), "coverage": cov,
           "vo2_hist": [[d, v.get("vo2_run")] for d, v in sorted(glob.items())[-60:] if v.get("vo2_run")] if glob else []}
    if lt and cfg_lt and abs(lt - cfg_lt) >= 4:
        out["lthr_note"] = f"Garmin estime ton seuil cardiaque à {lt:.0f} bpm (réglage actuel : {cfg_lt} bpm). À confirmer par un test ou une course avant de changer config.py."
    return {k: v for k, v in out.items() if v not in (None, [], {})}
