"""Programme PPL (30 séances) adapté — généré depuis Programme_Optimal_PPL___Triathlon.md."""
PROGRAM = [{'type': 'push',
  'n': 1,
  'title': 'Force Fondamentale Pecs/Épaules',
  'cat': 'Pecs & Épaules Ciblés',
  'ex': [{'name': 'Développé couché barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé militaire debout barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé incliné haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Écartés à la poulie vis-à-vis', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 2,
  'title': 'Focus Développé Incliné & Deltoïde Média',
  'cat': 'Pecs & Épaules Ciblés',
  'ex': [{'name': 'Développé incliné à la barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé épaules assis à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé couché convergente assis', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales à la poulie basse', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Pec Deck / Machine écarté poitrine', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 3,
  'title': 'Charge Lourde & Stabilité',
  'cat': 'Pecs & Épaules Ciblés',
  'ex': [{'name': 'Développé couché avec haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé Arnold assis', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Dips lestés', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales unilatérales poulie', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé vertical à la machine', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 4,
  'title': 'Tension Continue Pecs & Triceps',
  'cat': 'Pecs & Triceps Ciblés',
  'ex': [{'name': 'Développé couché à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé couché prise serrée', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Dips à la machine convergente', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Écartés couché aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension triceps au-dessus de la tête à la poulie basse',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''}]},
 {'type': 'push',
  'n': 5,
  'title': 'Force Polyarticulaire Triceps & Pecs',
  'cat': 'Pecs & Triceps Ciblés',
  'ex': [{'name': 'Dips lestés sur barres parallèles', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé incliné haltères prise neutre', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Barre au front / Skullcrusher barre EZ', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Pushdown triceps poulie haute barre droite', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Écartés bas-vers-haut à la poulie', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 6,
  'title': 'Isolation Hypertrophie Triceps & Pecs',
  'cat': 'Pecs & Triceps Ciblés',
  'ex': [{'name': 'Développé couché convergente lourde', 'kind': 'Guidé', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension triceps californienne (Barre EZ au torse)',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Pushdown triceps à la corde', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé incliné à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension triceps unilatérale à la poulie haute', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 7,
  'title': 'Équilibre Global PUSH',
  'cat': 'Triade Complète (Pecs, Triceps & Épaules)',
  'ex': [{'name': 'Développé couché barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé militaire aux haltères assis', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé incliné convergente', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension triceps poulie haute corde', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Dips à la machine', 'kind': 'Guidé', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 8,
  'title': 'Force Maximale Haut du Corps',
  'cat': 'Triade Complète (Pecs, Triceps & Épaules)',
  'ex': [{'name': 'Développé militaire strict debout', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-5', 'unit': 'reps', 'note': ''},
         {'name': 'Développé couché lourd', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-5', 'unit': 'reps', 'note': ''},
         {'name': 'Dips lestés', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Barre au front sur banc incliné', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales poulie', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Ecartés poulie vis-à-vis', 'kind': 'Guidé', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 9,
  'title': 'Contrôle Tension & Amplitude',
  'cat': 'Triade Complète (Pecs, Triceps & Épaules)',
  'ex': [{'name': 'Développé incliné aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé épaules à la machine guidée', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Développé couché à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Pushdown triceps barre V poulie', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales unilatérales haltères sur banc incliné',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Extension triceps unilatérale à la poulie', 'kind': 'Guidé', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'push',
  'n': 10,
  'title': "Volume & Variabilité d'Angles",
  'cat': 'Triade Complète (Pecs, Triceps & Épaules)',
  'ex': [{'name': 'Développé couché prise neutre aux haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Développé militaire à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Chest Fly à la machine / Pec Deck', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension triceps buste penché à la poulie', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Élévations latérales poulie basse derrière le dos', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Dips au poids du corps ou légèrement lestés',
          'kind': 'Poids libre',
          'sets': 3,
          'reps': '6',
          'unit': 'reps',
          'note': ''}]},
 {'type': 'pull',
  'n': 1,
  'title': 'Force Tractions & Biceps',
  'cat': 'Pull Focus Biceps',
  'ex': [{'name': 'Tractions supination lestées', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing barre buste penché pronation', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl à la barre EZ debout', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Tirage horizontal poulie basse prise neutre', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl incliné aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 2,
  'title': 'Isolation Biceps & Épaisseur Dos',
  'cat': 'Pull Focus Biceps',
  'ex': [{'name': 'Rowing T-Bar', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Tirage vertical poulie haute supination', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl pupitre (Scott) à la barre EZ', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl concentré à un bras', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Tirage vertical unilatéral machine convergente', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 3,
  'title': 'Tension Continue Biceps',
  'cat': 'Pull Focus Biceps',
  'ex': [{'name': 'Tractions prise neutre lestées', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing haltère unilatéral sur banc', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl pupitre à la machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl vis-à-vis aux poulies hautes (Biceps "Spider")',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Pull-over à la poulie haute', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 4,
  'title': 'Grip & Brachial',
  'cat': 'Pull Focus Avant-bras & Grip',
  'ex': [{'name': 'Rowing barre buste penché pronation lourde',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '4-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Tirage horizontal poulie basse prise pronation large',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Curl marteau (Hammer curl) haltères lourds',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Curl inversé à la barre EZ', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': "Farmer's Walk (Marche du fermier haltères très lourds)",
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '30-45',
          'unit': 's',
          'note': ''}]},
 {'type': 'pull',
  'n': 5,
  'title': 'Avant-bras & Flexion de Poignet',
  'cat': 'Pull Focus Avant-bras & Grip',
  'ex': [{'name': 'Tractions pronation lestées', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing à la machine convergente prise neutre', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Wrist Curl (Flexion des poignets) à la barre assis sur banc',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Reverse Wrist Curl (Extension des poignets) barre ou haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Curl marteau à la poulie basse avec corde', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 6,
  'title': 'Endurance de Force Avant-bras / Grip',
  'cat': 'Pull Focus Avant-bras & Grip',
  'ex': [{'name': 'Rowing Seal / Rowing sur banc incliné aux haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '4-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Tirage vertical poitrine prise large pronation', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl inversé à la poulie basse', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Plate Pinch Hold (Maintien de disques de fonte à la force des doigts)',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '30-45',
          'unit': 's',
          'note': ''},
         {'name': 'Face Pull à la poulie haute', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 7,
  'title': 'Force Globale Tirage',
  'cat': 'Pull Polyvalent (Biceps & Avant-bras)',
  'ex': [{'name': 'Tractions lestées pronation', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing T-Bar guidé ou libre', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl barre EZ debout', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl marteau haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Tirage horizontal poulie basse prise V', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Extensions de poignet à la poulie', 'kind': 'Guidé', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 8,
  'title': 'Épaisseur & Bras Complet',
  'cat': 'Pull Polyvalent (Biceps & Avant-bras)',
  'ex': [{'name': 'Rowing machine convergente unilatéral', 'kind': 'Guidé', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Tirage vertical prise neutre serrée', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl incliné haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl inversé barre droite', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Shrugs aux haltères ou barre (Piège du grip)',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Face Pull corde poulie', 'kind': 'Guidé', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 9,
  'title': 'Largeur de Dos & Force de Préhension',
  'cat': 'Pull Polyvalent (Biceps & Avant-bras)',
  'ex': [{'name': 'Tirage vertical lourd poulie haute', 'kind': 'Guidé', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing buste penché aux haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl pupitre unilatéral haltère', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl marteau en travers du corps (Pinwheel curl)',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Pull-over poulie haute', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Wrist Curl barre derrière le dos debout', 'kind': 'Poids libre', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'pull',
  'n': 10,
  'title': 'Biceps & Avant-bras Machine/Libre',
  'cat': 'Pull Polyvalent (Biceps & Avant-bras)',
  'ex': [{'name': 'Tractions supination au poids du corps ou lestées',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '4-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Tirage horizontal machine convergente', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl à la poulie basse avec barre EZ', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Curl marteau poulie basse avec corde', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Rowing unilatéral à la poulie basse', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Suspension passive à une ou deux mains à la barre de traction',
          'kind': 'Grip',
          'sets': 3,
          'reps': 'max',
          'unit': 'temps',
          'note': ''}]},
 {'type': 'legs',
  'n': 1,
  'title': 'Unilatéral & Stabilité (Spécial Course)',
  'cat': '',
  'ex': [{'name': 'Bulgarian Split Squats (Fentes bulgares) avec haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps/jambe',
          'note': ''},
         {'name': 'Soulevé de terre roumain (RDL) barre ou haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Presse à cuisses inclinée lourde', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Leg Curl assis', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Mollets debout à la machine',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': "Temps d'arrêt de 1s en bas"}]},
 {'type': 'legs',
  'n': 2,
  'title': 'Puissance Quadriceps & Cyclisme',
  'cat': '',
  'ex': [{'name': 'Back Squat barre',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '4-6',
          'unit': 'reps',
          'note': 'Contrôle strict à la descente'},
         {'name': 'Hip Thrust barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': 'Puissance fessiers'},
         {'name': 'Presse à cuisses unilatérale', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Leg Extension', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Mollets assis (Soléaire pour le vélo)', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 3,
  'title': 'Protection Genoux & Buste Érigé',
  'cat': '',
  'ex': [{'name': 'Front Squat (Squat avant barre)', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Fentes marchées avec haltères lourds', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'pas/jambe', 'note': ''},
         {'name': 'Soulevé de terre roumain unilatéral aux haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps/jambe',
          'note': ''},
         {'name': 'Leg Curl couché', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Gainage dynamique / Ab Wheel (Roulette)', 'kind': 'Poids libre', 'sets': 3, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 4,
  'title': 'Chaîne Postérieure Lourd (Anti-Blessures)',
  'cat': '',
  'ex': [{'name': 'Soulevé de terre conventionnel ou Sumo (Deadlift)',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '4-5',
          'unit': 'reps',
          'note': ''},
         {'name': 'Bulgarian Split Squat à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Good Morning barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': 'Charge modérée'},
         {'name': 'Leg Curl assis', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension mollets unilatérale avec haltère',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps/jambe',
          'note': ''}]},
 {'type': 'legs',
  'n': 5,
  'title': 'Sécurité Dorsale & Charge Ciblée',
  'cat': '',
  'ex': [{'name': 'Hack Squat à la machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Hip Thrust à la machine ou Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Fentes arrière (Reverse Lunges) avec haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps/jambe',
          'note': ''},
         {'name': 'Leg Extension unilatéral', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Mollets à la presse à cuisses', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 6,
  'title': 'Amplitude & Mobilité',
  'cat': '',
  'ex': [{'name': 'Goblet Squat lourd avec kettlebell/haltère',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': 'Amplitude maximale'},
         {'name': 'Soulevé de terre jambes tendues/semi-tendues aux haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps',
          'note': ''},
         {'name': 'Step-up (Montées sur banc/boîte haute) avec haltères',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '5-6',
          'unit': 'reps/jambe',
          'note': ''},
         {'name': 'Leg Curl couché', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Extension mollets debout à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 7,
  'title': 'Force Globale Bas du Corps',
  'cat': '',
  'ex': [{'name': 'Squat barre basse (Low Bar Squat)', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Soulevé de terre roumain barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Presse à cuisses horizontale', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Adducteurs à la machine',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '6',
          'unit': 'reps',
          'note': 'Stabilité du bassin en course'},
         {'name': 'Mollets debout machine', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 8,
  'title': 'Focus Stabilité Hanches & Fessiers',
  'cat': '',
  'ex': [{'name': 'Bulgarian Split Squat lourd', 'kind': 'Poids libre', 'sets': 4, 'reps': '4-6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Hack Squat', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Glute Ham Raise ou Nordic Hamstring Curl', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Leg Extension', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Mollets assis', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''}]},
 {'type': 'legs',
  'n': 9,
  'title': 'Polyvalent Unilatéral / Machine',
  'cat': '',
  'ex': [{'name': 'Fentes marchées à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '5-6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Soulevé de terre roumain unilatéral à la poulie basse',
          'kind': 'Guidé',
          'sets': 4,
          'reps': '6',
          'unit': 'reps/jambe',
          'note': ''},
         {'name': 'Presse à cuisses unilatérale', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Leg Curl assis unilatéral', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Gainage latéral lesté', 'kind': 'Poids libre', 'sets': 3, 'reps': '30', 'unit': 's/côté', 'note': ''}]},
 {'type': 'legs',
  'n': 10,
  'title': 'Renforcement Fonctionnel Triathlète',
  'cat': '',
  'ex': [{'name': 'Front Squat à la Smith machine', 'kind': 'Guidé', 'sets': 4, 'reps': '4-6', 'unit': 'reps', 'note': ''},
         {'name': 'Hip Thrust barre', 'kind': 'Poids libre', 'sets': 4, 'reps': '5-6', 'unit': 'reps', 'note': ''},
         {'name': 'Step-Up latéral avec haltères', 'kind': 'Poids libre', 'sets': 4, 'reps': '6', 'unit': 'reps/jambe', 'note': ''},
         {'name': 'Leg Curl couché', 'kind': 'Guidé', 'sets': 4, 'reps': '6', 'unit': 'reps', 'note': ''},
         {'name': 'Mollets debout unilatéral au poids du corps avec haltère',
          'kind': 'Poids libre',
          'sets': 4,
          'reps': '6',
          'unit': 'reps/jambe',
          'note': ''}]}]

# ───────────────────────── Logique (stdlib uniquement, déterministe) ─────────────────────────
import re, hashlib

TYPES = {"push": ("Push", "Pecs · épaules · triceps"),
         "pull": ("Pull", "Dos · biceps · avant-bras"),
         "legs": ("Legs", "Jambes · chaîne postérieure · unilatéral")}
ORDER = ["push", "pull", "legs"]

WARMUP = {
    "title": "Échauffement standard (10 min)",
    "phases": [
        "Articulaire & vasculaire (3 min) : cardio léger rameur/vélo + mobilisations épaules, hanches, poignets, chevilles.",
        "Activation ciblée (3 min) : {act}",
        "Montée en charge (4 min) sur le 1er exercice lourd : 50 % × 8, 70 % × 5, 85 % × 2, puis 2 min de repos avant les séries utiles.",
    ],
    "act": {
        "push": "Y-T-W à l'élastique, rotations externes d'épaule (coiffe).",
        "pull": "pull-apart à l'élastique, tirage menton léger, suspension passive/active.",
        "legs": "monster walk à l'élastique, ponts fessiers unilatéraux, mobilité de cheville.",
    },
}
GUIDE = [
    "Progression : dès que toutes les séries atteignent le haut de la fourchette de répétitions avec une technique propre, ajoute 2,5 à 5 % de charge à la séance suivante.",
    "Concurrent training : sépare une séance Legs lourde d'une séance clé de course ou de vélo (seuil, VMA) d'au moins 6 h, idéalement 24 h.",
    "Repos : 2'30–3' sur les polyarticulaires lourds en poids libre ; 1'30–2' sur machines guidées et isolation.",
]

_ISO = re.compile(r"(élévation|curl|pushdown|extension triceps|barre au front|skullcrusher|écarté|pec deck|pull-over|shrug|face pull|wrist|poignet|mollet|adducteur|abducteur|leg extension|nordic|glute ham|gainage|avant-bras|farmer|suspension|rotation)", re.I)
_REPS_ADAPT = [  # (regex, nouvelle fourchette, raison)
    (r"nordic|glute ham", None, "Exercice très exigeant pour les ischios : limité à 3 séries de 3-5 reps (tolérance tendineuse, courbatures qui gêneraient la course)."),
    (r"élévation.*latérale", "10-12", "Deltoïde médian : petit muscle, tolère mal les charges lourdes ; 10-12 reps préservent la technique."),
    (r"curl|barre au front|skullcrusher|shrug|extension triceps|pushdown", "8-10", "Isolation mono-articulaire : 8-10 reps limitent le stress articulaire (coude, poignet) pour une tension équivalente."),
    (r"écarté|pec deck|pull-over|leg extension|adducteur|abducteur", "8-12", "Exercice d'étirement/isolation : mieux toléré (épaule, genou) en 8-12 reps."),
    (r"face pull|wrist|poignet|avant-bras", "12-15", "Petits stabilisateurs/avant-bras : tolèrent et demandent plus de répétitions."),
    (r"mollet", "8-10", "Mollets : amplitude complète et pause en bas, 8-10 reps pour travailler le tendon d'Achille sans excès de charge."),
]
_REST = {"heavy": (135, "2'30-3'"), "guided": (100, "1'30-2'"), "timed": (110, "2'")}

def _rest(e):
    if e["unit"] in ("s", "s/côté", "temps"): return _REST["timed"]
    if e["kind"] == "Poids libre" and not _ISO.search(e["name"]): return _REST["heavy"]
    return _REST["guided"]

def adapt_exercise(e):
    """Retourne une copie adaptée + raison (None si inchangé)."""
    x = dict(e); x["adapted"] = False; x["why"] = ""; x["orig"] = None
    if e["unit"] in ("reps", "reps/jambe") and re.fullmatch(r"\d+(-\d+)?", e["reps"]):
        for rx, new, why in _REPS_ADAPT:
            if re.search(rx, e["name"], re.I):
                x["orig"] = f'{e["sets"]}×{e["reps"]}'
                if new: x["reps"] = new
                if re.search("nordic|glute ham", e["name"], re.I): x["sets"] = min(x["sets"], 3); x["reps"] = "3-5"
                x["adapted"] = True; x["why"] = why; break
    if re.search("dips", e["name"], re.I):
        x["note"] = (x["note"] + " " if x["note"] else "") + "Descends jusqu'à ~90° de flexion de coude, pas plus (protège l'épaule)."
        if not x["adapted"]: x["adapted"] = True; x["orig"] = f'{e["sets"]}×{e["reps"]}'; x["why"] = "Amplitude limitée à 90° de coude pour protéger l'épaule."
    s, label = _rest(x); x["rest_s"] = s; x["rest"] = label
    return x

def scale_sets(i, base, faf):
    """Modulation du volume par le FAF (0,5–1,15)."""
    if faf >= 0.95: return base
    if faf >= 0.80: return base if i < 2 else max(2, base - 1)
    if faf >= 0.65: return min(base, 3) if i < 2 else 2
    return 2 if i < 3 else 0

def effort_note(faf):
    if faf >= 0.95: return "Forme bonne : séance complète, charges de travail habituelles (1-2 reps en réserve)."
    if faf >= 0.80: return "Forme correcte : exercices principaux complets, volume réduit sur les accessoires (-1 série)."
    if faf >= 0.65: return "Forme moyenne : 3 séries sur les 2 premiers exercices, 2 sur les autres, charges -5 à -10 %."
    return "Forme dégradée : séance courte (3 exercices × 2 séries), charges -10 à -15 %, pas d'échec musculaire."

def _find(t, n):
    for s in PROGRAM:
        if s["type"] == t and s["n"] == n: return s
    raise KeyError((t, n))

PLYO = {"name": "Pliométrie : pogo jumps puis sauts sur place", "kind": "Poids du corps", "sets": 3, "reps": "8-10", "unit": "contacts",
        "note": "Contacts au sol les plus brefs possible, chevilles raides ; à faire frais, juste après l'échauffement (v5 : charges lourdes et pliométrie "
                "améliorent l'économie de course, Llanos-Lagos et al. 2024)."}


def render_session(s, faf=1.0):
    ex, dropped = [], []
    if s["type"] == "legs" and faf >= 0.85 and not any("plio" in e["name"].lower() for e in s["ex"]):
        s = dict(s, ex=[PLYO] + list(s["ex"]))
    for i, e in enumerate(s["ex"]):
        a = adapt_exercise(e); k = scale_sets(i, a["sets"], faf)
        if k <= 0: dropped.append(a["name"]); continue
        if k != a["sets"]:
            a["sr"] = f'{a["sets"]}→{k}'; a["sets"] = k
        else: a["sr"] = ""
        a["i"] = len(ex) + 1; ex.append(a)
    secs = sum(x["sets"] * (35 + x["rest_s"]) for x in ex)
    return {"id": f'{s["type"]}{s["n"]:02d}', "type": s["type"], "n": s["n"], "title": s["title"], "cat": s["cat"],
            "ex": ex, "min": round(10 + secs / 60), "dropped": dropped, "effort": effort_note(faf),
            "notes": [x["why"] for x in ex if x["why"]]}

def render_program(faf=1.0):
    out = {}
    for t in ORDER:
        out[t] = {"label": TYPES[t][0], "sub": TYPES[t][1],
                  "warmup": {"title": WARMUP["title"], "phases": [p.replace("{act}", WARMUP["act"][t]) for p in WARMUP["phases"]]},
                  "sessions": [render_session(_find(t, n), faf) for n in range(1, 11)]}
    return out

_STR = {"push": re.compile(r"push|pecs?|pectoraux|développé|epaule|épaule|triceps", re.I),
        "pull": re.compile(r"pull|dos\b|traction|biceps|tirage", re.I),
        "legs": re.compile(r"leg|jambe|squat|fente|quadri|fessier|presse", re.I)}
def type_from_name(name):
    for t in ORDER:
        if _STR[t].search(name or ""): return t
    return None

LEVELS = [(0.95, "Plein régime"), (0.80, "Normal"), (0.65, "Allégé"), (0.0, "Léger")]

def level_of(faf):
    return next(lab for lim, lab in LEVELS if faf >= lim)

def today_index(day, t):
    """N° (1-10) de la séance proposée pour ce type : avance de 1 à chaque jour, décalage fixe par type.
    Sur 10 jours on parcourt les 10 séances du type, jamais deux jours de suite la même."""
    off = int(hashlib.md5(("ppl." + t).encode()).hexdigest(), 16) % 10
    return (day.toordinal() + off) % 10 + 1

def muscu_payload(day, per_type, default_type, reason):
    """per_type : {type: {"faf": float, "why": [str]}} -> charge utile complète pour le dashboard.
    Chaque type contient ses 10 séances adaptées à SON facteur de forme (jambes allégées après une grosse sortie vélo,
    haut du corps allégé après une grosse natation, etc.)."""
    types = {}
    for t in ORDER:
        faf = per_type[t]["faf"]
        sessions = [render_session(_find(t, n), faf) for n in range(1, 11)]
        types[t] = {"label": TYPES[t][0], "sub": TYPES[t][1], "faf": round(faf, 2), "level": level_of(faf),
                    "why": per_type[t]["why"], "effort": effort_note(faf), "today_n": today_index(day, t),
                    "warmup": {"title": WARMUP["title"], "phases": [p.replace("{act}", WARMUP["act"][t]) for p in WARMUP["phases"]]},
                    "sessions": sessions}
    names = {e["name"] for t in types.values() for s in t["sessions"] for e in s["ex"]}
    try:
        import exo_tips                                      # fiches conseils du bouton « i » : une par exercice affiché
        tips = exo_tips.fiches(sorted(names))
    except Exception:                                        # noqa: BLE001 : jamais bloquant pour le dashboard
        tips = {}
    return {"default": default_type, "reason": reason, "guide": GUIDE, "types": types, "tips": tips}
