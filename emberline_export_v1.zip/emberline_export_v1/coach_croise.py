"""Évolution croisée pour « Le mot du coach ».

Le mot du coach ne parle que de la période choisie (1 semaine, 1 mois ou 3 mois) et de SA note /20, calculée par
analysis.pillars_period sans aucune influence des autres périodes. Ce module ajoute la lecture de son évolution à la lumière
des deux autres :
  - 1 semaine : volume de la semaine face à la moyenne hebdo du mois et des 3 mois, note de la semaine face au mois
                (et au pilier qui fait la différence), comparaison avec la semaine précédente ;
  - 1 mois    : volume du mois face au rythme de fond des 3 mois, dernière semaine qui confirme ou inverse le mois,
                comparaison avec le mois précédent ;
  - 3 mois    : tendance de fond (première moitié contre seconde moitié du trimestre), forme récente (mois et semaine)
                face au niveau de fond.
Il dit aussi si la période choisie est en baisse (note ou performance) : le coach adopte alors « Grosbichou » comme surnom
principal et un ton plus piquant (voir bilan_bank.compose). Les phrases sont des banques (variables entre accolades) choisies
par rotation déterministe et par la mémoire anti-redondance du coach : même date + mêmes données = même texte."""
import hashlib
import math
from datetime import timedelta

GROS = "Grosbichou"
D_SCALE = 0.3                      # écart de note significatif entre deux échelles (points sur 20)
D_PREV = 0.5                       # écart significatif avec la période précédente de même durée
VOL_PIC, VOL_CREUX = 1.22, 0.78    # volume de la semaine / moyenne hebdo du mois
VOL_UP, VOL_DOWN = 1.12, 0.88      # volume hebdo du mois / moyenne hebdo des 3 mois
PNAME = {"run": "la course à pied", "load": "la gestion de la charge", "rec": "la récupération", "cross": "le renfo et le multisport"}

PIL = {"run": "course à pied", "load": "gestion de la charge", "rec": "récupération", "cross": "renfo et multisport"}
APNAME = {"run": "à la course à pied", "load": "à la gestion de la charge", "rec": "à la récupération", "cross": "au renfo et au multisport"}
N_EVOL = {"1S": 2, "1M": 2, "3M": 1}  # lectures croisées par paragraphe (3 mois : une seule, la situation y évolue lentement)

# =============================================================================================
# BANQUES « ÉVOLUTION » (insérées dans le mot du coach juste après l'accroche)
# Variables communes : {nick} {name} {win}. {pil} = nom nu du pilier (« le pilier {pil} », « côté {pil} »),
# {apname} = pilier précédé de « à » contracté (« grâce {apname} », « la faute {apname} ») : accords toujours justes.
# =============================================================================================
EV = {
    # ---------- 1 SEMAINE : volume de la semaine face à la moyenne hebdo du mois (et des 3 mois) ----------
    "w_vol_creux": [
        "Cette semaine, {wh} h d'entraînement contre {mh} h par semaine en moyenne sur le mois ({wp}) : le volume a fondu comme neige au soleil.",
        "{wh} h seulement sur 7 jours, quand ton mois tourne à {mh} h par semaine ({wp}) : la semaine a levé le pied, {nick}.",
        "Le volume de la semaine décroche : {wh} h contre {mh} h/sem sur le mois ({wp}) et {fh} h/sem sur 3 mois.",
        "Par rapport au mois ({mh} h/sem), la semaine plonge à {wh} h ({wp}) : coup de frein volontaire ou panne d'envie ?",
        "En volume, la semaine est maigre : {wh} h, soit {wp} contre tes {mh} h hebdomadaires du mois.",
        "{wh} h au compteur en sept jours, ton mois en affiche {mh} par semaine ({wp}) : on a connu des semaines plus gourmandes.",
        "Petite semaine, très petite même : {wh} h, pour une moyenne mensuelle de {mh} h ({wp}). Les baskets ont pris des vacances sans prévenir.",
        "Sept jours, {wh} h : c'est {wp} par rapport à ton tempo du mois ({mh} h/sem), et ton trimestre tourne à {fh} h. La pédale de frein a été écrasée.",
        "Diète sévère côté volume : {wh} h cette semaine contre {mh} h/sem d'habitude ce mois-ci ({wp}). Repos voulu ou flemme déguisée, {nick} ?",
        "La semaine fait régime : {wh} h, soit {wp} face aux {mh} h hebdomadaires du mois.",
        "Semaine en pointillés : {wh} h quand ton mois en aligne {mh} par semaine ({wp}).",
        "On a rangé le dossard un peu tôt : {wh} h en sept jours, {wp} contre les {mh} h/sem du mois.",
        "{wh} h, et c'est tout : ton mois tournait à {mh} h/sem ({wp}). La montre s'ennuie, {nick}.",
        "Le réservoir d'heures se vide : {wh} h cette semaine, {wp} sous le régime du mois ({mh} h/sem).",
    ],
    "w_vol_pic": [
        "Cette semaine, {wh} h au compteur, soit {wp} face à ton mois ({mh} h/sem) : tu as appuyé fort, reste à le digérer.",
        "Semaine chargée : {wh} h contre {mh} h/sem sur le mois ({wp}) et {fh} h/sem sur 3 mois. Le chaudron a pris des tours.",
        "{wh} h en 7 jours, bien au-dessus de ton rythme du mois ({mh} h/sem, {wp}) : la semaine sort du lot.",
        "Gros volume cette semaine ({wh} h, {wp} par rapport au mois) : de quoi construire, à condition de récupérer derrière.",
        "Grosse cylindrée cette semaine : {wh} h, soit {wp} contre ton tempo du mois ({mh} h/sem).",
        "{wh} h en sept jours contre {mh} h/sem en moyenne ce mois-ci ({wp}) : tu as mis les bouchées doubles.",
        "La semaine déborde du cadre : {wh} h, soit {wp} sur le rythme du mois, et loin des {fh} h/sem du trimestre. Belle gourmandise, à digérer.",
        "Tu as ouvert les vannes : {wh} h cette semaine pour {mh} h/sem sur le mois ({wp}). L'élan est là, la récupération doit suivre.",
        "Semaine costaude, {wh} h ({wp} par rapport aux {mh} h hebdomadaires du mois) : le carnet d'entraînement prend du poids.",
        "{wp} de volume face au mois ({wh} h contre {mh} h/sem) : la semaine a faim, {nick}.",
        "Semaine XXL : {wh} h au compteur, {wp} contre le mois ({mh} h/sem). Gare à l'addition.",
        "Les heures s'empilent : {wh} h en sept jours, contre {mh} h/sem ce mois-ci ({wp}).",
        "Tu as fait le plein cette semaine : {wh} h, soit {wp} sur ton rythme mensuel, {nick}.",
        "{wh} h cette semaine, bien au-delà des {mh} h/sem du mois ({wp}) et des {fh} h/sem sur 90 jours.",
    ],
    "w_vol_normal": [
        "En volume, {wh} h cette semaine pour {mh} h/sem en moyenne sur le mois : la cadence est tenue.",
        "{wh} h sur la semaine, dans la droite ligne du mois ({mh} h/sem) et du trimestre ({fh} h/sem) : pas de trou, pas d'excès.",
        "Volume stable : {wh} h cette semaine, {mh} h/sem sur le mois. La régularité fait son travail.",
        "La semaine reste dans tes standards de volume ({wh} h contre {mh} h/sem sur le mois).",
        "Volume calé sur tes habitudes : {wh} h en sept jours, {mh} h/sem ce mois-ci.",
        "{wh} h cette semaine, quasiment ton tempo du mois ({mh} h/sem) : la mesure est tenue, comme une partition bien apprise.",
        "Rien à redire sur la quantité : {wh} h, pile dans ton tempo mensuel ({mh} h/sem).",
        "En heures, la semaine ({wh} h) ressemble trait pour trait à ton mois ({mh} h/sem) et à ton trimestre ({fh} h/sem).",
        "Le compteur affiche {wh} h, à peine différent des {mh} h hebdomadaires du mois : continuité tranquille.",
        "Même dose que d'habitude : {wh} h cette semaine pour {mh} h/sem sur le mois. Ni folie, ni paresse.",
        "Volume de croisière : {wh} h ces sept jours, à peine différent de ton mois ({mh} h/sem).",
        "La semaine coche la case heures sans forcer : {wh} h, dans le sillage des {mh} h/sem du mois.",
        "{wh} h cette semaine, du même tonneau que ton mois ({mh} h/sem) : le carnet reste bien tenu.",
        "Pas d'emballement ni de trou d'air : {wh} h cette semaine, {mh} h/sem sur le mois, {fh} h/sem sur 90 jours.",
        "La semaine reprend ta partition habituelle : {wh} h, pour {mh} h hebdomadaires ce mois-ci.",
    ],
    # ---------- 1 SEMAINE : note de la semaine face au mois (et au pilier qui fait la différence) ----------
    "w_note_down": [
        "Mais la note de la semaine ({s}) passe sous celle du mois ({s30}) : c'est le pilier {pil} qui tire vers le bas ({a}/4 contre {b}/4 sur 30 jours).",
        "La semaine ({s}) décroche du mois ({s30}) et du trimestre ({s90}) : côté {pil}, ça coince, {a}/4 contre {b}/4 sur le mois.",
        "Résultat : {s} cette semaine contre {s30} sur le mois, la faute {apname} ({a}/4 au lieu de {b}/4).",
        "La note glisse ({s} sur la semaine, {s30} sur le mois) et le coupable est tout trouvé : le pilier {pil}, {a}/4 contre {b}/4.",
        "Moins bien que ton mois ({s} contre {s30}) : le pilier {pil} a lâché du lest, de {b}/4 à {a}/4.",
        "{s} cette semaine, {s30} sur trente jours : la marche ratée porte un nom, {pil} ({a}/4, contre {b}/4 d'ordinaire).",
        "La semaine recule face au mois ({s} contre {s30}), et c'est surtout {apname} qu'on le doit : {a}/4 au lieu de {b}/4.",
        "Avec {s}, la semaine reste en dessous du mois ({s30}) ; le pilier {pil} plonge à {a}/4 (il tournait à {b}/4).",
        "Ton mois valait {s30}, ta semaine {s} : le pilier {pil} est passé de {b}/4 à {a}/4. Voilà la fuite.",
        "Recul net face au mois ({s} contre {s30}) : le pilier {pil} s'est fait la malle, {a}/4 contre {b}/4, {nick}.",
        "Sept jours à {s}, trente à {s30} : l'écart vient presque tout entier du pilier {pil}, tombé à {a}/4 (il était à {b}/4).",
        "Comparée au mois ({s30}), ta semaine ({s}) perd du terrain, et c'est {pil} qui cède : {a}/4 au lieu de {b}/4.",
        "La semaine ({s}) n'a pas suivi le rythme du mois ({s30}) ; regarde du côté du pilier {pil} : {b}/4 avant, {a}/4 maintenant.",
        "Entre ton mois ({s30}) et ta semaine ({s}), un pilier a flanché : {pil}, descendu de {b}/4 à {a}/4.",
        "Petite baisse face au mois ({s} contre {s30}) : {pil} explique l'essentiel, {a}/4 cette semaine pour {b}/4 habituellement.",
        "Le mois tenait {s30}, la semaine {s} : le décrochage se lit dans {pil}, revenu à {a}/4 après {b}/4.",
    ],
    "w_note_down_n": [
        "Mais la note de la semaine ({s}) passe sous celle du mois ({s30}) et du trimestre ({s90}).",
        "La semaine ({s}) fait moins bien que ton mois ({s30}) : petite glissade à surveiller.",
        "Résultat : {s} cette semaine contre {s30} sur le mois, la courbe pique du nez.",
        "Et la note ne rattrape rien : {s} cette semaine, en retrait de ton mois ({s30}).",
        "{s} pour la semaine contre {s30} pour le mois : ça s'effrite, doucement mais sûrement.",
        "La semaine ({s}) se range derrière le mois ({s30}) et le trimestre ({s90}) : pas glorieux, {nick}.",
        "Sur la note, la semaine perd du terrain : {s}, quand le mois tient {s30}.",
        "Ton mois affichait {s30}, ta semaine n'en vaut que {s} : la courbe s'affaisse.",
        "Note en repli : {s} sur 7 jours contre {s30} sur 30 jours. On a connu plus flamboyant.",
        "La semaine ({s}) recule face au mois ({s30}) : on a perdu un peu de mordant.",
        "{s} cette semaine contre {s30} sur le mois : le curseur glisse dans le mauvais sens, {nick}.",
        "Note de la semaine sous celle du mois ({s} contre {s30}) : petit coup de mou.",
    ],
    "w_note_up": [
        "Et la note suit : {s} cette semaine contre {s30} sur le mois et {s90} sur 3 mois, portée par le pilier {pil} ({a}/4 contre {b}/4).",
        "La semaine ({s}) dépasse le mois ({s30}) : le pilier {pil} fait la différence ({a}/4 contre {b}/4 sur 30 jours).",
        "Mention spéciale {apname} ({a}/4 cette semaine contre {b}/4 sur le mois) : c'est là que la semaine gagne son {s}.",
        "La semaine fait mieux que ton mois ({s} contre {s30}) grâce {apname} : de {b}/4 à {a}/4.",
        "{s} cette semaine contre {s30} sur le mois : le pilier {pil} a passé la surmultipliée, {a}/4 au lieu de {b}/4.",
        "Note en hausse face au mois ({s} contre {s30}), et le mérite revient surtout {apname} ({a}/4, contre {b}/4).",
        "Le mois tournait à {s30}, la semaine grimpe à {s} : côté {pil}, ça brille ({a}/4 contre {b}/4).",
        "Semaine au-dessus du lot ({s}, le mois est à {s30}) : le pilier {pil} passe de {b}/4 à {a}/4, joli coup.",
        "La note décolle ({s} contre {s30} sur trente jours) et le moteur s'appelle {pil} : {a}/4 contre {b}/4.",
        "Ta semaine ({s}) toise ton mois ({s30}) : merci {apname}, {a}/4 contre {b}/4.",
    ],
    "w_note_up_n": [
        "Et la note suit : {s} cette semaine contre {s30} sur le mois et {s90} sur 3 mois.",
        "La semaine ({s}) fait mieux que le mois ({s30}) : la forme récente monte d'un cran.",
        "Avec {s} cette semaine contre {s30} sur le mois, la courbe repart vers le haut.",
        "Note en progrès : {s} sur la semaine, {s30} sur le mois. Ça respire mieux.",
        "La semaine ({s}) passe devant le mois ({s30}) et le trimestre ({s90}) : jolie remontée, {nick}.",
        "{s} cette semaine, quand le mois plafonne à {s30} : la forme récente prend l'ascenseur.",
        "Ton mois valait {s30}, ta semaine vaut {s} : on monte d'un étage.",
        "Sur la note, la semaine prend l'avantage sur le mois ({s} contre {s30}).",
        "Avec {s}, la semaine bat le mois ({s30}) : signe que le travail commence à payer.",
        "La semaine ({s}) devance le mois ({s30}) : le curseur monte.",
        "{s} cette semaine contre {s30} sur le mois : tu remets du charbon, et ça se voit.",
        "Note de la semaine au-dessus de celle du mois ({s} contre {s30}) : bonne pioche.",
    ],
    "w_note_flat": [
        "La note de la semaine ({s}) colle à celle du mois ({s30}) : même niveau, même partition.",
        "{s} cette semaine, {s30} sur le mois, {s90} sur 3 mois : la semaine s'inscrit dans la continuité.",
        "Pas de surprise sur la note : la semaine ({s}) reste au niveau de ton mois ({s30}).",
        "Note de la semaine ({s}) calée sur le mois ({s30}) : constance, constance.",
        "{s} sur 7 jours, {s30} sur 30 : la semaine ne déroge pas à la règle.",
        "Même tarif que le mois pour la note ({s} contre {s30}) : du solide, sans fioriture.",
        "La semaine ({s}) ne s'écarte ni du mois ({s30}) ni du trimestre ({s90}) : stabilité suisse.",
        "Pas d'écart notable entre la semaine ({s}) et le mois ({s30}) : tu restes fidèle à toi-même.",
        "Sur la note, la semaine ({s}) photocopie le mois ({s30}).",
        "La semaine ({s}) et le mois ({s30}) se tiennent à un cheveu : aucune dérive.",
        "{s} cette semaine, {s30} sur trente jours : ligne droite, sans virage.",
        "La note de la semaine ({s}) épouse celle du mois ({s30}) et des 90 jours ({s90}).",
    ],
    # ---------- 1 MOIS : volume du mois contre le rythme de fond des 3 mois ----------
    "m_vol_up": [
        "Ce mois-ci, {mh} h d'entraînement par semaine contre {fh} h sur 3 mois ({mp}) : tu as remis du charbon dans la chaudière.",
        "Le mois pousse au-dessus de ta base : {mh} h/sem contre {fh} sur 3 mois ({mp}). Phase de construction assumée.",
        "{mp} de volume par rapport à ta base des 3 mois ({mh} contre {fh} h/sem) : le mois a de l'appétit.",
        "Le mois tourne à {mh} h hebdo, au-dessus de tes {fh} h habituelles sur 3 mois ({mp}) : tu as monté le son.",
        "{mh} h par semaine ce mois-ci, {fh} sur le trimestre ({mp}) : le mois a mis le turbo.",
        "Ce mois-ci, la jauge d'heures grimpe : {mh} h/sem contre {fh} h/sem sur 90 jours ({mp}).",
        "Gros mois : {mh} h hebdomadaires, {mp} face à ta base des 3 mois ({fh} h). Les fondations s'épaississent.",
        "Tu charges la mule ce mois-ci : {mh} h/sem pour {fh} h/sem sur le trimestre ({mp}). Construction en cours, {nick}.",
        "Plus d'heures que ton rythme de croisière : {mh} h par semaine contre {fh} ({mp}).",
        "Le mois force la dose : {mh} h/sem pour {fh} h/sem sur 90 jours ({mp}).",
        "Ce mois-ci, les heures grimpent : {mh} h hebdo contre les {fh} h de ta base ({mp}).",
        "Tu en remets une couche ce mois-ci : {mh} h/sem, {mp} face à tes 3 mois.",
        "Mois copieux : {mh} h hebdomadaires contre {fh} h sur 3 mois ({mp}), l'élan est là.",
        "Le compteur mensuel s'emballe : {mh} h/sem, là où tes 90 jours tournent à {fh} ({mp}).",
    ],
    "m_vol_down": [
        "Ce mois-ci, {mh} h par semaine contre {fh} h sur 3 mois ({mp}) : le mois vit sur les réserves du trimestre.",
        "Le mois décroche de ta base : {mh} h/sem contre {fh} sur 3 mois ({mp}). Tu grignotes ton capital.",
        "Moins de jus que d'habitude : {mh} h hebdo ce mois-ci contre {fh} h sur 3 mois ({mp}).",
        "Le mois rame un peu : {mh} h/sem contre {fh} h/sem sur le trimestre ({mp}).",
        "{mh} h hebdo ce mois-ci, alors que ton trimestre tourne à {fh} h ({mp}) : la cadence s'est relâchée, {nick}.",
        "Moins d'heures qu'à l'accoutumée : {mh} h par semaine contre {fh} sur 3 mois ({mp}). Le capital s'entame.",
        "Ce mois-ci, la jauge d'heures baisse : {mh} h/sem pour {fh} h/sem sur 90 jours ({mp}). On a vu plus vaillant.",
        "Le mois lève le pied : {mp} de volume face à ton trimestre ({mh} contre {fh} h/sem).",
        "Mois en sous-régime : {mh} h hebdomadaires, là où tes 3 mois en affichent {fh} ({mp}).",
        "Le mois s'allège : {mh} h/sem pour {fh} h/sem sur 90 jours ({mp}).",
        "Ce mois-ci, les heures fondent : {mh} h hebdo face aux {fh} h de ta base ({mp}), {nick}.",
        "Tu as levé le pied ce mois-ci : {mh} h/sem, {mp} contre tes 3 mois.",
        "Mois au ralenti : {mh} h hebdomadaires contre {fh} h sur 3 mois ({mp}).",
        "Le compteur mensuel s'essouffle : {mh} h/sem, là où tes 90 jours tournent à {fh} ({mp}).",
    ],
    "m_vol_flat": [
        "Ce mois-ci, {mh} h par semaine, quasiment ton rythme des trois derniers mois ({fh} h/sem) : continuité parfaite.",
        "Le volume du mois colle à ta base ({mh} contre {fh} h/sem) : le navire garde sa vitesse de croisière.",
        "{mh} h/sem sur le mois, {fh} sur 3 mois : même tempo, aucun à-coup.",
        "{mh} h hebdo ce mois-ci contre {fh} sur le trimestre : copie conforme.",
        "Le mois reprend exactement ton tempo des 3 mois : {mh} h/sem, pour {fh} h/sem sur 3 mois.",
        "Ni plus ni moins : {mh} h par semaine ce mois-ci, {fh} sur 3 mois. La routine fait son œuvre.",
        "Volume du mois aligné sur ta moyenne longue ({mh} contre {fh} h/sem) : du sérieux, sans coup d'éclat.",
        "En heures, le mois imite fidèlement le trimestre ({mh} h/sem contre {fh}).",
        "Le mois tient ta cadence : {mh} h/sem, pour {fh} h/sem sur 90 jours.",
        "Mois réglé comme une horloge : {mh} h hebdo, ta base en affiche {fh}.",
        "Ce mois-ci, {mh} h/sem : la même ration que sur 3 mois ({fh}).",
        "Le volume du mois ne s'écarte pas de ta base : {mh} contre {fh} h/sem.",
        "Pile dans tes habitudes : {mh} h par semaine ce mois-ci, {fh} sur 90 jours.",
    ],
    # ---------- 1 MOIS : note du mois face aux 3 mois ----------
    "m_note_down": [
        "La note du mois ({s}) reste sous ta base ({s90}) : le mois n'a pas encore retrouvé ton standard.",
        "Avec {s} sur le mois contre {s90} sur 3 mois, la forme du moment est un cran sous ta moyenne.",
        "Le mois ({s}) fait moins bien que ton trimestre ({s90}) : la dynamique récente fléchit, {nick}.",
        "Note du mois ({s}) en retrait de tes 3 mois ({s90}) : le standard maison n'est pas atteint.",
        "{s} sur 30 jours contre {s90} sur 90 : le mois tire la langue.",
        "Le mois ({s}) se fait doubler par ton trimestre ({s90}) : pas de quoi pavoiser, {nick}.",
        "Ta moyenne longue tient {s90}, ton mois seulement {s} : la forme a pris un petit coup de mou.",
        "Le mois reste un ton en dessous du trimestre pour la note ({s} contre {s90}).",
        "Note du mois ({s}) en dessous de tes 90 jours ({s90}) : la courbe s'affaisse.",
        "Le mois ({s}) ne retrouve pas le niveau de tes 3 mois ({s90}).",
        "{s} ce mois-ci contre {s90} sur 3 mois : on a laissé filer quelques points, {nick}.",
        "Le mois recule face à ta base ({s} contre {s90}) : il faut remettre du rythme.",
    ],
    "m_note_up": [
        "La note du mois ({s}) dépasse ton niveau de fond ({s90}) : le mois relève la barre.",
        "Avec {s} sur le mois contre {s90} sur 3 mois, tu es au-dessus de ta base.",
        "Le mois ({s}) fait mieux que ton trimestre ({s90}) : la forme récente pousse dans le bon sens.",
        "Note du mois ({s}) au-dessus de tes 3 mois ({s90}) : le niveau grimpe.",
        "{s} sur 30 jours contre {s90} sur 90 : le mois tire tout le monde vers le haut.",
        "Ta moyenne longue est à {s90}, ton mois à {s} : la forme prend du galon, {nick}.",
        "Le mois devance le trimestre ({s} contre {s90}) : c'est ce qu'on appelle une bonne dynamique.",
        "Sur la note, le mois surclasse ta base de 3 mois ({s} contre {s90}).",
        "Note du mois ({s}) au-dessus de tes 90 jours ({s90}) : la courbe grimpe.",
        "Le mois ({s}) dépasse le niveau de tes 3 mois ({s90}).",
        "{s} ce mois-ci contre {s90} sur 3 mois : de beaux points gagnés, {nick}.",
        "Le mois prend le dessus sur ta base ({s} contre {s90}) : la forme suit.",
    ],
    # ---------- 1 MOIS : la dernière semaine confirme ou inverse le mois ----------
    "m_week_down": [
        "Et la dernière semaine ({s7}, {wh} h) tire la moyenne vers le bas : la fin de mois s'essouffle.",
        "Attention à la dernière semaine, plus faible ({s7}) que le mois ({s}) : le rythme commence à fléchir.",
        "La dernière semaine fait moins bien ({s7}) : le mois finit sur un ralentissement, {nick}.",
        "Sauf que la semaine écoulée ({s7}) fait moins bien que le mois ({s}) : la fin de période tousse.",
        "Les sept derniers jours ({s7}, {wh} h) baissent la moyenne : le mois finit au ralenti.",
        "Et la dernière ligne droite déçoit : {s7} sur la semaine contre {s} sur le mois.",
        "Petit bémol final : la semaine passée ({s7}) n'est pas à la hauteur du mois ({s}), {nick}.",
        "Mais la semaine la plus récente cale à {s7}, loin du {s} mensuel : il va falloir relancer.",
        "La semaine la plus récente ({s7}) décroche du mois ({s}) : finish poussif.",
        "Fin de mois en roue libre : {s7} sur les sept derniers jours, {s} sur le mois.",
        "Dernière semaine à {s7}, en retrait du mois ({s}) : la flamme vacille, {nick}.",
        "Les derniers jours ({s7}, {wh} h) tirent le mois vers le bas ({s}).",
    ],
    "m_week_up": [
        "Et la dernière semaine ({s7}) relève la moyenne : le mois finit plus fort qu'il n'a commencé.",
        "Bonne nouvelle, la dernière semaine ({s7}) fait mieux que le mois ({s}) : la dynamique est repartie.",
        "La dernière semaine ({s7}, {wh} h) donne le ton : ça remonte en fin de mois.",
        "Et les sept derniers jours ({s7}) font mieux que le mois ({s}) : la fin de période envoie du lourd.",
        "Bonus : la semaine écoulée ({s7}, {wh} h) tire le mois vers le haut.",
        "La dernière ligne droite est la plus forte : {s7} sur la semaine contre {s} sur le mois.",
        "Et ça finit fort : la semaine la plus récente grimpe à {s7}, au-dessus du {s} mensuel, {nick}.",
        "Le mois se termine en accélération, avec une semaine à {s7} contre {s} sur l'ensemble.",
        "La semaine la plus récente ({s7}) dépasse le mois ({s}) : finish en boulet de canon.",
        "Fin de mois tonique : {s7} sur les sept derniers jours, {s} sur le mois.",
        "Dernière semaine à {s7}, au-dessus du mois ({s}) : la flamme se ravive, {nick}.",
        "Les derniers jours ({s7}, {wh} h) poussent le mois vers le haut ({s}).",
    ],
    "m_week_flat": [
        "La dernière semaine ({s7}) reste dans le ton du mois : rien ne s'emballe, rien ne s'effondre.",
        "La semaine écoulée ({s7}) confirme le niveau du mois ({s}).",
        "Les sept derniers jours ({s7}) restent dans la lignée du mois ({s}) : aucun décrochage.",
        "Semaine récente ({s7}) et mois ({s}) au diapason : la régularité paie.",
        "Fin de mois sans surprise : la dernière semaine ({s7}, {wh} h) tient le niveau.",
        "La semaine écoulée ne bouge pas la moyenne ({s7} contre {s}) : stabilité assumée.",
        "La semaine la plus récente ({s7}) colle au mois ({s}) : aucune rupture.",
        "Fin de mois linéaire : {s7} sur les sept derniers jours, {s} sur le mois.",
        "Dernière semaine ({s7}, {wh} h) dans la continuité du mois.",
        "Les derniers jours ne changent rien à l'affaire : {s7} contre {s}.",
    ],
    # ---------- 3 MOIS : tendance de fond (première moitié contre seconde moitié du trimestre) ----------
    "q_trend_up": [
        "Sur la durée, la pente est bonne : {tp} de volume entre la première et la seconde moitié du trimestre.",
        "Tendance de fond ascendante : les dernières semaines pèsent {tp} de plus que les premières. Ça bâtit.",
        "La courbe des 3 mois grimpe ({tp} entre les deux moitiés) : exactement ce qu'on appelle progresser.",
        "Le trimestre se finit plus chargé qu'il n'a commencé ({tp}) : la progression est réelle.",
        "Bonne pente sur 3 mois : {tp} de volume du début à la fin, {nick}.",
        "La seconde moitié du trimestre pèse {tp} de plus que la première : ça bâtit du solide.",
        "Courbe de fond en hausse ({tp} sur le trimestre) : les fondations prennent de l'épaisseur.",
        "Depuis 3 mois, le volume grimpe ({tp} entre le début et la fin) : l'édifice s'élève brique par brique.",
        "Le volume prend de l'altitude sur 3 mois ({tp}) : chaque bloc pèse plus que le précédent.",
        "Montée régulière depuis 90 jours ({tp}) : la charge s'installe sans brûler les étapes.",
        "Les semaines récentes sont plus garnies que celles du début ({tp}), {nick}.",
        "Sur 3 mois, la courbe des heures gagne {tp} : c'est la bonne direction.",
        "Le trimestre empile les heures ({tp} entre début et fin) : progression assumée.",
        "Ta charge hebdomadaire monte en douceur ({tp} sur 90 jours) : du travail de fond, au sens noble.",
    ],
    "q_trend_down": [
        "Mais la tendance de fond s'effrite : {tp} de volume entre la première et la seconde moitié du trimestre.",
        "Attention à la pente : les dernières semaines affichent {tp} par rapport aux premières. Le trimestre finit en roue libre.",
        "La courbe des 3 mois pique du nez ({tp} entre les deux moitiés) : on ne prépare pas un marathon en descente.",
        "La seconde moitié du trimestre pèse {tp} par rapport à la première : la dynamique s'essouffle, {nick}.",
        "Sur 3 mois, le volume descend la pente ({tp}) : l'élan du début s'est dissipé.",
        "Le trimestre finit moins chargé qu'il n'a commencé ({tp}) : les fondations se lézardent.",
        "Pente négative sur 90 jours ({tp} entre le début et la fin) : il faut remettre du carburant.",
        "Courbe de fond en baisse ({tp} sur le trimestre) : le capital construit au départ fond doucement.",
        "Depuis 3 mois, le volume se dégonfle ({tp}) : pas idéal pour viser haut.",
        "Le volume perd de l'altitude sur 3 mois ({tp}) : chaque bloc pèse moins que le précédent.",
        "Descente régulière depuis 90 jours ({tp}) : la charge se délite, {nick}.",
        "Les semaines récentes sont moins garnies que celles du début ({tp}).",
        "Sur 3 mois, la courbe des heures lâche {tp} : ce n'est pas la bonne direction.",
        "Le trimestre se vide peu à peu ({tp} entre début et fin) : il faut redresser la barre.",
        "Ta charge hebdomadaire s'érode ({tp} sur 90 jours) : le moteur va finir par le sentir.",
    ],
    "q_trend_flat": [
        "Les deux moitiés du trimestre se valent ({tp}) : rassurant, mais une marche de plus serait bienvenue.",
        "Pas de pente marquée sur 3 mois ({tp}) : la régularité est là, l'élan beaucoup moins.",
        "Le volume trace une ligne presque plate sur 3 mois ({tp}) : rassurant pour la santé, un peu tiède pour le chrono.",
        "Sur 90 jours, le volume ne bouge guère ({tp} entre le début et la fin) : stable, sans plus.",
        "Le trimestre avance à plat ({tp}) : l'assiduité est acquise, à toi de créer du relief.",
        "Ni montée ni descente sur 3 mois ({tp}) : une autoroute sans virage.",
        "Courbe de fond horizontale ({tp} sur le trimestre) : le corps s'habitue, il faudra le surprendre.",
        "Volume quasi identique d'une moitié du trimestre à l'autre ({tp}) : bon pour la santé, neutre pour le chrono.",
        "Sur 90 jours, la charge reste étale ({tp}) : solide, mais sans élan.",
        "Le volume n'a ni monté ni baissé depuis 3 mois ({tp}) : routine bien huilée.",
        "Charge hebdomadaire stable sur le trimestre ({tp}) : la régularité est acquise.",
        "Les semaines se ressemblent depuis 90 jours ({tp}) : prévisible, {nick}, peut-être trop.",
        "Aucune pente notable sur 3 mois ({tp}) : de quoi consolider, pas de quoi décoller.",
        "La courbe des heures fait du sur-place depuis 90 jours ({tp}) : confortable, rien de plus.",
    ],
    # ---------- 3 MOIS : forme récente (mois et semaine) face au niveau de fond ----------
    "q_recent_down": [
        "Et la forme actuelle plombe le bilan : {s30} sur le dernier mois, {s7} sur la dernière semaine, contre {s} sur 3 mois.",
        "Le dernier mois ({s30}) et la dernière semaine ({s7}) passent sous ta base ({s}) : la dynamique actuelle fléchit.",
        "Ces dernières semaines font moins bien que le trimestre ({s30} sur le mois, {s7} sur la semaine) : le fond s'use.",
        "Et le présent fait moins bien que le passé : {s30} sur 30 jours et {s7} sur 7, contre {s} sur 90.",
        "La forme actuelle décroche de ta base ({s}) : {s30} pour le mois, {s7} pour la semaine, {nick}.",
        "Le mois ({s30}) comme la semaine ({s7}) restent sous ta note trimestrielle ({s}) : ça s'use par le bout.",
        "Sur les 30 derniers jours ({s30}) et les 7 derniers ({s7}), tu fais moins bien que sur le trimestre ({s}).",
        "Ton trimestre tient {s}, mais les dernières semaines reculent : {s30} sur le mois, {s7} sur la semaine.",
        "Ça tire la langue ces jours-ci : {s30} sur le mois, {s7} sur la semaine, quand tes 90 jours valent {s}.",
        "Mois ({s30}) et semaine ({s7}) en retrait de ta note de 3 mois ({s}) : la forme s'étiole.",
        "Ta base tient {s}, mais le mois ({s30}) et la semaine ({s7}) décrochent, {nick}.",
        "Les dernières semaines grignotent ton capital : {s30} sur 30 jours, {s7} sur 7, contre {s}.",
        "Mois et semaine en berne : {s30} pour le mois, {s7} pour la semaine, {s} sur 90 jours.",
    ],
    "q_recent_up": [
        "Et ta forme actuelle tire le trimestre vers le haut : {s30} sur le dernier mois, {s7} sur la dernière semaine, contre {s} sur 3 mois.",
        "Le dernier mois ({s30}) et la dernière semaine ({s7}) dépassent ta base ({s}) : le plus beau reste à venir.",
        "Les dernières semaines font mieux que le trimestre ({s30} sur le mois, {s7} sur la semaine) : ça monte en puissance.",
        "Et le présent fait mieux que le passé : {s30} sur 30 jours et {s7} sur 7, contre {s} sur 90.",
        "Ta forme actuelle dépasse ta base ({s}) : {s30} pour le mois, {s7} pour la semaine, {nick}.",
        "Le mois ({s30}) comme la semaine ({s7}) battent ta note trimestrielle ({s}) : ça monte en régime.",
        "Sur les 30 derniers jours ({s30}) et les 7 derniers ({s7}), tu surclasses ton trimestre ({s}).",
        "Ton trimestre tient {s}, et ces dernières semaines pousse plus haut : {s30} sur le mois, {s7} sur la semaine.",
        "Ça pousse fort ces jours-ci : {s30} sur le mois, {s7} sur la semaine, quand tes 90 jours valent {s}.",
        "Mois ({s30}) et semaine ({s7}) au-dessus de ta note de 3 mois ({s}) : la forme s'affûte.",
        "Ta base tient {s}, et le mois ({s30}) comme la semaine ({s7}) font mieux, {nick}.",
        "Les dernières semaines font fructifier ton capital : {s30} sur 30 jours, {s7} sur 7, contre {s}.",
        "Ces jours-ci, tout pétille : {s30} pour le mois, {s7} pour la semaine, {s} sur 90 jours.",
    ],
    "q_recent_mixed": [
        "Le mois ({s30}) et la semaine ({s7}) tirent dans deux directions opposées autour de ta base ({s}) : à surveiller.",
        "Le dernier mois ({s30}) et la dernière semaine ({s7}) ne racontent pas la même histoire : le trimestre ({s}) cherche encore sa direction.",
        "Mois à {s30}, semaine à {s7}, fond à {s} : la forme récente hésite entre deux directions.",
        "Signaux contradictoires : {s30} sur le mois, {s7} sur la semaine, {s} sur 3 mois. La tendance récente se cherche.",
        "Le présent fait le yoyo autour de ta base ({s}) : mois à {s30}, semaine à {s7}.",
        "Entre un mois à {s30} et une semaine à {s7}, ton trimestre ({s}) attend que tu choisisses ton camp, {nick}.",
        "Pas de direction claire : le mois ({s30}) et la semaine ({s7}) se contredisent contre ton niveau trimestriel ({s}).",
        "Le mois ({s30}) et la semaine ({s7}) se tirent la bourre autour de tes {s} sur 3 mois.",
        "Récent indécis : {s30} pour le mois, {s7} pour la semaine, {s} sur 90 jours.",
        "Mois et semaine ne s'accordent pas ({s30} contre {s7}) face à ta base ({s}).",
        "Une échelle monte, l'autre baisse : {s30} sur 30 jours, {s7} sur 7, pour {s} sur 90.",
    ],
    "q_recent_flat": [
        "Mois ({s30}) et semaine ({s7}) restent alignés sur ton niveau de fond ({s}) : rien ne bouge, ni en bien ni en mal.",
        "La forme récente ({s30} sur le mois, {s7} sur la semaine) colle à ta base ({s}).",
        "Mois à {s30}, semaine à {s7}, trimestre à {s} : un encéphalogramme plat, dans le bon sens du terme.",
        "Ces dernières semaines ressemblent à ta base : {s30} sur 30 jours, {s7} sur 7, {s} sur 90.",
        "Zéro différence entre la forme actuelle ({s30} puis {s7}) et ton niveau trimestriel ({s}).",
        "Trois échelles, une seule note ou presque ({s}, {s30}, {s7}) : du linéaire pur.",
        "Tout reste fidèle à ta base : {s30} pour le mois, {s7} pour la semaine, {s} sur 90 jours.",
        "Mois ({s30}) et semaine ({s7}) collent à ta note de 3 mois ({s}) : stabilité.",
        "Le mois et la semaine ne s'écartent pas de ta base ({s30}, {s7} contre {s}).",
        "Aucune dérive ces dernières semaines : {s30} sur 30 jours, {s7} sur 7, {s} sur 90.",
    ],
    # ---------- Toutes périodes : comparaison avec la période précédente de même durée ----------
    "prev_up": [
        "Par rapport à {plab} ({p0}), c'est {dd} {pt} de mieux.",
        "{plab_c} plafonnait à {p0} : {dd} {pt} de mieux, et ça se mérite.",
        "Comparé à {plab} ({p0}), la note progresse de {dd} {pt}.",
        "De {p0} à {s} par rapport à {plab} : le gain est net.",
        "{plab_c} s'arrêtait à {p0}, te voilà à {s} : {dd} de gagné.",
        "Tu prends {dd} {pt} sur {plab} ({p0} avant, {s} maintenant).",
        "Gain net sur {plab} : {p0} avant, {s} aujourd'hui.",
        "{plab_c} affichait {p0} ; tu gagnes {dd} {pt} depuis.",
        "La période gagne {dd} {pt} sur {plab} ({p0}).",
        "Belle remontée contre {plab} : de {p0} à {s}.",
    ],
    "prev_down": [
        "Par rapport à {plab} ({p0}), c'est {dd} {pt} de moins.",
        "{plab_c} tenait {p0} : {dd} de perdu en route.",
        "Comparé à {plab} ({p0}), la note recule de {dd} {pt}.",
        "De {p0} à {s} par rapport à {plab} : la pente est descendante.",
        "{plab_c} affichait {p0}, te voilà à {s} : {dd} de laissé en chemin.",
        "Tu lâches {dd} {pt} sur {plab} ({p0} avant, {s} maintenant).",
        "Perte nette sur {plab} : {p0} avant, {s} aujourd'hui.",
        "{plab_c} affichait {p0} ; tu perds {dd} {pt} depuis.",
        "La période cède {dd} {pt} sur {plab} ({p0}).",
        "Recul par rapport à {plab} : de {p0} à {s}.",
    ],
    "prev_up_1S": [
        "Il y a sept jours, tu étais à {p0} : {dd} de mieux depuis, joli rebond.",
        "La semaine d'avant valait {p0} ; celle-ci gagne {dd} {pt}.",
        "Face aux sept jours d'avant ({p0}), la remontée est de {dd} {pt}.",
    ],
    "prev_down_1S": [
        "Il y a sept jours, tu étais à {p0} : {dd} de perdu depuis, {nick}.",
        "La semaine d'avant valait {p0} ; celle-ci en abandonne {dd}.",
        "Face aux sept jours d'avant ({p0}), la rechute est de {dd} {pt}.",
    ],
    "prev_up_1M": [
        "Le mois d'avant tenait {p0} : te voilà {dd} {pt} plus haut.",
        "Sur les trente jours précédents, tu étais à {p0} : {dd} de gagné depuis.",
        "Face au mois d'avant ({p0}), la progression est de {dd} {pt}.",
    ],
    "prev_down_1M": [
        "Le mois d'avant tenait {p0} : te voilà {dd} {pt} plus bas.",
        "Sur les trente jours précédents, tu étais à {p0} : {dd} de perdu depuis.",
        "Face au mois d'avant ({p0}), le recul est de {dd} {pt}, {nick}.",
    ],
    "prev_up_3M": [
        "Le trimestre d'avant culminait à {p0} : {dd} {pt} de mieux aujourd'hui.",
        "Sur les quatre-vingt-dix jours précédents, la note était de {p0} : {dd} de gagné.",
        "Face au trimestre d'avant ({p0}), tu grimpes de {dd} {pt}.",
    ],
    "prev_down_3M": [
        "Le trimestre d'avant montait à {p0} : {dd} {pt} de moins aujourd'hui.",
        "Sur les quatre-vingt-dix jours précédents, la note était de {p0} : {dd} de perdu.",
        "Face au trimestre d'avant ({p0}), tu cèdes {dd} {pt}.",
    ],
}
ALLOWED = {"s", "s7", "s30", "s90", "wh", "mh", "fh", "wp", "mp", "tp", "pil", "apname", "a", "b", "p0", "dd", "pt", "plab", "plab_c"}
PLAB_PREV = {"1S": "la semaine précédente", "1M": "le mois précédent", "3M": "le trimestre précédent"}
PLAB_ALT = {"1S": ["la semaine précédente", "la semaine d'avant", "les sept jours d'avant", "la semaine passée"],
            "1M": ["le mois précédent", "le mois d'avant", "les trente jours d'avant", "le mois passé"],
            "3M": ["le trimestre précédent", "le trimestre d'avant", "les trois mois d'avant", "le trimestre passé"]}


# =============================================================================================
# OUTILS
# =============================================================================================
def f1(x, n=1):
    return None if x is None else f"{x:.{n}f}".replace(".", ",")


def pct_txt(v):
    return None if v is None else f"{v:+.0f} %".replace("-", "−")


def _pct(a, b):
    return None if not b else (a - b) / b * 100


def _weeks(acts, T, nb, key="m"):
    out = []
    for i in range(nb - 1, -1, -1):
        a, b = (T - timedelta(days=7 * i + 6)).isoformat(), (T - timedelta(days=7 * i)).isoformat()
        out.append(sum(x[key] for x in acts if a <= x["d"] <= b))
    return out


def _dir(a, b, th=D_SCALE):
    if a is None or b is None: return "flat"
    return "up" if a > b + th else "down" if a < b - th else "flat"


# =============================================================================================
# 1. SIGNAUX PAR PÉRIODE
# =============================================================================================
def preparer(pillars_p, stats, acts, T, prev_scores=None):
    """Résumé de chaque période (note, volume hebdo, piliers) + tendance de fond du trimestre. None si une période manque."""
    if not all(k in pillars_p and k in stats for k in ("1S", "1M", "3M")): return None
    prev_scores = prev_scores or {}
    P = {}
    for key, n in (("1S", 7), ("1M", 30), ("3M", 90)):
        PP, S = pillars_p[key], stats[key]["cur"]
        P[key] = {"s": PP.get("score"), "prev": prev_scores.get(key), "h": S["h"], "hw": S["h"] / (n / 7.0),
                  "pil": {p["key"]: p["score"] for p in PP.get("pillars", []) if p.get("score") is not None and p["key"] != "pred"}}
    wk = _weeks(acts, T, 13)
    act = [i for i, v in enumerate(wk) if v > 0]
    tp = None
    if len(act) >= 6:
        wk = wk[act[0]:]
        h = len(wk) // 2
        tp = _pct(sum(wk[-h:]) / h, sum(wk[:h]) / h)
    P["trend"] = tp
    return P


DOWN = {"w_vol_creux", "w_note_down", "w_note_down_n", "m_vol_down", "m_note_down", "m_week_down", "q_trend_down", "q_recent_down", "prev_down"}


def baisse(key, P):
    """La période choisie est-elle en baisse ? Oui dès qu'une lecture croisée constate un recul (note sous l'échelle plus large,
    volume en creux ou en érosion, fin de période qui fléchit, note en recul sur la période précédente). C'est la règle
    « Grosbichou » : le texte et le surnom disent toujours la même chose."""
    return any(sc in DOWN for sc, _, _ in _evolution_all(key, P))


# =============================================================================================
# 2. PHRASES D'ÉVOLUTION POUR LA PÉRIODE CHOISIE
# =============================================================================================
def evolution(key, P, date_str=""):
    """Phrases d'évolution retenues pour le mot du coach (scénario, banque, variables) : 1 semaine et 1 mois, en général la
    lecture principale (volume) + une autre, tournantes ; 3 mois, une seule lecture tournante (tendance, forme récente,
    trimestre précédent). Si la période est en baisse, une lecture de baisse figure toujours parmi elles : le texte justifie
    « Grosbichou »."""
    tout = _evolution_all(key, P)
    n = N_EVOL.get(key, 2)
    if len(tout) <= n: return _plab(tout, key, date_str)
    hh = lambda salt: int(hashlib.md5(f"{date_str}:{key}:{salt}".encode()).hexdigest(), 16)
    downs = [i for i, x in enumerate(tout) if x[0] in DOWN]
    if n == 1:
        return _plab([tout[downs[hh("evd") % len(downs)] if downs else hh("ev1") % len(tout)]], key, date_str)
    choix = [0 if hh("evol0") % 3 else 1]                 # la lecture principale cède sa place un jour sur trois
    reste = [i for i in range(len(tout)) if i not in choix]
    while len(choix) < n and reste:
        if downs and not any(i in downs for i in choix):
            j = next(i for i in reste if i in downs)
        else:
            j = reste[hh(f"evol:{len(choix)}") % len(reste)]
        choix.append(j); reste.remove(j)
    return _plab([tout[i] for i in sorted(choix)], key, date_str)


def _plab(evs, key, date_str):
    """Libellé de la période précédente tournant d'un jour à l'autre (« la semaine d'avant », « la semaine passée »…)."""
    out = []
    for sc, pool, v in evs:
        if sc in ("prev_up", "prev_down") and key in PLAB_ALT:
            alt = PLAB_ALT[key]; pl = alt[int(hashlib.md5(f"{date_str}:{key}:plab".encode()).hexdigest(), 16) % len(alt)]
            v = dict(v, plab=pl, plab_c=pl[:1].upper() + pl[1:])
        out.append((sc, pool, v))
    return out


def _evolution_all(key, P):
    """Toutes les lectures croisées de la période choisie, par ordre d'importance."""
    if not P: return []
    out = []
    W, M, Q = P["1S"], P["1M"], P["3M"]
    g = {"s7": f1(W["s"]), "s30": f1(M["s"]), "s90": f1(Q["s"])}
    if key == "1S":
        if M["hw"]:
            r = W["hw"] / M["hw"]
            k = "w_vol_pic" if r >= VOL_PIC else "w_vol_creux" if r <= VOL_CREUX else "w_vol_normal"
            out.append((k, EV[k], {"wh": f1(W["h"]), "mh": f1(M["hw"]), "fh": f1(Q["hw"]) if Q["hw"] else None, "wp": pct_txt(_pct(W["hw"], M["hw"]))}))
        if W["s"] is not None and M["s"] is not None:
            d = _dir(W["s"], M["s"])
            common = [x for x in W["pil"] if x in M["pil"]]
            drv = max(common, key=lambda x: abs(W["pil"][x] - M["pil"][x])) if common else None
            dv = {"s": g["s7"], "s30": g["s30"], "s90": g["s90"]}
            if d != "flat" and drv and abs(W["pil"][drv] - M["pil"][drv]) >= 0.3 and (W["pil"][drv] > M["pil"][drv]) == (d == "up"):
                k = f"w_note_{d}"
                dv.update(pil=PIL.get(drv, drv), apname=APNAME.get(drv, "à " + PNAME.get(drv, drv)), a=f1(W["pil"][drv]), b=f1(M["pil"][drv]))
            else:
                k = f"w_note_{d}" + ("_n" if d != "flat" else "")
            out.append((k, EV[k], dv))
    elif key == "1M":
        if Q["hw"]:
            k = "m_vol_up" if M["hw"] >= VOL_UP * Q["hw"] else "m_vol_down" if M["hw"] <= VOL_DOWN * Q["hw"] else "m_vol_flat"
            out.append((k, EV[k], {"mh": f1(M["hw"]), "fh": f1(Q["hw"]), "mp": pct_txt(_pct(M["hw"], Q["hw"]))}))
        if M["s"] is not None and Q["s"] is not None and _dir(M["s"], Q["s"]) != "flat":
            k = "m_note_" + _dir(M["s"], Q["s"])
            out.append((k, EV[k], {"s": g["s30"], "s90": g["s90"]}))
        if W["s"] is not None and M["s"] is not None:
            k = "m_week_" + _dir(W["s"], M["s"])
            out.append((k, EV[k], {"s7": g["s7"], "s": g["s30"], "wh": f1(W["h"])}))
    else:
        if P["trend"] is not None:
            k = "q_trend_" + ("up" if P["trend"] >= 12 else "down" if P["trend"] <= -12 else "flat")
            out.append((k, EV[k], {"tp": pct_txt(P["trend"])}))
        if all(x is not None for x in (W["s"], M["s"], Q["s"])):
            dm, dw = _dir(M["s"], Q["s"]), _dir(W["s"], Q["s"])
            k = "q_recent_" + (dm if dm == dw else "flat" if {dm, dw} == {"flat"} else
                               "down" if "up" not in (dm, dw) else "up" if "down" not in (dm, dw) else "mixed")
            out.append((k, EV[k], {"s": g["s90"], "s30": g["s30"], "s7": g["s7"]}))
    me = P[key]
    if me["s"] is not None and me["prev"] is not None and abs(me["s"] - me["prev"]) >= D_PREV:
        dd = abs(me["s"] - me["prev"])
        k = "prev_up" if me["s"] > me["prev"] else "prev_down"
        pl = PLAB_PREV[key]
        out.append((k, EV[k] + EV.get(f"{k}_{key}", []), {"plab": pl, "plab_c": pl[:1].upper() + pl[1:], "p0": f1(me["prev"]), "s": f1(me["s"]), "dd": f1(dd), "pt": "points" if dd >= 2 else "point"}))
    return out


def library_size():
    return sum(len(v) for v in EV.values())
