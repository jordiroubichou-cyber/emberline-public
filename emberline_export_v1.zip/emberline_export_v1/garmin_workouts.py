"""Séances proposées -> entraînements Garmin Connect (format JSON du service « workout-service »).

Chaque séance du dashboard (course, natation, vélo, musculation) est convertie en entraînement structuré :
échauffement, blocs (durée ou distance), répétitions, récupérations, cibles d'allure (course) ou de puissance (vélo),
consignes en note de chaque étape. Les fichiers sont générés à chaque mise à jour dans garmin/workouts/<date>/
(versionnés dans le dépôt privé) puis envoyés sur Garmin Connect par garmin_export.py, à la demande, depuis le dashboard.

Entrée : A["suggest"] (analysis.py). Aucune dépendance externe."""
import json, re
from datetime import date, timedelta
from pathlib import Path

# ------------------------------------------------------------------ vocabulaire Garmin Connect
SPORT = {"run": (1, "running"), "bike": (2, "cycling"), "swim": (4, "swimming"), "strength": (5, "strength_training")}
STEP = {"warmup": 1, "cooldown": 2, "interval": 3, "recovery": 4, "rest": 5, "repeat": 6, "other": 7}
COND = {"lap.button": 1, "time": 2, "distance": 3, "iterations": 7, "reps": 10}
TARGET = {"no.target": 1, "power.zone": 2, "pace.zone": 6}
PREFIX = "Emberline · "
KEEP_DAYS = 7


def _clean(t):
    """Retire la partie « 🩹 douleur » (gardée en note) et les espaces superflus."""
    return re.sub(r"\s+", " ", str(t or "").split(" 🩹")[0]).strip(" .")


def _pain(t):
    m = str(t or "").split(" 🩹", 1)
    return ("🩹" + m[1]).strip() if len(m) > 1 else ""


def _short(t, n=240):
    t = re.sub(r"\s+", " ", str(t or "")).strip()
    return t if len(t) <= n else t[: n - 1].rsplit(" ", 1)[0] + "…"


# ------------------------------------------------------------------ lecture des textes de séance
def _secs(t):
    """Première durée du texte en secondes (« 2 min 30 », « 45 s », « 30'' »), ou None."""
    m = re.search(r"(\d+(?:[.,]\d+)?) ?h(?: ?(\d+))?\b(?! ?W)", t)
    if m and "km/h" not in t:
        return int(float(m.group(1).replace(",", ".")) * 3600 + int(m.group(2) or 0) * 60)
    m = re.search(r"(\d+) ?min(?:utes?)?(?: (\d+)(?!\s?(?:min|m\b|s\b|×)))?", t)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2) or 0)
    m = re.search(r"(\d+) ?(?:s|sec|secondes|'')(?![a-zé/])", t)
    return int(m.group(1)) if m else None


def _meters(t):
    m = re.search(r"(\d+(?:[.,]\d+)?) ?km\b(?!/h)", t)
    if m:
        return int(round(float(m.group(1).replace(",", ".")) * 1000))
    m = re.search(r"(?<![\d'])(\d+) ?m\b(?![a-zéè])", t)
    return int(m.group(1)) if m else None


def _pace_s(m, s): return int(m) * 60 + int(s)


def _target(t, disc):
    """Cible lue dans le texte : (type, valeur1, valeur2). Course : allure -> vitesse m/s ; vélo : puissance en W."""
    if disc == "run":
        m = re.search(r"(\d+)'(\d\d)-(\d+)'(\d\d)/km", t)
        if m:
            a, b = _pace_s(m.group(1), m.group(2)), _pace_s(m.group(3), m.group(4))
            return ("pace.zone", round(1000 / max(a, b), 3), round(1000 / min(a, b), 3))
        m = re.search(r"environ (\d+) s/km plus vite que (\d+)'(\d\d)/km", t)
        if m:
            p = _pace_s(m.group(2), m.group(3)) - int(m.group(1))
            return ("pace.zone", round(1000 / (p + 5), 3), round(1000 / (p - 5), 3))
        m = re.search(r"(\d+)'(\d\d)/km( ou plus lent)?", t)
        if m:
            p = _pace_s(m.group(1), m.group(2))
            lo, hi = (p + 60, p) if m.group(3) else (p + 6, p - 6)
            return ("pace.zone", round(1000 / lo, 3), round(1000 / hi, 3))
    if disc == "bike":
        m = re.search(r"(\d+)-(\d+) W", t)
        if m:
            return ("power.zone", int(m.group(1)), int(m.group(2)))
        m = re.search(r"moins de (\d+) W", t)
        if m:
            return ("power.zone", int(int(m.group(1)) * 0.6), int(m.group(1)))
    return None


def _is_recovery(t, tgt):
    t = t.lower()
    if re.match(r"^(récupération|récup|repos)\b", t):
        return True
    return tgt is None and bool(re.search(r"\b(marche|trot|souple|récupération|repos|décontract)", t))


def _split_top(t, seps=(", puis ", " puis ", " + ", ", ")):
    """Découpe au premier niveau (hors parenthèses)."""
    out, depth, cur, i = [], 0, "", 0
    while i < len(t):
        c = t[i]
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if depth == 0:
            hit = next((s for s in seps if t.startswith(s, i)), None)
            if hit:
                out.append(cur.strip()); cur = ""; i += len(hit); continue
        cur += c; i += 1
    if cur.strip():
        out.append(cur.strip())
    return [x for x in out if x]


class _S:
    """Étape intermédiaire (avant numérotation Garmin)."""
    def __init__(self, kind, secs=None, meters=None, tgt=None, desc="", reps=None, cont=False):
        self.kind, self.secs, self.meters, self.tgt, self.desc, self.reps, self.cont = kind, secs, meters, tgt, desc, reps, cont


class _R:
    def __init__(self, n, steps):
        self.n, self.steps = n, steps


def _one(seg, disc, kind=None):
    """Une étape simple depuis un fragment (« 45 min à 5'27-5'57/km », « 200 m de trot »)."""
    tgt = _target(seg, disc)
    s0 = _secs(seg)
    rec = _is_recovery(seg, tgt) and not (s0 and s0 >= 600 and not re.match(r"^(récup|repos)", seg.lower()))
    other = bool(re.search(r"étirement|mobilité|gainage|éducatifs", seg.lower())) and not tgt
    k = kind or ("other" if other else "rest" if (rec and disc == "swim" and re.search(r"\brepos\b", seg)) else "recovery" if rec else "interval")
    m = _meters(seg) if disc != "strength" else None
    s = _secs(seg)
    # « 400 m » prioritaire en natation ; « 45 min à 5'27/km » : la durée prime sur une distance citée ensuite
    if disc == "swim" and m:
        return _S(k, meters=m, tgt=tgt, desc=_short(seg, 120))
    pos_m = re.search(r"(?<![\d'])\d+ ?(?:m|km)\b(?![a-zé])", seg)
    pos_s = re.search(r"\d+ ?(?:min|s\b|'')", seg)
    if m and (not pos_s or (pos_m and pos_m.start() < pos_s.start())):
        return _S(k, meters=m, tgt=tgt, desc=_short(seg, 120))
    if s:
        return _S(k, secs=s, tgt=tgt, desc=_short(seg, 120), cont=(k == "interval" and s >= 600))
    return None


def _recovery_of(text, disc):
    m = re.search(r"(?:récupération|récup|repos)[^,;)]*", text)
    if not m:
        return None
    st = _one(m.group(0), disc)
    if st:
        st.kind = "rest" if disc == "swim" and "repos" in m.group(0) else "recovery"
    return st


def parse_main(text, disc):
    """Corps de séance -> liste d'étapes et de répétitions."""
    t = _clean(text)
    out = []
    # « 2 séries de 10 × (30 s vite à X / 30 s de trot), 4 min de récupération entre les séries »
    m = re.match(r"^(\d+) séries de (\d+) × \((.+?)\),? (.*?)(?:de récupération|récupération) entre les séries(.*)$", t)
    if m:
        S, n, inner, rec_txt, rest = int(m.group(1)), int(m.group(2)), m.group(3), m.group(4), m.group(5)
        inner_steps = [x for x in (_one(p, disc) for p in re.split(r" / | \+ ", inner)) if x]
        rec = _one(rec_txt or "4 min", disc) or _S("recovery", secs=240)
        rec.kind = "recovery"
        for i in range(S):
            out.append(_R(n, inner_steps))
            if i < S - 1:
                out.append(_S("recovery", secs=rec.secs, meters=rec.meters, desc="Récupération entre les séries"))
        return out + (parse_main(rest.strip(" ,"), disc) if rest.strip(" ,.") else [])
    m = re.match(r"^(\d+) séries de (\d+) × ([^,]+), récupération ([^,]+?) entre les (?:efforts|répétitions), ([^,]+?) entre les séries(.*)$", t)
    if m:
        S, n = int(m.group(1)), int(m.group(2))
        work, r1, r2 = _one(m.group(3), disc, "interval"), _one(m.group(4), disc, "recovery"), _one(m.group(5), disc, "recovery")
        for i in range(S):
            out.append(_R(n, [x for x in (work, r1) if x]))
            if r2 and i < S - 1:
                out.append(_S("recovery", secs=r2.secs, meters=r2.meters, desc="Récupération entre les séries"))
        rest = m.group(6).strip(" ,.")
        return out + (parse_main(rest, disc) if rest else [])
    # « 5, 10, 15, 10 puis 5 min à X, récupération 2 min de trot entre chaque bloc »
    m = re.search(r"((?:\d+, )+\d+) puis (\d+) (min|m) à ([^,]+)(.*)$", t)
    if m:
        vals = [int(x) for x in m.group(1).split(", ")] + [int(m.group(2))]
        unit, zone, tail = m.group(3), m.group(4), m.group(5)
        rec = _recovery_of(tail, disc)
        half = "moitié" in tail
        for i, v in enumerate(vals):
            out.append(_one(f"{v} {unit} à {zone}", disc))
            if i < len(vals) - 1:
                if half:
                    q = v / 2
                    out.append(_S("recovery", meters=int(q) if unit == "m" else None, secs=int(q * 60) if unit == "min" else None,
                                  desc="Récupération en trot (moitié de l'effort)"))
                elif rec:
                    out.append(_S(rec.kind, secs=rec.secs, meters=rec.meters, desc=rec.desc))
        return [x for x in out if x]
    t = re.sub(r"^\d+ min [^:,]{0,30}: (?=\d)", "", t)
    segs = _split_top(t)
    for seg in segs:
        low = seg.lower()
        if re.match(r"^(récupération|récup|repos)\b", low) and out:
            rec = _one(seg, disc)
            if rec:
                rec.kind = "rest" if disc == "swim" and low.startswith("repos") else "recovery"
                last = out[-1]
                if isinstance(last, _R):
                    last.steps = last.steps + [rec]
                else:
                    out.append(rec)
            continue
        m = re.match(r"^(\d+) × \((.+)\)(.*)$", seg)
        if m:
            inner = [x for x in (_one(p, disc) for p in re.split(r" / | \+ |, ", m.group(2))) if x]
            if inner:
                out.append(_R(int(m.group(1)), inner)); continue
        m = re.match(r"^(\d+) × (.+)$", seg)
        if m:
            body = m.group(2)
            par = re.search(r"\(([^()]*)\)", body)
            work = _one(re.sub(r"\([^()]*\)", "", body).strip(), disc, "interval")
            if work:
                steps = [work]
                if par:
                    r = _recovery_of(par.group(1), disc) or _one(par.group(1), disc)
                    if r:
                        r.kind = "rest" if disc == "swim" and "repos" in par.group(1) else "recovery"
                        steps.append(r)
                out.append(_R(int(m.group(1)), steps)); continue
        st = _one(seg, disc)
        if st:
            out.append(st)
    return out


def parse_edge(text, disc, kind):
    """Échauffement / retour au calme : une étape (durée ou distance totale), le texte complet en note."""
    t = _clean(text)
    head = re.split(r" \+ (?=\d+ (?:lignes|accélérations|gammes|×))", t)[0]
    if disc == "swim":
        m = _meters(re.sub(r"\([^()]*\)", "", head))
        if m:
            return _S(kind, meters=m, desc=_short(t, 160))
    mins = sum(int(x) for x in re.findall(r"(\d+) ?min", re.sub(r"\d+ × \d+ ?s", "", head)))
    if mins:
        return _S(kind, secs=mins * 60, desc=_short(t, 160))
    return _S(kind, desc=_short(t, 160)) if t else None


# ------------------------------------------------------------------ assemblage au format Garmin
def _est(steps, disc, pace_run=360, pace_swim=120):
    tot = 0
    for s in steps:
        if isinstance(s, _R):
            tot += s.n * _est(s.steps, disc, pace_run, pace_swim)
        elif s.secs:
            tot += s.secs
        elif s.meters:
            tot += s.meters / 1000 * pace_run if disc == "run" else s.meters / 100 * pace_swim if disc == "swim" else s.meters / 1000 * 140
    return tot


def _fit_duration(warm, main, cool, disc, target_min):
    """Le texte de la bibliothèque garde la durée de référence ; le dashboard affiche la durée adaptée à la forme.
    On raccourcit les blocs continus (10 min ou plus) pour que la séance tienne dans la durée affichée."""
    if not target_min or disc == "swim":
        return False
    edges = sum(s.secs or 0 for s in (warm, cool) if s)
    total = edges + _est(main, disc)
    goal = target_min * 60
    cont = [s for s in main if isinstance(s, _S) and s.cont and s.secs]
    if total <= goal * 1.1 or not cont:
        return False
    fixed = total - sum(s.secs for s in cont)
    room = max(len(cont) * 300, goal - fixed)
    k = room / sum(s.secs for s in cont)
    for s in cont:
        old = s.secs
        s.secs = max(300, int(round(s.secs * k / 60)) * 60)
        if s.secs != old:
            s.desc = _short(f"{s.secs // 60} min (durée adaptée à ta forme, référence {old // 60} min) · {s.desc}", 250)
    return True


def _cond(key):
    return {"conditionTypeId": COND[key], "conditionTypeKey": key, "displayOrder": COND[key], "displayable": True}


def _stype(key):
    return {"stepTypeId": STEP[key], "stepTypeKey": key, "displayOrder": STEP[key]}


def _ttype(key):
    return {"workoutTargetTypeId": TARGET[key], "workoutTargetTypeKey": key, "displayOrder": TARGET[key]}


def _garmin_steps(items, counter, child=None):
    out = []
    for it in items:
        counter[0] += 1
        if isinstance(it, _R):
            counter[1] += 1
            cid = counter[1]
            g = {"type": "RepeatGroupDTO", "stepOrder": counter[0], "stepType": _stype("repeat"), "childStepId": cid,
                 "numberOfIterations": it.n, "smartRepeat": False, "endCondition": _cond("iterations"), "endConditionValue": float(it.n)}
            g["workoutSteps"] = _garmin_steps(it.steps, counter, cid)
            out.append(g)
            continue
        st = {"type": "ExecutableStepDTO", "stepOrder": counter[0], "stepType": _stype(it.kind), "childStepId": child,
              "description": _short(it.desc, 250) or None}
        if it.reps:
            st["endCondition"], st["endConditionValue"] = _cond("reps"), float(it.reps)
        elif it.secs:
            st["endCondition"], st["endConditionValue"] = _cond("time"), float(it.secs)
        elif it.meters:
            st["endCondition"], st["endConditionValue"] = _cond("distance"), float(it.meters)
            st["preferredEndConditionUnit"] = {"unitKey": "kilometer" if it.meters >= 1000 and it.meters % 100 == 0 else "meter"}
        else:
            st["endCondition"], st["endConditionValue"] = _cond("lap.button"), None
        if it.tgt:
            st["targetType"], st["targetValueOne"], st["targetValueTwo"] = _ttype(it.tgt[0]), it.tgt[1], it.tgt[2]
        else:
            st["targetType"] = _ttype("no.target")
        out.append(st)
    return out


def _workout(disc, name, desc, steps, est_s=None, est_m=None):
    sid, skey = SPORT[disc]
    counter = [0, 0]
    w = {"workoutName": _short(PREFIX + name, 80), "description": _short(desc, 1000), "sportType": {"sportTypeId": sid, "sportTypeKey": skey},
         "workoutSegments": [{"segmentOrder": 1, "sportType": {"sportTypeId": sid, "sportTypeKey": skey},
                              "workoutSteps": _garmin_steps(steps, counter)}]}
    if est_s:
        w["estimatedDurationInSecs"] = int(est_s)
    if est_m:
        w["estimatedDistanceInMeters"] = float(est_m)
    if disc == "swim":
        w["poolLength"], w["poolLengthUnit"] = 25.0, {"unitId": 1, "unitKey": "meter", "factor": 100.0}
    return w


def _blocks(card):
    return {b[0]: b[1] for b in card.get("blocks") or []}


def from_card(card):
    """Carte course / natation / vélo du dashboard -> (entraînement Garmin, résumé lisible)."""
    disc = card["id"]
    B = _blocks(card)
    warm = parse_edge(B.get("Échauffement", ""), disc, "warmup")
    cool = parse_edge(B.get("Retour au calme", ""), disc, "cooldown")
    main = parse_main(B.get("Corps de séance", ""), disc)
    if not main:                                                  # texte non structuré : une étape libre avec la consigne
        main = [_S("interval", desc=_short(_clean(B.get("Corps de séance", "")), 200))]
    m = re.search(r"(\d+) min", card.get("meta", ""))
    adjusted = _fit_duration(warm, main, cool, disc, int(m.group(1)) if m else None)
    steps = [s for s in [warm] + main + [cool] if s]
    pain = " ".join(x for x in (_pain(B.get(k, "")) for k in ("Échauffement", "Corps de séance", "Retour au calme")) if x)
    desc = " · ".join(x for x in [card.get("meta", ""), _clean(B.get("Zones cibles", "")), B.get("Consignes techniques", ""),
                                  "Durée ajustée à ta forme du jour." if adjusted else "", _short(pain, 300)] if x)
    est_m = card.get("dist") or None
    if disc == "swim":
        mm = re.search(r"([\d \s]+) m au total", card.get("meta", ""))
        est_m = int(re.sub(r"\D", "", mm.group(1))) if mm else None
    return _workout(disc, card.get("title", disc), desc, steps, est_s=_est(steps, disc) or None, est_m=est_m)


def _reps(e):
    nums = [int(x) for x in re.findall(r"\d+", str(e.get("reps", "")))]
    return max(nums) if nums else None


def from_strength(T, sess):
    """Séance Push / Pull / Legs -> entraînement Garmin (échauffement, séries × répétitions, repos)."""
    steps = [_S("warmup", secs=600, desc=_short(" ".join(T.get("warmup", {}).get("phases", [])), 250))]
    for e in sess.get("ex", []):
        unit = str(e.get("unit", "reps"))
        n = _reps(e)
        note = f"{e['name']} : {e['sets']} × {e.get('reps', '')} {unit}" + (f" · {e['note']}" if e.get("note") else "") + \
               (f" · 🩹 {e['pain']['txt']}" if e.get("pain") else "")
        if unit.startswith("s") or unit.startswith("sec"):
            work = _S("interval", secs=n or 30, desc=note)
        elif unit.startswith("min"):
            work = _S("interval", secs=(n or 1) * 60, desc=note)
        else:
            work = _S("interval", reps=n, desc=note) if n else _S("interval", desc=note)
        rest = _S("rest", secs=int(e.get("rest_s") or 90), desc=f"Repos {e.get('rest', '')}".strip())
        steps.append(_R(int(e.get("sets") or 1), [work, rest]))
    steps.append(_S("cooldown", secs=300, desc="Retour au calme : mobilité et étirements doux"))
    desc = " · ".join(x for x in [f"{T.get('label', '')} {sess.get('n', 0):02d} · {sess.get('title', '')}", T.get("sub", ""),
                                  f"{sess.get('min', '')} min · {len(sess.get('ex', []))} exercices", T.get("effort", "")] if x)
    return _workout("strength", f"{T.get('label', 'Muscu')} {sess.get('n', 0):02d} · {sess.get('title', '')}", desc, steps,
                    est_s=int(sess.get("min") or 0) * 60 or None)


# ------------------------------------------------------------------ résumé lisible (dashboard)
def summary(w):
    """Liste courte des étapes (« 10 min · échauffement », « 5 × [20 s + 40 s] ») pour l'aperçu avant envoi."""
    def dur(s):
        v = s.get("endConditionValue"); k = s["endCondition"]["conditionTypeKey"]
        if k == "time":
            v = int(v); return f"{v // 60} min" + (f" {v % 60:02d}" if v % 60 else "") if v >= 60 else f"{v} s"
        if k == "distance":
            return f"{v / 1000:g} km".replace(".", ",") if v >= 1000 else f"{int(v)} m"
        if k == "reps":
            return f"{int(v)} reps"
        return "au tour"
    def tgt(s):
        t = s.get("targetType", {}).get("workoutTargetTypeKey")
        if t == "pace.zone":
            f = lambda v: f"{int(1000 / v) // 60}'{int(1000 / v) % 60:02d}"
            return f" · {f(s['targetValueTwo'])}-{f(s['targetValueOne'])}/km"
        if t == "power.zone":
            return f" · {int(s['targetValueOne'])}-{int(s['targetValueTwo'])} W"
        return ""
    LAB = {"warmup": "échauffement", "cooldown": "retour au calme", "recovery": "récup", "rest": "repos", "interval": "", "other": "libre"}
    out = []
    for s in w["workoutSegments"][0]["workoutSteps"]:
        if s["type"] == "RepeatGroupDTO":
            inner = " + ".join(dur(c) + tgt(c) for c in s["workoutSteps"])
            out.append(f"{s['numberOfIterations']} × [{inner}]")
        else:
            lab = LAB.get(s["stepType"]["stepTypeKey"], "")
            out.append(dur(s) + tgt(s) + (f" · {lab}" if lab else ""))
    return out


# ------------------------------------------------------------------ génération des fichiers
def build(A):
    """Entraînements du jour : {clé: entraînement}. Clés : run, swim, bike, strength-push, strength-pull, strength-legs."""
    S = A.get("suggest") or {}
    W = {}
    for c in S.get("cards") or []:
        if c.get("id") in ("run", "swim", "bike") and not c.get("blocked"):      # discipline à éviter (douleur) ou en pause (vacances) : rien à envoyer
            try:
                W[c["id"]] = from_card(c)
            except Exception as e:  # une séance illisible n'empêche pas les autres
                print(f"Garmin : séance {c.get('id')} non convertie ({type(e).__name__} : {e}).")
    M = S.get("muscu") or {}
    for t, T in (M.get("types") or {}).items():
        try:
            sess = T["sessions"][T["today_n"] - 1]
            W[f"strength-{t}"] = from_strength(T, sess)
        except Exception as e:
            print(f"Garmin : séance de musculation {t} non convertie ({type(e).__name__} : {e}).")
    return W


def coach_keys(A):
    S = A.get("suggest") or {}
    M = S.get("muscu") or {}
    return [("strength-" + M.get("default", "push")) if r == "strength" else r for r in S.get("rec") or []]


def write(root, A, today):
    """Écrit garmin/workouts/<date>/<clé>.json + index.json ; supprime les dossiers de plus de 7 jours.
    Retourne le manifeste pour le dashboard : {date, coach, items: {clé: {name, file, steps}}}."""
    try:
        W = build(A)
        d = Path(root) / today
        d.mkdir(parents=True, exist_ok=True)
        items = {}
        for k, w in W.items():
            f = d / f"{k}.json"
            txt = json.dumps(w, ensure_ascii=False, indent=1) + "\n"
            if not f.exists() or f.read_text(encoding="utf-8") != txt:   # pas de commit inutile si rien ne change
                f.write_text(txt, encoding="utf-8")
            items[k] = {"name": w["workoutName"][len(PREFIX):], "file": f"garmin/workouts/{today}/{k}.json", "steps": summary(w),
                        "sport": w["sportType"]["sportTypeKey"]}
        man = {"date": today, "coach": [k for k in coach_keys(A) if k in items], "items": items}
        idx = d / "index.json"
        txt = json.dumps(man, ensure_ascii=False, indent=1) + "\n"
        if not idx.exists() or idx.read_text(encoding="utf-8") != txt:
            idx.write_text(txt, encoding="utf-8")
        limit = date.fromisoformat(today) - timedelta(days=KEEP_DAYS)
        for old in Path(root).iterdir():
            if old.is_dir() and re.fullmatch(r"\d{4}-\d\d-\d\d", old.name) and date.fromisoformat(old.name) < limit:
                for f in old.iterdir():
                    f.unlink()
                old.rmdir()
        print(f"Garmin : {len(items)} entraînement(s) prêts à l'export ({', '.join(items)}).")
        return man
    except Exception as e:
        print(f"Garmin : entraînements non générés ({type(e).__name__} : {e}).")
        return None
