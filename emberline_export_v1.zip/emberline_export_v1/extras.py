"""Emberline v5.2 : compléments de l'accueil et de l'onglet Objectifs (calculés à chaque génération, jamais bloquants).

  week_plan    « Cette semaine » : semaine type (séances par jour) figée au premier passage de la semaine (plan_memory.json),
               réconciliée avec la séance du coach du jour ; le volume des jours à venir suit la forme, les séances faites leur durée réelle.
  pred_history pronostic de course semaine après semaine (même méthode que analysis.predictions) vers le temps visé.
  challenges   défis de la semaine, du mois et des trois mois, choisis selon les objectifs, la forme, la fatigue et les douleurs.
  records      séries (bilans du soir, jours actifs, semaines complètes) et records (distance, allure, dénivelé, volume).

Tout se calcule à partir des activités, des objectifs et des bilans du soir ; seul le schéma de la semaine est conservé (plan_memory.json, clé « semaine »).
"""
from datetime import date, timedelta
import json
from pathlib import Path

import planner as PLN
import profil as PF
import zones_forme as ZF

DOW = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
DOW_L = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
RUN_T = {"vo2": "Fractionné VO2max", "spec": "Allure spécifique", "aerobe": "Endurance active", "long": "Sortie longue", "trail": "Spécifique trail",
         "z2": "Footing aérobie", "recup": "Footing de récupération", "taper": "Rappel d'allure", "brick": "Enchaînement"}
FAM_RUN = {"vo2": "Fractionné VO2max", "seuil": "Seuil", "threshold": "Seuil", "tempo": "Tempo", "allure": "Allure spécifique",
           "aerobe": "Endurance active", "z2": "Endurance", "recup": "Footing de récupération", "cotes": "Côtes", "hills": "Côtes"}


def _d(s):
    return date.fromisoformat(str(s)[:10])


def family(a):
    """Famille d'une activité : run, bike, swim, strength, mob (mobilité / étirements), other."""
    s, nm = a.get("s") or "other", (a.get("nm") or "").lower()
    if s in ("run", "trail"): return "run"
    if s in ("bike", "swim", "strength"): return s
    if "mobilit" in nm or "étirement" in nm or "etirement" in nm or "récupération" in nm or "activation" in nm or "yoga" in nm: return "mob"
    return "other"


def _week_start(T):
    return T - timedelta(days=T.weekday())


def _main_goal(goals, T):
    """Objectif principal à venir : priorité A la plus proche, sinon le plus proche."""
    up = sorted([g for g in goals or [] if g.get("date") and _d(g["date"]) >= T], key=lambda g: (g.get("prio") != "A", g["date"]))
    return up[0] if up else None


# ---------------------------------------------------------------------------------------------------------------- semaine type
import re as _re

SCHEMA_V = 4                                                  # version du schéma conservé : un schéma d'une version antérieure est recalculé
QUALITY = {"vo2", "seuil", "threshold", "tempo", "allure", "cotes", "hills"}
CARD_FAM = {"run": "run", "trail": "run", "bike": "bike", "swim": "swim", "strength": "strength"}


def _vol_factor(plan, faf, taper):
    """Facteur de volume lisible : semaine allégée 0,75 · affûtage 0,65 · forme prudente 0,9 · sinon 1."""
    if any(((plan or {}).get("deload") or {}).values()): return 0.75, "deload"
    if taper: return 0.65, "taper"
    if faf is not None and faf < 0.85: return 0.9, "prudent"
    return 1.0, "full"


def _days_ctx(T, goals, ath):
    ath = ath or {}
    g = _main_goal(goals, T)
    days_left = (_d(g["date"]) - T).days if g else None
    longd = tuple(ath.get("long_days") or (5, 6))
    run_long_day = 6 if 6 in longd else longd[-1]
    return g, days_left, days_left is not None and days_left <= 10, run_long_day, (5 if run_long_day == 6 else 6)


def _fresh_schema(acts, T, goals, ath, plan, faf):
    """Schéma de la semaine (séances par jour, durées) calculé au premier passage de la semaine, puis figé."""
    ath, plan = ath or {}, plan or {}
    mon = _week_start(T)
    vol = plan.get("vol") or {}
    pfam = plan.get("plan_fam") or plan.get("fam") or {}
    caps = plan.get("long_cap") or {}
    g, days_left, taper, run_long_day, bike_day = _days_ctx(T, goals, ath)
    f, mode = _vol_factor(plan, faf, taper)
    before = [a for a in acts if a.get("d", "") < mon.isoformat()]
    fit = ZF.fitness(before, mon - timedelta(days=1), ath, next((x.get("vo2") for x in reversed(before) if x.get("vo2")), None))
    km4, long42 = ZF.volume_markers(before, mon - timedelta(days=1))
    easy = (fit.get("thr") or 300) * 1.22                     # allure facile (s/km)
    d_min = (ath.get("day_minutes") or (60, 90))[0]
    lt = float(ath.get("long_run_target_km") or 30)
    long_km = max(8.0, min(lt, (long42 or 10) * 1.1)) * (0.7 if mode in ("deload", "taper") else 1)
    long_min = min(long_km * easy / 60, caps.get("run") or 180)
    rv, bv, sv = vol.get("run", 1.0), vol.get("bike", 1.0), vol.get("swim", 1.0)
    # course : 3 séances au minimum (qualité, 2e séance selon l'objectif, sortie longue), choisies selon les objectifs et l'état du moment
    up = sorted([x for x in goals or [] if x.get("date") and _d(x["date"]) >= T and x.get("sport") in ("run", "trail", "triathlon")], key=lambda x: x["date"])
    gm = next((x for x in up if x.get("prio") == "A"), up[0] if up else None)
    dist = float((gm or {}).get("dist") or 10)
    is_trail = (gm or {}).get("sport") == "trail"
    trail_soon = any(x.get("sport") == "trail" and (_d(x["date"]) - T).days <= 84 for x in up) or ((gm or {}).get("elev") or 0) >= 800
    # familles du planificateur (planner.py) : le coach construit exactement ces séances le jour J (plafonnées par la forme du jour)
    phase = (plan.get("phase") or {}).get("run") or "developpement"
    allowed = PLN.ALLOWED.get(phase) or {"aerobe", "long", "vo2"}
    pref = ["taper"] if phase == "affutage" else ["trail", "aerobe", "vo2"] if is_trail else (["spec", "aerobe", "vo2"] if dist >= 30 else ["aerobe", "vo2", "spec"] if dist > 12 else ["vo2", "aerobe", "spec"])
    qf = next((x for x in pref if x in allowed), "aerobe")
    if mode == "deload" and qf in ("vo2", "spec"): qf = "aerobe"
    r2f = "trail" if trail_soon and "trail" in allowed and mode == "full" else "z2"
    lf = "long" if "long" in allowed else "z2"
    q, r2 = RUN_T[qf], RUN_T[r2f]
    lt_lab = "Sortie longue"
    S = lambda s, t, m, key=False: {"s": s, "t": t, "min": int(round(m * f / 5) * 5) if m else 0, "key": key}
    run_l = {"s": "run", "t": f"{lt_lab} ≈ {round(long_km)} km", "min": int(round(long_min / 5) * 5), "key": True}
    light = mode == "taper"
    push = S("strength", "Musculation · Push" + (" léger" if light else ""), 30 if light else 45)
    pull = S("strength", "Musculation · Pull" + (" léger" if light else ""), 25 if light else 40)
    run_l["fam"] = lf
    push["st"], pull["st"] = "push", "pull"
    tpl = {0: [push], 1: [dict(S("run", q, 55 * rv, True), fam=qf)], 2: [S("swim", "Natation", 45 * sv)],
           3: [dict(S("run", r2, d_min * 0.75 * rv), fam=r2f)],
           4: [pull, {"s": "mob", "t": "Mobilité", "min": 15, "key": False}],
           bike_day: [S("bike", "Vélo", min(caps.get("bike") or 120, 120) * bv, run_long_day == 6)], run_long_day: [run_l]}
    why = {"taper": "Affûtage", "deload": "Semaine allégée", "prudent": "Volume réduit"}.get(mode, "")
    return {"v": SCHEMA_V, "start": mon.isoformat(), "f": f, "why": why, "days": {str(k): v for k, v in tpl.items()}}


SRC = Path("garmin")                                          # dossier des données (fixé par build_dashboard)
MOVES_FILE = "deplacements.json"                              # séances déplacées depuis l'app (écrit par la PWA via l'API GitHub)
WINS_FILE = None                                              # défis réussis gardés jusqu'à la fin de leur période (fixé par build_dashboard ;
                                                              # None : rien n'est écrit, pour les tests et les générations d'essai)
WK_PREFIX = "Emberline · "                                    # préfixe des entraînements envoyés sur la montre (garmin_workouts.PREFIX)


def load_moves(root=None):
    """{lundi ISO: [{"from": k, "to": k2, "s": sport, "t": titre}]} ; fichier absent ou illisible : rien."""
    for base in ([Path(root)] if root else []) + [SRC.parent, Path(".")]:
        try:
            d = json.loads((base / MOVES_FILE).read_text(encoding="utf-8"))
            return d.get("weeks", d) if isinstance(d, dict) else {}
        except (OSError, ValueError):
            continue
    return {}


def apply_moves(fr, moves):
    """Déplace les séances demandées dans le schéma d'une semaine (même sport, même titre de préférence). Renvoie une copie."""
    L = (moves or {}).get(fr.get("start")) or []
    if not L: return fr
    days = {k: [dict(it) for it in v] for k, v in fr["days"].items()}
    done = []
    for m in L:
        try: a, b = str(int(m["from"])), str(int(m["to"]))
        except (KeyError, TypeError, ValueError): continue
        if a == b or not (0 <= int(b) <= 6): continue
        src = days.get(a) or []
        j = next((i for i, it in enumerate(src) if it.get("s") == m.get("s") and it.get("t") == m.get("t")), None)
        if j is None: j = next((i for i, it in enumerate(src) if it.get("s") == m.get("s")), None)
        if j is None: continue
        it = src.pop(j); it["moved"] = int(a); days.setdefault(b, []).append(it); done.append(m)
    out = dict(fr); out["days"] = {k: v for k, v in days.items() if v}; out["moves"] = done
    return out


def _wk_names(dk):
    """Noms des entraînements préparés pour la date dk (garmin/workouts/<dk>/index.json) : {nom: sport}."""
    try:
        ix = json.loads((SRC / "workouts" / dk / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    SP = {"running": "run", "cycling": "bike", "swimming": "swim", "strength_training": "strength"}
    return {str(v.get("name") or "").strip(): SP.get(v.get("sport"), k.split("-")[0]) for k, v in (ix.get("items") or {}).items() if v.get("name")}


def _sent():
    """Entraînements envoyés sur la montre : {workoutId: {"d": date prévue, "s": sport}} (garmin/workouts/sent.json)."""
    try: return json.loads((SRC / "workouts" / "sent.json").read_text(encoding="utf-8"))
    except (OSError, ValueError): return {}


def _wk_date(a, mon, sent=None):
    """Jour de la semaine (0-6) où l'entraînement suivi par l'activité avait été préparé : d'abord par l'identifiant Garmin
    de l'entraînement (associatedWorkoutId), sinon par son nom « Emberline · … » ; None pour une activité libre."""
    wid = (a.get("x") or {}).get("wid")
    e = (sent if sent is not None else _sent()).get(str(wid)) if wid else None
    if e and e.get("d"):
        k = (date.fromisoformat(e["d"]) - mon).days
        if 0 <= k <= 6: return k
    nm = str(a.get("nm") or "")
    if not nm.startswith(WK_PREFIX): return None
    name = nm[len(WK_PREFIX):].strip()
    hits = [k for k in range(7) if name in _wk_names((mon + timedelta(days=k)).isoformat())]
    if not hits: return None
    d = (date.fromisoformat(a["d"]) - mon).days
    return min(hits, key=lambda k: (abs(k - d), k))


def _frozen(plan_mem, mon):
    fr = (plan_mem or {}).get("semaine") if isinstance(plan_mem, dict) else None
    if isinstance(fr, dict) and fr.get("v") == SCHEMA_V and fr.get("start") == mon.isoformat() and isinstance(fr.get("days"), dict):
        try:
            if all(isinstance(v, list) and all(isinstance(it, dict) and it.get("s") and "min" in it for it in v) for v in fr["days"].values()):
                return fr
        except Exception:  # noqa: BLE001
            return None
    return None


def today_sched(acts, T, goals, ath, plan=None, faf=None, plan_mem=None):
    """Séances prévues aujourd'hui dans la semaine type (figée, sinon celle qui sera figée) : le coach les suit (discipline, famille,
    type de musculation) tant que la forme, la fatigue et les douleurs le permettent."""
    fr = apply_moves(_frozen(plan_mem, _week_start(T)) or _fresh_schema(acts, T, goals, ath, plan, faf), load_moves())
    out = [dict(it) for it in fr["days"].get(str(T.weekday()), []) if it.get("s") != "mob"]
    rp = key_report(acts, T, fr, plan_mem, plan) if faf is None or faf >= 0.85 else None
    if rp:
        for it in out:
            if it["s"] == "run": it.update(fam=rp.get("fam"), key=True, t=rp["t"], report=True)
    return out


def day_sports(T, goals, ath, plan_mem=None):
    """Disciplines prévues aujourd'hui dans la semaine type (figée si elle existe) : sert au coach pour rester fidèle au schéma."""
    mon = _week_start(T)
    fr = _frozen(plan_mem, mon)
    if fr: fr = apply_moves(fr, load_moves()); return {it["s"] for it in fr["days"].get(str(T.weekday()), []) if it["s"] != "mob"}
    _, _, taper, run_long_day, bike_day = _days_ctx(T, goals, ath)
    tpl = {0: ["strength"], 1: ["run"], 2: ["swim"], 3: ["run"], 4: ["strength"], bike_day: ["bike"], run_long_day: ["run"]}
    return set(tpl.get(T.weekday(), []))


def _card_min(c):
    m = _re.search(r"(\d+)\s*min", c.get("meta") or "")
    if m: return int(m.group(1))
    h = _re.search(r"(\d+)\s*h\s*(\d+)?", c.get("meta") or "")
    return int(h.group(1)) * 60 + int(h.group(2) or 0) if h else 0


def _link(it, a):
    """séance faite : identifiant (fiche détaillée) et verdict prévu / réalisé (v6)"""
    if a.get("id") is not None and a.get("x"): it["aid"] = str(a["id"])
    c = a.get("cmp")
    if c and c.get("code"): it["cmp"] = {"code": c["code"], "label": c.get("label"), "score": c.get("score")}


def _st_kw(t):
    """push / pull / legs d'un titre de séance de musculation (None si non précisé)"""
    t = (t or "").lower()
    for k, ws in (("push", ("push", "poussée", "pecto")), ("pull", ("pull", "tirage", "dos")), ("legs", ("legs", "jambes", "squat"))):
        if any(w in t for w in ws): return k
    return None


def _pick(fams, used, it, day=None, strict=False):
    """activité de la même famille non encore utilisée ; en musculation, le même type (push / pull / jambes) d'abord.
    strict : un type explicitement différent ne compte pas (une séance Push ne couvre pas la séance Pull d'un autre jour)."""
    C = [(i, a) for i, fm, a in fams if i not in used and fm == it["s"] and (day is None or a["d"] == day)]
    if day is None:                                           # autre jour : une course enchaînée après le vélo ou une séance bien plus courte
        C = [(i, a) for i, a in C if not (a.get("brick") and a["s"] in ("run", "trail"))      # ne remplacent pas la séance prévue
             and not ((it.get("min") or 0) >= 30 and it["s"] in ("run", "bike", "swim") and (a.get("m") or 0) < 0.45 * it["min"])]
    if not C: return None
    if it["s"] == "strength":
        kw = _st_kw(it.get("t"))
        if kw:
            same = [i for i, a in C if _st_kw(a.get("nm")) == kw]
            if same: return same[0]
            if strict: C = [(i, a) for i, a in C if _st_kw(a.get("nm")) in (None, kw)]
    return C[0][0] if C else None


def done_list(day_fams, link, k):
    """Séances réellement faites un jour donné (toutes, prévues ou non), dans l'ordre de la journée : de quoi afficher
    leur fiche sous le jour sélectionné de « Cette semaine ». La fiche complète est dans A["detail"]["acts"][id]."""
    out = []
    for i, fm, a in sorted(day_fams, key=lambda r: (r[2].get("t") or "99:99", r[0])):
        e = {"id": str(a["id"]) if a.get("id") is not None else None, "s": fm, "sp": a.get("s"), "nm": a.get("nm") or "",
             "t": a.get("t") or "", "m": round(a.get("m") or 0), "km": round(a["km"], 2) if a.get("km") else None,
             "hr": round(a["hr"]) if a.get("hr") else None, "el": round(a["el"]) if a.get("el") else None,
             "ld": round(a["ld"]) if a.get("ld") else None, "det": bool(a.get("x")), "est": bool(a.get("est")),
             "brk": ("bike" if (a.get("brick") or {}).get("run") else "run") if a.get("brick") else None}
        if i in link:
            kk, it = link[i]
            e["plan"] = it.get("t"); e["key"] = bool(it.get("key"))
            if kk != k: e["pday"] = DOW_L[kk]
            c = a.get("cmp") or {}
            if c.get("code"): e["cmp"] = c["code"]
        else: e["extra"] = True                                  # non prévue (mobilité comprise) : « ajoutée »
        out.append({x: v for x, v in e.items() if v not in (None, "", False)} | {"m": e["m"]})
    return out


def key_report(acts, T, fr, plan_mem=None, plan=None):
    """Séance clé course de la semaine (mardi) non réalisée comme prévu (manquée, faite en endurance, partielle) :
    reportée au jeudi si aucune autre séance clé n'a été faite depuis. Renvoie la séance à reporter ou None."""
    if T.weekday() != 3: return None
    mon = _week_start(T)
    key = next((it for it in fr["days"].get("1", []) if it.get("s") == "run" and it.get("key") and it.get("fam")), None)
    if not key: return None
    ph = ((plan or {}).get("phase") or {}).get("run")
    if ph in ("affutage", "recuperation", "jour_j", "reprise"): return None          # pas de rattrapage en affûtage ni en récupération
    if ph and key.get("fam") not in PLN.ALLOWED.get(ph, {key.get("fam")}): return None
    tue = (mon + timedelta(days=1)).isoformat()
    runs = [a for a in acts if family(a) == "run" and tue <= a["d"] < T.isoformat()]
    good = [a for a in runs if (a.get("cmp") or {}).get("code") in ("ok", "harder") or ((a.get("x") or {}).get("st") or {}).get("kind") == "intervals"]
    if good: return None
    if runs and not any(a.get("cmp") or a.get("x") for a in runs): return None      # pas de détail : on ne présume pas d'un échec
    return dict(key)


def week_plan(acts, T, goals, ath, plan=None, faf=None, pain_any=False, plan_mem=None, sug=None):
    """« Cette semaine » : le schéma (quelles séances, quels jours) est figé au premier passage de la semaine et ne bouge plus.
    Ce qui s'adapte : aujourd'hui = la séance du coach (même durée, même titre que « Ta séance du jour ») ; jours à venir = volume
    ajusté à la forme du jour ; séances faites = durée réelle."""
    ath = ath or {}
    mon = _week_start(T)
    fr = _frozen(plan_mem, mon)
    fresh = fr is None
    if fresh: fr = _fresh_schema(acts, T, goals, ath, plan, faf)
    fr0, fr = fr, PF.filter_schema(apply_moves(fr, load_moves()))   # le schéma figé reste celui d'origine ; déplacements et sports choisis appliqués à chaque génération
    g, days_left, taper, _, _ = _days_ctx(T, goals, ath)
    f_now, _ = _vol_factor(plan, faf, taper)
    adj = max(0.6, min(1.1, f_now / (fr.get("f") or 1.0)))
    items = []
    for k in range(7):
        dk = mon + timedelta(days=k)
        for it in fr["days"].get(str(k), []):
            it = {"s": it["s"], "t": it["t"], "min": int(it.get("min") or 0), "key": bool(it.get("key")), "note": "",
                  **({"mv": DOW_L[it["moved"]]} if isinstance(it.get("moved"), int) else {})}
            it["plan_min"] = it["min"]
            if dk > T and it["s"] != "mob" and abs(adj - 1) > 0.02: it["min"] = int(round(it["min"] * adj / 5) * 5)
            if pain_any and it["s"] == "run": it["note"] = "selon la douleur (vélo ou natation sinon)"
            items.append([k, dk, it])
    rp = key_report(acts, T, fr, plan_mem, plan) if faf is None or faf >= 0.85 else None
    if rp:
        for k, dk, it in items:
            if k == 3 and dk == T and it["s"] == "run":
                it.update(t=rp["t"], key=True, fam=rp.get("fam"), min=rp.get("min") or it["min"], report=True)
    for k, dk, it in items:                                   # jours passés : la séance que le coach avait réellement proposée ce jour-là
        lg = (plan_mem or {}).get(dk.isoformat()) if dk < T else None
        e = lg.get(it["s"]) if isinstance(lg, dict) else None
        if isinstance(e, dict) and e.get("t"):
            it.update(t=e["t"], coach=True)
            if e.get("m"): it["min"] = int(e["m"])
    wk = [a for a in acts if mon.isoformat() <= a.get("d", "") <= (mon + timedelta(days=6)).isoformat()]
    fams = [(i, family(a), a) for i, a in enumerate(wk)]
    used = set()
    sent = _sent()
    for i, fm, a in fams:                                     # 1) entraînement envoyé sur la montre : identifiant ou nom (exact)
        kd = _wk_date(a, mon, sent)
        if kd is None: continue
        it = next((it for k, dk, it in items if k == kd and it["s"] == fm and "_hit" not in it), None)
        if it is None: continue
        used.add(i); it["_hit"] = i; it["real"] = round(a.get("m") or 0); _link(it, a); it["byname"] = True
        it["st"] = "done" if a["d"] == (mon + timedelta(days=kd)).isoformat() else "moved"
    for k, dk, it in items:                                   # 2) séance faite le jour prévu (même sport)
        if "_hit" in it: continue
        hit = _pick(fams, used, it, dk.isoformat(), strict=True)
        if hit is not None: used.add(hit); it["st"] = "done"; it["real"] = round(wk[hit].get("m") or 0); _link(it, wk[hit]); it["_hit"] = hit
    # aujourd'hui : la séance du coach remplace la séance générique (même discipline), ou la remplace en changeant de discipline
    cards = [c for c in (sug or {}).get("cards") or [] if c.get("rec") and CARD_FAM.get(c.get("id"))]
    tk = T.weekday() if mon <= T <= mon + timedelta(days=6) else None
    if tk is not None and cards:
        today = [it for k, dk, it in items if k == tk]
        left = [c for c in cards]
        for it in today:
            c = next((c for c in left if CARD_FAM[c["id"]] == it["s"]), None)
            if c is None: continue
            left.remove(c)
            if it.get("report") and c.get("fam") and c["fam"] != it.get("fam"): it.pop("report", None)   # le coach a jugé autrement (forme du jour)
            it.update(t=c.get("title") or it["t"], min=_card_min(c) or it["min"], coach=True)
        for it in today:                                      # discipline changée par le coach (forme, douleur, récupération)
            if not left: break
            if it.get("coach") or it.get("st") == "done" or it["s"] == "mob": continue
            c = left.pop(0)
            it.update(swap=it["t"], s=CARD_FAM[c["id"]], t=c.get("title") or it["t"], min=_card_min(c) or it["min"], coach=True)
        for it in today:                                      # prévue mais non conseillée aujourd'hui par le coach (forme, récupération)
            if not it.get("coach") and it["s"] != "mob" and it.get("st") != "done": it["skip"] = True
        for c in left:                                        # jour de repos ou séance supplémentaire proposée par le coach
            items.append([tk, T, {"s": CARD_FAM[c["id"]], "t": c.get("title") or "", "min": _card_min(c), "plan_min": 0, "key": False,
                                  "note": "", "coach": True, "bonus": True}])
        for k, dk, it in items:                               # la séance du coach peut avoir été faite entre-temps
            if k == tk and it.get("coach") and not it.get("st"):
                hit = _pick(fams, used, it, dk.isoformat(), strict=True)
                if hit is not None: used.add(hit); it["st"] = "done"; it["real"] = round(wk[hit].get("m") or 0); _link(it, wk[hit]); it["_hit"] = hit
    for k, dk, it in items:                                   # faite un autre jour de la semaine (déplacée)
        if it.get("st"): continue
        hit = _pick(fams, used, it, strict=True) if not it.get("bonus") else None
        if hit is not None: used.add(hit); it["st"] = "moved"; it["real"] = round(wk[hit].get("m") or 0); _link(it, wk[hit]); it["_hit"] = hit
        else: it["st"] = "missed" if dk < T else "today" if dk == T else "next"
    link = {}                                                 # activité réalisée -> séance du plan qu'elle couvre
    for k, dk, it in items:
        h = it.pop("_hit", None)
        if h is not None: link[h] = (k, it)
    days = []
    for k in range(7):
        dk = mon + timedelta(days=k)
        its = [it for kk, _, it in items if kk == k]
        extra = [family(a) for i, fm, a in fams if i not in used and a["d"] == dk.isoformat() and fm not in ("other",)]
        days.append({"dow": DOW[k], "date": dk.isoformat(), "today": dk == T, "past": dk < T, "items": its,
                     "extra": [e for e in extra if e != "mob"], "mob": sum(1 for _, fm, a in fams if fm == "mob" and a["d"] == dk.isoformat()),
                     "done": done_list([(i, fm, a) for i, fm, a in fams if a["d"] == dk.isoformat()], link, k)})
    planned = [it for _, _, it in items if it["s"] != "mob" and not it.get("bonus")]
    due = [it for (k, dk, it) in items if it["s"] != "mob" and not it.get("bonus") and dk <= T]
    done = [it for it in planned if it["st"] in ("done", "moved")]
    pm = sum((it.get("real") if it["st"] in ("done", "moved") and it.get("real") else it["min"]) for it in planned)
    dm = round(sum(a.get("m") or 0 for a in wk if family(a) in ("run", "bike", "swim", "strength")))
    why = fr.get("why") or ""
    if abs(adj - 1) > 0.02:
        why = " · ".join(x for x in (why, f"prochains jours {'+' if adj > 1 else '−'}{abs(round((adj - 1) * 100))} %") if x)
    out = {"start": mon.isoformat(), "days": days, "planned": len(planned), "due": len(due), "done": len(done),
           "min_planned": pm, "min_done": dm, "factor": round(fr.get("f") or 1.0, 2), "adj": round(adj, 2), "why": why.strip(), "frozen": not fresh,
           "goal": {"label": g.get("label") or g.get("name"), "days_left": days_left} if g else None}
    if fresh: out["_freeze"] = fr0                            # à conserver dans plan_memory.json (build_dashboard.memoriser_plan)
    if T.weekday() == 6:                                      # dimanche : aperçu de la semaine prochaine, séances déplaçables depuis l'app
        try: out["next"] = next_week(acts, T, goals, ath, plan, faf)
        except Exception as e:  # noqa: BLE001
            print(f"Compléments : semaine prochaine non calculée ({type(e).__name__}: {e})")
    return out


def next_week(acts, T, goals, ath, plan=None, faf=None):
    """Schéma prévu de la semaine suivante (même calcul que le schéma figé lundi), déplacements déjà demandés compris."""
    mon = _week_start(T) + timedelta(days=7)
    fr = PF.filter_schema(apply_moves(_fresh_schema(acts, mon, goals, ath, plan, faf), load_moves()))
    days = []
    for k in range(7):
        its = [{"s": it["s"], "t": it["t"], "min": int(it.get("min") or 0), "key": bool(it.get("key")),
                **({"mv": DOW_L[it["moved"]]} if isinstance(it.get("moved"), int) else {})} for it in fr["days"].get(str(k), [])]
        days.append({"date": (mon + timedelta(days=k)).isoformat(), "dow": DOW[k], "items": its})
    return {"start": mon.isoformat(), "days": days, "why": fr.get("why") or "", "applied": [m.get("id") for m in fr.get("moves") or [] if m.get("id")]}


# ---------------------------------------------------------------------------------------------------------------- pronostic
def pred_history(acts, T, goals, ath, weeks=10):
    """Pronostic semaine après semaine pour chaque objectif de course à pied avec un temps visé (fin de chaque semaine)."""
    out = []
    first = min([a["d"] for a in acts] or [T.isoformat()])
    for g in goals or []:
        if g.get("sport", "run") != "run" or not g.get("target_s") or not g.get("dist") or not g.get("date") or _d(g["date"]) < T:
            continue
        pts = []
        for k in range(weeks - 1, -1, -1):
            Tw = T - timedelta(days=7 * k)
            if (Tw - _d(first)).days < 28: continue
            aw = [a for a in acts if a.get("d", "") <= Tw.isoformat()]
            vo2 = next((x.get("vo2") for x in reversed(aw) if x.get("vo2")), None)
            fit = ZF.fitness(aw, Tw, ath, vo2)
            km4, long42 = ZF.volume_markers(aw, Tw)
            pr = ZF.predict(fit, float(g["dist"]), km4, long42)
            if pr: pts.append({"d": Tw.isoformat(), "t": round(pr["t"]), "lo": round(pr["lo"]), "hi": round(pr["hi"])})
        if len(pts) < 2: continue
        last, prev4 = pts[-1]["t"], pts[max(0, len(pts) - 5)]["t"]
        out.append({"id": g.get("id"), "label": g.get("label") or g.get("name"), "dist": g["dist"], "date": g["date"], "prio": g.get("prio"),
                    "target": g["target_s"], "pts": pts, "now": last, "d4": last - prev4, "gap": last - g["target_s"],
                    "days_left": (_d(g["date"]) - T).days})
    out.sort(key=lambda r: (r["prio"] != "A", r["date"]))
    return out


# ---------------------------------------------------------------------------------------------------------------- défis
def _range_stats(acts, a0, a1):
    s = {"run_km": 0.0, "el": 0.0, "bike_min": 0.0, "swim_min": 0.0, "cross_n": 0, "mob_n": 0, "str_n": 0, "n": 0, "min": 0.0, "run_n": 0, "long_km": 0.0}
    for a in acts:
        if not (a0 <= a.get("d", "") <= a1): continue
        fm = family(a)
        if fm == "run":
            s["run_km"] += a.get("km") or 0; s["el"] += a.get("el") or 0; s["run_n"] += 1; s["long_km"] = max(s["long_km"], a.get("km") or 0)
        elif fm == "bike": s["bike_min"] += a.get("m") or 0; s["cross_n"] += 1
        elif fm == "swim": s["swim_min"] += a.get("m") or 0; s["cross_n"] += 1
        elif fm == "strength": s["str_n"] += 1
        elif fm == "mob": s["mob_n"] += 1
        if fm in ("run", "bike", "swim", "strength"): s["n"] += 1; s["min"] += a.get("m") or 0
    return s


def _ch(cid, scale, sport, title, cur, target, unit, a0, a1, T, why, fmt=None):
    tot = (a1 - a0).days + 1
    el = min(tot, max(0, (T - a0).days + 1))
    pct = 0 if not target else max(0.0, min(1.0, cur / target))
    return {"id": cid, "scale": scale, "sport": sport, "title": title, "cur": round(cur, 1), "target": target, "unit": unit,
            "pct": round(pct, 3), "time": round(el / tot, 3), "start": a0.isoformat(), "end": a1.isoformat(),
            "days_left": (a1 - T).days, "done": cur >= target, "why": why, "fmt": fmt}


def challenges(acts, T, goals, ath, wk=None, faf=None, strain=None, pain_any=False, ress_dates=(), review=None):
    ath = ath or {}
    tired = (faf is not None and faf < 0.85) or (strain is not None and strain >= 65)
    out = []
    # ---- semaine (lundi -> dimanche)
    a0 = _week_start(T); a1 = a0 + timedelta(days=6); s0, s1 = a0.isoformat(), a1.isoformat()
    S = _range_stats(acts, s0, s1)
    if wk and wk.get("planned"):
        out.append(_ch("w-plan", "week", "multi", "Suivre la semaine type", wk["done"], wk["planned"], "séances", a0, a1, T,
                       "Coller au schéma du lundi, c'est garder l'équilibre entre clé, longue, croisé et renfort."))
    mob_t = 5 if (tired or pain_any) else 4
    out.append(_ch("w-mob", "week", "mob", f"{mob_t} séances de mobilité", S["mob_n"], mob_t, "séances", a0, a1, T,
                   "Fatigue ou douleur : la mobilité accélère la récupération." if (tired or pain_any) else "Quinze minutes qui protègent tes tendons et ta foulée."))
    nb = sum(1 for d in ress_dates if s0 <= d <= s1)
    out.append(_ch("w-bilan", "week", "multi", "Bilan du soir chaque jour", nb, 7, "jours", a0, a1, T,
                   "Plus il y a de bilans, plus le coach ajuste finement tes séances."))
    missed_swim = bool((review or {}).get("missed", {}).get("swim"))
    if pain_any:
        out.append(_ch("w-cross", "week", "swim", "3 séances croisées en douceur", S["cross_n"], 3, "séances", a0, a1, T,
                       "La douleur ménage la course : vélo et natation entretiennent le moteur."))
    elif missed_swim:
        out.append(_ch("w-swim", "week", "swim", "2 séances de natation", sum(1 for a in acts if s0 <= a["d"] <= s1 and family(a) == "swim"), 2,
                       "séances", a0, a1, T, "La natation a sauté la semaine dernière : on la remet au programme."))
    # ---- mois civil
    m0 = T.replace(day=1); m1 = (m0 + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    M = _range_stats(acts, m0.isoformat(), m1.isoformat()); wks = ((m1 - m0).days + 1) / 7
    B = _range_stats(acts, (m0 - timedelta(days=28)).isoformat(), (m0 - timedelta(days=1)).isoformat())   # 4 semaines avant le mois
    if not pain_any:
        cap = (ath.get("weekly_km_target") or 40) * wks
        base = B["run_km"] / 4 * wks * 1.1 if B["run_km"] else cap * 0.6        # progression d'environ 10 % sur ton volume récent
        km_t = max(10, int(round(min(cap, base) * (0.85 if tired else 1.0) / 10) * 10))
        out.append(_ch("m-km", "month", "run", f"{km_t} km de course ce mois", M["run_km"], km_t, "km", m0, m1, T,
                       "Volume calé sur ta cible hebdomadaire" + (", réduit par la fatigue." if tired else ".")))
    cpw = ath.get("cross_per_week") or 1.5
    cr_t = max(4, int(round(min(max(cpw * wks, B["cross_n"] / 4 * wks), cpw * wks * 1.3) + (2 if pain_any else 0))))
    out.append(_ch("m-cross", "month", "bike", f"{cr_t} séances de vélo ou natation", M["cross_n"], cr_t, "séances", m0, m1, T,
                   "Le croisé construit l'endurance sans user les jambes de coureur."))
    st_t = int(round((ath.get("strength_per_week") or 2) * wks))
    out.append(_ch("m-str", "month", "strength", f"{st_t} séances de renforcement", M["str_n"], st_t, "séances", m0, m1, T,
                   "Le renfort réduit le risque de blessure quand le volume monte."))
    out.append(_ch("m-mob", "month", "mob", "12 séances de mobilité", M["mob_n"], 12, "séances", m0, m1, T,
                   "La souplesse se gagne par la régularité, pas par l'intensité."))
    # ---- trois mois (trimestre civil)
    qm = (T.month - 1) // 3 * 3 + 1
    q0 = T.replace(month=qm, day=1)
    q1 = (date(q0.year + (1 if qm == 10 else 0), 1 if qm == 10 else qm + 3, 1)) - timedelta(days=1)
    Q = _range_stats(acts, q0.isoformat(), q1.isoformat())
    QB = _range_stats(acts, (q0 - timedelta(days=28)).isoformat(), (q0 - timedelta(days=1)).isoformat())
    qw = ((q1 - q0).days + 1) / 7
    trail = next((g for g in goals or [] if g.get("sport") == "trail" and g.get("elev") and g.get("date") and _d(g["date"]) >= T), None)
    if trail and not pain_any:
        el_t = int(round(max(trail["elev"] * 2, QB["el"] / 4 * qw * 1.15) / 100) * 100)
        out.append(_ch("q-elev", "quarter", "run", f"{el_t} m de D+ cumulé", Q["el"], el_t, "m", q0, q1, T,
                       f"Préparer les montées du {trail.get('label') or trail.get('name')}."))
    hrs = (Q["bike_min"] + Q["swim_min"]) / 60
    hb = (QB["bike_min"] + QB["swim_min"]) / 60 / 4 * qw * 1.1                 # +10 % sur ton rythme croisé récent
    cq = (ath.get("cross_per_week") or 1.5) * qw          # une séance croisée ≈ 1 h ; plafond : 1,6 fois la cible hebdomadaire
    h_t = max(10, int(round(min(max(hb, cq), cq * 1.6) / 5) * 5))
    out.append(_ch("q-tri", "quarter", "multi", f"{h_t} h de vélo et natation", hrs, h_t, "h", q0, q1, T,
                   "Multisport : un socle croisé solide pour la saison."))
    g = _main_goal(goals, T)
    if g and g.get("sport", "run") == "run" and not pain_any:
        lk = round(min(float(ath.get("long_run_target_km") or 30), max(14.0, float(g.get("dist") or 10) * (1.6 if (g.get("dist") or 10) <= 12 else 0.75))))
        out.append(_ch("q-long", "quarter", "run", f"Une sortie longue de {lk} km", Q["long_km"], lk, "km", q0, q1, T,
                       f"Base d'endurance pour {g.get('label') or g.get('name')}."))
    return _ch_sports(out)


def _ch_sports(out):
    """Défis limités aux sports choisis dans Paramètres ; vélo ou natation seuls : intitulés ajustés."""
    need = {"w-mob": ("mob",), "m-mob": ("mob",), "w-swim": ("swim",), "m-km": ("run",), "q-long": ("run",), "m-str": ("strength",),
            "q-elev": ("trail",), "w-cross": ("bike", "swim"), "m-cross": ("bike", "swim"), "q-tri": ("bike", "swim")}
    keep = [c for c in out if any(PF.ok(s) for s in need.get(c["id"], ("multi",))) or c["id"] not in need]
    b, w = PF.ok("bike"), PF.ok("swim")
    if b != w:
        for c in keep:
            c["title"] = c["title"].replace("vélo ou natation", "vélo" if b else "natation").replace("vélo et natation", "vélo" if b else "natation")
            c["why"] = c.get("why", "").replace("vélo et natation", "vélo" if b else "natation")
    return keep


def remember_wins(chs, T, path=None):
    """Défis atteints : une fois réussi, un défi reste affiché (fiche à partager) jusqu'au dernier jour de sa période, même si
    sa cible change ensuite (fatigue, douleur) ou s'il sort de la liste. Mémoire : garmin/defis_atteints.json, entrées expirées purgées."""
    path = Path(path) if path else (Path(WINS_FILE) if WINS_FILE else None)
    mem = {}
    if path and path.exists():
        try: mem = (json.loads(path.read_text(encoding="utf-8")) or {}).get("wins") or {}
        except (OSError, ValueError): mem = {}
    t = T.isoformat()
    mem = {k: v for k, v in mem.items() if isinstance(v, dict) and (v.get("end") or "") >= t}
    for c in chs or []:
        if not c.get("done"): continue
        k = f"{c['id']}|{c['start']}"
        old = mem.get(k) or {}
        mem[k] = {"id": c["id"], "scale": c["scale"], "sport": c["sport"], "title": old.get("title") or c["title"], "target": old.get("target") or c["target"],
                  "unit": c["unit"], "cur": max(c["cur"], old.get("cur") or 0), "start": c["start"], "end": c["end"], "at": old.get("at") or t, "fmt": c.get("fmt")}
    for k, v in mem.items():                                  # défi encore listé : progression mise à jour même si sa cible a changé
        c = next((c for c in chs or [] if f"{c['id']}|{c['start']}" == k), None)
        if c: v["cur"] = max(v["cur"], c["cur"])
    if path:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps({"version": 1, "wins": mem}, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError: pass
    order = {"quarter": 0, "month": 1, "week": 2}
    return sorted(mem.values(), key=lambda v: (order.get(v["scale"], 3), v["at"]))


# ---------------------------------------------------------------------------------------------------------------- séries et records
def _streak(days_set, T, allow_today_missing=True):
    """Série en cours (jours consécutifs jusqu'à aujourd'hui, ou hier si aujourd'hui n'est pas encore rempli) et meilleure série."""
    cur, d = 0, T
    if allow_today_missing and T.isoformat() not in days_set: d = T - timedelta(days=1)
    while d.isoformat() in days_set: cur += 1; d -= timedelta(days=1)
    best, run, prev = 0, 0, None
    for s in sorted(days_set):
        x = _d(s)
        run = run + 1 if prev and (x - prev).days == 1 else 1
        best = max(best, run); prev = x
    return cur, max(best, cur)


def records(acts, T, ress_dates=(), ath=None):
    ath = ath or {}
    recent = (T - timedelta(days=6)).isoformat()
    R = []
    def rec(rid, label, val, unit, d, sport, fmt=None):
        if val: R.append({"id": rid, "label": label, "val": round(val, 2), "unit": unit, "date": d, "sport": sport, "fmt": fmt, "new": d >= recent})
    runs = [a for a in acts if family(a) == "run" and (a.get("km") or 0) > 0]
    if runs:
        a = max(runs, key=lambda x: x["km"]); rec("long_run", "Plus longue sortie", a["km"], "km", a["d"], "run")
        a = max(runs, key=lambda x: x.get("el") or 0); rec("elev", "Plus grand dénivelé", a.get("el") or 0, "m", a["d"], "run")
        for dmin, lab, rid in ((5, "Meilleure allure ≥ 5 km", "pace5"), (10, "Meilleure allure ≥ 10 km", "pace10")):
            c = [x for x in runs if x["km"] >= dmin and (x.get("m") or 0) > 0 and x.get("s") == "run"]
            if c:
                a = min(c, key=lambda x: x["m"] / x["km"]); rec(rid, lab, a["m"] * 60 / a["km"], "s/km", a["d"], "run", "pace")
    for k, lab in (("1k", "Meilleur 1 km"), ("5k", "Meilleur 5 km"), ("10k", "Meilleur 10 km"), ("21k", "Meilleur semi")):
        c = [(a["x"]["best"][k], a["d"]) for a in runs if ((a.get("x") or {}).get("best") or {}).get(k)]   # v6 : meilleur effort mesuré dans la séance
        if c:
            v, d = min(c); rec("best_" + k, lab, v, "s", d, "run", "chrono")
    for fam, lab, rid in (("bike", "Plus longue sortie vélo", "long_bike"), ("swim", "Plus longue nage", "long_swim")):
        if not PF.ok(fam): continue                           # sport non pratiqué (Paramètres) : record non affiché
        c = [a for a in acts if family(a) == fam and (a.get("km") or 0) > 0]
        if c:
            a = max(c, key=lambda x: x["km"]); rec(rid, lab, a["km"], "km", a["d"], fam)
    sess = [a for a in acts if family(a) in ("run", "bike", "swim", "strength")]
    if sess:
        a = max(sess, key=lambda x: x.get("m") or 0); rec("long_sess", "Plus longue séance", (a.get("m") or 0) / 60, "h", a["d"], family(a), "h")
    # semaines (lundi -> dimanche)
    wk = {}
    for a in acts:
        k = _week_start(_d(a["d"])).isoformat(); w = wk.setdefault(k, {"km": 0.0, "min": 0.0, "n": 0, "fams": set()})
        fm = family(a)
        if fm == "run": w["km"] += a.get("km") or 0
        if fm in ("run", "bike", "swim", "strength"): w["min"] += a.get("m") or 0; w["n"] += 1; w["fams"].add(fm)
    if wk:
        k = max(wk, key=lambda x: wk[x]["km"]); rec("week_km", "Plus grosse semaine de course", wk[k]["km"], "km", k, "run")
        k = max(wk, key=lambda x: wk[x]["min"]); rec("week_h", "Plus grosse semaine d'entraînement", wk[k]["min"] / 60, "h", k, "multi", "h")
    # séries
    cur_b, best_b = _streak(set(ress_dates), T)
    active = {a["d"] for a in acts if family(a) in ("run", "bike", "swim", "strength", "mob")}
    cur_a, best_a = _streak(active, T)
    # semaine complète : au moins 4 séances, dont course et (croisé ou renfort) ; la semaine en cours ne casse pas la série
    full = lambda w: w["n"] >= 4 and "run" in w["fams"] and (("bike" in w["fams"] or "swim" in w["fams"]) or "strength" in w["fams"])
    this = _week_start(T)
    cur_w, k = 0, this
    if not (k.isoformat() in wk and full(wk[k.isoformat()])): k -= timedelta(days=7)
    while k.isoformat() in wk and full(wk[k.isoformat()]): cur_w += 1; k -= timedelta(days=7)
    best_w, run, prev = 0, 0, None
    for s in sorted(x for x in wk if full(wk[x])):
        x = _d(s); run = run + 1 if prev and (x - prev).days == 7 else 1; best_w = max(best_w, run); prev = x
    streaks = [{"id": "bilan", "label": "Bilans du soir d'affilée", "cur": cur_b, "best": best_b, "unit": "j"},
               {"id": "active", "label": "Jours actifs d'affilée", "cur": cur_a, "best": best_a, "unit": "j"},
               {"id": "weeks", "label": "Semaines complètes", "cur": cur_w, "best": max(best_w, cur_w), "unit": "sem."}]
    return {"streaks": streaks, "records": R}


def build(acts, T, goals, ath, plan=None, faf=None, strain=None, pain_any=False, ress=None, plan_mem=None, sug=None):
    """Point d'entrée appelé par analysis.build_analysis. Chaque bloc est indépendant : une erreur n'en supprime qu'un."""
    rd = sorted((ress or {}).keys())
    out = {}
    for k, fn in (("week", lambda: week_plan(acts, T, goals, ath, plan, faf, pain_any, plan_mem, sug)),
                  ("pred_hist", lambda: pred_history(acts, T, goals, ath)),
                  ("records", lambda: records(acts, T, rd, ath))):
        try: out[k] = fn()
        except Exception as e:  # noqa: BLE001 : le dashboard doit toujours se générer
            out[k] = None; print(f"Compléments : {k} non calculé ({type(e).__name__}: {e})")
    try:
        out["challenges"] = challenges(acts, T, goals, ath, out.get("week"), faf, strain, pain_any, rd, (plan or {}).get("review"))
    except Exception as e:  # noqa: BLE001
        out["challenges"] = None; print(f"Compléments : défis non calculés ({type(e).__name__}: {e})")
    try:
        out["wins"] = remember_wins(out.get("challenges"), T)
    except Exception as e:  # noqa: BLE001
        out["wins"] = []; print(f"Compléments : défis réussis non mémorisés ({type(e).__name__}: {e})")
    return out
