"""Réglages par défaut d'Emberline.

Tu n'as normalement RIEN à modifier ici : tes réglages se font dans l'app (menu › Paramètres) et pour tes courses dans
l'onglet Objectifs. Les valeurs ci-dessous ne servent que de point de départ, avant ta première configuration :
- la FC seuil, le prénom, le genre et les sports sont remplacés par ce que tu mets dans Paramètres (fichier profil.json) ;
- les objectifs sont remplacés par ceux de l'onglet Objectifs (fichier objectifs.json).
"""

# Objectifs par défaut (vides : tu les ajoutes dans l'onglet Objectifs de l'app).
GOALS = []

ATHLETE = {
    # --- repères cardiaques : la FC seuil est l'ancre des zones (méthode de Friel). Règle-la dans Paramètres. ---
    "hr_max": 190,              # FC max (bpm) par défaut (estimée si tu ne la connais pas)
    "lthr_run": None,           # FC au seuil en course ; None = estimée (91 % de la FC max ou tes courses soutenues)
    "lthr_bike": None,          # FC au seuil à vélo ; None = FC seuil course - 6 bpm
    # --- vélo ---
    "power_meter": False,       # True si un capteur de puissance équipe le vélo
    "ftp_w": None,              # FTP vélo (W), seulement si power_meter = True
    # --- natation : la CSS est recalculée depuis tes nages récentes ---
    "swim_css_s_100m": 110,     # allure seuil natation (s / 100 m), valeur de secours
    # --- volume et disponibilités (adaptés ensuite à tes données) ---
    "weekly_km_target": 30,     # volume hebdomadaire de course de référence
    "long_run_target_km": 20,   # sortie longue visée
    "strength_per_week": 2,     # séances de musculation par semaine
    "cross_per_week": 1.5,      # séances vélo + natation par semaine
    "day_minutes": (45, 75),    # créneau habituel en semaine (min)
    "long_day_minutes": 150,    # créneau du jour long (min)
    "long_days": (5, 6),        # jours possibles pour la sortie longue (5 = samedi, 6 = dimanche)
}

# Résultats de course récents (optionnel) : référence de forme, prioritaire sur l'estimation FC-allure.
RACES = []

# Tracé GPS : "crop" = 300 m masqués au départ et à l'arrivée (protège ton domicile), "full" = tracé complet, "off" = aucun.
GPS_MODE = "crop"

# Périodes glissantes du dashboard.
PERIODS = {"1S": 7, "1M": 30, "3M": 90}
