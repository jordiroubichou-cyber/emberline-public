"""Mobilité et étirements pour le triathlon : 48 exercices et 5 séances de 15 minutes qui changent chaque jour.

Chaque séance tient exactement 15 min (exercices + 5 s de transition entre chacun). La sélection change chaque jour
(tirage déterministe sur la date), évite les exercices qui sollicitent une zone douloureuse déclarée, et la séance
recommandée dépend de l'activité de la veille ou du jour. Les animations sont définies dans le dashboard (MOB_EX).

Chaque séance-sport ne retient que des exercices qui ciblent ce que le sport sollicite ou raccourcit :
  - course   : mollets et tendon d'Achille, chevilles, tibias, quadriceps, fléchisseurs, ischios, fessiers, bandelette ;
  - vélo     : fléchisseurs et droit fémoral (position assise), quadriceps, fessiers, bas du dos, thoracique, nuque, pectoraux ;
  - natation : épaules (coiffe, arrière de l'épaule), grands dorsaux, pectoraux, triceps, rotation et extension thoraciques,
               nuque (respiration), chevilles en extension (battements) ;
  - activation : uniquement des mouvements dynamiques ; récupération : étirements doux du corps entier.
Dans une séance, l'ordre suit les positions (debout, à genoux, assis, sur le ventre, sur le dos) pour limiter les transitions."""
import random

import profil as PF
from datetime import date, timedelta

TOTAL, GAP = 900, 5

# id : (nom, zone, durée en s (par côté si bilatéral), par côté ?, type, zones à éviter si douloureuses, consignes, intérêt triathlon)
EX = {
 "flechisseur": ("Fente basse du fléchisseur de hanche", "Fléchisseurs de hanche", 45, True, "hold", ["genou", "hanche"],
    ["Genou arrière au sol sur un coussin, buste droit", "Rentre le bassin puis avance-le doucement", "Lève le bras du côté du genou au sol pour accentuer"],
    "Libère les fléchisseurs raccourcis par le vélo et la course."),
 "wgs": ("Fente du coureur avec rotation", "Hanches et thoracique", 30, True, "dyn", ["hanche", "lombaires"],
    ["Grande fente, mains au sol à l'intérieur du pied avant", "Ouvre le bras côté jambe avant vers le plafond", "Suis la main du regard, reviens lentement"],
    "L'exercice de mobilité le plus complet avant de courir."),
 "pigeon": ("Pigeon", "Fessiers et piriforme", 45, True, "hold", ["genou", "hanche"],
    ["Jambe avant pliée devant toi, jambe arrière tendue", "Bassin face au sol, descends le buste sur les avant-bras", "Respire lentement, relâche à chaque expiration"],
    "Détend le piriforme, souvent tendu chez le coureur."),
 "9090": ("Rotations 90/90", "Rotation des hanches", 60, False, "dyn", ["hanche", "genou"],
    ["Assis, genoux pliés à 90°, pieds au sol écartés", "Bascule les deux genoux d'un côté puis de l'autre", "Garde le buste grand, mains au sol derrière toi"],
    "Entretient la rotation de hanche, utile en course et en natation."),
 "ischio_sangle": ("Ischio-jambiers à la sangle", "Ischio-jambiers", 45, True, "hold", ["cuisse", "lombaires"],
    ["Allongé, sangle sous le pied, jambe tendue vers le plafond", "Rapproche la jambe sans décoller le bassin", "L'autre jambe reste allongée au sol"],
    "Étire l'arrière de cuisse sans charger le dos."),
 "cossack": ("Fente latérale alternée", "Adducteurs", 60, False, "dyn", ["hanche", "genou"],
    ["Pieds très écartés, descends sur une jambe", "L'autre jambe reste tendue, pointe de pied relevée", "Passe d'un côté à l'autre lentement"],
    "Assouplit les adducteurs et stabilise les hanches."),
 "papillon": ("Papillon", "Adducteurs", 60, False, "hold", ["hanche", "genou"],
    ["Assis, plantes de pieds collées, talons proches", "Laisse descendre les genoux sans forcer", "Petits battements doux, dos droit"],
    "Ouvre les hanches après les sorties longues."),
 "figure4": ("Étirement en 4 allongé", "Fessiers", 45, True, "hold", ["hanche", "genou"],
    ["Allongé, cheville posée sur le genou opposé", "Attrape l'arrière de la cuisse et ramène-la vers toi", "Tête et épaules relâchées au sol"],
    "Relâche les fessiers après le vélo."),
 "swing_av": ("Balancier de jambe avant-arrière", "Hanches (dynamique)", 30, True, "dyn", ["hanche"],
    ["Une main au mur, buste droit", "Balance la jambe d'avant en arrière, amplitude progressive", "Contrôle le mouvement, sans à-coups"],
    "Activation idéale juste avant une sortie course."),
 "swing_lat": ("Balancier de jambe latéral", "Adducteurs et abducteurs", 30, True, "dyn", ["hanche"],
    ["Face au mur, mains en appui", "Balance la jambe de gauche à droite devant toi", "Bassin fixe, amplitude croissante"],
    "Réveille les hanches dans le plan latéral."),
 "squat": ("Squat profond tenu", "Hanches et chevilles", 60, False, "hold", ["genou", "cheville"],
    ["Pieds largeur d'épaules, descends le plus bas possible", "Coudes contre l'intérieur des genoux, talons au sol", "Balance doucement le poids d'un pied à l'autre"],
    "Mobilise chevilles et hanches en même temps."),
 "mollet_mur": ("Mollet au mur, jambe tendue", "Mollets (gastrocnémien)", 40, True, "hold", ["mollet", "cheville"],
    ["Mains au mur, jambe arrière tendue", "Talon arrière bien au sol, pied droit", "Avance le bassin vers le mur"],
    "Indispensable pour le coureur : entretient la souplesse du mollet et du tendon d'Achille."),
 "soleaire": ("Soléaire, genou fléchi", "Mollets (soléaire)", 40, True, "hold", ["mollet", "cheville"],
    ["Même position, genou arrière légèrement fléchi", "Talon au sol, descends le genou vers le sol", "Tu sens l'étirement plus bas dans le mollet"],
    "Cible le soléaire, très sollicité en course."),
 "genou_mur": ("Genou au mur (cheville)", "Chevilles", 30, True, "dyn", ["cheville", "genou"],
    ["Pied à une main du mur, talon au sol", "Amène le genou toucher le mur, puis recule", "Recule le pied si c'est trop facile"],
    "Améliore la flexion de cheville et la foulée."),
 "chevilles": ("Cercles de chevilles", "Chevilles", 30, True, "dyn", ["cheville"],
    ["Debout sur une jambe, genou opposé levé", "Dessine de grands cercles avec la pointe du pied", "Change de sens à mi-temps"],
    "Lubrifie la cheville avant course et vélo."),
 "orteils": ("Assis sur les orteils", "Pieds et voûte plantaire", 60, False, "hold", ["pied", "genou"],
    ["À genoux, orteils retournés sous les pieds", "Assieds-toi doucement sur les talons", "Penche-toi un peu en arrière si c'est confortable"],
    "Assouplit la voûte plantaire et soulage le pied."),
 "chat_vache": ("Chat-vache", "Colonne vertébrale", 60, False, "dyn", ["poignet"],
    ["À quatre pattes, mains sous les épaules", "Expire en arrondissant le dos, inspire en le creusant", "Mouvement lent, vertèbre par vertèbre"],
    "Déverrouille le dos après la position aéro."),
 "aiguille": ("Fil de l'aiguille", "Thoracique", 30, True, "dyn", ["epaule", "poignet"],
    ["À quatre pattes, glisse un bras sous ton corps", "Puis ouvre-le vers le plafond en tournant le buste", "Suis ta main du regard"],
    "Rotation thoracique essentielle pour le crawl."),
 "pont": ("Pont fessier", "Fessiers et hanches", 60, False, "dyn", ["lombaires"],
    ["Allongé, genoux pliés, pieds à plat", "Monte le bassin en serrant les fessiers", "Redescends lentement, vertèbre par vertèbre"],
    "Active les fessiers, moteurs de la course."),
 "enfant": ("Posture de l'enfant, bras tendus", "Dos et grands dorsaux", 60, False, "hold", ["genou", "epaule"],
    ["À genoux, assieds-toi sur les talons", "Bras loin devant, front vers le sol", "Pousse les mains vers l'avant en expirant"],
    "Étire les grands dorsaux, sollicités à chaque mouvement de bras."),
 "cercles_bras": ("Grands cercles de bras", "Épaules (dynamique)", 45, False, "dyn", ["epaule"],
    ["Debout, bras tendus, fais de grands cercles", "Moitié du temps vers l'avant, puis vers l'arrière", "Amplitude progressive, sans douleur"],
    "Échauffe les épaules avant de nager."),
 "pec_porte": ("Pectoraux au mur", "Pectoraux et avant des épaules", 40, True, "hold", ["epaule"],
    ["Main au mur derrière toi, bras à hauteur d'épaule", "Avance d'un pas et tourne doucement le buste", "Épaule basse, pas de douleur"],
    "Compense la posture fermée du vélo et la natation."),
 "baton": ("Passage de bâton", "Mobilité des épaules", 45, False, "dyn", ["epaule"],
    ["Tiens un bâton ou une serviette, mains écartées", "Passe les bras tendus de devant à derrière", "Écarte les mains si ça coince"],
    "Gagne de l'amplitude d'épaule pour le retour de bras."),
 "triceps_lat": ("Triceps et flanc au-dessus de la tête", "Triceps et grands dorsaux", 40, True, "hold", ["epaule"],
    ["Main derrière la tête, coude vers le plafond", "L'autre main tire doucement le coude", "Penche le buste du côté opposé"],
    "Étire toute la chaîne du bras de nage."),
 "anges": ("Anges au mur", "Omoplates et posture", 45, False, "dyn", ["epaule"],
    ["Dos et bras contre un mur, coudes à 90°", "Glisse les bras vers le haut sans décoller", "Redescends en serrant les omoplates"],
    "Renforce la posture et soulage l'épaule du nageur."),
 "cou": ("Inclinaison du cou", "Cervicales et trapèzes", 30, True, "hold", ["cervicales"],
    ["Assis ou debout, épaules basses", "Incline l'oreille vers l'épaule", "La main posée sur la tête accompagne sans tirer"],
    "Relâche la nuque après la position aéro et la respiration en crawl."),
 "genoux_poitrine": ("Genoux à la poitrine", "Bas du dos", 45, False, "hold", ["lombaires"],
    ["Allongé, ramène les genoux contre la poitrine", "Enlace-les avec les bras", "Berce-toi doucement de gauche à droite"],
    "Soulage le bas du dos après le vélo."),
 "torsion": ("Torsion allongée", "Colonne et fessiers", 45, True, "hold", ["lombaires"],
    ["Allongé, genoux pliés, bras en croix", "Laisse tomber les genoux d'un côté", "Les épaules restent au sol, regard opposé"],
    "Décompresse la colonne en fin de séance."),
 "cobra": ("Sphinx puis cobra", "Extension du dos et abdominaux", 45, False, "hold", ["lombaires"],
    ["À plat ventre, appuie-toi sur les avant-bras", "Puis tends progressivement les bras si c'est confortable", "Bassin au sol, épaules loin des oreilles"],
    "Contre la flexion prolongée du vélo."),
 "inclinaison": ("Inclinaison latérale debout", "Flancs et grands dorsaux", 30, True, "hold", ["lombaires", "epaule"],
    ["Debout, bras tendus au-dessus de la tête", "Penche-toi sur le côté sans tourner le buste", "Pousse la main vers le haut et le côté"],
    "Allonge les flancs pour une meilleure respiration."),
 "charniere": ("Charnière de hanche", "Ischio-jambiers (dynamique)", 45, False, "dyn", ["lombaires", "cuisse"],
    ["Debout, genoux légèrement fléchis", "Recule les fesses en gardant le dos plat", "Remonte en poussant les hanches vers l'avant"],
    "Apprend à fléchir la hanche dos plat, utile en côte et en vélo."),
 "ischio_debout": ("Ischios pied sur une marche", "Ischio-jambiers et mollet", 40, True, "hold", ["cuisse", "lombaires"],
    ["Talon posé sur une marche, jambe tendue", "Penche-toi en avant dos plat", "Pointe de pied tirée vers toi"],
    "Étirement facile à faire après chaque course."),
 "quad_debout": ("Quadriceps debout", "Quadriceps", 40, True, "hold", ["genou"],
    ["Debout, attrape ton pied derrière toi", "Genoux serrés, bassin légèrement rentré", "Tiens-toi au mur si besoin"],
    "Relâche les quadriceps après la course et le vélo."),
 "respiration": ("Respiration abdominale", "Récupération", 90, False, "breath", [],
    ["Allongé, genoux pliés, mains sur le ventre", "Inspire 4 s par le nez en gonflant le ventre", "Expire 6 s par la bouche, épaules relâchées"],
    "Fait redescendre le rythme cardiaque et améliore la récupération."),
 # ---------- v4.1 : 14 exercices supplémentaires ----------
 "demi_grand_ecart": ("Demi-grand écart", "Ischio-jambiers et fléchisseurs", 40, True, "dyn", ["cuisse", "genou", "hanche"],
    ["Genou arrière au sol, pied avant à plat devant toi", "Recule le bassin en tendant la jambe avant, pointe de pied vers toi", "Reviens en fente basse puis repars en arrière, sans à-coups"],
    "Allonge ischios et fléchisseurs dans le même mouvement, idéal après une sortie longue."),
 "canape": ("Étirement du canapé", "Quadriceps (droit fémoral)", 45, True, "hold", ["genou", "cuisse"],
    ["Genou arrière au sol contre le mur, tibia remonté le long du mur", "Pied avant à plat, mains sur le genou avant", "Redresse doucement le buste en serrant le fessier"],
    "Le meilleur étirement du droit fémoral, raccourci par des heures de pédalage."),
 "ischio_assis": ("Ischios assis, jambe tendue", "Ischio-jambiers", 45, True, "hold", ["cuisse", "lombaires"],
    ["Assis, une jambe tendue, l'autre pied contre l'intérieur de la cuisse", "Penche-toi en avant depuis les hanches, dos long", "Mains vers la cheville sans arrondir le haut du dos"],
    "Assouplit l'arrière de cuisse pour une foulée plus ample."),
 "mollet_marche": ("Talon dans le vide sur une marche", "Mollets et tendon d'Achille", 40, True, "dyn", ["mollet", "cheville"],
    ["Avant du pied sur une marche, talon dans le vide, une main au mur", "Monte sur la pointe puis descends lentement le talon sous la marche", "Trois secondes pour descendre, genou tendu"],
    "Renforce et assouplit le tendon d'Achille, point faible du coureur."),
 "tibial": ("Assis sur les talons, dessus du pied au sol", "Tibias et dessus du pied", 45, False, "hold", ["genou", "cheville", "tibia", "pied"],
    ["À genoux, dessus des pieds à plat, assieds-toi sur les talons", "Mains au sol derrière toi, penche-toi en arrière", "Soulève doucement les genoux si c'est confortable"],
    "Étire les releveurs du pied : utile contre la périostite et pour des battements souples en natation."),
 "ouverture_thoracique": ("Ouverture thoracique sur une chaise", "Thoracique et grands dorsaux", 45, False, "hold", ["epaule", "lombaires"],
    ["À genoux face à une chaise, coudes posés sur l'assise", "Mains jointes derrière la tête, hanches au-dessus des genoux", "Laisse descendre la poitrine entre les bras en expirant"],
    "Redonne de l'extension au haut du dos, enroulé sur le vélo, et de l'amplitude aux bras pour nager."),
 "rotation_thoracique": ("Rotation thoracique main-nuque", "Rotation thoracique", 30, True, "dyn", ["epaule", "poignet", "dorsales"],
    ["À quatre pattes, une main derrière la tête", "Amène le coude vers le bras d'appui en expirant", "Puis ouvre-le vers le plafond en le suivant du regard"],
    "Libère la rotation du haut du dos, clé de la respiration en crawl."),
 "ytw": ("Y-T-W allongé", "Omoplates et haut du dos", 60, False, "dyn", ["epaule", "lombaires"],
    ["À plat ventre, front juste au-dessus du sol", "Décolle les bras en Y, puis en T, puis en W", "Serre les omoplates à chaque position, épaules loin des oreilles"],
    "Active les stabilisateurs de l'omoplate qui protègent l'épaule du nageur."),
 "bird_dog": ("Bras-jambe opposés à quatre pattes", "Gainage et fessiers", 30, True, "dyn", ["lombaires", "poignet", "genou"],
    ["À quatre pattes, dos plat, nombril rentré", "Tends le bras et la jambe opposée jusqu'à l'horizontale", "Reviens lentement, sans laisser le bassin tourner"],
    "Stabilise le tronc et le bassin pour courir et pédaler sans perte d'énergie."),
 "dead_bug": ("Dead bug", "Gainage profond", 60, False, "dyn", ["lombaires"],
    ["Dos au sol, bras vers le plafond, genoux à 90°", "Allonge un bras et la jambe opposée sans décoller le bas du dos", "Reviens et change de côté, en expirant à chaque extension"],
    "Gainage profond sans charger le dos : la base d'une course stable."),
 "hanche_cercle": ("Cercles de hanche debout", "Rotation des hanches", 30, True, "dyn", ["hanche", "genou"],
    ["Une main au mur, buste droit, main libre sur la hanche", "Monte le genou devant toi puis ouvre-le sur le côté", "Redescends en dessinant un grand cercle, sans bouger le buste"],
    "Lubrifie la hanche dans toutes ses directions avant de courir ou de pédaler."),
 "tfl": ("Bandelette ilio-tibiale debout", "Bandelette ilio-tibiale et hanche", 40, True, "hold", ["hanche", "genou"],
    ["Debout, croise la jambe à étirer derrière l'autre", "Bras au-dessus de la tête, pousse la hanche vers l'extérieur", "Penche le buste du côté opposé, sans tourner"],
    "Détend le côté de la cuisse, souvent en cause dans les douleurs externes du genou (coureur et cycliste)."),
 "epaule_croise": ("Épaule, bras croisé", "Arrière de l'épaule", 40, True, "hold", ["epaule", "coude"],
    ["Bras tendu, ramène-le à l'horizontale contre la poitrine", "L'autre main tire doucement juste au-dessus du coude", "Épaule basse, regard droit devant"],
    "Assouplit l'arrière de l'épaule, très sollicité par la traction en crawl."),
 "rotation_externe": ("Rotations externes, coudes au corps", "Coiffe des rotateurs", 45, False, "dyn", ["epaule"],
    ["Debout, coudes collés au corps et pliés à 90°", "Ouvre les avant-bras vers l'extérieur sans décoller les coudes", "Serre les omoplates en fin de mouvement, reviens lentement"],
    "Réveille la coiffe des rotateurs, garde-fou de l'épaule du nageur."),
}

# Zones travaillées par chaque exercice et besoins de chaque sport (vérifié par test_mobilite.py : chaque exercice d'une
# séance-sport doit cibler au moins un besoin du sport ; l'activation ne contient que des mouvements dynamiques).
CIBLES = {
 "flechisseur": {"hanche", "quadriceps"}, "wgs": {"hanche", "dorsales", "ischios"}, "pigeon": {"fessiers", "hanche"},
 "9090": {"hanche", "fessiers"}, "ischio_sangle": {"ischios"}, "cossack": {"adducteurs", "hanche"}, "papillon": {"adducteurs", "hanche"},
 "figure4": {"fessiers"}, "swing_av": {"hanche", "ischios"}, "swing_lat": {"adducteurs", "hanche"}, "squat": {"hanche", "cheville"},
 "mollet_mur": {"mollet"}, "soleaire": {"mollet", "cheville"}, "genou_mur": {"cheville"}, "chevilles": {"cheville"}, "orteils": {"pied"},
 "chat_vache": {"lombaires", "dorsales"}, "aiguille": {"dorsales", "epaule"}, "pont": {"fessiers", "tronc"}, "enfant": {"dorsales", "epaule"},
 "cercles_bras": {"epaule"}, "pec_porte": {"pectoraux", "epaule"}, "baton": {"epaule"}, "triceps_lat": {"epaule", "dorsales"},
 "anges": {"epaule", "dorsales"}, "cou": {"cervicales"}, "genoux_poitrine": {"lombaires"}, "torsion": {"lombaires", "fessiers"},
 "cobra": {"lombaires", "dorsales"}, "inclinaison": {"dorsales", "tronc"}, "charniere": {"ischios", "hanche"},
 "ischio_debout": {"ischios", "mollet"}, "quad_debout": {"quadriceps"}, "respiration": {"global"},
 "demi_grand_ecart": {"ischios", "hanche"}, "canape": {"quadriceps", "hanche"}, "ischio_assis": {"ischios"},
 "mollet_marche": {"mollet", "cheville"}, "tibial": {"tibia", "pied", "cheville"}, "ouverture_thoracique": {"dorsales", "epaule"},
 "rotation_thoracique": {"dorsales"}, "ytw": {"epaule", "dorsales"}, "bird_dog": {"tronc", "fessiers"}, "dead_bug": {"tronc"},
 "hanche_cercle": {"hanche"}, "tfl": {"bandelette", "hanche"}, "epaule_croise": {"epaule"}, "rotation_externe": {"epaule"},
}
BESOINS = {
 "course": {"mollet", "cheville", "pied", "tibia", "quadriceps", "ischios", "hanche", "fessiers", "bandelette", "global"},
 "velo": {"hanche", "quadriceps", "fessiers", "ischios", "bandelette", "lombaires", "dorsales", "cervicales", "pectoraux", "global"},
 "nage": {"epaule", "dorsales", "pectoraux", "cervicales", "tibia", "global"},
}

# (clé, titre, icône, sous-titre, exercices dans l'ordre de la séance, exercice garanti, exercice final)
THEMES = [
 ("course", "Course : mollets, hanches et ischios", "ei-run", "Pour les jambes après une sortie course",
  ["mollet_mur", "soleaire", "mollet_marche", "quad_debout", "tfl", "ischio_debout", "genou_mur", "flechisseur", "canape",
   "demi_grand_ecart", "pigeon", "tibial", "orteils", "ischio_assis", "9090", "figure4", "ischio_sangle", "respiration"], "mollet_mur", "respiration"),
 ("velo", "Vélo : fléchisseurs, dos et nuque", "ei-bike", "Contre la position assise et aéro",
  ["cou", "pec_porte", "quad_debout", "tfl", "flechisseur", "canape", "chat_vache", "ouverture_thoracique", "enfant", "pigeon",
   "cobra", "figure4", "ischio_sangle", "pont", "genoux_poitrine", "torsion", "respiration"], "flechisseur", "respiration"),
 ("nage", "Natation : épaules et thoracique", "ei-swim", "Amplitude et santé des épaules",
  ["cercles_bras", "rotation_externe", "baton", "epaule_croise", "pec_porte", "triceps_lat", "anges", "inclinaison", "cou",
   "chat_vache", "rotation_thoracique", "aiguille", "ouverture_thoracique", "enfant", "tibial", "ytw", "cobra", "respiration"], "rotation_thoracique", "respiration"),
 ("activation", "Activation avant la séance", "ei-bolt", "Dynamique, pour préparer le corps",
  ["cercles_bras", "rotation_externe", "baton", "anges", "swing_av", "swing_lat", "hanche_cercle", "chevilles", "genou_mur",
   "squat", "cossack", "charniere", "wgs", "chat_vache", "aiguille", "bird_dog", "dead_bug", "pont"], "wgs", "pont"),
 ("recup", "Récupération complète", "ei-batt", "Étirements doux du corps entier",
  ["cou", "mollet_mur", "quad_debout", "enfant", "pigeon", "papillon", "ischio_assis", "9090", "cobra", "ischio_sangle",
   "figure4", "genoux_poitrine", "torsion", "respiration"], "genoux_poitrine", "respiration"),
]
SPORT_THEME = {"run": "course", "trail": "course", "bike": "velo", "swim": "nage", "strength": "recup", "walk": "recup"}
REGION_FR = {"hanche": "la hanche", "cuisse": "la cuisse", "genou": "le genou", "tibia": "le tibia", "mollet": "le mollet",
             "cheville": "la cheville", "pied": "le pied", "epaule": "l'épaule", "coude": "le coude", "poignet": "le poignet",
             "cervicales": "la nuque", "dorsales": "le dos", "lombaires": "le bas du dos"}


def _time(ids):
    return sum(EX[i][2] * (2 if EX[i][3] else 1) for i in ids) + GAP * max(0, len(ids) - 1)


FILL = ["chat_vache", "flechisseur", "genoux_poitrine", "torsion", "cobra", "pigeon", "ischio_sangle", "mollet_mur", "papillon",
        "9090", "figure4", "quad_debout", "pont", "enfant", "soleaire", "ischio_debout", "ischio_assis", "cou", "epaule_croise",
        "dead_bug", "respiration"]


def _session(key, pool, first, last, today, bad, must=()):
    """Tirage du jour (même résultat toute la journée), ordre logique de la liste, durée ramenée à 15 min pile.
    `first` est garanti dans la séance (exercice clé du sport) et garde sa place dans l'ordre des positions.
    Si des douleurs retirent trop d'exercices, la séance est complétée avec des exercices sans risque pour la zone."""
    safe = lambda i: not (set(EX[i][5]) & bad)
    ok = [i for i in pool if safe(i)]
    rng = random.Random(f"{today}|{key}")
    head = [first] if first in ok else []
    head += [m for m in must if m in EX and safe(m) and m not in head and m != last]   # v6 : zones réellement sollicitées par les séances
    tail = [last] if last in ok and last != first else []
    mid = [i for i in ok if i not in head + tail]
    rng.shuffle(mid)
    chosen = head + tail
    for i in mid:
        if _time(chosen + [i]) <= TOTAL - 25:
            chosen.append(i)
    extra = []
    if _time(chosen) < TOTAL - 100:
        fill = [i for i in FILL if safe(i) and i not in chosen]
        rng.shuffle(fill)
        for i in fill:
            if _time(chosen + extra + [i]) <= TOTAL - 25:
                extra.append(i)
    order = {i: n for n, i in enumerate(pool)}
    chosen.sort(key=lambda i: order[i])
    if last in chosen:
        chosen.remove(last)
    chosen = chosen + extra + ([last] if last in tail else [])
    # répartit le temps restant (pas de 5 s ; 10 s pour un exercice par côté) pour finir à 15 min pile
    base = {i: EX[i][2] for i in chosen}
    durs = dict(base)
    rest = TOTAL - _time(chosen)
    order2 = [i for i in chosen if EX[i][4] in ("hold", "breath")] + [i for i in chosen if EX[i][4] == "dyn"]
    for cap in (1.5, 2.0, 3.0, 99):
        moved = True
        while rest > 0 and moved:
            moved = False
            for i in order2:
                step = 10 if EX[i][3] else 5
                if rest >= step and durs[i] + 5 <= base[i] * cap:
                    durs[i] += 5; rest -= step; moved = True
                if rest <= 0:
                    break
        if rest <= 0:
            break
    if rest > 0:                              # 5 s restantes avec seulement des exercices par côté : sur une transition
        j = next((i for i in reversed(chosen) if not EX[i][3]), None)
        if j:
            durs[j] += rest
    return [{"id": i, "dur": durs[i], "side": EX[i][3]} for i in chosen]


# v5 (audit A1) : les étirements entretiennent l'amplitude mais ne préviennent pas les blessures de surcharge (Behm et al. 2016 ;
# Lauersen et al. 2014 : RR 0,96 non significatif) ; le renforcement, lui, les réduit (RR 0,32). D'où ce bloc court, à part.
RENFO = [
    ("Montées sur pointes, descente lente sur une jambe", "Mollets et tendon d'Achille", "3 × 12 par jambe, descente en 3 s", "cheville"),
    ("Relevés de pointes de pied, dos au mur", "Tibial antérieur (tibia)", "3 × 15", "tibia"),
    ("Abduction de hanche couché sur le côté", "Moyen fessier", "3 × 15 par côté", "hanche"),
    ("Pont fessier sur une jambe", "Fessiers et ischio-jambiers", "3 × 10 par jambe", "genou"),
]


def renfo(pains):
    """Renforcement de prévention (8 min, 2 à 3 fois par semaine) ; un exercice qui charge une zone douloureuse active est retiré."""
    active = {p.get("region") for p in (pains or []) if not p.get("archived") and (p.get("intensity") or 0) >= 4}
    past = {p.get("region") for p in (pains or []) if p.get("archived") or (p.get("intensity") or 0) == 0}
    ex = [{"name": n, "zone": z, "dose": d, "focus": r in past, "region": r} for n, z, d, r in RENFO if r not in active]
    why = "Les étirements entretiennent l'amplitude ; c'est le renforcement qui réduit les blessures de surcharge."
    if "tibia" in past: why += " Le relevé de pointes cible directement la zone de ta périostite passée."
    return {"title": "Renforcement de prévention", "freq": "8 min, 2 à 3 fois par semaine, par exemple après un footing facile", "ex": ex, "why": why}


def build(A, pains, acts, today):
    """Séances du jour pour le dashboard."""
    try:
        bad = {p.get("region") for p in (pains or []) if not p.get("archived") and (p.get("intensity") or 0) >= 1 and p.get("region")}
        d0 = date.fromisoformat(today)
        done = [a for a in acts if str(a.get("d", ""))[:10] == today]
        yday = [a for a in acts if str(a.get("d", ""))[:10] == (d0 - timedelta(days=1)).isoformat()]
        rec_sp = ((A.get("suggest") or {}).get("rec") or [])
        dem = None
        try:                                       # v6 : thème et exercices d'après le contenu réel des séances des 48 h
            import detail_analysis as DA
            dem = DA.mob_demand(acts, today)
        except Exception:                          # noqa: BLE001
            dem = None
        if done or yday:
            base = SPORT_THEME.get((done or yday)[-1].get("s"), "recup")
            rec = dem["theme"] if dem and dem.get("theme") else base
            why = ("Après ta séance du jour." if done else "Pour récupérer de ta séance d'hier.") + \
                  (f" Ciblée sur ce que tes séances ont sollicité : {dem['why']}." if dem and dem.get("why") else "")
        elif any(s in ("run", "bike") for s in rec_sp):
            rec, why = "activation", "À faire avant ta séance du jour."
        else:
            rec, why = "recup", "Journée calme : on entretient la souplesse."
        try:                                       # bilan d'hier soir : maladie, repos choisi, jambes lourdes, stress (ressenti.py)
            import ressenti
            fr = (A.get("ress") or {})
            mp = ressenti.mobility_pick({"cur": fr.get("cur"), "flags": fr.get("flags") or [], "dispo": (fr.get("cur") or {}).get("dispo")})
            if mp: rec, why = mp
        except Exception:                          # noqa: BLE001
            pass
        TH_SP = {"course": "run", "velo": "bike", "nage": "swim"}       # thèmes liés à un sport : seulement si ce sport est pratiqué (Paramètres)
        if rec in TH_SP and not PF.ok(TH_SP[rec]): rec = "recup"
        note = ""
        if bad:
            note = "Exercices qui sollicitent " + ", ".join(REGION_FR.get(r, r) for r in sorted(bad)) + " retirés (douleur déclarée)."
        sessions = []
        for key, title, icon, sub, pool, first, last in THEMES:
            if key in TH_SP and not PF.ok(TH_SP[key]): continue
            must = [m for m in (dem or {}).get("must") or [] if m in pool] if key == rec else []
            ex = _session(key, pool, first, last, today, bad, must)
            zones, base = [], set()
            for e in ex:
                z = EX[e["id"]][1]
                b = z.split(" (")[0].split(" et ")[0].strip().lower()      # « mollets (soléaire) » et « mollets » : une seule zone affichée
                if b not in base and EX[e["id"]][4] != "breath":
                    zones.append(z.split(" (")[0]); base.add(b)
            sessions.append({"key": key, "title": title, "icon": icon, "sub": sub, "rec": key == rec, "ex": ex,
                             "total": TOTAL, "zones": zones[:4]})
        sessions.sort(key=lambda s: not s["rec"])
        lib = {i: {"name": v[0], "zone": v[1], "side": v[3], "kind": v[4], "cues": v[6], "tip": v[7]} for i, v in EX.items()}
        rf = renfo(pains)
        if dem and rf:                              # v6 : renforcement ciblé (descentes, séries rapides -> mollets, tendon et genoux)
            hot = set()
            if "quad_debout" in (dem.get("must") or []): hot |= {"cheville", "genou"}
            if "mollet_mur" in (dem.get("must") or []): hot.add("cheville")
            for e in rf.get("ex") or []:
                if e.get("region") in hot: e["focus"] = True
        return {"date": today, "rec": rec, "why": why, "note": note, "gap": GAP, "sessions": sessions, "lib": lib, "renfo": rf, "demand": dem}
    except Exception as e:  # jamais bloquant pour le dashboard
        print(f"Mobilité : séances non générées ({type(e).__name__} : {e}).")
        return None
