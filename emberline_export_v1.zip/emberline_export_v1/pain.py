"""Douleurs et blessures : lecture/validation de douleurs.json (écrit par la sous-page « MàJ des douleurs » du dashboard),
mémoire de récidive et modulation déterministe des séances suggérées (aucune IA).

Principes (repères généraux de prise en charge des tendinopathies et douleurs d'effort, non médicaux) :
- la douleur déclarée pendant l'effort ou au repos est plus préoccupante que celle qui apparaît après l'effort ;
- une douleur gérable (1 à 3) n'impose pas d'arrêt : on garde le volume et on ajoute échauffement et renforcement ciblés ;
- une douleur modérée (4 à 6) réduit le volume et l'intensité des disciplines qui sollicitent la zone, jusqu'à les remplacer par une discipline portée ;
- une douleur aiguë (7 à 10) impose le repos strict de la zone et un avis médical ;
- une récidive dans la même zone (douleur déjà déclarée puis archivée ou résolue) renforce la prudence.
Les données ne sont jamais effacées : une douleur « supprimée » est archivée (archived = true) et sert de mémoire de récidive.
Ce module ne remplace pas un avis médical."""
import hashlib
import json
from datetime import date
from pathlib import Path

PAIN_FILE = "douleurs.json"

# ---------------------------------------------------------------------------------------------
# 1. Arborescence zone -> région -> latéralisation -> pathologie (listes extensibles : ajouter une ligne suffit)
# ---------------------------------------------------------------------------------------------
MACROS = {"bas": "Bas du corps", "haut": "Haut du corps", "tronc": "Tronc & rachis"}
SIDES = {"G": "Gauche", "D": "Droite", "B": "Bilatéral", "C": "Central"}
WHENS = {"pendant": "Pendant l'effort", "apres": "Après l'effort", "repos": "Au repos"}
SYMPTOMS = {"sourde": "Douleur sourde", "brulure": "Brûlure", "tiraillement": "Tiraillement", "blocage": "Blocage"}

# région : (libellé, macro, charge mécanique par discipline 0..1 : course, vélo, natation, musculation, latéralité possible)
REGIONS = {
    "hanche": ("Hanche / aine", "bas", (0.8, 0.5, 0.4, 0.6)),
    "cuisse": ("Cuisse", "bas", (0.8, 0.5, 0.2, 0.6)),
    "genou": ("Genou", "bas", (0.9, 0.6, 0.3, 0.6)),
    "tibia": ("Tibia", "bas", (1.0, 0.15, 0.1, 0.3)),
    "mollet": ("Mollet", "bas", (0.9, 0.3, 0.2, 0.4)),
    "cheville": ("Cheville / Achille", "bas", (0.9, 0.4, 0.3, 0.4)),
    "pied": ("Pied / orteils", "bas", (1.0, 0.35, 0.15, 0.4)),
    "epaule": ("Épaule", "haut", (0.1, 0.3, 1.0, 0.8)),
    "coude": ("Coude", "haut", (0.0, 0.3, 0.4, 0.6)),
    "poignet": ("Poignet / main", "haut", (0.0, 0.5, 0.3, 0.6)),
    "cervicales": ("Cervicales", "tronc", (0.1, 0.6, 0.6, 0.5)),
    "dorsales": ("Dorsales", "tronc", (0.2, 0.4, 0.5, 0.5)),
    "lombaires": ("Lombaires", "tronc", (0.5, 0.6, 0.4, 0.7)),
}
DISCS = ("run", "bike", "swim", "strength")
DISC_LABEL = {"run": "course à pied", "bike": "vélo", "swim": "natation", "strength": "musculation"}

# pathologie : (libellé, région, surcharges de charge mécanique {discipline: poids}, plancher de gravité ou 0, clé de protocole)
PATHOS = {
    "pubalgie": ("Pubalgie / adducteurs", "hanche", {}, 0, "adducteurs"),
    "fessier": ("Tendinopathie des fessiers / bursite trochantérienne", "hanche", {"run": 0.8, "bike": 0.4}, 0, "fessier"),
    "ischio": ("Lésion des ischio-jambiers", "cuisse", {"run": 1.0, "bike": 0.5}, 0, "muscle"),
    "quadriceps": ("Contracture / lésion du quadriceps", "cuisse", {"run": 0.9, "bike": 0.6}, 0, "muscle"),
    "itbs": ("Syndrome de l'essuie-glace (bandelette ilio-tibiale)", "genou", {"run": 1.0, "bike": 0.5, "swim": 0.1}, 0, "itbs"),
    "fempat": ("Syndrome fémoro-patellaire", "genou", {"run": 0.9, "bike": 0.6, "swim": 0.3}, 0, "fempat"),
    "rotulien": ("Tendinite rotulienne", "genou", {"run": 0.9, "bike": 0.7, "swim": 0.2}, 0, "rotulien"),
    "pattedoie": ("Tendinopathie de la patte d'oie", "genou", {"run": 0.7, "bike": 0.5, "swim": 0.4}, 0, "pattedoie"),
    "periostite": ("Périostite tibiale (syndrome de stress tibial)", "tibia", {"run": 1.0, "bike": 0.1, "swim": 0.1}, 0, "periostite"),
    "fracture": ("Suspicion de fracture de fatigue", "tibia", {"run": 1.0, "bike": 0.3, "swim": 0.1}, 7, "fracture"),
    "mollet": ("Élongation / lésion du mollet", "mollet", {"run": 1.0, "bike": 0.4, "swim": 0.2}, 0, "muscle"),
    "achille": ("Tendinopathie d'Achille", "cheville", {"run": 1.0, "bike": 0.3, "swim": 0.15}, 0, "achille"),
    "entorse": ("Entorse de cheville", "cheville", {"run": 1.0, "bike": 0.4, "swim": 0.2}, 0, "entorse"),
    "peroniers": ("Tendinopathie des péroniers", "cheville", {"run": 0.9, "bike": 0.3}, 0, "peroniers"),
    "fascite": ("Fascite plantaire (aponévrosite)", "pied", {"run": 1.0, "bike": 0.4, "swim": 0.2}, 0, "fascite"),
    "metatarsalgie": ("Métatarsalgie", "pied", {"run": 1.0, "bike": 0.4}, 0, "metatarsalgie"),
    "coiffe": ("Tendinopathie de la coiffe des rotateurs (épaule du nageur)", "epaule", {"swim": 1.0, "strength": 0.9}, 0, "coiffe"),
    "sousacromial": ("Conflit sous-acromial", "epaule", {"swim": 1.0, "strength": 0.9, "bike": 0.3}, 0, "coiffe"),
    "epicondylite": ("Épicondylite (tennis elbow)", "coude", {"swim": 0.3, "strength": 0.7, "bike": 0.2}, 0, "coude"),
    "epitrochleite": ("Épitrochléite (golf elbow)", "coude", {"swim": 0.3, "strength": 0.7, "bike": 0.2}, 0, "coude"),
    "dequervain": ("Ténosynovite de De Quervain", "poignet", {"swim": 0.3, "strength": 0.7, "bike": 0.5}, 0, "poignet"),
    "canal": ("Syndrome du canal carpien", "poignet", {"swim": 0.2, "strength": 0.6, "bike": 0.7}, 0, "poignet"),
    "cervicalgie": ("Cervicalgie / torticolis", "cervicales", {}, 0, "rachis"),
    "dorsalgie": ("Dorsalgie / douleur intercostale", "dorsales", {}, 0, "rachis"),
    "lombalgie": ("Lombalgie", "lombaires", {}, 0, "lombalgie"),
    "sciatique": ("Lombo-sciatalgie", "lombaires", {"run": 0.7, "bike": 0.7}, 5, "lombalgie"),
}

# Protocoles : conseils par niveau (léger / modéré / aigu) et par discipline, renfo ciblé. Clé de protocole -> dictionnaire.
GENERIC_LIGHT = "Garde le volume prévu. Ajoute 5 à 10 minutes d'échauffement ciblé sur la zone, de la mobilité douce, puis un renforcement progressif en fin de séance."
PROTO = {
    "itbs": {"warm": "Échauffement fessier moyen : 2 × 12 pas latéraux avec élastique et 2 × 10 'clamshell' par côté.",
             "renfo": "Renfort excentrique des abducteurs (fessier moyen) : 3 × 10 relevés latéraux lents, gainage latéral 3 × 30 s, puis travail de contrôle du genou en fente.",
             "run": "Évite descentes, dévers et pistes en sens unique ; foulée plus courte et cadence un peu plus haute.",
             "bike": "Vélocité souple (cadence 90-100 tr/min, faible résistance), position de selle vérifiée (pas trop basse, cales neutres).",
             "swim": "Natation possible : évite les battements de brasse, favorise le pull-buoy et le crawl."},
    "fempat": {"warm": "Échauffement : 2 × 10 squats partiels contrôlés (amplitude sans douleur) et activation des fessiers.",
               "renfo": "Quadriceps en chaîne fermée dans l'amplitude confortable (squat sur chaise, presse légère, step-up bas) et fessiers : 3 × 12, tempo lent.",
               "run": "Limite descentes, escaliers et sols durs ; allonge peu la foulée.", "bike": "Selle un peu plus haute, résistance faible, cadence souple.",
               "swim": "Évite la brasse ; crawl et pull-buoy."},
    "rotulien": {"warm": "Échauffement : 5 minutes de vélo très léger, puis isométrie du quadriceps (5 × 30-45 s, genou à 60°).",
                 "renfo": "Tendon rotulien : isométrie 5 × 45 s, puis excentriques sur plan incliné à 25° (3 × 12 lents) en augmentant la charge si la douleur reste ≤ 3/10.",
                 "run": "Pas de sauts, pas de descente rapide ; garde un terrain plat.", "bike": "Évite les grosses résistances et les côtes en danseuse.",
                 "swim": "Crawl et pull-buoy, pas de brasse."},
    "pattedoie": {"warm": "Échauffement : mobilité du genou et activation des ischio-jambiers et des adducteurs.",
                  "renfo": "Renfort des ischio-jambiers et des adducteurs (pont fessier à une jambe, curl nordique assisté) : 3 × 10 lents.",
                  "run": "Foulée courte, pas de virages brusques.", "bike": "Cadence souple, genou aligné.", "swim": "Pas de brasse."},
    "periostite": {"warm": "Avant la course : 5 min de marche rapide, mobilité de cheville, 2 × 15 élévations de pointes de pied.",
                   "renfo": "Renforcement excentrique : élévations de talons (mollet) 3 × 15 lentes, relevés de pointes (tibial antérieur) 3 × 15, marche sur talons et sur pointes.",
                   "run": "Réduis fortement l'impact : alternance marche-trot sur surface souple, jamais deux jours de suite.",
                   "bike": "Vélo en vélocité souple (cadence 90-100 tr/min) : bon relais de charge cardio.",
                   "swim": "Natation conseillée sans culbutes ni appuis traumatisants : virages en toucher de mur."},
    "fracture": {"warm": "Aucun échauffement de course.", "renfo": "Aucun impact tant qu'un avis médical n'a pas écarté une fracture de fatigue.",
                 "run": "Arrêt complet des impacts.", "bike": "Vélo très léger seulement s'il est totalement indolore.", "swim": "Natation sans culbutes si indolore."},
    "achille": {"warm": "Échauffement : 2 × 15 élévations de talons lentes et mobilité de cheville, puis marche rapide avant le trot.",
                "renfo": "Charge progressive du tendon : isométrie 5 × 45 s sur la pointe, puis excentriques ou travail lent et lourd (3 × 12-15), si la douleur reste ≤ 4/10 et revient à la normale en 24 h.",
                "run": "Évite côtes, séances de vitesse et sols durs ; limite le volume.", "bike": "Résistance faible, talon bas, cadence souple.",
                "swim": "Natation possible ; limite les battements très appuyés."},
    "entorse": {"warm": "Échauffement : mobilité de cheville sans douleur, proprioception sur une jambe 3 × 30 s.",
                "renfo": "Proprioception (appui monopodal, planche instable), renfort des péroniers par élastique 3 × 15.",
                "run": "Reprise progressive sur terrain plat, pas de sentier irrégulier.", "bike": "Vélo léger si la cheville est stable et indolore.",
                "swim": "Natation avec pull-buoy pour rester actif sans charge."},
    "peroniers": {"warm": "Échauffement : activation des péroniers par élastique (2 × 15) et proprioception.",
                  "renfo": "Eversion contre élastique 3 × 15, renforcement du mollet et appui monopodal.", "run": "Évite sentiers irréguliers et dévers.",
                  "bike": "Cadence souple, attention à la pression sur le bord externe.", "swim": "Natation possible."},
    "fascite": {"warm": "Avant d'appuyer : étirement du mollet et de la voûte plantaire, mobilisation de la plante avec une balle.",
                "renfo": "Renforcement du pied : 'short foot' 3 × 10, élévations de talons lentes avec une serviette sous les orteils 3 × 12, étirement du mollet.",
                "run": "Réduis volume et impact, change de chaussures usées, évite la vitesse.", "bike": "Vélo possible, chaussures à semelle rigide.",
                "swim": "Natation possible."},
    "metatarsalgie": {"warm": "Échauffement : mobilité des orteils et du pied.", "renfo": "Renforcement intrinsèque du pied et décharge de l'avant-pied.",
                      "run": "Surface souple, pas de séances sur piste dure.", "bike": "Cales reculées si possible, chaussures bien ajustées.", "swim": "Natation possible."},
    "coiffe": {"warm": "Échauffement épaule : 2 × 15 rotations externes avec élastique léger, rétractions scapulaires, cercles de bras amples et lents.",
               "renfo": "Rotateurs externes et stabilisateurs de la scapula (serratus, trapèze inférieur) : 3 × 15 à l'élastique, tempo lent, sans douleur.",
               "run": "Course possible, bras relâchés.", "bike": "Évite la position aéro prolongée.",
               "swim": "Allège le volume, passe au pull-buoy sans plaquettes avec amplitude réduite et rotation du tronc plus ample, évite les sprints, le papillon et les plaquettes ; privilégie les battements."},
    "coude": {"warm": "Échauffement : mobilité du coude et du poignet, étirements doux des extenseurs ou fléchisseurs.",
              "renfo": "Isométrie puis excentriques lents du poignet (3 × 12) avec charge légère, prise de barre plus large ou sangles.",
              "run": "Course sans contrainte.", "bike": "Réduis les appuis sur le cintre, garde les coudes souples.", "swim": "Limite les plaquettes."},
    "poignet": {"warm": "Échauffement : mobilité du poignet, glissements nerveux doux.", "renfo": "Renforcement progressif des fléchisseurs et des extenseurs, mains neutres.",
                "run": "Course sans contrainte.", "bike": "Change régulièrement de prise, gants rembourrés.", "swim": "Réduis les plaquettes."},
    "muscle": {"warm": "Échauffement progressif, mobilité et activation du muscle sollicité.",
               "renfo": "Renforcement progressif du muscle concerné (excentrique contrôlé) après disparition de la douleur à la marche.",
               "run": "Pas de vitesse ni de côtes tant que la douleur persiste ; reprise en footing très facile.", "bike": "Vélo léger à cadence souple.", "swim": "Natation avec pull-buoy."},
    "adducteurs": {"warm": "Échauffement : activation des adducteurs et du transverse, mobilité de hanche.",
                   "renfo": "Squeeze isométrique ballon entre les genoux 5 × 30 s, gainage, puis adducteurs progressifs (Copenhagen assisté).",
                   "run": "Évite changements de direction, vitesse et côtes.", "bike": "Vélo léger, selle de hauteur correcte.", "swim": "Pas de brasse."},
    "fessier": {"warm": "Échauffement : ponts fessiers et pas latéraux avec élastique.",
                "renfo": "Fessier moyen en isométrie puis charge progressive ; évite les positions en adduction maintenue.",
                "run": "Réduis les côtes et le dénivelé.", "bike": "Selle de hauteur correcte, cadence souple.", "swim": "Natation possible."},
    "rachis": {"warm": "Échauffement : mobilité douce du rachis et respiration profonde.", "renfo": "Gainage doux, renforcement des muscles posturaux et mobilité scapulaire.",
               "run": "Foulée relâchée, évite la vitesse.", "bike": "Redresse la position (évite l'aéro prolongé).", "swim": "Respiration bilatérale, évite le papillon."},
    "lombalgie": {"warm": "Échauffement : mobilité du bassin et de la colonne, respiration abdominale.",
                  "renfo": "Gainage doux (planche 3 × 20-30 s, 'bird dog'), fessiers et mobilité de hanche ; pas de charges axiales lourdes.",
                  "run": "Foulée relâchée, terrain plat, évite la vitesse.", "bike": "Redresse la position (évite l'aéro prolongé), selle de bonne hauteur.",
                  "swim": "Évite le papillon et la brasse ; crawl avec pull-buoy."},
    "defaut": {"warm": "Échauffement progressif de la zone concernée (5 à 10 minutes) et mobilité douce.",
               "renfo": "Renforcement progressif, tempo lent et sans douleur, de la zone et des muscles voisins.",
               "run": "Réduis impact et vitesse.", "bike": "Cadence souple et résistance faible.", "swim": "Pull-buoy et nage souple."},
}
SYMPTOM_BUMP = {"blocage": 1}      # un blocage mécanique est plus préoccupant : gravité +1
KEYS = ("id", "start", "macro", "region", "side", "patho", "symptom", "label", "when", "intensity", "updated", "archived", "archived_on")


# ---------------------------------------------------------------------------------------------
# 2. Lecture / validation
# ---------------------------------------------------------------------------------------------
def _date(v):
    try:
        return date.fromisoformat(str(v)[:10]).isoformat()
    except (TypeError, ValueError):
        return None


def _pid(p):
    return "d" + hashlib.sha1(f"{p['start']}|{p['region']}|{p['side']}|{p['patho']}|{p['label']}".encode()).hexdigest()[:8]


def normalize(raw, warnings=None):
    """Liste brute -> douleurs valides (jamais d'exception ; entrées invalides ignorées avec avertissement). Les douleurs archivées sont conservées."""
    warnings = warnings if warnings is not None else []
    out, seen = [], set()
    for i, r in enumerate(raw if isinstance(raw, list) else []):
        if not isinstance(r, dict):
            warnings.append(f"douleur {i + 1} ignorée : format invalide")
            continue
        region = str(r.get("region") or "")
        st = _date(r.get("start"))
        if region not in REGIONS or not st:
            warnings.append(f"douleur {i + 1} ignorée : zone ou date invalide")
            continue
        try:
            it = int(round(float(r.get("intensity"))))
        except (TypeError, ValueError):
            it = 0
        patho = str(r.get("patho") or "")
        if patho not in PATHOS or PATHOS[patho][1] != region:
            patho = "custom" if patho == "custom" or r.get("label") else ""
        side = str(r.get("side") or "")
        side = side if side in SIDES else ("C" if REGIONS[region][1] == "tronc" else "B")
        p = {"start": st, "macro": REGIONS[region][1], "region": region, "side": side, "patho": patho,
             "symptom": str(r.get("symptom") or "") if str(r.get("symptom") or "") in SYMPTOMS else "",
             "label": str(r.get("label") or "").strip()[:80], "when": str(r.get("when") or "") if str(r.get("when") or "") in WHENS else "pendant",
             "intensity": max(0, min(10, it)), "updated": _date(r.get("updated")) or st,
             "archived": bool(r.get("archived")), "archived_on": _date(r.get("archived_on")) or "",
             "hist": _hist(r.get("hist"))}
        p["id"] = str(r.get("id") or "")[:24] or _pid(p)
        if p["id"] in seen:
            p["id"] = _pid(p) + str(i)
        seen.add(p["id"])
        out.append(p)
    return sort_pains(out)


def _hist(raw):
    """Historique des intensités [{d: date, i: 0..10}] (v5 : conservé à chaque enregistrement, 90 points au plus)."""
    out = []
    for h in (raw if isinstance(raw, list) else []):
        if not isinstance(h, dict): continue
        d = _date(h.get("d"))
        try:
            i = max(0, min(10, int(round(float(h.get("i"))))))
        except (TypeError, ValueError):
            continue
        if d: out.append({"d": d, "i": i})
    out.sort(key=lambda h: h["d"])
    return out[-90:]


def tendance(p, today):
    """+1 si la douleur a augmenté sur les 7 derniers jours, -1 si elle a baissé, 0 sinon (historique insuffisant compris).
    Repère du modèle de suivi de la douleur (Silbernagel et al. 2007) : la douleur ne doit pas augmenter d'une semaine à l'autre."""
    h = [x for x in (p.get("hist") or []) if x["d"] <= today.isoformat()]
    if len(h) < 2: return 0
    lo = (today - __import__("datetime").timedelta(days=7)).isoformat()
    old = [x for x in h if x["d"] <= lo]
    ref = old[-1]["i"] if old else h[0]["i"]
    cur = h[-1]["i"]
    return 1 if cur > ref else -1 if cur < ref else 0


def sort_pains(pains):
    """Douleurs actives d'abord (intensité > 0), les plus récentes en premier, puis suivies à 0, puis archivées."""
    return sorted(pains, key=lambda p: (p["archived"], p["intensity"] == 0, -date.fromisoformat(p["start"]).toordinal(), -p["intensity"], p["id"]))


def load(root):
    """-> (douleurs, avertissements). Fichier absent ou illisible : liste vide (la génération du dashboard ne doit jamais échouer)."""
    warnings, p = [], Path(root) / PAIN_FILE
    if not p.exists():
        return [], warnings
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return normalize(data.get("pains") if isinstance(data, dict) else data, warnings), warnings
    except (OSError, ValueError) as e:
        warnings.append(f"douleurs.json illisible ({type(e).__name__}) : ignoré")
        return [], warnings


def to_file_json(pains):
    return json.dumps({"version": 1, "pains": pains}, ensure_ascii=False, indent=2) + "\n"


def catalog():
    """Arborescence pour l'interface : macro-zones, régions, pathologies par région, listes."""
    return {"macros": MACROS, "sides": SIDES, "whens": WHENS, "symptoms": SYMPTOMS,
            "regions": {k: {"label": v[0], "macro": v[1]} for k, v in REGIONS.items()},
            "pathos": {k: {"label": v[0], "region": v[1]} for k, v in PATHOS.items()}}


# ---------------------------------------------------------------------------------------------
# 3. Évaluation : gravité, récidive, effets par discipline
# ---------------------------------------------------------------------------------------------
def _same_zone(a, b):
    if a["region"] != b["region"]:
        return False
    return a["side"] == b["side"] or "B" in (a["side"], b["side"]) or "C" in (a["side"], b["side"])


FEM = {"hanche", "cuisse", "cheville", "epaule", "cervicales", "dorsales", "lombaires"}


def label(p):
    """Libellé court : pathologie (ou descripteur) + zone + côté, ex. « Périostite tibiale · tibia gauche »."""
    ph = PATHOS.get(p["patho"])
    zone = REGIONS[p["region"]][0].split(" / ")[0].lower()
    side = {"G": "gauche", "D": "droite" if p["region"] in FEM else "droit", "B": "des deux côtés", "C": ""}[p["side"]]
    if REGIONS[p["region"]][1] == "tronc": side = ""
    z = (zone + " " + side).strip()
    if ph:
        return f"{ph[0].split(' (')[0]} · {z}"
    return f"{p['label'] or SYMPTOMS.get(p['symptom'], 'Douleur')} · {z}"


def recidive(p, pains):
    """Nombre de douleurs antérieures dans la même zone (archivées ou résolues à 0), hors elle-même."""
    return sum(1 for q in pains if q["id"] != p["id"] and _same_zone(p, q) and q["start"] < p["start"] and (q["archived"] or q["intensity"] == 0))


def gravite(p, n_rec):
    """Gravité effective 0..10 : intensité + moment (repos, effort) + symptôme + plancher de pathologie ; la récidive (+1 si une, +2 si deux ou plus)
    renforce la gravité mais ne déclenche pas à elle seule l'alerte rouge (plafond à 6 si la douleur n'est pas aiguë sans elle)."""
    i = p["intensity"]
    if i <= 0:
        return 0
    s = i
    if p["when"] == "repos":
        s += 2 if i >= 4 else (1 if i >= 2 else 0)
    elif p["when"] == "pendant" and i >= 3:
        s += 1
    s += SYMPTOM_BUMP.get(p["symptom"], 0)
    ph = PATHOS.get(p["patho"])
    if ph:
        s = max(s, min(ph[3], 10))
    base = s
    if n_rec:
        s += 1 if n_rec == 1 else 2
        if base <= 6: s = min(s, 6)
    return max(1, min(10, s))


def niveau(s):
    return "none" if s <= 0 else "light" if s <= 3 else "moderate" if s <= 6 else "acute"


NIVEAU_FR = {"none": "suivie", "light": "gérable", "moderate": "modérée", "acute": "aiguë"}


def poids(p):
    """Charge mécanique de la zone par discipline (0..1)."""
    w = dict(zip(DISCS, REGIONS[p["region"]][2]))
    ph = PATHOS.get(p["patho"])
    if ph:
        w.update(ph[2])
    return w


def pr_key(p):
    ph = PATHOS.get(p["patho"])
    return ph[4] if ph else "defaut"


def _proto(p):
    ph = PATHOS.get(p["patho"])
    return PROTO.get(ph[4] if ph else "defaut", PROTO["defaut"]) if ph else PROTO["defaut"]


NOTE_MIN = 0.3        # une douleur n'agit sur une discipline (volume, intensité, séance, conseils) que si elle la sollicite à ce niveau au moins
# Échauffement ciblé de la zone, sans mention d'aucune discipline ; la fin propre à la discipline consultée est ajoutée par sport_texts().
WARM_BASE = {
    "itbs": "2 × 12 pas latéraux à l'élastique et 2 × 10 clamshell par côté pour réveiller le fessier moyen.",
    "fempat": "2 × 10 squats partiels contrôlés (amplitude sans douleur) et activation des fessiers.",
    "rotulien": "5 min de cardio très léger (rameur ou ergomètre), puis isométrie du quadriceps : 5 × 30-45 s, genou à 60°.",
    "pattedoie": "Mobilité du genou, puis activation des ischio-jambiers et des adducteurs : 2 × 10 ponts fessiers.",
    "periostite": "5 min de marche rapide, mobilité de cheville, 2 × 15 élévations de pointes de pied.",
    "fracture": "Mobilité douce de cheville et de hanche, sans appui ni charge sur le tibia.",
    "achille": "Mobilité de cheville, puis 2 × 15 élévations de talons lentes (3 s à la descente).",
    "entorse": "Mobilité de cheville sans douleur et proprioception : appui sur une jambe 3 × 30 s.",
    "peroniers": "Activation des péroniers à l'élastique (2 × 15) et appui sur une jambe pour la proprioception.",
    "fascite": "Étirement du mollet et de la voûte plantaire, mobilisation de la plante du pied avec une balle.",
    "metatarsalgie": "Mobilité des orteils et du pied, puis 2 × 10 élévations de talons lentes à deux pieds.",
    "coiffe": "2 × 15 rotations externes à l'élastique léger, rétractions scapulaires et cercles de bras amples et lents.",
    "coude": "Mobilité du coude et du poignet, étirements doux des fléchisseurs et des extenseurs.",
    "poignet": "Mobilité du poignet et glissements nerveux doux.",
    "muscle": "Activation progressive du muscle concerné : contractions légères puis moyennes, sans douleur.",
    "adducteurs": "Activation des adducteurs et du transverse, mobilité de hanche : 2 × 10 ponts fessiers, squeeze ballon 3 × 20 s.",
    "fessier": "2 × 12 ponts fessiers et pas latéraux à l'élastique pour activer le fessier moyen.",
    "rachis": "Mobilité douce du rachis (chat-vache, rotations thoraciques) et respiration profonde.",
    "lombalgie": "Mobilité du bassin et de la colonne, respiration abdominale, puis 2 × 8 'bird dog' lents.",
    "defaut": "Mobilité douce de la zone et activation légère des muscles voisins.",
}
WARM_TAIL = {"run": "Puis 5 min de marche rapide et de trot très lent avant de lancer la séance.",
             "bike": "Puis 10 min de pédalage très souple avant la partie principale.",
             "swim": "Puis 200 m de nage souple avant la partie principale."}
RELIEF_ACUTE = "Pas de renforcement tant que la douleur est aiguë : repos de la zone et avis médical si elle persiste."


def sport_texts(key, d, lv):
    """(échauffement, consigne, soulagement) propres à la discipline d : aucune autre discipline n'y est citée."""
    pr = PROTO.get(key, PROTO["defaut"])
    warm = WARM_BASE.get(key, WARM_BASE["defaut"]) + " " + WARM_TAIL[d]
    tip = pr.get(d) or PROTO["defaut"][d]
    relief = RELIEF_ACUTE if lv == "acute" else pr["renfo"]
    return warm, tip, relief


def evaluer(pains, T):
    """-> dict : actives (détail par douleur), effects (par discipline : vol, excluded, easy, prefer, avoid, notes), alerts, panel, any.
    T : date du jour. Les douleurs archivées, à 0 ou futures n'ont aucun effet sur les séances."""
    pains = pains or []
    today = T if isinstance(T, date) else date.fromisoformat(str(T)[:10])
    eff = {d: {"vol": 1.0, "excluded": False, "easy": 0, "prefer": [], "avoid": [], "notes": [], "items": [], "reason": ""} for d in DISCS}
    actives, alerts = [], []
    for p in pains:
        if p["archived"] or p["intensity"] <= 0 or date.fromisoformat(p["start"]) > today:
            continue
        n_rec = recidive(p, pains)
        s = gravite(p, n_rec)
        trend = tendance(p, today)
        if trend > 0: s = min(10, s + 1)                    # douleur en hausse sur 7 jours : prudence renforcée
        lv = niveau(s)
        days = (today - date.fromisoformat(p["start"])).days
        w = poids(p)
        pr = _proto(p)
        lab = label(p)
        item = {"id": p["id"], "label": lab, "level": lv, "level_fr": NIVEAU_FR[lv], "severity": s, "intensity": p["intensity"], "recidive": n_rec,
                "days": days, "start": p["start"], "when": p["when"], "region": p["region"], "patho": p["patho"], "proto": pr_key(p), "w": {d: round(w.get(d, 0.0), 2) for d in DISCS}, "advice": []}
        recid_txt = f" Récidive dans cette zone ({n_rec + 1}e épisode) : prudence renforcée, reprise plus progressive." if n_rec else ""
        if trend > 0: recid_txt += " Douleur en hausse sur 7 jours : réduis davantage."
        during = p["when"] == "pendant" and p["intensity"] >= 4
        if lv == "light":
            item["advice"].append(WARM_BASE.get(pr_key(p), WARM_BASE["defaut"]) + " " + pr["renfo"])
            item["advice"].append("Volume maintenu ; surveille la douleur pendant et après la séance (elle doit rester ≤ 3/10 et disparaître sous 24 h)." + recid_txt)
        elif lv == "moderate":
            item["advice"].append(("Douleur de 4/10 ou plus pendant l'effort : pas de séance dans les disciplines qui chargent fortement la zone tant qu'elle ne redescend pas "
                                   "à 3/10 ou moins (modèle de suivi de la douleur) ; garde une discipline portée ou peu sollicitante." if during else
                                   "Réduis le volume et l'intensité des disciplines qui sollicitent la zone ; remplace-les par une discipline portée.") + recid_txt)
            item["advice"].append(WARM_BASE.get(pr_key(p), WARM_BASE["defaut"]) + " " + pr["renfo"])
        else:
            item["advice"].append("Alerte : repos strict de la zone concernée et adaptation immédiate du plan. Pas de séance qui sollicite cette zone." + recid_txt)
            item["advice"].append("Avis médical conseillé, surtout si la douleur est présente au repos, nocturne ou s'accompagne de gonflement, de perte de force ou d'engourdissement.")
        if lv in ("moderate", "acute") and days >= 14:
            item["advice"].append(f"Douleur présente depuis {days} jours : un avis médical ou kiné est recommandé.")
        if p["when"] == "repos" and lv != "acute":
            item["advice"].append("Douleur au repos : signal à prendre au sérieux, consulte si elle persiste.")
        actives.append(item)
        k = 0.0 if lv == "light" else (0.35 + 0.1 * (s - 4) + (0.1 if n_rec else 0.0) if lv == "moderate" else 1.0)
        for d in DISCS:
            wd = w.get(d, 0.0)
            if wd < NOTE_MIN: continue                      # la zone n'est pas sollicitée par cette discipline : aucun effet, aucune mention
            e = eff[d]
            if d != "strength":
                warm, tip, relief = sport_texts(pr_key(p), d, lv)
                e["items"].append({"lab": lab, "z": lab.split(" · ")[-1], "lv": lv, "int": p["intensity"], "sev": s, "warm": warm, "tip": tip, "relief": relief})
                e["notes"].append(f"{lab} : {tip}")
            if lv == "light": continue
            red = wd * k
            vol = max(0.4, 1.0 - red)
            e["vol"] = min(e["vol"], vol)
            excl = (lv == "acute" and wd >= 0.5) or (lv == "moderate" and red >= 0.45) or (during and lv != "light" and wd >= 0.7)      # v5 (audit I7)
            if excl:
                e["excluded"] = True
                e["reason"] = e["reason"] or lab
            if wd >= 0.5:
                e["easy"] = max(e["easy"], 2 if s >= 6 else 1)
            else:
                e["easy"] = max(e["easy"], 1)
            if d == "swim" and wd >= 0.5:
                e["prefer"] += ["jambes", "pull-buoy", "souple", "technique"]
                e["avoid"] += ["plaquettes", "sprint", "rapides", "lactique", "pyramide", "départ"]
            if d == "bike" and wd < 0.5:
                e["prefer"] += ["cadence", "souple", "progressi"]
            if d == "run":
                e["avoid"] += ["côte", "vallonn", "descente", "sprint"]
        if lv == "acute":
            alerts.append(f"Alerte douleur · {lab} ({p['intensity']}/10) : repos strict de la zone. " + item["advice"][1])
    actives.sort(key=lambda a: (-a["severity"], a["days"]))
    allx = actives and all(eff[d]["excluded"] for d in DISCS)
    panel = []
    for a in sorted(actives, key=lambda x: (x["start"], x["intensity"]), reverse=True):
        txt = f"{a['label']} · {a['intensity']}/10 ({a['level_fr']}), depuis {a['days']} jour{'s' if a['days'] > 1 else ''}"
        if a["recidive"]: txt += " · récidive"
        panel.append({"title": txt, "level": a["level"], "lines": a["advice"], "intensity": a["intensity"], "label": a["label"], "start": a["start"]})
    return {"any": bool(actives), "actives": actives, "effects": eff, "alerts": alerts, "panel": panel, "all_excluded": bool(allx)}


def substitute_order(pn):
    """Disciplines autorisées, de la moins sollicitée par les douleurs actives à la plus sollicitée (vélo, natation, musculation, course en cas d'égalité)."""
    pref = ("bike", "swim", "strength", "run")
    ok = [d for d in pref if not pn["effects"][d]["excluded"]]
    return sorted(ok, key=lambda d: (max([0.0] + [a["w"][d] for a in pn["actives"]]), pref.index(d)))
