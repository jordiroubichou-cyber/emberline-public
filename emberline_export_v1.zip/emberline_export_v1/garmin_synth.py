"""garmin_synth.py — réponses Garmin SYNTHÉTIQUES (même forme que l'API) pour les tests de la v6. Aucune donnée réelle."""
import math
import random

random.seed(7)


def _details(segments, lat0=43.70, lon0=7.25, hr_lag=25, alt_fn=None, cad=172, step=1):
    """segments : [(durée s, vitesse m/s, fc cible)] -> réponse get_activity_details (1 point par seconde)."""
    rows, t, d, hr = [], 0, 0.0, 95.0
    lat, lon = lat0, lon0
    for dur, v, hr_t in segments:
        for _ in range(0, int(dur), step):
            hr += (hr_t - hr) / hr_lag
            d += v * step; t += step
            hd = 0.8 + 1.1 * math.sin(d / 2300) + 0.5 * math.sin(d / 610)                 # parcours sinueux (cap qui varie)
            lat += v * step * math.cos(hd) / 111000; lon += v * step * math.sin(hd) / 80500
            alt = alt_fn(d) if alt_fn else 20 + 3 * math.sin(d / 300)
            rows.append({"metrics": [t, round(hr + random.uniform(-1.6, 1.6)), round(v, 3), round(alt, 1), round(d, 1), cad if v > 1.8 else 110, lat, lon]})
    keys = ["sumDuration", "directHeartRate", "directSpeed", "directElevation", "sumDistance", "directRunCadence", "directLatitude", "directLongitude"]
    return {"metricDescriptors": [{"metricsIndex": i, "key": k} for i, k in enumerate(keys)], "activityDetailMetrics": rows,
            "geoPolylineDTO": {"polyline": [{"lat": r["metrics"][6], "lon": r["metrics"][7]} for r in rows[::10]]}}


def _lap(d, t, it, hr, hrmax=None, **kw):
    l = {"distance": d, "duration": t, "averageSpeed": d / t if t else 0, "averageHR": hr, "maxHR": hrmax or hr + 6, "intensityType": it}
    l.update(kw); return l


def run_intervals(n=8, rep_m=400, v=4.45, fade=0.0, rec_s=90, hr_work=178, type_key="running", wid=None):
    laps = [_lap(2500, 900, "WARMUP", 140)]
    seg = [(900, 2.78, 140)]
    for i in range(n):
        vi = v * (1 - fade * i / max(1, n - 1))
        laps.append(_lap(rep_m, rep_m / vi, "INTERVAL", hr_work + i * 0.5, hr_work + 6 + i, averageRunCadence=182))
        laps.append(_lap(rec_s * 2.0, rec_s, "RECOVERY", 145))
        seg += [(rep_m / vi, vi, hr_work + 8), (rec_s, 2.0, 130)]
    laps.append(_lap(1500, 540, "COOLDOWN", 138)); seg.append((540, 2.78, 135))
    dist = sum(l["distance"] for l in laps); dur = sum(l["duration"] for l in laps)
    act = {"summaryDTO": {"distance": dist, "duration": dur, "averageHR": 155, "trainingEffect": 3.6, "anaerobicTrainingEffect": 2.8,
                          "activityTrainingLoad": 140, "averageRunCadence": 176, "groundContactTime": 238, "verticalOscillation": 8.6,
                          "strideLength": 118, "trainingEffectLabel": "VO2MAX"},
           "activityTypeDTO": {"typeKey": type_key}, "metadataDTO": {"associatedWorkoutId": wid}}
    return {"get_activity": act, "get_activity_splits": {"lapDTOs": laps}, "get_activity_typed_splits": {"splits": []},
            "get_activity_hr_in_timezones": [{"zoneNumber": z, "secsInZone": s} for z, s in ((1, 300), (2, 900), (3, 600), (4, 500), (5, 300))],
            "get_activity_details": _details(seg), "get_activity_weather": {"temp": 64.4, "relativeHumidity": 60, "windSpeed": 6},
            "get_activity_gear": [{"uuid": "g1", "displayName": "Chaussures test", "gearTypeName": "Shoes"}]}, dist / 1000, dur / 60


def run_steady(minutes=70, v=3.0, hr0=145, drift=0.0, type_key="running", alt_fn=None):
    seg = [(minutes * 60 * 0.5, v, hr0), (minutes * 60 * 0.5, v, hr0 * (1 + drift))]
    dist = v * minutes * 60
    laps = [_lap(1000, 1000 / v, "ACTIVE", hr0 + (k * drift * hr0 / max(1, dist / 1000))) for k in range(int(dist // 1000))]
    act = {"summaryDTO": {"distance": dist, "duration": minutes * 60, "averageHR": hr0, "trainingEffect": 3.0, "activityTrainingLoad": 95},
           "activityTypeDTO": {"typeKey": type_key}}
    return {"get_activity": act, "get_activity_splits": {"lapDTOs": laps}, "get_activity_details": _details(seg, alt_fn=alt_fn),
            "get_activity_hr_in_timezones": [], "get_activity_weather": {"temp": 59}}, dist / 1000, minutes


def swim(sets=((300, 0), (50, 15), (50, 15), (50, 15), (50, 15), (50, 15), (50, 15), (100, 0)), p100=105, swolf=38):
    laps = []
    for dist, rest in sets:
        n = dist // 25
        lens = [{"distance": 25, "duration": p100 / 4 * (1 + random.uniform(-.03, .03)), "swimStroke": "FREESTYLE",
                 "totalNumberOfStrokes": 14, "averageSWOLF": swolf} for _ in range(n)]
        laps.append({"distance": dist, "duration": sum(l["duration"] for l in lens), "intensityType": "ACTIVE", "swimStroke": "FREESTYLE",
                     "averageSWOLF": swolf, "averageStrokes": 14, "numberOfActiveLengths": n, "lengthDTOs": lens})
        if rest: laps.append({"distance": 0, "duration": rest, "intensityType": "REST"})
    dist = sum(l["distance"] for l in laps); dur = sum(l["duration"] for l in laps)
    act = {"summaryDTO": {"distance": dist, "duration": dur, "averageHR": 140, "poolLength": 25}, "activityTypeDTO": {"typeKey": "lap_swimming"}}
    return {"get_activity": act, "get_activity_splits": {"lapDTOs": laps}}, dist / 1000, dur / 60


def strength(plan=(("BENCH_PRESS", 4, 8, 60), ("SHOULDER_PRESS", 3, 10, 30), ("TRICEPS_EXTENSION", 3, 12, 15), ("PUSH_UP", 3, 15, 0)), full=True):
    sets = []
    for cat, n, reps, kg in plan:
        for i in range(n):
            r = reps if full or i < n - 1 else reps - 3
            sets.append({"setType": "ACTIVE", "duration": 40, "repetitionCount": r, "weight": kg * 1000,
                         "exercises": [{"category": cat, "name": cat, "probability": 97}]})
            sets.append({"setType": "REST", "duration": 90})
    act = {"summaryDTO": {"duration": 3000, "averageHR": 110, "activityTrainingLoad": 40}, "activityTypeDTO": {"typeKey": "strength_training"}}
    return {"get_activity": act, "get_activity_exercise_sets": {"exerciseSets": sets}}, 0.0, 50
