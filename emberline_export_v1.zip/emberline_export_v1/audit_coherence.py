#!/usr/bin/env python3
"""Audit de cohérence : recompte indépendamment chaque grandeur affichée à plusieurs endroits (note, piliers, prédictions, objectifs,
jours restants, volumes, douleurs, mails) et signale tout écart. Usage : python audit_coherence.py  (aucune dépendance externe).
Aussi appelé par test_robustesse.t_coherence()."""
import re
import sys
from datetime import date, timedelta

import analysis as an
import build_dashboard as B
import config as cf
import goals as G
import pain as PN
import test_planification as TP

f1, hms = an.f1, an.hms
PER = {"1S": 7, "1M": 30, "3M": 90}


def recount(acts, T, n, off=0):
    a = (T - timedelta(days=off + n - 1)).isoformat(); b = (T - timedelta(days=off)).isoformat()
    L = [x for x in acts if a <= x["d"] <= b]
    runs = [x for x in L if x["s"] in ("run", "trail")]
    return {"n": len(L), "h": sum(x["m"] for x in L) / 60, "rn": len(runs), "rkm": sum(x["km"] for x in runs), "rm": sum(x["m"] for x in runs)}


def audit(A, acts, T, goals, label=""):
    """Retourne la liste des écarts (chaîne vide = cohérent)."""
    bad = []
    chk = lambda cond, msg: None if cond else bad.append(f"[{label}] {msg}")
    today = date.fromisoformat(A["today"])
    chk(today == T, f"A.today {A['today']} != T {T}")
    # ---- 1. notes et piliers par période
    for k, P in A["pillars_p"].items():
        sc = [p["score"] for p in P["pillars"] if p["score"] is not None]
        chk(all(0 <= s <= 4.0001 for s in sc), f"{k} : pilier hors 0–4 {sc}")
        if sc:
            tot = sum(sc) / (4 * len(sc)) * 20
            chk(abs(tot - P["score"]) < 1e-9, f"{k} : note {P['score']} != somme des piliers {tot}")
            chk(P["label"] == an.score_label(P["score"]), f"{k} : libellé {P['label']} != {an.score_label(P['score'])}")
            chk(0 <= P["score"] <= 20.0001, f"{k} : note hors 0–20")
            chk(P.get("n_scored") == len(sc), f"{k} : n_scored {P.get('n_scored')} != {len(sc)}")
            chk(P.get("tone") == an.score_tone(P["score"]), f"{k} : couleur {P.get('tone')} != {an.score_tone(P['score'])}")
            for q in P["pillars"]: chk(q.get("tone") == an.pillar_tone(q["score"]), f"{k} : couleur pilier {q['key']}")
        # ---- 2. prédictions : cohérence interne et avec les textes
        pr = {p["key"]: p for p in P["preds"]}
        if pr.get("10k", {}).get("ret") and pr.get("semi", {}).get("ret") and pr.get("marathon", {}).get("ret"):
            r1, r2, r3 = pr["10k"]["ret"], pr["semi"]["ret"], pr["marathon"]["ret"]
            chk(1.95 <= r2 / r1 <= 2.3, f"{k} : semi/10 km = {r2 / r1:.2f} (attendu 2,0–2,3) : {hms(r1)} · {hms(r2)}")
            chk(1.95 <= r3 / r2 <= 2.3, f"{k} : marathon/semi = {r3 / r2:.2f} (attendu 2,0–2,3) : {hms(r2)} · {hms(r3)}")
        txt = " ".join(P["pillars"][0]["lines"] + P["pillars"][1]["lines"] + A["synth"][k]["focus"])
        for p in P["preds"]:
            if p["ret"]:
                chk(hms(p["ret"]) in txt, f"{k} : prédiction {p['label']} {hms(p['ret'])} absente des textes")
        # pilier « Préparation aux objectifs » = paragraphe « Préparation aux objectifs » (mêmes scores, pondérés par priorité et échéance)
        pp0 = P["pillars"][0]
        chk(pp0["key"] == "pred" and pp0["name"] == "Préparation aux objectifs", f"{k} : nom du 1er pilier {pp0['name']}")
        okp = [o for o in A["prep"] if o["score"] is not None]
        if okp:
            wsum = sum(an.prep_weight(o) for o in okp)
            exp = sum(an.prep_weight(o) * o["score"] for o in okp) / wsum / 100 * 4
            chk(pp0["score"] is not None and abs(pp0["score"] - exp) < 1e-9, f"{k} : note du pilier préparation {pp0['score']} != moyenne pondérée {exp}")
            for o in sorted(okp, key=lambda x: x["days_left"])[:4]:
                chk(any(o["name"] in l and f"{o['score']}/100" in l for l in pp0["lines"]), f"{k} : objectif {o['name']} ({o['score']}/100) absent du pilier")
            chk(abs(A["pillars"][0]["score"] - pp0["score"]) < 1e-9, f"{k} : pilier préparation 28 j != pilier de la période")
        else:
            chk(pp0["score"] is None, f"{k} : pilier préparation noté sans objectif évalué")
        # ---- 3. recomptes depuis les séances
        n = PER[k]
        S, Sp = A["stats"][k]["cur"], A["stats"][k]["prev"]
        R = recount(acts, T, n)
        chk(S["n"] == R["n"] and abs(S["h"] - R["h"]) < 1e-6, f"{k} : séances {S['n']}/{S['h']:.2f} h != recompte {R['n']}/{R['h']:.2f} h")
        chk(S["run"]["n"] == R["rn"] and abs(S["run"]["km"] - R["rkm"]) < 1e-6, f"{k} : course {S['run']['n']}/{S['run']['km']:.1f} km != recompte {R['rn']}/{R['rkm']:.1f} km")
        head = A["synth"][k]["head"]
        chk(f"{S['n']} séance(s), {f1(S['h'])} h" in head, f"{k} : tête de synthèse ne reprend pas {S['n']} séance(s), {f1(S['h'])} h : {head[:90]}")
        chk(f"{S['run']['n']} sortie(s), {f1(S['run']['km'])} km" in head, f"{k} : synthèse course {S['run']['n']} sortie(s) {f1(S['run']['km'])} km absent")
        if Sp:
            Rp = recount(acts, T, n, n)
            chk(Sp["n"] == Rp["n"], f"{k} : période précédente {Sp['n']} != {Rp['n']}")
            if Rp["h"]:
                d = (R["h"] - Rp["h"]) / Rp["h"] * 100
                chk(an.sgn(d) in head, f"{k} : variation d'heures {an.sgn(d)} absente de la synthèse")
        # ---- 4. texte du coach : nombres repris
        bt = (A["bilan"].get(k) or {}).get("text") or ""
        if bt and P["score"] is not None:
            m = re.search(r"(\d+,\d)\s*/\s*20", bt)
            chk(m is None or m.group(1) == f1(P["score"]), f"{k} : coach dit {m.group(1) if m else ''}/20, note {f1(P['score'])}")
        for m in re.finditer(r"\((\d,\d)/4\)", bt):
            chk(any(f1(p["score"]) == m.group(1) for p in P["pillars"] if p["score"] is not None), f"{k} : coach cite {m.group(1)}/4 sans pilier correspondant")
        # ---- 5. objectifs : temps visés seulement pour des courses à venir
        for p in P["preds"]:
            if p["target"]:
                up = [g for g in goals if g["date"] >= T.isoformat() and g.get("sport", "run") == "run" and abs(g["dist"] - p["dist"]) < 0.5 and g["target_s"]]
                chk(bool(up), f"{k} : temps visé {hms(p['target'])} ({p['label']}) issu d'un objectif passé ou absent")
    # ---- 6. objectifs et jours restants
    for g in A["goals"]:
        chk(g["left"] == (date.fromisoformat(g["date"]) - T).days, f"objectif {g['label']} : left {g['left']} incohérent")
    for x in A["prep"]:
        chk(x["days_left"] == (date.fromisoformat(x["date"]) - T).days if x.get("date") else True, f"préparation {x['name']} : jours restants incohérents")
    plan = (A["suggest"] or {}).get("plan") or {}
    for o in plan.get("objs", []):
        chk(o["days_left"] == (date.fromisoformat(o["date"]) - T).days, f"plan {o['label']} : jours restants incohérents")
    up = sorted([g for g in goals if g["date"] >= T.isoformat()], key=lambda g: g["date"])
    if up:
        nx = up[0]; dl = (date.fromisoformat(nx["date"]) - T).days
        for k in PER:
            fo = " ".join(A["synth"][k]["focus"])
            chk(f"Prochaine échéance : {nx['label']} dans {dl} jours" in fo, f"{k} : prochaine échéance incohérente ({nx['label']} {dl} j)")
        needs = " ".join(A["suggest"]["needs"])
        if "prochaine échéance" in needs:
            chk(f"{nx['label']} dans {dl} jours" in needs, f"besoins : prochaine échéance incohérente ({nx['label']} {dl} j) : {needs[-200:]}")
        roles = {o["label"]: o["role"] for o in plan.get("objs", [])}
        for g in up:
            if g.get("prio") == "A": chk(roles.get(g["label"]) == "principal", f"{g['label']} marqué A mais rôle {roles.get(g['label'])}")
            if g.get("prio") == "B": chk(roles.get(g["label"]) in ("secondaire", "intermédiaire"), f"{g['label']} marqué B mais rôle {roles.get(g['label'])}")
            if g.get("prio") == "C": chk(roles.get(g["label"]) == "préparatoire", f"{g['label']} marqué C mais rôle {roles.get(g['label'])}")
    # ---- 7. mail = dashboard (1 semaine)
    try:
        h = B.build_email(A, "https://x.y/")
        P1 = A["pillars_p"]["1S"]
        if P1["score"] is not None:
            chk(f"Rapport du jour · {f1(P1['score'])}/20" in h, "mail : note du sujet != note 1 semaine du dashboard")
        for p in P1["pillars"]:
            if p["score"] is not None: chk(f"{f1(p['score'])} / 4" in h, f"mail : pilier {p['name']} {f1(p['score'])} absent")
    except Exception as e:      # noqa: BLE001
        bad.append(f"[{label}] mail : {type(e).__name__}: {e}")
    # ---- 8. douleurs
    pn = A["pain"]
    chk(pn["any"] == bool(pn["panel"]), "douleurs : any != panneau")
    # ---- 9. suggestions
    sg = A["suggest"]
    pl = sg.get("plan")
    if pl:
        for d in ("run", "bike", "swim"):
            v = pl["vol"][d]
            chk(0.4 <= v <= 1.0, f"plan {d} : volume {v} hors 40–100 %")
            if pl["phase"][d] == "affutage": chk(pl["fam"][d] in ("taper", "z2", "recup"), f"plan {d} : famille {pl['fam'][d]} pendant l'affûtage")
            if pl["phase"][d] in ("jour_j", "recuperation"): chk(pl["fam"][d] in ("z2", "recup"), f"plan {d} : famille {pl['fam'][d]} en {pl['phase'][d]}")
        for o in pl["objs"]:
            chk(o["taper_d"] >= 0 and o["rec_d"] >= 0, f"objectif {o['label']} : durées négatives")
    chk("plan_log" in sg and all(e["m"] > 0 and e["f"] for e in sg["plan_log"].values()), "plan_log absent ou invalide")
    for c in sg["cards"]:
        if c.get("blocked"): continue
        m = re.search(r"(\d+) min", c.get("meta") or "")
        chk(m is not None or c.get("id") == "strength", f"séance {c.get('id')} : durée absente du méta {c.get('meta')!r}")
    return bad


def monde_variantes():
    """Jeux de données variés : base, objectifs passés et futurs, sans objectif, douleurs, données creuses."""
    out = []
    for seed, n in ((3, 200), (7, 160), (11, 90)):
        acts, days = TP.monde(n, seed=seed) if hasattr(TP, "monde") else (None, None)
        out.append((f"seed{seed}", acts, days))
    return out


def run_all(verbose=False):
    """Audite tous les jeux de données synthétiques ; renvoie la liste des écarts."""
    import synth
    import pathlib
    ecarts = []
    for seed, n in ((3, 200), (7, 160), (11, 90), (5, 400)):
        acts, days = synth.monde(n, seed=seed, start=date(2026, 4, 20))
        T = date(2026, 4, 20) + timedelta(days=n - 1)
        variantes = {
            "défaut": G.load_goals(pathlib.Path("."), cf.GOALS)[0],
            "passé+futur": G.normalize([{"sport": "run", "name": "10 km passé", "dist": 10, "target": "40:00", "date": (T - timedelta(days=20)).isoformat()},
                                         {"sport": "run", "name": "10 km futur", "dist": 10, "target": "42:00", "date": (T + timedelta(days=50)).isoformat()},
                                         {"sport": "run", "name": "Marathon", "dist": 42.195, "target": "3:15:00", "date": (T + timedelta(days=150)).isoformat(), "prio": "A"}]),
            "aucun": [],
            "A multiples": G.normalize([{"sport": "run", "name": "Prom", "dist": 10, "target": "42:00", "date": (T + timedelta(days=66)).isoformat(), "prio": "A"},
                                         {"sport": "run", "name": "Marathon", "dist": 42.195, "target": "3:15:00", "date": (T + timedelta(days=171)).isoformat(), "prio": "A"}]),
        }
        for vn, goals in variantes.items():
            for pains in ([], PN.normalize([{"start": (T - timedelta(days=10)).isoformat(), "region": "tibia", "side": "G", "patho": "periostite", "when": "pendant", "intensity": 5}])):
                A = B.build_analysis(acts, days, T.isoformat(), goals, cf.ATHLETE, cf.PERIODS, events=[], meta={}, coach_mem=None, pains=pains)
                for m in audit(A, acts, T, goals, f"seed{seed}/{vn}/{'douleur' if pains else 'sans'}"):
                    ecarts.append(m)
    return ecarts


if __name__ == "__main__":
    e = run_all()
    for m in e: print(m)
    print("écarts :", len(e))
