"""Profil de l'utilisateur : prénom, surnom, genre (accords), sports pratiqués, FC seuil, dépôt GitHub.

Le profil est écrit par la section « Paramètres » de l'app dans profil.json, à la racine du dépôt (via le jeton GitHub de l'appareil),
puis lu à chaque génération : tout ce qui est produit (coach, bilans, plan, défis, notifications, mail) s'adapte à la personne.
- prénom et surnom : remplacent partout l'ancien prénom ; le surnom entre dans la rotation des surnoms du coach ;
- genre : « m » ou « f » ; au féminin, les textes qui s'adressent à la personne sont accordés (prête, fatiguée, championne…) ;
- sports : disciplines proposées (course, trail, vélo, natation, musculation, mobilité) ; les autres disparaissent des suggestions,
  du plan de la semaine, des défis et de l'app ;
- FC seuil : un nombre (bpm) ou « auto » (estimée : estimation Garmin si disponible, sinon depuis tes sorties).
Sans profil.json, les réglages de config.py et les valeurs par défaut ci-dessous s'appliquent (rien ne change)."""
import json
import re
from datetime import date, timedelta
from pathlib import Path

FILE = "profil.json"
SPORTS = ("run", "trail", "bike", "swim", "strength", "mob")
SPORT_FR = {"run": "Course à pied", "trail": "Trail", "bike": "Vélo", "swim": "Natation", "strength": "Musculation", "mob": "Mobilité"}
DEFAULT = {"prenom": "Jordi", "surnom": "Grosbichou", "genre": "m", "sports": list(SPORTS), "lthr": None}
BASE_NAME = "Jordi"                        # prénom écrit dans les textes d'origine : remplacé partout par le prénom du profil

P = dict(DEFAULT)                          # profil courant (chargé par load)
INFO = {}                                  # FC seuil retenue et sa source, pour l'app


# ------------------------------------------------------------------------------------------------------------------- lecture
def clean(raw):
    """Profil brut (fichier, app) -> profil valide ; toute valeur invalide est remplacée par la valeur par défaut."""
    raw = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULT)
    pr = re.sub(r"\s+", " ", str(raw.get("prenom") or "")).strip()[:30]
    if pr: out["prenom"] = pr
    if "surnom" in raw: out["surnom"] = re.sub(r"\s+", " ", str(raw.get("surnom") or "")).strip()[:30]
    if raw.get("genre") in ("m", "f"): out["genre"] = raw["genre"]
    sp = [s for s in (raw.get("sports") or []) if s in SPORTS] if isinstance(raw.get("sports"), list) else None
    if sp is not None and any(s in sp for s in ("run", "trail", "bike", "swim", "strength")):
        out["sports"] = [s for s in SPORTS if s in sp]
    lt = raw.get("lthr")
    if lt == "auto": out["lthr"] = "auto"
    else:
        try:
            v = int(round(float(str(lt).replace(",", "."))))
            out["lthr"] = v if 120 <= v <= 215 else None
        except (TypeError, ValueError):
            out["lthr"] = None
    if raw.get("repo") and re.fullmatch(r"[\w.-]+/[\w.-]+", str(raw["repo"])): out["repo"] = str(raw["repo"])
    return out


def load(root="."):
    """Lit profil.json (racine du dépôt). Absent ou illisible : profil par défaut."""
    global P
    p = Path(root) / FILE
    raw = {}
    if p.exists():
        try: raw = json.loads(p.read_text(encoding="utf-8")) or {}
        except (OSError, ValueError): raw = {}
    P = clean(raw)
    return P


def ok(s):
    """La discipline (ou la famille d'activité) est-elle proposée ? Les séances déjà faites restent toujours affichées."""
    sp = P.get("sports") or SPORTS
    s = {"other": "mob", "yoga": "mob", "mobility": "mob", "mobilite": "mob", "renfo": "strength", "muscu": "strength", "running": "run",
         "cycling": "bike", "swimming": "swim", "triathlon": "multi"}.get(s, s)
    if s == "trail": return "trail" in sp
    if s == "triathlon_full": return all(x in sp for x in ("run", "bike", "swim"))
    if s == "multi": return sum(x in sp for x in ("run", "bike", "swim")) >= 2
    return s not in SPORTS or s in sp


KW = {"bike": ("vélo", "cyclisme", "home-trainer", "pédal", "sortie à vélo"), "swim": ("natation", "nage", "nager", "piscine", "bassin", "crawl"),
      "strength": ("muscu", "renfo", "renforcement", "push", "pull", "legs", "haltère"), "mob": ("mobilité", "étirement", "yoga"),
      "trail": ("trail", "dénivelé", "d+")}


def prune(lines):
    """Conseils (besoins, points à retenir) : retire ceux qui proposent un sport non pratiqué (Paramètres)."""
    if all_on() or not lines: return lines
    off = [k for k in KW if not ok(k)]
    def bad(t):
        lo = (t if isinstance(t, str) else " ".join(str(x) for x in t)).lower()
        return any(w in lo for k in off for w in KW[k])
    out = [t for t in lines if not bad(t)]
    return out or lines[:1]


def all_on():
    return all(s in (P.get("sports") or SPORTS) for s in SPORTS)


def filter_schema(fr):
    """Schéma de semaine -> sans les séances des disciplines non proposées (copie ; l'original n'est pas modifié)."""
    if not fr or all_on(): return fr
    days = {k: [it for it in v if ok(it.get("s"))] for k, v in (fr.get("days") or {}).items()}
    return {**fr, "days": {k: v for k, v in days.items() if v}}


# ------------------------------------------------------------------------------------------------------------------- FC seuil
def estimate_lthr(acts, T=None, lt_garmin=None, hr_max=None):
    """FC seuil estimée -> (bpm, source). Ordre : estimation Garmin ; sinon tes courses de 20 à 75 min (une course soutenue de
    30 à 60 min se court à peu près à la FC seuil) ; sinon 91 % de la FC max."""
    if lt_garmin and 120 <= lt_garmin <= 215:
        return int(round(lt_garmin)), "estimation Garmin"
    T = T or date.today()
    lim = (T - timedelta(days=365)).isoformat()
    obs_max = max([a.get("mx") or 0 for a in acts or [] if a.get("d", "") >= lim] or [0])
    hm = max(hr_max or 0, obs_max) or 190
    cand = sorted((a["hr"] * (1.0 if a.get("m", 0) >= 30 else 0.97)) for a in acts or []
                  if a.get("s") in ("run", "trail", "treadmill") and a.get("hr") and 20 <= (a.get("m") or 0) <= 75 and a.get("d", "") >= lim)
    if len(cand) >= 3:
        v = cand[-2]                                          # la 2e meilleure : une valeur isolée (capteur) ne fausse pas tout
        return int(round(max(0.80 * hm, min(0.95 * hm, v)))), f"tes courses soutenues ({len(cand)} sorties)"
    return int(round(0.91 * hm)), "91 % de ta FC max"


# ------------------------------------------------------------------------------------------------------------------- surnoms
NICK_F = ["championne", "ma grande", "la patronne", "la boss", "la machine", "la légende", "l'artiste", "l'athlète", "ma belle", "la reine de la foulée",
          "ma gazelle", "la panthère", "la fusée", "{p} la fusée", "Usain {p}", "Eliud {p}", "{p}-la-foulée", "la tigresse", "la lionne", "Wonder Woman",
          "la flèche", "la locomotive", "la cheffe", "maestra", "la crack", "la phénomène", "ma reine", "la guerrière", "la louve", "Capitaine Foulée",
          "la reine du dimanche", "la reine du bitume", "madame Marathon", "madame Fartlek", "la titane", "la comète", "ma lionne", "la sage", "la cheffe de meute",
          "la gazelle du bitume", "la métronome", "l'amazone", "la walkyrie", "ma star", "la virtuose", "la fonceuse"]
INS_F = ["flemmarde", "limace", "marmotte", "patate de canapé", "feignasse", "mollusque", "pantoufle", "grosse larve", "paresseuse", "escargot",
         "moule", "grosse loutre", "tortue de salon", "grosse dormeuse", "championne du canapé", "athlète du zapping", "ourse en hibernation",
         "vieille pantoufle", "grosse marmotte", "limace en short", "momie de salon", "Miss Sieste", "grosse flemme", "reine du plaid",
         "princesse du canapé", "grosse paresseuse", "marmotte de compétition", "loutre de salon", "reine de la sieste", "duchesse du canapé"]


def nick_list(base):
    """Surnoms tournants du coach : ceux du genre choisi, le prénom d'origine remplacé par celui du profil. Le surnom personnel,
    lui, est le surnom « imposé » quand la période est en baisse (coach_croise.GROS)."""
    pr = P.get("prenom") or BASE_NAME
    L = NICK_F if P.get("genre") == "f" else base
    L = [n.replace("{p}", pr) for n in L]
    L = [re.sub(rf"\b{BASE_NAME}\b", pr, n) for n in L]
    L = [n for n in L if "Biarritz" not in n] + (["la gazelle du bitume"] if P.get("genre") != "f" else [])
    return L


def ins_list(base):
    return INS_F if P.get("genre") == "f" else base


# ------------------------------------------------------------------------------------------------------------------- accords au féminin
ADJ = {"prêt": "prête", "frais": "fraîche", "malin": "maligne", "gentil": "gentille", "fou": "folle", "mou": "molle", "vieux": "vieille", "beau": "belle",
       "nouveau": "nouvelle", "sec": "sèche", "doux": "douce", "faux": "fausse", "gros": "grosse", "bon": "bonne", "seul": "seule", "fier": "fière",
       "meilleur": "meilleure", "supérieur": "supérieure", "costaud": "costaude", "sportif": "sportive", "actif": "active", "attentif": "attentive",
       "heureux": "heureuse", "sérieux": "sérieuse", "courageux": "courageuse", "dangereux": "dangereuse", "nerveux": "nerveuse", "joyeux": "joyeuse",
       "régulier": "régulière", "premier": "première", "dernier": "dernière", "entier": "entière", "léger": "légère", "complet": "complète", "inquiet": "inquiète",
       "champion": "championne", "bas": "basse", "las": "lasse", "épais": "épaisse", "grand": "grande", "lourd": "lourde", "chaud": "chaude",
       "assis": "assise", "mis": "mise", "pris": "prise", "surpris": "surprise", "repris": "reprise", "parti": "partie", "sorti": "sortie", "fini": "finie",
       "ravi": "ravie", "guéri": "guérie", "remis": "remise", "petit": "petite", "cuit": "cuite", "plein": "pleine", "fin": "fine", "vidé": "vidée",
       "rincé": "rincée", "cramé": "cramée", "ponctuel": "ponctuelle", "naturel": "naturelle", "matinal": "matinale", "normal": "normale", "flemmard": "flemmarde",
       "perdu": "perdue", "tendu": "tendue", "détendu": "détendue", "battu": "battue", "attendu": "attendue", "rendu": "rendue", "têtu": "têtue", "muet": "muette",
       "discret": "discrète", "inscrit": "inscrite", "content": "contente", "prudent": "prudente", "patient": "patiente", "lent": "lente", "excellent": "excellente",
       "vigilant": "vigilante", "constant": "constante", "performant": "performante", "gagnant": "gagnante", "reconnaissant": "reconnaissante", "puissant": "puissante",
       "confiant": "confiante", "motivé": "motivée", "reposé": "reposée", "fatigué": "fatiguée", "entraîné": "entraînée", "allé": "allée", "venu": "venue",
       "resté": "restée", "rentré": "rentrée", "levé": "levée", "couché": "couchée", "réveillé": "réveillée", "blessé": "blessée", "malade": "malade"}
STOP = {"à", "au", "aux", "dans", "en", "sur", "sous", "du", "de", "des", "la", "le", "les", "un", "une", "qu", "l", "comme", "entre", "quelques", "quelque",
        "celui", "celle", "loin", "bien", "plus", "moins", "si", "serait", "suit", "suivra", "pas", "jamais", "encore", "toujours", "déjà", "très", "trop",
        "là", "ici", "dehors", "debout", "partout", "rien", "tout", "toute", "ton", "ta", "tes", "mon", "ma", "son", "sa", "on", "avec", "sans", "pour", "par",
        "chez", "vers", "après", "avant", "depuis", "pendant", "en", "y", "ne", "n", "que", "quand", "car", "mais", "ou", "et", "donc", "or", "ni"}
ADV = r"(?:(?:bien|très|trop|plus|encore|vraiment|un peu|assez|toujours|déjà|super|pas|plus|jamais|si|aussi|tellement|presque|à nouveau|hyper|moins|" \
      r"parfaitement|clairement|carrément|officiellement|complètement|totalement|enfin|vite|peut-être|sûrement|sans doute|même|pas trop|un brin|à peine)\s+)*"
_W = r"([A-Za-zÀ-ÖØ-öø-ÿœŒ-]+)"
CTX = (r"\btu\s+es|\bt['’]es|\btu\s+n['’]es|\btu\s+te\s+sens|\btu\s+ne\s+te\s+sens|\bte\s+sens|\bte\s+sentir|\bte\s+sentiras|\btu\s+restes|\btu\s+seras|"
       r"\bes-tu|\btu\s+étais|\btu\s+as\s+été|\bt['’]as\s+été|\btu\s+as\s+l['’]air|\btu\s+sembles|\btu\s+parais|\btu\s+deviens|\btu\s+te\s+retrouves|"
       r"\bte\s+voilà|\bte\s+revoilà|\bne\s+sois|\bsois|\bsoit\s+toi|\btoi\s+qui\s+es|\bêtre\s+resté")
_AND = r"(?:\s+(?:et|ou|mais)\s+(?P<w2>[A-Za-zÀ-ÖØ-öø-ÿœŒ-]+))?"
RX_CTX = re.compile(rf"(?:{CTX})\s+{ADV}(?P<w>[A-Za-zÀ-ÖØ-öø-ÿœŒ-]+){_AND}", re.I)
RX_IMP = re.compile(rf"(?:(?:^|[.!?:;,«\"(—–]\s*|\bet\s+|\bou\s+)(?:ne\s+)?[Rr]este\s+){ADV}(?P<w>[A-Za-zÀ-ÖØ-öø-ÿœŒ-]+){_AND}")
SENT = ("prêt", "fatigué", "reposé", "motivé", "content", "cramé", "rincé", "lessivé", "vidé", "fier", "frais", "chaud", "remis", "guéri", "rassuré")
RX_STATE = re.compile(r"(\b(?:et|mais|déjà|encore|trop|plutôt|un peu|pas trop|pas assez|bien|si)\s+)(" + "|".join(SENT) + r")\b(?!\s+(?:de|du|des|à)\b)")
RX_SENT = re.compile(r"((?:^|[.!?]\s+|«\s*|\n)(?:Bien |Pas trop |Trop |Encore |Toujours |Plutôt )?)(" + "|".join(w.capitalize() for w in SENT) + "|" + "|".join(SENT) + r")\b")
ADDR = [(r"\b([Ll]e|[Uu]n|[Mm]on|[Dd]u)\s+champion\b(?!n)", None), (r"\bChampion\b(?!n)", "Championne"), (r"\bchampion\b(?!n)", "championne"),
        (r"\bBonhomme\b", "Ma grande"), (r"\bbonhomme\b", "ma grande"), (r"\b[Mm]on grand\b", None), (r"\b[Mm]on gars\b", None), (r"\b[Mm]on pote\b", None),
        (r"\b[Mm]on vieux\b", None), (r"\b[Mm]on héros\b", None), (r"\b[Mm]onsieur\b", None)]
ART_F = {"le": "la", "Le": "La", "un": "une", "Un": "Une", "mon": "ma", "Mon": "Ma", "du": "de la", "Du": "De la"}
ADDR_F = {"mon grand": "ma grande", "mon gars": "ma belle", "mon pote": "ma pote", "mon vieux": "ma vieille", "mon héros": "mon héroïne", "monsieur": "madame"}


def _fem_word(w):
    lo = w.lower()
    if lo in STOP or len(lo) < 3: return w
    if lo in ADJ: f = ADJ[lo]
    elif lo.endswith("ment"): return w                                    # adverbe
    elif lo.endswith("é"): f = lo + "e"
    elif lo.endswith("if"): f = lo[:-2] + "ive"
    elif lo.endswith("eux"): f = lo[:-3] + "euse"
    elif lo.endswith("ier"): f = lo[:-3] + "ière"
    elif lo.endswith(("ant", "ent")): f = lo + "e"
    elif lo.endswith("ien"): f = lo + "ne"
    elif lo.endswith("u") and not lo.endswith(("eu", "au", "ou")): f = lo + "e"
    elif lo.endswith("is") and not lo.endswith("ais"): f = lo + "e"
    elif lo.endswith(("ard", "aud", "and", "ond", "ourd")): f = lo + "e"
    else: return w
    return f[0].upper() + f[1:] if w[0].isupper() else f


def fem(text):
    """Accorde au féminin ce qui s'adresse à la personne (« tu es prêt » -> « tu es prête », « champion » -> « championne »)."""
    if not text or P.get("genre") != "f" or not isinstance(text, str): return text
    def rep(m):
        g, a = m.group(0), m.start()
        out = g[:m.start("w") - a] + _fem_word(m.group("w"))
        if m.group("w2"):
            w2 = _fem_word(m.group("w2")) if _fem_word(m.group("w")) != m.group("w") else m.group("w2")   # « patient et régulier »
            out += g[m.end("w") - a:m.start("w2") - a] + w2
        return out
    s = RX_CTX.sub(rep, text)
    s = RX_IMP.sub(rep, s)
    s = RX_SENT.sub(lambda m: m.group(1) + _fem_word(m.group(2)), s)
    s = RX_STATE.sub(lambda m: m.group(1) + _fem_word(m.group(2)), s)
    s = re.sub(r"(\b(?:ne\s+)?(?:sors|pars|cours|roule|nage|t['’]entraîne|reste|t['’]aventure)\s+(?:jamais\s+|pas\s+)?)seul\b", r"\1seule", s)
    s = re.sub(r"(\btu\b[^.!?]{0,30}?\btout\s+)seul\b", lambda m: m.group(1)[:-len("tout ")] + "toute seule" if m.group(1).endswith("tout ") else m.group(1) + "seule", s)
    for pat, rep in ADDR:
        if rep is not None: s = re.sub(pat, rep, s)
        elif "champion" in pat: s = re.sub(pat, lambda m: ART_F.get(m.group(1), m.group(1)) + " championne", s)
        else: s = re.sub(pat, lambda m: (lambda r: r[0].upper() + r[1:] if m.group(0)[0].isupper() else r)(ADDR_F[m.group(0).lower()]), s)
    return s


def text(s):
    """Texte final : prénom d'origine remplacé par celui du profil, puis accords."""
    if not isinstance(s, str) or not s: return s
    pr = P.get("prenom") or BASE_NAME
    if pr != BASE_NAME and BASE_NAME in s: s = re.sub(rf"\b{BASE_NAME}\b", pr, s)
    return fem(s)


SKIP_KEYS = {"id", "key", "d", "date", "t", "s", "sp", "start", "end", "at", "url", "href", "trk", "ser", "repo", "gh", "nm"}


def personalize(obj, _k=None):
    """Applique text() à toutes les chaînes d'une structure (dict, liste), sauf identifiants, dates et noms d'activités Garmin."""
    if isinstance(obj, str): return obj if _k in SKIP_KEYS else text(obj)
    if isinstance(obj, list): return [personalize(v, _k) for v in obj]
    if isinstance(obj, dict): return {k: (v if k in SKIP_KEYS else personalize(v, k)) for k, v in obj.items()}
    return obj


# ------------------------------------------------------------------------------------------------------------------- application
def apply(config, acts=None, T=None, lt_garmin=None):
    """Applique le profil aux réglages et aux banques de textes, avant toute analyse."""
    global INFO
    ath = getattr(config, "ATHLETE", {})
    INFO = {"lthr_cfg": ath.get("lthr_run")}
    lt = P.get("lthr")
    if isinstance(lt, int):
        ath["lthr_run"] = lt; INFO.update(lthr_val=lt, lthr_src="saisie dans Paramètres")
    elif lt == "auto":
        v, src = estimate_lthr(acts, T, lt_garmin, ath.get("hr_max"))
        ath["lthr_run"] = v; INFO.update(lthr_val=v, lthr_src="estimée : " + src)
    else:
        INFO.update(lthr_val=ath.get("lthr_run"), lthr_src="réglage par défaut")
    if lt != "auto":                                          # l'estimation reste proposée dans Paramètres (« je ne sais pas »)
        v, src = estimate_lthr(acts, T, lt_garmin, ath.get("hr_max")); INFO.update(lthr_est=v, lthr_est_src=src)
    else:
        INFO.update(lthr_est=ath["lthr_run"], lthr_est_src=INFO["lthr_src"].replace("estimée : ", ""))
    sp = P.get("sports") or SPORTS
    if "strength" not in sp: ath["strength_per_week"] = 0
    if "bike" not in sp and "swim" not in sp: ath["cross_per_week"] = 0
    try:
        import bilan_bank as BB
        if not hasattr(BB, "_NICK0"): BB._NICK0, BB._INS0 = list(BB.NICK), list(BB.INS)
        BB.NAME = P.get("prenom") or BASE_NAME
        BB.NICK, BB.INS = nick_list(BB._NICK0), ins_list(BB._INS0)
    except ImportError:
        pass
    try:
        import coach_croise as CC
        if not hasattr(CC, "_GROS0"): CC._GROS0 = CC.GROS
        CC.GROS = (P.get("surnom") or "").strip() or P.get("prenom") or CC._GROS0
    except (ImportError, AttributeError):
        pass
    try:
        import redondance as R
        R.DOMAINE.update(w.lower() for w in ((P.get("prenom") or BASE_NAME), (P.get("surnom") or "")) for w in w.split() if w)
    except (ImportError, AttributeError):
        pass
    return P


def public(repo=None):
    """Ce que l'app reçoit : le profil et la FC seuil retenue (pour pré-remplir Paramètres)."""
    return {**{k: P.get(k) for k in ("prenom", "surnom", "genre", "sports", "lthr")}, "repo": P.get("repo") or repo, **INFO}
