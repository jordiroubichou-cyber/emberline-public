"""Configuration du site Emberline, pour que l'installation tienne en une seule étape (sans multiplier les secrets GitHub).

Les réglages techniques de l'utilisateur sont lus dans emberline.json, à la racine du dépôt (créé par la « Première configuration » de
l'app) :
  {
    "password": "...",            mot de passe de la page (chiffre index.html ; la page est publique mais illisible sans lui)
    "vapid_public": "...",        clé publique des notifications (intégrée à la page)
    "vapid_private": "...",       clé privée des notifications (utilisée pour envoyer les notifications)
    "vapid_subject": "mailto:..." adresse de contact exigée par le protocole Web Push (facultatif)
  }
Une variable d'environnement du même nom (DASHBOARD_PASSWORD, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT) reste prioritaire :
l'installation historique par secrets GitHub continue donc de fonctionner sans changement. Le fichier n'est jamais inclus dans les
livraisons et reste dans le dépôt privé de l'utilisateur."""
import json
import os
from pathlib import Path

FILE = "emberline.json"
_cache = None


def load(root="."):
    """Contenu d'emberline.json (dict). Absent ou illisible : dict vide. Mis en cache pour la durée du processus."""
    global _cache
    if _cache is not None:
        return _cache
    p = Path(root) / FILE
    data = {}
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8")) or {}
        except (OSError, ValueError):
            data = {}
    _cache = data if isinstance(data, dict) else {}
    return _cache


def get(key, env=None, default="", root="."):
    """Valeur de réglage : la variable d'environnement `env` si elle existe (secrets GitHub), sinon emberline.json, sinon `default`."""
    if env:
        v = os.environ.get(env, "")
        if v:
            return v.strip() if isinstance(v, str) else v
    v = load(root).get(key)
    return v if v not in (None, "") else default


def password(root="."):
    return get("password", "DASHBOARD_PASSWORD", "", root)


def vapid_public(root="."):
    return get("vapid_public", "VAPID_PUBLIC_KEY", "", root)


def vapid_private(root="."):
    return get("vapid_private", "VAPID_PRIVATE_KEY", "", root)


def vapid_subject(root="."):
    return get("vapid_subject", "VAPID_SUBJECT", "", root)
