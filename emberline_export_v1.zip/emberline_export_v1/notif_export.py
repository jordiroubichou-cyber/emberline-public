"""Écrit dist/notif_data.json : les quelques infos utilisées par les notifications (send_push.py).
Appelé à la fin de build_dashboard.py. Ne fait jamais échouer la génération du dashboard."""
import json, math, re


def _num(x):
    return x if isinstance(x, (int, float)) and math.isfinite(x) else None


def mob_info(A, acts, mob):
    """Séance de mobilité conseillée du jour, et si elle est déjà faite (activité « Emberline · Mobilité » envoyée sur Garmin)."""
    if not mob:
        return None
    today = str(A.get("today") or "")
    rec = next((s for s in mob.get("sessions") or [] if s.get("rec")), None) or {}
    done = any(str(a.get("d", ""))[:10] == today and re.search(r"mobilit|emberline", str(a.get("nm") or ""), re.I) and a.get("s") in ("other", "yoga", None)
               for a in acts)
    return {"key": mob.get("rec"), "title": rec.get("title"), "why": mob.get("why"), "done": bool(done)}


def write(out, A, acts, mob=None):
    try:
        S = ((A.get("stats") or {}).get("1S") or {}).get("cur") or {}
        cards = [{"cat": c.get("cat"), "title": c.get("title"), "meta": c.get("meta")}
                 for c in ((A.get("suggest") or {}).get("cards") or []) if c.get("rec")]
        data = {
            "today": A.get("today"),
            "note": _num(((A.get("pillars_p") or {}).get("1S") or {}).get("score")),
            "cards": cards,
            "pain": bool((A.get("pain") or {}).get("any")),
            "fresh": (A.get("fresh") or {}).get("level") or "",
            "week_n": S.get("n"),
            "week_km": _num((S.get("run") or {}).get("km")),
            "acts": sorted([[str(a.get("d"))[:10], a.get("s")] for a in acts if a.get("d")])[-80:],
            "mob": mob_info(A, acts, mob),                                            # rappel de mobilité de 20 h
            "statut": (((A.get("ress") or {}).get("statut") or {}).get("cur")),      # bilan du soir : normal, malade, vacances
        }
        (out / "notif_data.json").write_text(json.dumps(data, ensure_ascii=False, default=str), encoding="utf-8")
        print("Notifications : notif_data.json écrit.")
    except Exception as e:  # jamais bloquant
        print(f"Notifications : notif_data.json non écrit ({type(e).__name__} : {e}).")
