"""Rapport mensuel PDF Emberline : synthèse déterministe (sans IA) des 30 derniers jours.
Données Garmin essentielles, objectifs et douleurs, dans l'identité Emberline (ivoire, encre, braise, titres Fraunces).
Dessiné entièrement en code avec ReportLab (graphiques vectoriels) ; polices et logos dans le dossier rapport/.
Utilisé par build_dashboard.py : build_report(...) renvoie les octets du PDF ; une erreur ici ne bloque jamais le dashboard."""
from datetime import date, timedelta
from io import BytesIO
from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import simpleSplit, ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ASSETS = Path(__file__).resolve().parent / "rapport"
try:
    from PIL import Image as _I
    LOGO_R = (lambda w, h: w / h)(*_I.open(ASSETS / "logo-braise.png").size)
except Exception:                                    # noqa: BLE001
    LOGO_R = 3.68
W, H = A4
M = 40                                   # marge latérale
CW = W - 2 * M                           # largeur utile

# Palette Emberline (thème clair du dashboard)
PAGE, CARD, FILL, LINE = HexColor("#F7F3EC"), HexColor("#FBF8F3"), HexColor("#EEE8DF"), HexColor("#DDD6CC")
INK, MUT, SUB = HexColor("#17130F"), HexColor("#4A4641"), HexColor("#67635D")
EM, EMT, EMS, ASH = HexColor("#CF7230"), HexColor("#905225"), HexColor("#F3E3D3"), HexColor("#9C9891")
LV = {5: HexColor("#D17838"), 4: HexColor("#CF7230"), 3: HexColor("#BE7F51"), 2: HexColor("#B0896C"), 1: HexColor("#9C9891")}
LVT = {5: HexColor("#9D5B2D"), 4: HexColor("#9F5927"), 3: HexColor("#926340"), 2: HexColor("#856852"), 1: HexColor("#6F6B65")}
SPORT = {"run": ("Course", HexColor("#CF7230")), "trail": ("Trail", HexColor("#905225")), "bike": ("Vélo", HexColor("#B0896C")),
         "swim": ("Natation", HexColor("#6F6B65")), "strength": ("Musculation", HexColor("#E2B48E")),
         "walk": ("Marche", HexColor("#C9C2B8")), "other": ("Autre", HexColor("#C9C2B8"))}
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]
MOIS3 = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]

_FONTS = False


def _fonts():
    global _FONTS
    if _FONTS:
        return
    for n in ("Inter-Regular", "Inter-Medium", "Inter-SemiBold", "Inter-Bold", "Fraunces-Display", "Fraunces-Label"):
        pdfmetrics.registerFont(TTFont(n, str(ASSETS / f"{n}.ttf")))
    _FONTS = True


# ---------- formats français ----------
def n1(x, d=1):
    return "–" if x is None else f"{x:.{d}f}".replace(".", ",")


def n0(x):
    return "–" if x is None else f"{x:,.0f}".replace(",", " ")


def hms(s):
    if s is None:
        return "–"
    s = int(round(s)); h, r = divmod(s, 3600); m, sec = divmod(r, 60)
    return f"{h}h{m:02d}'{sec:02d}" if h else f"{m}'{sec:02d}"


def hmin(hours):
    if not hours:
        return "0 h"
    m = int(round(hours * 60)); h, mm = divmod(m, 60)
    return f"{h} h {mm:02d}" if h else f"{mm} min"


def pace(p):
    if not p:
        return "–"
    m = int(p); s = int(round((p - m) * 60))
    if s == 60:
        m, s = m + 1, 0
    return f"{m}'{s:02d}/km"


def dfr(d, year=True):
    d = d if isinstance(d, date) else date.fromisoformat(str(d)[:10])
    return f"{d.day} {MOIS[d.month - 1]}" + (f" {d.year}" if year else "")


def dshort(d):
    d = d if isinstance(d, date) else date.fromisoformat(str(d)[:10])
    return f"{d.day:02d}/{d.month:02d}"


def level(score20):
    if score20 is None:
        return 0
    return 5 if score20 >= 17 else 4 if score20 >= 14 else 3 if score20 >= 11 else 2 if score20 >= 8 else 1


def fire_label(score20):
    return {5: "En feu", 4: "Bouillant", 3: "Ça chauffe", 2: "Tiède", 1: "Refroidi"}.get(level(score20), "–")


def mean(v):
    v = [x for x in v if x is not None]
    return sum(v) / len(v) if v else None


def delta(cur, prev, unit="%"):
    """Écart relatif au mois précédent, texte + signe (+1 / -1 / 0)."""
    if cur is None or not prev:
        return "", 0
    p = (cur - prev) / prev * 100
    if abs(p) < 0.5:
        return "stable", 0
    return (f"+{n1(p, 0)} %" if p > 0 else f"−{n1(-p, 0)} %"), (1 if p > 0 else -1)


# ---------- briques de dessin ----------
class Doc:
    def __init__(self, c, period, total):
        self.c, self.period, self.total, self.n = c, period, total, 0

    def page(self, kicker, title, lead=None):
        """Nouvelle page : fond ivoire, en-tête logo, pied de page, titre de section. Renvoie le y de départ du contenu."""
        c = self.c
        if self.n:
            c.showPage()
        self.n += 1
        c.setFillColor(PAGE); c.rect(0, 0, W, H, stroke=0, fill=1)
        # en-tête
        c.drawImage(ImageReader(str(ASSETS / "logo-braise.png")), M, H - 46, height=16, width=16 * LOGO_R, mask="auto", preserveAspectRatio=True, anchor="sw")
        c.setFont("Inter-Medium", 8); c.setFillColor(SUB)
        c.drawRightString(W - M, H - 41, f"Rapport mensuel · {self.period}")
        c.setStrokeColor(LINE); c.setLineWidth(.6); c.line(M, H - 56, W - M, H - 56)
        # pied de page
        c.setFont("Inter-Regular", 7.5); c.setFillColor(SUB)
        c.drawString(M, 28, "Emberline · analyse 100 % automatique et déterministe, sans IA")
        c.drawRightString(W - M, 28, f"{self.n} / {self.total}")
        y = H - 92
        if kicker:
            text(c, M, y, kicker.upper(), "Inter-SemiBold", 8, EMT, spacing=1.4); y -= 30
        if title:
            c.setFont("Fraunces-Display", 28); c.setFillColor(INK); c.drawString(M, y, title); y -= 22
        if lead:
            y = para(c, M, y, lead, CW, "Inter-Regular", 10, MUT, 14) - 8
        return y


def text(c, x, y, s, font, size, color, anchor="l", spacing=0):
    c.setFont(font, size); c.setFillColor(color)
    if spacing:
        t = c.beginText(); t.setTextOrigin(x, y); t.setFont(font, size); t.setCharSpace(spacing); t.setFillColor(color); t.textOut(s); t.setCharSpace(0); c.drawText(t)
    elif anchor == "r":
        c.drawRightString(x, y, s)
    elif anchor == "c":
        c.drawCentredString(x, y, s)
    else:
        c.drawString(x, y, s)


def fit(s, font, size, width):
    """Coupe une chaîne avec « … » pour tenir dans width."""
    s = str(s or "")
    if pdfmetrics.stringWidth(s, font, size) <= width:
        return s
    while s and pdfmetrics.stringWidth(s + "…", font, size) > width:
        s = s[:-1]
    return s.rstrip() + "…"


def para(c, x, y, s, width, font, size, color, lead):
    """Paragraphe à la ligne automatique ; renvoie le y sous la dernière ligne."""
    c.setFont(font, size); c.setFillColor(color)
    for line in simpleSplit(str(s), font, size, width):
        c.drawString(x, y, line); y -= lead
    return y


def para_h(s, width, font, size, lead):
    return len(simpleSplit(str(s), font, size, width)) * lead


def card(c, x, y_top, w, h, fill=CARD, stroke=LINE, r=12, lw=.6):
    c.setFillColor(fill)
    if stroke is not None:
        c.setStrokeColor(stroke); c.setLineWidth(lw)
    c.roundRect(x, y_top - h, w, h, r, stroke=1 if stroke else 0, fill=1)


def bar(c, x, y, w, v, vmax, color, h=5):
    c.setFillColor(FILL); c.roundRect(x, y, w, h, h / 2, stroke=0, fill=1)
    if v and vmax:
        c.setFillColor(color); c.roundRect(x, y, max(h, w * min(1, v / vmax)), h, h / 2, stroke=0, fill=1)


def heat(c, x, y, lv, w=120, h=6):
    seg = (w - 4 * 3) / 5
    for k in range(1, 6):
        c.setFillColor(LV[k] if k <= lv else FILL)
        c.roundRect(x + (k - 1) * (seg + 3), y, seg, h, h / 2, stroke=0, fill=1)


def bullets(c, x, y, items, width, color, size=9.5, lead=13, gap=4):
    for it in items:
        c.setFillColor(color); c.circle(x + 2.5, y + 3, 2.2, stroke=0, fill=1)
        y = para(c, x + 11, y, it, width - 11, "Inter-Regular", size, MUT, lead) - gap
    return y


def bullets_h(items, width, size=9.5, lead=13, gap=4):
    return sum(para_h(it, width - 11, "Inter-Regular", size, lead) + gap for it in items)


def line_chart(c, x, y, w, h, pts, color, title, unit, fmt=lambda v: n1(v, 0), days_range=None):
    """Petit graphique en ligne : titre, moyenne en grand, courbe, ligne de moyenne pointillée, repères min / max."""
    card(c, x, y, w, h)
    text(c, x + 14, y - 22, title.upper(), "Inter-SemiBold", 7.5, SUB, spacing=.9)
    vals = [v for _, v in pts if v is not None]
    if not vals:
        text(c, x + 14, y - 48, "Pas de donnée sur la période", "Inter-Regular", 9, SUB); return
    av = mean(vals)
    text(c, x + 14, y - 46, fmt(av), "Inter-Bold", 18, INK)
    c.setFont("Inter-Bold", 18); tw = c.stringWidth(fmt(av), "Inter-Bold", 18)
    text(c, x + 18 + tw, y - 46, f"{unit} · moyenne", "Inter-Regular", 8.5, SUB)
    px0, px1, py0, py1 = x + 16, x + w - 16, y - h + 24, y - 64
    lo, hi = min(vals), max(vals)
    pad = (hi - lo) * .15 or 1
    lo, hi = lo - pad, hi + pad
    d0, d1 = days_range
    span = max(1, (d1 - d0).days)
    X = lambda d: px0 + (d - d0).days / span * (px1 - px0)
    Y = lambda v: py0 + (v - lo) / (hi - lo) * (py1 - py0)
    # repères hebdomadaires
    c.setStrokeColor(FILL); c.setLineWidth(.6); c.setFont("Inter-Regular", 6.5); c.setFillColor(SUB)
    k = d0
    while k <= d1:
        if k.weekday() == 0:
            c.line(X(k), py0, X(k), py1); c.drawCentredString(X(k), py0 - 11, dshort(k))
        k += timedelta(days=1)
    # moyenne
    c.setStrokeColor(LINE); c.setDash(2, 2); c.line(px0, Y(av), px1, Y(av)); c.setDash()
    # courbe
    c.setStrokeColor(color); c.setLineWidth(1.4); c.setLineJoin(1); c.setLineCap(1)
    p = c.beginPath(); started = False
    for d, v in pts:
        if v is None:
            continue
        if not started:
            p.moveTo(X(d), Y(v)); started = True
        else:
            p.lineTo(X(d), Y(v))
    c.drawPath(p, stroke=1, fill=0)
    c.setFillColor(color)
    for d, v in pts:
        if v is not None:
            c.circle(X(d), Y(v), 1.3, stroke=0, fill=1)
    # min / max
    vmin = min(pts, key=lambda t: t[1] if t[1] is not None else 1e9); vmax = max(pts, key=lambda t: t[1] if t[1] is not None else -1e9)
    c.setFont("Inter-Medium", 7); c.setFillColor(MUT)
    c.drawCentredString(X(vmax[0]), Y(vmax[1]) + 5, fmt(vmax[1]))
    c.drawCentredString(X(vmin[0]), Y(vmin[1]) - 10, fmt(vmin[1]))


def period_label(today):
    """« 9 oct. – 7 nov. 2026 » : les 30 jours couverts par le rapport."""
    T = date.fromisoformat(str(today)[:10]); d0 = T - timedelta(days=29)
    return f"{d0.day} {MOIS3[d0.month - 1]}" + (f" {d0.year}" if d0.year != T.year else "") + f" – {T.day} {MOIS3[T.month - 1]} {T.year}"


# ---------- contenu ----------
def build_report(acts, days, A, pains, today=None, athlete_name=None):
    """Construit le PDF du mois (30 derniers jours) et renvoie ses octets."""
    _fonts()
    T = date.fromisoformat(today or A["today"])
    d0 = T - timedelta(days=29)
    period = period_label(T.isoformat())
    acts_m = sorted([a for a in acts if d0.isoformat() <= str(a.get("d", ""))[:10] <= T.isoformat()], key=lambda a: (a["d"], a.get("t") or ""), reverse=True)
    rows_per_page = 30
    annex_pages = max(1, -(-len(acts_m) // rows_per_page))
    doc = Doc(canvas.Canvas(buf := BytesIO(), pagesize=A4, pageCompression=1), period, 5 + annex_pages)
    c = doc.c
    c.setTitle(f"Emberline · Rapport mensuel · {period}"); c.setAuthor("Emberline"); c.setSubject("Synthèse déterministe des données Garmin, objectifs et douleurs")
    S = A["stats"]["1M"]; cur, prev = S["cur"], S.get("prev") or {}
    PP = A["pillars_p"]["1M"]; sc = PP["score"]; lv = level(sc)
    sy = A["synth"]["1M"]

    # ===== Page 1 : synthèse =====
    c.setFillColor(PAGE); c.rect(0, 0, W, H, stroke=0, fill=1)
    doc.n = 1
    c.drawImage(ImageReader(str(ASSETS / "icone.png")), M, H - 104, 52, 52, mask="auto")
    c.drawImage(ImageReader(str(ASSETS / "logo-braise.png")), M + 66, H - 92, height=28, width=28 * LOGO_R, mask="auto", preserveAspectRatio=True, anchor="sw")
    text(c, W - M, H - 74, "RAPPORT MENSUEL", "Inter-SemiBold", 8, EMT, anchor="r")
    text(c, W - M, H - 90, period, "Inter-Medium", 10, INK, anchor="r")
    c.setFont("Fraunces-Display", 40); c.setFillColor(INK)
    c.drawString(M, H - 160, f"Le mois de {athlete_name}" if athlete_name else "Bilan du mois")
    para(c, M, H - 184, sy.get("head", ""), CW, "Inter-Regular", 10.5, MUT, 15)
    # carte note + piliers
    y = H - 236; h = 168
    card(c, M, y, CW, h, stroke=LV.get(lv, LINE), lw=1.2)
    note = n1(sc) if sc is not None else "–"
    text(c, M + 22, y - 72, note, "Inter-Bold", 54, INK)
    c.setFont("Inter-Bold", 54); nw = c.stringWidth(note, "Inter-Bold", 54)
    text(c, M + 26 + nw, y - 72, "/20", "Inter-SemiBold", 16, SUB)
    c.setFont("Fraunces-Label", 24); c.setFillColor(LVT.get(lv, SUB)); c.drawString(M + 22, y - 104, fire_label(sc))
    heat(c, M + 22, y - 124, lv, 150, 7)
    text(c, M + 22, y - 146, "Somme des 5 piliers, chacun noté sur 4", "Inter-Regular", 8, SUB)
    px = M + 230; pw = CW - 230 - 22; py = y - 26
    for p in PP["pillars"]:
        v = p.get("score"); pl = level(v * 5) if v is not None else 0
        text(c, px, py, p["name"], "Inter-SemiBold", 9, INK)
        text(c, px + pw, py, "n/a" if v is None else f"{n1(v)} / 4", "Inter-Medium", 9, SUB, anchor="r")
        bar(c, px, py - 11, pw, v, 4, LV.get(pl, ASH)); py -= 28
    # mot du coach
    bl = ((A.get("bilan") or {}).get("1M") or {}).get("text") or ""
    y = y - h - 16
    th = para_h(bl, CW - 44, "Inter-Regular", 10, 14.2)
    ch = 50 + th
    card(c, M, y, CW, ch, fill=EMS, stroke=EM, lw=1)
    c.setFont("Fraunces-Label", 17); c.setFillColor(EMT); c.drawString(M + 22, y - 30, "Le mot du coach")
    text(c, W - M - 22, y - 29, "1 mois glissant", "Inter-Medium", 8.5, SUB, anchor="r")
    para(c, M + 22, y - 52, bl, CW - 44, "Inter-Regular", 10, INK, 14.2)
    # indicateurs clés
    y = y - ch - 16
    rc, rp, r = cur.get("rec") or {}, (prev.get("rec") or {}), cur.get("run") or {}
    tiles = [("Séances", f"{cur.get('n', 0)}", hmin(cur.get("h")), delta(cur.get("h"), prev.get("h"))),
             ("Course", f"{n1(r.get('km'))} km", f"{r.get('n', 0)} sorties · {pace(r.get('pace'))}", delta(r.get("km"), (prev.get("run") or {}).get("km"))),
             ("Charge", n0(cur.get("ld")), f"ratio aigu/chronique {n1(cur.get('acwr'), 2) if cur.get('acwr') else '–'}", delta(cur.get("ld"), prev.get("ld"))),
             ("Sommeil", f"{n0(rc.get('sc'))}/100" if rc.get("sc") else "–", f"{n1(rc.get('sh'))} h par nuit", delta(rc.get("sc"), rp.get("sc"))),
             ("VFC", f"{n0(rc.get('hrv'))} ms" if rc.get("hrv") else "–", f"FC repos {n0(rc.get('rhr'))} bpm", delta(rc.get("hrv"), rp.get("hrv"))),
             ("Body Battery", f"{n0(rc.get('bbx'))}" if rc.get("bbx") else "–", "maximum moyen", delta(rc.get("bbx"), rp.get("bbx")))]
    tw_, th_ = (CW - 2 * 10) / 3, 68
    for i, (lab, val, det, (dt, sg)) in enumerate(tiles):
        tx = M + (i % 3) * (tw_ + 10); ty = y - (i // 3) * (th_ + 10)
        card(c, tx, ty, tw_, th_, fill=FILL, stroke=None)
        text(c, tx + 14, ty - 20, lab.upper(), "Inter-SemiBold", 7.5, SUB, spacing=.8)
        text(c, tx + 14, ty - 42, val, "Inter-Bold", 17, INK)
        text(c, tx + 14, ty - 56, fit(det, "Inter-Regular", 8, tw_ - 28), "Inter-Regular", 8, SUB)
        if dt:
            col = EMT if sg > 0 else SUB
            text(c, tx + tw_ - 12, ty - 20, ("▲ " if sg > 0 else "▼ " if sg < 0 else "") + dt, "Inter-SemiBold", 7.5, col, anchor="r")
    if y - 2 * (th_ + 10) - 4 > 46:
        text(c, M, y - 2 * (th_ + 10) - 4, "Flèches : évolution par rapport aux 30 jours précédents.", "Inter-Regular", 7.5, SUB)
    c.setFont("Inter-Regular", 7.5); c.setFillColor(SUB)
    c.drawString(M, 28, "Emberline · analyse 100 % automatique et déterministe, sans IA"); c.drawRightString(W - M, 28, f"1 / {doc.total}")

    # ===== Page 2 : entraînement =====
    y = doc.page("Entraînement", "Volume et régularité")
    # barres empilées par semaine (lundi → dimanche) sur la période
    wk0 = d0 - timedelta(days=d0.weekday())
    weeks = []
    k = wk0
    while k <= T:
        weeks.append(k); k += timedelta(days=7)
    order = ["run", "trail", "bike", "swim", "strength", "walk", "other"]
    agg = {w: {s: 0.0 for s in order} for w in weeks}
    for a in acts_m:
        d = date.fromisoformat(a["d"][:10]); w = d - timedelta(days=d.weekday())
        s = a.get("s") if a.get("s") in order else "other"
        if w in agg:
            agg[w][s] += (a.get("m") or 0) / 60
    ch = 210; card(c, M, y, CW, ch)
    text(c, M + 16, y - 22, "HEURES D'ENTRAÎNEMENT PAR SEMAINE", "Inter-SemiBold", 7.5, SUB, spacing=.9)
    used = [s for s in order if any(agg[w][s] > 0 for w in weeks)]
    lx = M + 16
    for s in used:
        nm, col = SPORT[s]; c.setFillColor(col); c.roundRect(lx, y - 40, 8, 8, 2, stroke=0, fill=1)
        text(c, lx + 12, y - 39, nm, "Inter-Medium", 8, MUT); lx += 22 + c.stringWidth(nm, "Inter-Medium", 8)
    tot = [sum(agg[w].values()) for w in weeks]; vmax = max(tot + [1])
    step = 2 if vmax <= 10 else 4 if vmax <= 20 else 5
    top = (int(vmax / step) + 1) * step
    gx0, gx1, gy0, gy1 = M + 40, M + CW - 16, y - ch + 30, y - 58
    c.setFont("Inter-Regular", 7); c.setFillColor(SUB); c.setStrokeColor(FILL); c.setLineWidth(.6)
    v = 0
    while v <= top:
        yy = gy0 + v / top * (gy1 - gy0); c.line(gx0, yy, gx1, yy); c.drawRightString(gx0 - 6, yy - 2.5, f"{v} h"); v += step
    bw = (gx1 - gx0) / len(weeks)
    for i, w in enumerate(weeks):
        bx = gx0 + i * bw + bw * .22; ww = bw * .56; yy = gy0
        for s in order:
            hh = agg[w][s] / top * (gy1 - gy0)
            if hh > 0:
                c.setFillColor(SPORT[s][1]); c.rect(bx, yy, ww, hh, stroke=0, fill=1); yy += hh
        text(c, bx + ww / 2, yy + 5, hmin(tot[i]).replace(" h ", "h"), "Inter-SemiBold", 7.5, INK, anchor="c")
        part = "" if w >= d0 and w + timedelta(days=6) <= T else " *"
        text(c, bx + ww / 2, gy0 - 13, f"sem. {dshort(w)}{part}", "Inter-Regular", 7, SUB, anchor="c")
    y -= ch + 6
    text(c, M, y - 4, "* semaine incomplète dans la période de 30 jours.", "Inter-Regular", 7, SUB)
    y -= 18
    # tableau par sport
    sp = cur.get("sp") or {}; spp = prev.get("sp") or {}
    rows = [(SPORT.get(s, (s, ASH))[0], SPORT.get(s, (s, ASH))[1], sp[s]) for s in order if s in sp and sp[s].get("n")]
    cols = [("Sport", 0, "l"), ("Séances", 150, "r"), ("Durée", 215, "r"), ("Distance", 290, "r"), ("D+", 350, "r"), ("Charge", 415, "r"), ("vs mois préc.", CW - 14, "r")]
    th = 26 + 20 * len(rows) + 8
    card(c, M, y, CW, th)
    for lab, cx, an in cols:
        text(c, M + 14 + cx if an == "l" else M + cx, y - 18, lab.upper(), "Inter-SemiBold", 7, SUB, anchor="r" if an == "r" else "l")
    yy = y - 38
    for nm, col, d in rows:
        key = [k for k, v in SPORT.items() if v[0] == nm][0]
        dp, _ = delta(d.get("h"), (spp.get(key) or {}).get("h"))
        c.setFillColor(col); c.circle(M + 18, yy + 3, 3, stroke=0, fill=1)
        text(c, M + 28, yy, nm, "Inter-SemiBold", 9, INK)
        text(c, M + 150, yy, str(d.get("n", 0)), "Inter-Regular", 9, INK, anchor="r")
        text(c, M + 215, yy, hmin(d.get("h")), "Inter-Regular", 9, INK, anchor="r")
        text(c, M + 290, yy, f"{n1(d.get('km'))} km" if d.get("km") else "–", "Inter-Regular", 9, INK, anchor="r")
        text(c, M + 350, yy, f"{n0(d.get('el'))} m" if d.get("el") else "–", "Inter-Regular", 9, INK, anchor="r")
        text(c, M + 415, yy, n0(d.get("ld")), "Inter-Regular", 9, INK, anchor="r")
        text(c, M + CW - 14, yy, dp or "nouveau", "Inter-Medium", 8.5, SUB, anchor="r")
        c.setStrokeColor(FILL); c.setLineWidth(.6); c.line(M + 14, yy - 7, M + CW - 14, yy - 7)
        yy -= 20
    y -= th + 14
    # course à pied
    r = cur.get("run") or {}
    items = [("Allure moyenne", pace(r.get("pace"))), ("Plus longue sortie", f"{n1(r.get('longest'))} km" if r.get("longest") else "–"),
             ("FC moyenne", f"{n0(r.get('hr'))} bpm" if r.get("hr") else "–"), ("Dénivelé", f"{n0(r.get('el'))} m" if r.get("el") else "–"),
             ("VO2max", n0(A.get("vo2")) if A.get("vo2") else "–")]
    card(c, M, y, CW, 64, fill=FILL, stroke=None)
    text(c, M + 16, y - 20, "COURSE À PIED", "Inter-SemiBold", 7.5, EMT, spacing=.9)
    cw5 = (CW - 32) / 5
    for i, (lab, val) in enumerate(items):
        text(c, M + 16 + i * cw5, y - 42, val, "Inter-Bold", 13, INK)
        text(c, M + 16 + i * cw5, y - 55, lab, "Inter-Regular", 8, SUB)
    y -= 64 + 16
    # points forts / à améliorer
    colw = (CW - 14) / 2
    good, bad = (sy.get("good") or [])[:5], (sy.get("bad") or [])[:5]
    hh = 34 + max(bullets_h(good, colw - 28, 8.8, 12, 4), bullets_h(bad, colw - 28, 8.8, 12, 4))
    for i, (ttl, its, col) in enumerate((("Points forts", good, EM), ("À améliorer", bad, ASH))):
        cx = M + i * (colw + 14)
        card(c, cx, y, colw, hh)
        text(c, cx + 14, y - 20, ttl.upper(), "Inter-SemiBold", 7.5, EMT if i == 0 else SUB, spacing=.9)
        bullets(c, cx + 14, y - 36, its, colw - 28, col, 8.8, 12, 4)

    # ===== Page 3 : récupération =====
    y = doc.page("Récupération", "Sommeil, VFC et énergie")
    dd = [d0 + timedelta(days=i) for i in range(30)]
    g = lambda k: [(d, (days.get(d.isoformat()) or {}).get(k)) for d in dd]
    gw, gh = (CW - 12) / 2, 168
    charts = [("Sommeil", g("sh"), "h", lambda v: n1(v, 1)), ("VFC nocturne", g("hrv"), "ms", lambda v: n1(v, 0)),
              ("FC au repos", g("rhr"), "bpm", lambda v: n1(v, 0)), ("Body Battery max", g("bbx"), "", lambda v: n1(v, 0))]
    for i, (ttl, pts, unit, fmt) in enumerate(charts):
        line_chart(c, M + (i % 2) * (gw + 12), y - (i // 2) * (gh + 12), gw, gh, pts, EM if i % 2 == 0 else EMT, ttl, unit, fmt, (d0, T))
    y -= 2 * (gh + 12) + 4
    vals = lambda k: [v for _, v in g(k) if v is not None]
    deep, rem, sh_ = mean(vals("deep")), mean(vals("rem")), mean(vals("sh"))
    pct = lambda m: f"{n1(m / (sh_ * 60) * 100, 0)} %" if m and sh_ else "–"
    tiles = [("Score sommeil", f"{n0(mean(vals('sc')))}/100" if vals("sc") else "–"), ("Sommeil profond", pct(deep)), ("Sommeil paradoxal", pct(rem)),
             ("Stress moyen", n0(mean(vals("st"))) if vals("st") else "–"), ("Readiness", n0(mean(vals("tr"))) if vals("tr") else "–"), ("Pas par jour", n0(mean(vals("stp"))) if vals("stp") else "–")]
    tw6 = (CW - 5 * 8) / 6
    for i, (lab, val) in enumerate(tiles):
        tx = M + i * (tw6 + 8)
        card(c, tx, y, tw6, 56, fill=FILL, stroke=None)
        text(c, tx + 10, y - 26, val, "Inter-Bold", 12.5, INK)
        text(c, tx + 10, y - 42, lab, "Inter-Regular", 7.5, SUB)
    y -= 56 + 16
    co = A.get("coach") or {}
    lect = []
    hv = co.get("hrv") or {}
    if hv.get("state"):
        lect.append(f"VFC : {hv['state']}" + (f" (dernière nuit {n1(hv.get('val'), 0)} ms, référence {n1(hv.get('base'), 0)} ms)" if hv.get("val") and hv.get("base") else "") + ".")
    sl = co.get("sleep") or {}
    if sl.get("debt") is not None:
        lect.append(f"Dette de sommeil estimée : {n1(sl['debt'], 1)} h.")
    if co.get("acwr_zone"):
        lect.append(f"Charge : zone « {str(co['acwr_zone']).replace('_', ' ')} » (ratio aigu/chronique {n1(co.get('acwr'), 2) if co.get('acwr') else '–'}).")
    if co.get("faf_label"):
        lect.append(f"Forme du jour : {co['faf_label']}.")
    for cr in (A.get("corr") or [])[:2]:
        if cr.get("text"):
            lect.append(cr["text"][:1].upper() + cr["text"][1:])
    if lect:
        hh = 34 + bullets_h(lect, CW - 28, 9, 12.5, 4)
        card(c, M, y, CW, hh)
        text(c, M + 14, y - 20, "LECTURE", "Inter-SemiBold", 7.5, EMT, spacing=.9)
        bullets(c, M + 14, y - 36, lect, CW - 28, EM, 9, 12.5, 4)

    # ===== Page 4 : objectifs =====
    y = doc.page("Objectifs", "Où en est la préparation")
    preps = sorted(A.get("prep") or [], key=lambda p: p.get("date") or "")
    goals = {g_["id"]: g_ for g_ in (A.get("goals") or [])}
    for p in preps:
        gl = goals.get(p.get("id"), {})
        tx = p.get("text") or ""
        hh = max(96, 70 + para_h(tx, CW - 180, "Inter-Regular", 8.8, 12.5))
        if y - hh < 50:
            break
        sc100 = p.get("score"); plv = level(sc100 / 5) if sc100 is not None else 0
        card(c, M, y, CW, hh, stroke=LV.get(plv, LINE) if p.get("prio") == "A" else LINE, lw=1 if p.get("prio") == "A" else .6)
        c.setFont("Fraunces-Label", 15); c.setFillColor(INK); c.drawString(M + 16, y - 26, fit(p.get("name", ""), "Fraunces-Label", 15, CW - 180))
        meta = f"{p.get('date_fr', '')} · J-{p.get('days_left')} · {p.get('cls', '')} · {p.get('role', '')} · phase {p.get('phase_label', '')}"
        text(c, M + 16, y - 42, fit(meta, "Inter-Regular", 8.5, CW - 180), "Inter-Regular", 8.5, SUB)
        para(c, M + 16, y - 60, tx, CW - 180, "Inter-Regular", 8.8, MUT, 12.5)
        rx = M + CW - 136
        text(c, rx, y - 30, f"{sc100}" if sc100 is not None else "–", "Inter-Bold", 22, INK)
        c.setFont("Inter-Bold", 22); w_ = c.stringWidth(f"{sc100}", "Inter-Bold", 22)
        text(c, rx + w_ + 3, y - 30, "/100", "Inter-Medium", 8.5, SUB)
        text(c, rx, y - 44, p.get("label", ""), "Inter-SemiBold", 8.5, LVT.get(plv, SUB))
        bar(c, rx, y - 56, 120, sc100, 100, LV.get(plv, ASH))
        if gl.get("target_s") or p.get("target"):
            text(c, rx, y - 72, f"Visé {p.get('target') or hms(gl.get('target_s'))}", "Inter-Regular", 7.5, SUB)
        if gl.get("pred"):
            text(c, rx, y - 84, f"Estimé {hms(gl.get('pred'))}", "Inter-Medium", 7.5, INK)
        y -= hh + 10
    # prédictions
    preds = A.get("preds") or []
    if preds and y - 4 - (30 + 20 * len(preds) + 6) - 20 > 46:
        y -= 4
        th = 30 + 20 * len(preds) + 6
        card(c, M, y, CW, th)
        hdr = [("Distance", 14, "l"), ("Temps estimé", 200, "r"), ("Fourchette basse", 280, "r"), ("Fourchette haute", 360, "r"), ("Objectif", 440, "r"), ("Écart", CW - 14, "r")]
        for lab, cx, an in hdr:
            text(c, M + cx, y - 18, lab.upper(), "Inter-SemiBold", 7, SUB, anchor="r" if an == "r" else "l")
        yy = y - 38
        for pr in preds:
            gap = pr.get("gap")
            text(c, M + 14, yy, pr.get("label", ""), "Inter-SemiBold", 9, INK)
            text(c, M + 200, yy, hms(pr.get("ret")), "Inter-Bold", 9, INK, anchor="r")
            text(c, M + 280, yy, hms(pr.get("riegel")), "Inter-Regular", 9, MUT, anchor="r")
            text(c, M + 360, yy, hms(pr.get("daniels")), "Inter-Regular", 9, MUT, anchor="r")
            text(c, M + 440, yy, hms(pr.get("target")) if pr.get("target") else "–", "Inter-Regular", 9, MUT, anchor="r")
            gtxt = "–" if gap is None else (("+" if gap > 0 else "−") + hms(abs(gap)))
            text(c, M + CW - 14, yy, gtxt, "Inter-SemiBold", 9, EMT if gap is not None and gap > 0 else INK, anchor="r")
            yy -= 20
        y -= th + 6
        text(c, M, y - 4, "Temps estimé : valeur retenue par Emberline à partir de tes meilleures séances récentes ; écart positif = plus lent que l'objectif.", "Inter-Regular", 7, SUB)

    # ===== Page 5 : douleurs =====
    y = doc.page("Douleurs", "Douleurs et adaptations")
    pn = A.get("pain") or {}
    panel = pn.get("panel") or []
    if not panel:
        card(c, M, y, CW, 60, fill=FILL, stroke=None)
        text(c, M + 16, y - 34, "Aucune douleur active : les séances proposées n'ont pas eu besoin d'être adaptées.", "Inter-Medium", 10, MUT)
        y -= 76
    for it in panel:
        lines = it.get("lines") or []
        ttl = it.get("label") or it.get("title") or ""
        tl = simpleSplit(ttl, "Fraunces-Label", 14, CW - 48 - 130)
        hh = 74 + 17 * (len(tl) - 1) + bullets_h(lines, CW - 32, 9, 12.5, 4)
        if y - hh < 150:
            break
        inten = it.get("intensity") or 0
        plv = 1 if inten <= 0 else 2 if inten <= 3 else 4 if inten <= 6 else 5
        card(c, M, y, CW, hh)
        c.setFillColor(LV[plv]); c.circle(M + 21, y - 22, 4.5, stroke=0, fill=1)
        c.setFont("Fraunces-Label", 14); c.setFillColor(INK)
        for i_, ln in enumerate(tl):
            c.drawString(M + 32, y - 27 - 17 * i_, ln)
        since = f"depuis le {dfr(it['start'], False)}" if it.get("start") else ""
        text(c, M + 32, y - 42 - 17 * (len(tl) - 1), f"Intensité {inten}/10 · {since}", "Inter-Regular", 8.5, SUB)
        segw = 9
        for k in range(10):
            c.setFillColor(LV[plv] if k < inten else FILL); c.roundRect(M + CW - 16 - (10 - k) * (segw + 2), y - 26, segw, 6, 2, stroke=0, fill=1)
        bullets(c, M + 16, y - 62 - 17 * (len(tl) - 1), lines, CW - 32, EM, 9, 12.5, 4)
        y -= hh + 10
    # historique de la période
    hist = []
    for p in pains or []:
        st, ao = str(p.get("start") or ""), str(p.get("archived_on") or "")
        if (st and st >= d0.isoformat()) or (ao and ao >= d0.isoformat()) or (not p.get("archived") and (p.get("intensity") or 0) > 0):
            hist.append(p)
    if hist:
        try:
            import pain as pain_mod
            lab = lambda p: pain_mod.label(p)
        except Exception:                                # noqa: BLE001
            lab = lambda p: f"{p.get('region', '')} {p.get('side', '')}".strip()
        th = 30 + 20 * len(hist) + 6
        card(c, M, y, CW, th)
        for t_, cx, an in (("Douleur", 14, "l"), ("Début", 330, "l"), ("Statut", CW - 14, "r")):
            text(c, M + cx, y - 18, t_.upper(), "Inter-SemiBold", 7, SUB, anchor="r" if an == "r" else "l")
        yy = y - 38
        for p in sorted(hist, key=lambda p: str(p.get("start") or ""), reverse=True):
            text(c, M + 14, yy, fit(lab(p), "Inter-Medium", 9, 300), "Inter-Medium", 9, INK)
            text(c, M + 330, yy, dfr(p["start"]) if p.get("start") else "–", "Inter-Regular", 9, MUT)
            stt = f"archivée le {dshort(p['archived_on'])}" if p.get("archived") and p.get("archived_on") else f"active · {p.get('intensity', 0)}/10"
            text(c, M + CW - 14, yy, stt, "Inter-Medium", 8.5, EMT if not p.get("archived") else SUB, anchor="r")
            yy -= 20
        y -= th + 14
    # adaptations des séances
    cards_ = [cd for cd in ((A.get("suggest") or {}).get("cards") or []) if cd.get("pain") or cd.get("form")]
    if cards_ and y > 140:
        its = []
        for cd in cards_[:6]:
            why = " et ".join(w for w, ok in (("à ta forme", cd.get("form")), ("à tes douleurs", cd.get("pain"))) if ok)
            its.append(f"{cd.get('cat', '')} · {cd.get('title', '')} : adaptée {why}.")
        hh = 34 + bullets_h(its, CW - 28, 9, 12.5, 4)
        card(c, M, y, CW, hh, fill=EMS, stroke=None)
        text(c, M + 14, y - 20, "SÉANCES PROPOSÉES AUJOURD'HUI, ADAPTÉES", "Inter-SemiBold", 7.5, EMT, spacing=.9)
        bullets(c, M + 14, y - 36, its, CW - 28, EM, 9, 12.5, 4)
        y -= hh + 10
    para(c, M, max(y - 6, 60), "Conseils généraux : ils ne remplacent pas un avis médical. Consulte si la douleur persiste, s'aggrave, est présente au repos ou la nuit.", CW, "Inter-Regular", 7.5, SUB, 11)

    # ===== Annexe : séances =====
    cols = [("Date", 0, "l"), ("Sport", 52, "l"), ("Séance", 118, "l"), ("Durée", 330, "r"), ("Distance", 385, "r"), ("D+", 425, "r"), ("FC", 463, "r"), ("Charge", CW - 14, "r")]
    for pg in range(annex_pages):
        y = doc.page("Annexe", "Séances du mois" if pg == 0 else "Séances du mois (suite)",
                     f"{len(acts_m)} séances du {dfr(d0, False)} au {dfr(T)}." if pg == 0 else None)
        chunk = acts_m[pg * rows_per_page:(pg + 1) * rows_per_page]
        th = 28 + 18.5 * len(chunk) + 6
        card(c, M, y, CW, th)
        for lab, cx, an in cols:
            text(c, M + 14 + cx if an == "l" else M + cx, y - 18, lab.upper(), "Inter-SemiBold", 7, SUB, anchor="r" if an == "r" else "l")
        yy = y - 36
        for a in chunk:
            s = a.get("s") if a.get("s") in SPORT else "other"
            nm, col = SPORT[s]
            text(c, M + 14, yy, dshort(a["d"]), "Inter-Medium", 8.5, INK)
            c.setFillColor(col); c.circle(M + 69, yy + 3, 2.6, stroke=0, fill=1)
            text(c, M + 76, yy, nm, "Inter-Regular", 8.5, MUT)
            x = a.get("x") or {}; st = x.get("st") or {}; cm = (a.get("cmp") or {}).get("code")
            tag = " · ".join(t for t in (st.get("label") if st.get("kind") == "intervals" else "",
                                         {"ok": "conforme", "harder": "plus intense", "easier": "plus facile", "partial": "partielle", "other": "faite autrement",
                                          "short": "plus courte", "long": "plus longue"}.get(cm, ""), "enchaînement" if (a.get("brick") or {}).get("gap") is not None else "") if t)
            text(c, M + 132, yy, fit((a.get("nm") or "") + (f" · {tag}" if tag else ""), "Inter-Regular", 8.5, 166), "Inter-Regular", 8.5, INK)
            text(c, M + 330, yy, hmin((a.get("m") or 0) / 60), "Inter-Regular", 8.5, INK, anchor="r")
            text(c, M + 385, yy, f"{n1(a.get('km'))} km" if a.get("km") else "–", "Inter-Regular", 8.5, INK, anchor="r")
            text(c, M + 425, yy, f"{n0(a.get('el'))}" if a.get("el") else "–", "Inter-Regular", 8.5, MUT, anchor="r")
            text(c, M + 463, yy, f"{n0(a.get('hr'))}" if a.get("hr") else "–", "Inter-Regular", 8.5, MUT, anchor="r")
            text(c, M + CW - 14, yy, n0(a.get("ld")) if a.get("ld") else "–", "Inter-Regular", 8.5, MUT, anchor="r")
            c.setStrokeColor(FILL); c.setLineWidth(.5); c.line(M + 14, yy - 6.5, M + CW - 14, yy - 6.5)
            yy -= 18.5
        if pg == annex_pages - 1:
            para(c, M, y - th - 18, "Méthode : toutes les valeurs de ce rapport sont calculées de façon déterministe à partir de tes données Garmin, de tes objectifs et de tes douleurs déclarées ; les mêmes données donnent toujours le même rapport. Aucune intelligence artificielle n'intervient.", CW, "Inter-Regular", 7.5, SUB, 11)
    c.showPage(); c.save()
    return buf.getvalue()
