"""Monde synthétique pour les tests (réexporte test_robustesse.monde)."""
from test_robustesse import monde  # noqa: F401
