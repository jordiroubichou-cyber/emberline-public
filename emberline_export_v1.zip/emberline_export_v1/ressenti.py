"""Bilan du soir : le questionnaire de 22 h rempli dans l'app (ressenti.json), lu par l'analyse.

Une réponse datée du jour J décrit la soirée de J. Elle sert à l'analyse du lendemain (J+1) :
  - état ressenti (énergie, jambes, sérénité, motivation), comparé à ta propre base des six dernières semaines ;
  - plafonds du facteur d'ajustement de forme (FAF) et profil du jour (maladie, jambes lourdes, fatigue, stress) ;
  - charge ressentie (effort ressenti × durée), comparée à la charge mesurée par la montre ;
  - créneau disponible le lendemain (durée de la séance du coach, ou repos choisi) ;
  - mobilité conseillée, phrases de « La séance du coach » et du « Mot du coach ».
Sans réponse, l'analyse est exactement la même qu'avant : rien ne dépend du questionnaire pour fonctionner.

Format du fichier (écrit par l'app, une entrée par soir, la plus récente remplace celle du même jour) :
{"version": 1, "entries": [{"date": "2026-11-12", "energie": 4, "jambes": 2, "serenite": 3, "motivation": 4,
  "seance": true, "rpe": 7, "dispo": 60, "signaux": ["alcool"], "t": "2026-11-12T22:14:03+01:00", "v": 1}]}
  energie, jambes, serenite, motivation : 1 à 5 (5 = le mieux) · rpe : effort ressenti de la journée, 1 à 10 (null sans séance)
  dispo : minutes disponibles le lendemain (0 = repos voulu ; 120 = deux heures ou plus) · signaux : douleur, alcool, physique
  statut : normal, malade ou vacances ; il reste valable les soirs suivants tant qu'il n'est pas changé (jours sans réponse compris)
  sports : sports possibles en vacances (run, trail, bike, swim, strength)
Malade : récupération et mobilité seulement. Vacances : seulement les sports possibles, volume réduit.
Au retour à « normal » : reprise progressive de 7 à 21 jours selon la durée de l'épisode (volume et intensité remontent par paliers).
"""
import hashlib
import json
from datetime import date, timedelta
from pathlib import Path

FILE = "ressenti.json"
ITEMS = ("energie", "jambes", "serenite", "motivation")
W = {"energie": .35, "jambes": .30, "serenite": .20, "motivation": .15}
DISPO = (0, 30, 45, 60, 90, 120)
SIGNAUX = ("malade", "douleur", "alcool", "physique")      # « malade » : ancien signal, lu comme le statut « malade »
STATUTS = ("normal", "malade", "vacances")
SPORTS = ("run", "trail", "bike", "swim", "strength")
SPORT_FR = {"run": "course", "trail": "trail", "bike": "vélo", "swim": "natation", "strength": "musculation"}
CARRY_MAX = 21                  # un statut non renouvelé reste valable au plus 21 jours après le dernier bilan
NOM = {"energie": "énergie", "jambes": "jambes", "serenite": "sérénité", "motivation": "motivation"}
MOTS = {"energie": ("vidé", "fatigué", "correct", "en forme", "plein d'énergie"),
        "jambes": ("très lourdes", "lourdes", "normales", "légères", "toutes neuves"),
        "serenite": ("très stressé", "tendu", "posé", "détendu", "serein"),
        "motivation": ("aucune envie", "peu motivé", "partant", "motivé", "très motivé")}
SIGNAL_FR = {"malade": "symptômes de maladie", "douleur": "douleur", "alcool": "alcool", "physique": "journée physique"}
BASE_DAYS, BASE_MIN = 42, 7


def f1(x, n=1):
    return f"{x:.{n}f}".replace(".", ",")


def _int(v, lo, hi):
    try:
        x = int(round(float(v)))
    except (TypeError, ValueError):
        return None
    return x if lo <= x <= hi else None


def clean(e):
    """Entrée validée (None si inutilisable). Les valeurs hors bornes sont ignorées, jamais inventées."""
    if not isinstance(e, dict):
        return None
    d = str(e.get("date") or "")[:10]
    try:
        date.fromisoformat(d)
    except ValueError:
        return None
    o = {"date": d}
    for k in ITEMS:
        o[k] = _int(e.get(k), 1, 5)
    if all(o[k] is None for k in ITEMS) and e.get("statut") not in ("malade", "vacances"):
        return None
    o["seance"] = bool(e.get("seance")) if e.get("seance") is not None else (e.get("rpe") is not None)
    o["rpe"] = _int(e.get("rpe"), 1, 10) if o["seance"] else None
    dp = _int(e.get("dispo"), 0, 600)
    o["dispo"] = None if dp is None else min(DISPO, key=lambda x: abs(x - dp))
    o["signaux"] = sorted({s for s in (e.get("signaux") or []) if s in SIGNAUX}) if isinstance(e.get("signaux"), list) else []
    st = e.get("statut")
    o["statut"] = st if st in STATUTS else ("malade" if "malade" in o["signaux"] else "normal")
    sp = e.get("sports") if isinstance(e.get("sports"), list) else []
    o["sports"] = [x for x in SPORTS if x in sp] if o["statut"] == "vacances" else []
    o["t"] = str(e.get("t") or "")[:40]
    return o


def load(root):
    """Lit ressenti.json à la racine du dépôt -> ({date: entrée}, avertissements). Jamais bloquant."""
    p = Path(root) / FILE
    if not p.exists():
        return {}, []
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return {}, [f"{FILE} illisible ({type(e).__name__}) : bilans du soir ignorés."]
    lst = raw.get("entries") if isinstance(raw, dict) else raw if isinstance(raw, list) else []
    out, bad = {}, 0
    for e in lst or []:
        c = clean(e)
        if c:
            out[c["date"]] = c          # la plus récente l'emporte (ordre du fichier)
        else:
            bad += 1
    return dict(sorted(out.items())), ([f"{bad} entrée(s) de {FILE} ignorée(s) (format inattendu)."] if bad else [])


def _norm(x):
    return None if x is None else (x - 1) / 4


def comp_abs(e):
    """Forme ressentie sur l'échelle absolue (0 à 1), pondérée : énergie 35 %, jambes 30 %, sérénité 20 %, motivation 15 %."""
    p = [(W[k], _norm(e.get(k))) for k in ITEMS if e.get(k) is not None]
    return sum(w * v for w, v in p) / sum(w for w, _ in p) if p else None


def _day_acts(acts):
    m, ld, n = {}, {}, {}
    for a in acts or ():
        d = str(a.get("d", ""))[:10]
        m[d] = m.get(d, 0) + (a.get("m") or 0)
        ld[d] = ld.get(d, 0) + (a.get("ld") or 0)
        n[d] = n.get(d, 0) + 1
    return m, ld, n


def _median(xs):
    xs = sorted(xs)
    if not xs:
        return None
    k = len(xs) // 2
    return xs[k] if len(xs) % 2 else (xs[k - 1] + xs[k]) / 2


def timeline(entries, upto):
    """Statut de chaque jour jusqu'à `upto` (date ISO) : le statut d'un bilan vaut jusqu'au bilan suivant (21 jours au plus)."""
    out, last, last_d, last_sp = {}, "normal", None, []
    if not entries:
        return out
    d = date.fromisoformat(min(entries))
    end = date.fromisoformat(upto)
    while d <= end:
        k = d.isoformat()
        e = entries.get(k)
        if e:
            last, last_d, last_sp = e.get("statut") or "normal", d, e.get("sports") or []
        elif last_d is not None and (d - last_d).days > CARRY_MAX:
            last, last_sp = "normal", []
        out[k] = (last, last_sp)
        d += timedelta(days=1)
    return out


def reprise_plan(frm, L):
    """Durée de la reprise (jours) et volume du premier jour, selon le type et la durée de l'épisode."""
    if frm == "malade":
        return min(21, max(7, round(L * 1.5) + 4)), max(0.5, 0.75 - 0.02 * L)
    return min(21, max(7, L)), max(0.6, 0.9 - 0.015 * L)


def statut_info(entries, T):
    """Statut valable pour l'analyse du jour T (bilan de la veille au soir, prolongé si besoin) et reprise en cours."""
    d_cur = (T - timedelta(days=1)).isoformat()
    tl = timeline(entries, d_cur)
    info = {"cur": "normal", "since": None, "jour": 0, "sports": [], "reprise": None}
    if d_cur not in tl:
        return info
    cur, sp = tl[d_cur]
    days = sorted(tl)
    i = len(days) - 1
    while i > 0 and tl[days[i - 1]][0] == cur:
        i -= 1
    start = days[i]
    if cur != "normal":
        info.update(cur=cur, since=start, jour=(date.fromisoformat(d_cur) - date.fromisoformat(start)).days + 1, sports=list(sp))
        return info
    if i == 0:
        return info
    frm = tl[days[i - 1]][0]                     # épisode qui vient de se terminer (le premier soir « normal » est `start`)
    j0 = i - 1
    while j0 > 0 and tl[days[j0 - 1]][0] == frm:
        j0 -= 1
    L = (date.fromisoformat(days[i - 1]) - date.fromisoformat(days[j0])).days + 1
    R, v0 = reprise_plan(frm, L)
    j = (T - date.fromisoformat(start)).days     # jour 1 = lendemain du premier soir « ça va mieux » / « de retour »
    if 1 <= j <= R:
        p = (j - 1) / R
        vol = v0 + (1 - v0) * p
        lvl = 2 if p < 1 / 3 else 3 if p < 2 / 3 else 4
        info["reprise"] = {"from": frm, "len": L, "jour": j, "total": R, "vol": round(vol, 2), "pct": round(vol * 100), "lvl": lvl,
                           "since": start}
    return info


def evaluate(entries, T, acts=()):
    """État ressenti pour l'analyse du jour T, à partir du bilan de la veille au soir (T-1)."""
    entries = entries or {}
    d_cur = (T - timedelta(days=1)).isoformat()
    cur = entries.get(d_cur)
    mins, loads, nact = _day_acts(acts)
    # charge ressentie (sRPE) de chaque soir renseigné, comparée à la charge Garmin du même jour
    srpe = {}
    for d, e in entries.items():
        if e.get("seance") and e.get("rpe") and mins.get(d, 0) > 0:
            s = e["rpe"] * mins[d]
            srpe[d] = {"srpe": round(s), "ld": round(loads.get(d, 0)), "min": round(mins[d]), "ratio": (s / loads[d]) if loads.get(d, 0) > 0 else None}
    out = {"any": bool(entries), "n": len(entries), "cur": None, "date": d_cur, "comp": None, "comp_abs": None, "z": None, "base_n": 0,
           "flags": [], "caps": [], "hard_yday": False, "legs": False, "dispo": None, "rpe": None, "srpe": None, "cost": None,
           "today": entries.get(T.isoformat()), "srpe_by_day": srpe}
    stt = statut_info(entries, T)
    out["statut"] = stt
    if stt["cur"] == "malade":                  # statut prolongé même sans bilan la veille
        out["flags"] = ["malade"]; out["caps"] = [("Malade", 0.60, f"jour {stt['jour']} de maladie")]
    elif stt["cur"] == "vacances":
        out["flags"] = ["vacances"]
    if stt["reprise"]:
        out["flags"] = out["flags"] + ["reprise"]
    if not cur:
        return out
    out["cur"] = cur
    ca = comp_abs(cur)
    out["comp_abs"] = ca
    lo = (T - timedelta(days=1 + BASE_DAYS)).isoformat()
    hist = [e for d, e in entries.items() if lo <= d < d_cur]
    out["base_n"] = len(hist)
    comp = ca
    if len(hist) >= BASE_MIN and ca is not None:          # base personnelle : chacun note à sa façon, on regarde l'écart à TA normale
        z = {}
        for k in ITEMS:
            vals = [e[k] for e in hist if e.get(k) is not None]
            if len(vals) >= BASE_MIN and cur.get(k) is not None:
                mu = sum(vals) / len(vals)
                sd = max(0.5, (sum((v - mu) ** 2 for v in vals) / len(vals)) ** 0.5)
                z[k] = (cur[k] - mu) / sd
        if z:
            zc = sum(W[k] * z[k] for k in z) / sum(W[k] for k in z)
            out["z"] = {k: round(v, 2) for k, v in z.items()}
            comp = max(0.0, min(1.0, 0.55 * ca + 0.45 * (0.5 + 0.17 * zc)))
    out["comp"] = None if comp is None else round(comp, 3)
    e, j, s, m = (cur.get(k) for k in ITEMS)
    sig = set(cur.get("signaux") or [])
    fl = []
    if stt["cur"] == "malade": fl.append("malade")
    if stt["cur"] == "vacances": fl.append("vacances")
    if stt["reprise"]: fl.append("reprise")
    if j is not None and j <= 2: fl.append("jambes")
    if e is not None and e <= 2: fl.append("energie")
    if s is not None and s <= 2: fl.append("stress")
    if m is not None and m <= 2: fl.append("motivation")
    if "alcool" in sig: fl.append("alcool")
    if "physique" in sig: fl.append("physique")
    if "douleur" in sig: fl.append("douleur")
    if comp is not None and comp >= 0.75 and not [f for f in fl if f not in ("vacances", "reprise")]: fl.append("top")
    out["flags"] = fl
    caps = []
    if stt["cur"] == "malade": caps.append(("Malade", 0.60, f"jour {stt['jour']} de maladie"))
    if e == 1: caps.append(("Énergie au plus bas", 0.75, "énergie notée 1/5 hier soir"))
    elif e == 2: caps.append(("Énergie basse", 0.88, "énergie notée 2/5 hier soir"))
    if s == 1: caps.append(("Stress très élevé", 0.85, "sérénité notée 1/5 hier soir"))
    if "alcool" in sig: caps.append(("Alcool la veille", 0.90, "pas d'intensité aujourd'hui"))
    rpe = cur.get("rpe") if cur.get("seance") else None
    out["rpe"] = rpe
    if rpe is not None and rpe >= 9: caps.append(("Séance très dure hier", 0.90, f"effort ressenti {rpe}/10"))
    if comp is not None and comp < 0.3 and not caps: caps.append(("Ressenti très bas", 0.85, "forme ressentie très basse hier soir"))
    # séance plus coûteuse que ne l'indique la montre : charge ressentie / charge Garmin au-dessus de ta normale
    if d_cur in srpe:
        out["srpe"] = srpe[d_cur]
        r0 = srpe[d_cur]["ratio"]
        ratios = [v["ratio"] for d, v in srpe.items() if v["ratio"] and (T - timedelta(days=61)).isoformat() <= d < d_cur]
        med = _median(ratios) if len(ratios) >= 5 else None
        if r0 and med:
            out["cost"] = "haut" if r0 >= 1.3 * med else "bas" if r0 <= 0.75 * med else "normal"
            out["cost_pct"] = round((r0 / med - 1) * 100)
            if out["cost"] == "haut": caps.append(("Séance plus coûteuse que prévu", 0.92, f"effort ressenti {out['cost_pct']:+d} % au-dessus de ta normale pour cette charge"))
    out["caps"] = caps
    out["hard_yday"] = bool((rpe is not None and rpe >= 8) or out["cost"] == "haut")
    out["legs"] = bool((j is not None and j <= 2) or "physique" in sig)
    out["dispo"] = cur.get("dispo")
    return out


def cross(ress, ready):
    """Ressenti et physiologie en désaccord : le plus utile à signaler."""
    c = (ress or {}).get("comp")
    if c is None or ready is None:
        return None
    if c <= 0.38 and ready >= 0.62: return "bas_physio_ok"
    if c >= 0.72 and ready <= 0.45: return "haut_physio_bas"
    return None


def period(entries, T, n, acts=()):
    """Moyennes du ressenti sur les n derniers soirs (fenêtre de la période) et comparaison à la fenêtre précédente."""
    def win(off):
        lo, hi = (T - timedelta(days=n + off)).isoformat(), (T - timedelta(days=off)).isoformat()
        return [e for d, e in (entries or {}).items() if lo < d <= hi]
    cur, prev = win(0), win(n)
    if not cur:
        return None
    avg = lambda L, k: (sum(e[k] for e in L if e.get(k) is not None) / max(1, sum(1 for e in L if e.get(k) is not None))) if any(e.get(k) is not None for e in L) else None
    items = {k: avg(cur, k) for k in ITEMS}
    comps = [comp_abs(e) for e in cur if comp_abs(e) is not None]
    pc = [comp_abs(e) for e in prev if comp_abs(e) is not None]
    mins, loads, _ = _day_acts(acts)
    sr = [(e["rpe"] * mins[e["date"]], loads.get(e["date"], 0)) for e in cur if e.get("seance") and e.get("rpe") and mins.get(e["date"], 0) > 0]
    score = None if not comps else 1 + 4 * sum(comps) / len(comps)        # forme ressentie moyenne, sur 5
    pscore = None if len(pc) < 3 else 1 + 4 * sum(pc) / len(pc)
    out = {"n": len(cur), "days": n, "score": None if score is None else round(score, 2), "prev": None if pscore is None else round(pscore, 2),
           "items": {k: (None if v is None else round(v, 2)) for k, v in items.items()},
           "rpe": None, "srpe": None, "trend": None, "best": None, "worst": None,
           "series": [{"d": e["date"], "c": None if comp_abs(e) is None else round(1 + 4 * comp_abs(e), 2), "rpe": e.get("rpe")} for e in sorted(cur, key=lambda x: x["date"])]}
    rp = [e["rpe"] for e in cur if e.get("rpe")]
    if rp: out["rpe"] = round(sum(rp) / len(rp), 1)
    if sr: out["srpe"] = round(sum(a for a, _ in sr)); out["srpe_ld"] = round(sum(b for _, b in sr))
    if score is not None and pscore is not None:
        d = score - pscore
        out["trend"] = "up" if d >= 0.25 else "down" if d <= -0.25 else "flat"
    known = {k: v for k, v in items.items() if v is not None}
    if len(known) >= 2:
        out["best"], out["worst"] = max(known, key=known.get), min(known, key=known.get)
    return out


# ---------------------------------------------------------------------------------------------
# Textes : « La séance du coach » (pourquoi) et « Le mot du coach » (bloc FEEL)
# ---------------------------------------------------------------------------------------------
def _h(s):
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16)


def _pick(pool, salt, v):
    ok = [t for t in pool if all(v.get(f) not in (None, "") for f in _fields(t))] or [t for t in pool if not _fields(t)]
    return ok[_h(salt) % len(ok)].format_map({k: ("" if x is None else x) for k, x in v.items()}) if ok else ""


def _fields(t):
    import string
    return {f for _, f, _, _ in string.Formatter().parse(t) if f}


def mot(k, x):
    return None if x is None else MOTS[k][max(1, min(5, int(round(x)))) - 1]


def sports_fr(sp):
    L = [SPORT_FR[x] for x in sp if x in SPORT_FR]
    return None if not L else L[0] if len(L) == 1 else ", ".join(L[:-1]) + " et " + L[-1]


def vars_cur(ress):
    c = (ress or {}).get("cur") or {}
    v = {k: (None if c.get(k) is None else str(c[k])) for k in ITEMS}
    st = (ress or {}).get("statut") or {}
    rp = st.get("reprise") or {}
    v.update({"jour": str(st["jour"]) if st.get("jour") else None, "sports": sports_fr(st.get("sports") or []),
              "rj": str(rp["jour"]) if rp else None, "rt": str(rp["total"]) if rp else None, "rvol": f"{rp['pct']} %" if rp else None,
              "rlen": (f"{rp['len']} jour" + ("s" if rp["len"] > 1 else "")) if rp else None,
              "rfrom": {"malade": "ta maladie", "vacances": "tes vacances"}.get(rp.get("from")) if rp else None})
    v.update({"m_" + k: mot(k, c.get(k)) for k in ITEMS})
    v["rpe"] = None if ress.get("rpe") is None else str(ress["rpe"])
    v["dispo"] = dispo_fr(ress.get("dispo"))
    v["cost"] = None if ress.get("cost_pct") is None else f"{ress['cost_pct']:+d} %"
    return v


def dispo_fr(d):
    if d is None: return None
    if d == 0: return "repos"
    if d >= 120: return "2 h et plus"
    return f"{d // 60} h {d % 60:02d}".replace(" 00", "") if d >= 60 else f"{d} min"


def scen_cur(ress, st=None):
    """Scénario principal du soir précédent (ordre de priorité)."""
    fl = set(ress.get("flags") or [])
    if "malade" in fl: return "malade"
    if "vacances" in fl: return "vacances"
    if "reprise" in fl: return "reprise"
    x = ress.get("cross")
    if x == "bas_physio_ok": return "decal_bas"
    if x == "haut_physio_bas": return "decal_haut"
    if "jambes" in fl: return "jambes"
    if "energie" in fl or ("stress" in fl and "motivation" in fl): return "fatigue"
    if "stress" in fl: return "stress"
    if ress.get("hard_yday"): return "dur"
    if "top" in fl: return "top"
    return "moyen"


SEANCE = {
    "malade": ["Malade depuis {jour} jour(s) : récupération et mobilité seulement, on ne force rien.",
               "Tu es toujours malade (jour {jour}) : le corps se défend, on le laisse faire sans lui ajouter de charge."],
    "vacances": ["Vacances (jour {jour}) : séances en {sports} uniquement, volume réduit pour entretenir sans fatiguer.",
                 "En vacances avec {sports} sous la main : on entretient, en version allégée."],
    "reprise": ["Reprise après {rfrom} : jour {rj} sur {rt}, volume à {rvol} et intensité remontée par paliers.",
                "Retour progressif après {rfrom} ({rlen}) : jour {rj} sur {rt}, la séance remonte doucement vers la normale."],
    "decal_bas": ["Hier soir, tu te sentais moins bien que ce que disent tes mesures ({m_energie}, jambes {m_jambes}) : on reste prudent, ton ressenti compte.",
                  "Ta montre te trouve prêt, toi beaucoup moins hier soir : on coupe la poire en deux avec une séance plus douce."],
    "decal_haut": ["Tu te sentais {m_energie} hier soir, mais tes mesures restent basses : on garde l'élan sans brûler les étapes.",
                   "Bon moral hier soir, physiologie encore en retrait : séance tenue, intensité contenue."],
    "jambes": ["Jambes {m_jambes} hier soir ({jambes}/5) : on les épargne, pas d'intensité en course.",
               "Tu as noté des jambes {m_jambes} : la séance du jour les ménage."],
    "fatigue": ["Énergie {m_energie} et tête {m_serenite} hier soir : intensité revue à la baisse.",
                "Fatigue notée hier soir ({energie}/5) : on privilégie une séance qui recharge plutôt qu'une qui creuse."],
    "stress": ["Journée tendue hier ({serenite}/5 en sérénité) : séance qui défoule sans fatiguer davantage.",
               "Stress noté hier soir : l'entraînement reste, mais en version qui détend."],
    "dur": ["Séance d'hier ressentie à {rpe}/10 : place à du plus calme aujourd'hui.",
            "Hier, effort ressenti à {rpe}/10 : la récupération fait partie du plan."],
    "top": ["Feu vert de ton ressenti hier soir ({m_energie}, jambes {m_jambes}) : le plan prévu tient.",
            "Hier soir, tout était au vert de ton côté : on suit le programme."],
    "moyen": ["Ressenti d'hier soir pris en compte : énergie {energie}/5, jambes {jambes}/5.",
              "Ton bilan d'hier soir confirme une forme moyenne : séance mesurée."],
}


def seance_text(ress, D):
    if not ress or not (ress.get("cur") or set(ress.get("flags") or []) & {"malade", "vacances", "reprise"}):
        return ""
    sc = scen_cur(ress)
    return _pick(SEANCE[sc], f"{D}:seance:{sc}", vars_cur(ress))


def statut_line(ress):
    st = (ress or {}).get("statut") or {}
    if st.get("cur") == "malade": return f"Statut : malade depuis {st['jour']} jour(s) (récupération et mobilité seulement)"
    if st.get("cur") == "vacances": return f"Statut : vacances, jour {st['jour']} (" + (("sports possibles : " + sports_fr(st["sports"])) if st.get("sports") else "aucun sport disponible") + ", volume réduit)"
    rp = st.get("reprise")
    if rp: return f"Reprise après {rp['len']} jour(s) {'malade' if rp['from'] == 'malade' else 'de vacances'} : jour {rp['jour']} sur {rp['total']}, volume {rp['pct']} %, intensité plafonnée au niveau {rp['lvl']} sur 5"
    return ""


def context_line(ress):
    c = (ress or {}).get("cur")
    if not c:
        return statut_line(ress)
    bits = [f"{NOM[k]} {c[k]}/5" for k in ITEMS if c.get(k) is not None]
    if c.get("seance") and c.get("rpe"): bits.append(f"effort {c['rpe']}/10")
    elif c.get("seance") is False: bits.append("pas de séance")
    sg = [s for s in c.get("signaux") or [] if s != "malade"]
    if sg: bits.append("signal : " + ", ".join(SIGNAL_FR[s] for s in sg))
    if c.get("dispo") is not None: bits.append("créneau du jour : " + dispo_fr(c["dispo"]))
    sl = statut_line(ress)
    return "Bilan d'hier soir : " + " · ".join(bits) + ((" · " + sl[0].lower() + sl[1:]) if sl else "")


def needs_lines(ress):
    out = []
    st = (ress or {}).get("statut") or {}
    rp = st.get("reprise")
    if rp:
        out.append(f"Reprise : {rp['total']} jours pour revenir à la normale après {rp['len']} jour(s) {'de maladie' if rp['from'] == 'malade' else 'de vacances'} ; "
                   f"aujourd'hui jour {rp['jour']}, volume {rp['pct']} %, " + {2: "endurance seulement.", 3: "endurance active autorisée.", 4: "travail spécifique autorisé, sans séance maximale."}[rp["lvl"]])
    if not ress or not ress.get("cur"):
        return out
    if ress.get("cost") == "haut":
        out.append(f"Charge ressentie : la séance d'hier t'a coûté plus que ne l'indique la montre ({ress['cost_pct']:+d} % par rapport à ta normale).")
    elif ress.get("cost") == "bas":
        out.append("Charge ressentie : la séance d'hier est passée plus facilement que d'habitude pour cette charge, bon signe d'assimilation.")
    if ress.get("cross") == "bas_physio_ok":
        out.append("Ressenti en retrait sur les mesures : fatigue nerveuse ou extra-sportive possible, à surveiller sur deux ou trois soirs.")
    elif ress.get("cross") == "haut_physio_bas":
        out.append("Ressenti meilleur que les mesures : la récupération physiologique n'a pas encore rattrapé le moral.")
    if "douleur" in (ress.get("flags") or []):
        out.append("Douleur signalée hier soir : renseigne-la dans « Douleurs » pour que les séances s'y adaptent précisément.")
    if ress.get("base_n", 0) < BASE_MIN:
        out.append(f"Bilans du soir : {ress.get('base_n', 0) + 1} sur {BASE_MIN + 1} pour établir ta base personnelle ; d'ici là, le ressenti est lu sur l'échelle absolue.")
    return out


# Bloc « FEEL » du mot du coach : 1S = le soir précédent ; 1M et 3M = tendance du ressenti sur la période
FEEL = {
    "malade": ["Toujours malade, {name} (jour {jour}) : aujourd'hui on soigne, l'entraînement attendra que ça passe.",
               "Jour {jour} de maladie : récupération et mobilité, c'est comme ça qu'on revient le plus vite.",
               "Malade depuis {jour} jour(s) : je préfère un {nick} qui récupère deux jours qu'un {nick} qui traîne ça deux semaines.",
               "Ton corps a tiré la sonnette d'alarme et elle sonne encore (jour {jour}) : on l'écoute, point."],
    "vacances": ["Vacances, jour {jour} : {sports} au menu, en version allégée. Profite, l'entretien suffit.",
                 "Tu es en vacances et tu as {sports} sous la main : on entretient sans transformer les congés en stage commando.",
                 "Mode vacances (jour {jour}) : volume réduit, plaisir maximal, {nick}. La reprise sera progressive au retour.",
                 "En vacances avec {sports} pour seul terrain de jeu : c'est largement assez pour garder la forme."],
    "reprise": ["Reprise après {rfrom} : jour {rj} sur {rt}, volume à {rvol}. On remonte par paliers, sans brûler les étapes.",
                "De retour après {rfrom} ({rlen}) : jour {rj} sur {rt} de remise à niveau, ça remonte comme prévu.",
                "Jour {rj} sur {rt} de reprise : le volume est à {rvol}, l'intensité revient au fil des jours, {nick}.",
                "Remise à niveau en cours après {rfrom} : encore quelques jours (jour {rj} sur {rt}) et tu es de retour à plein régime."],
    "decal_bas": ["Hier soir, tu te sentais plus bas que ce que racontent tes mesures : la montre ne voit pas tout, moi je te crois.",
                  "Tes chiffres disent « prêt », ton bilan d'hier soir dit « bof » : quand les deux se contredisent, on choisit la prudence.",
                  "Décalage du jour : physiologie correcte, ressenti à la traîne. Ça arrive avec la fatigue nerveuse, on surveille.",
                  "Ton ressenti d'hier soir est en dessous de tes mesures : un signal faible, mais un signal quand même."],
    "decal_haut": ["Tu te sentais {m_energie} hier soir alors que tes mesures restent en retrait : garde ce moral, mais laisse le corps rattraper.",
                   "Le moral est devant la physiologie, d'après ton bilan d'hier soir : bonne nouvelle, à condition de ne pas en profiter pour forcer.",
                   "Ressenti au vert, mesures à l'orange : on avance, mais en gardant le pied près du frein.",
                   "Hier soir, tu te sentais mieux que ce que dit la montre : on prend l'élan, sans s'emballer."],
    "jambes": ["Jambes {m_jambes} hier soir ({jambes}/5) : elles ont eu leur dose, on les laisse souffler.",
               "Tu as noté des jambes {m_jambes} : pas de fractionné pour elles aujourd'hui, {nick}.",
               "Ton bilan d'hier soir parle de jambes {m_jambes} : je retire l'intensité des séances qui tapent dedans.",
               "Jambes à {jambes}/5 hier soir : la montre ne les sent pas, toi si, et c'est toi qui as raison."],
    "fatigue": ["Énergie à {energie}/5 hier soir : on recharge avant de redemander quoi que ce soit.",
                "Ton bilan d'hier soir sentait la fatigue ({m_energie}) : séance douce, sommeil prioritaire.",
                "Hier soir, réservoir presque vide d'après toi : aujourd'hui on remplit, on ne vide pas.",
                "Fatigue notée hier soir, {nick} : le meilleur entraînement du jour, c'est celui qui te remet d'aplomb."],
    "stress": ["Journée tendue hier d'après ton bilan ({serenite}/5) : une séance qui détend vaut mieux qu'une séance qui épuise.",
               "Le stress d'hier compte aussi dans la charge : on ajuste, sans culpabiliser.",
               "Tête chargée hier soir : le sport sert de soupape aujourd'hui, pas de deuxième source de pression.",
               "Sérénité à {serenite}/5 hier soir : on garde l'entraînement, on retire la pression."],
    "dur": ["Séance d'hier ressentie à {rpe}/10 : ça se paie aujourd'hui, donc on récupère.",
            "Effort ressenti à {rpe}/10 hier : belle séance, la suite logique est plus calme.",
            "Tu as noté {rpe}/10 d'effort hier : l'adaptation se fait au repos, pas pendant la séance.",
            "Hier à {rpe}/10 de ressenti : on encaisse avant de remettre une couche."],
    "top": ["Bilan d'hier soir au vert ({m_energie}, jambes {m_jambes}, {m_motivation}) : de quoi suivre le plan sans retenue.",
            "Tu te sentais {m_energie} hier soir et ça se voit dans tes réponses : on en profite intelligemment.",
            "Ressenti au top hier soir : les planètes s'alignent, {nick}, à toi de jouer.",
            "Hier soir, énergie, jambes et envie au rendez-vous : je n'ai rien à retenir aujourd'hui."],
    "moyen": ["Ton bilan d'hier soir dit « correct, sans plus » : séance mesurée, sans excès.",
              "Ressenti moyen hier soir ({energie}/5 d'énergie) : on avance au rythme de croisière.",
              "Hier soir, rien d'alarmant ni d'exceptionnel dans ton bilan : on reste sur le plan, sans forcer.",
              "Forme ressentie dans la moyenne hier soir : ni frein, ni accélérateur aujourd'hui."],
    "p_up": ["Ton ressenti {win} monte : {fsc}/5 en moyenne sur {fn} soirs, contre {fprev} avant.",
             "Côté ressenti, la courbe grimpe {win} ({fprev} puis {fsc}/5) : le corps suit, et la tête aussi.",
             "Tes bilans du soir sont en progrès {win} : {fsc}/5 de moyenne, ta meilleure note étant {fbest}.",
             "Ressenti en hausse {win} ({fsc}/5 sur {fn} bilans) : c'est souvent le premier signe que la forme arrive."],
    "p_down": ["Ton ressenti {win} baisse : {fsc}/5 en moyenne sur {fn} soirs, contre {fprev} avant ; {fworst} en tête des points faibles.",
               "Les bilans du soir s'essoufflent {win} ({fprev} puis {fsc}/5) : à surveiller avant que les mesures ne suivent.",
               "Ressenti en recul {win}, surtout côté {fworst} : un peu de marge dans la charge ne ferait pas de mal.",
               "{fsc}/5 de ressenti moyen {win}, en baisse : ton corps commence à le dire avant la montre."],
    "p_flat": ["Ressenti stable {win} : {fsc}/5 en moyenne sur {fn} soirs, point fort {fbest}, point faible {fworst}.",
               "Tes bilans du soir tiennent la ligne {win} ({fsc}/5) : régulier, comme tes réponses.",
               "Côté ressenti, rien ne bouge {win} : {fsc}/5 de moyenne, avec {fworst} un cran en dessous.",
               "Ressenti constant {win} ({fsc}/5 sur {fn} bilans) : la charge est encaissée sans à-coups."],
    "p_first": ["Premiers bilans du soir {win} : {fsc}/5 de ressenti moyen sur {fn} soirs, la base se construit.",
                "{fn} bilans du soir {win}, {fsc}/5 en moyenne : encore quelques soirs et je lirai tes écarts à ta propre normale.",
                "Ressenti moyen {win} : {fsc}/5 sur {fn} soirs ; {fbest} va bien, {fworst} un peu moins.",
                "Tes bilans du soir commencent à parler {win} : {fsc}/5 de moyenne, {fbest} en point fort."],
}
FEEL_VARS = {"energie", "jambes", "serenite", "motivation", "m_energie", "m_jambes", "m_serenite", "m_motivation", "rpe", "dispo", "cost",
             "fsc", "fprev", "fn", "fbest", "fworst", "jour", "sports", "rj", "rt", "rvol", "rlen", "rfrom"}


def feel_blocks(key, ress, per):
    """Liste de (scénario, banque, variables) pour bilan_bank.compose (bloc FEEL)."""
    out = []
    try:
        if key == "1S" and ress and (ress.get("cur") or set(ress.get("flags") or []) & {"malade", "vacances", "reprise"}):
            sc = scen_cur(ress)
            out.append((sc, FEEL[sc], vars_cur(ress)))
        elif key != "1S" and per and per.get("n", 0) >= 4 and per.get("score") is not None:
            v = {"fsc": f1(per["score"]), "fprev": None if per.get("prev") is None else f1(per["prev"]), "fn": str(per["n"]),
                 "fbest": NOM.get(per.get("best")), "fworst": NOM.get(per.get("worst"))}
            sc = "p_" + (per["trend"] if per.get("trend") else "first")
            out.append((sc, FEEL[sc], v))
    except Exception:           # noqa: BLE001 : le mot du coach reste disponible sans ce bloc
        return []
    return out


def mobility_pick(ress):
    """(thème, raison) imposé par le bilan d'hier soir, ou None."""
    if not ress:
        return None
    fl = set(ress.get("flags") or [])
    if "malade" in fl: return "recup", "Malade : mobilité douce et respiration, rien de plus."
    if not ress.get("cur"):
        return None
    if ress.get("dispo") == 0: return "recup", "Jour de repos choisi hier soir : 15 minutes de mobilité douce suffisent."
    if "jambes" in fl: return "course", "Jambes lourdes signalées hier soir : on délie mollets, hanches et ischios."
    if "stress" in fl or "energie" in fl: return "recup", "Journée chargée d'après ton bilan d'hier soir : on relâche et on respire."
    return None


def front(entries, ress, periods, T):
    """Données utiles à l'app : dates déjà renseignées (le questionnaire ne revient pas), bilan d'hier, statut à reprendre, tendances par période."""
    last = sorted(entries)[-120:]
    le = entries[last[-1]] if last else None
    stt = (ress or {}).get("statut") or (statut_info(entries, T) if entries else None)
    return {"dates": last, "cur": (ress or {}).get("cur"), "comp": (ress or {}).get("comp"), "flags": (ress or {}).get("flags") or [],
            "last": None if not le else {"date": le["date"], "statut": le.get("statut", "normal"), "sports": le.get("sports") or []},
            "statut": stt,
            "base_n": (ress or {}).get("base_n", 0), "base_min": BASE_MIN, "periods": periods, "srpe": (ress or {}).get("srpe"), "cost": (ress or {}).get("cost")}


# ---------------------------------------------------------------------------------------------
# Rappel de 22 h (send_push.py) : seulement si le bilan du soir n'est pas encore rempli
# ---------------------------------------------------------------------------------------------
RAPPEL_TITRES = ["🔥 Bilan du soir", "🌙 Ton coach t'écoute", "🔥 Trente secondes pour demain", "🌙 Avant de dormir",
                 "🔥 Comment tu te sens ?", "🌙 Le coach prend des notes"]
RAPPEL_TEXTES = ["Énergie, jambes, tête, envie : quatre touches et je cale ta séance de demain.",
                 "Dis-moi comment s'est passée ta journée, je m'occupe de demain.",
                 "Ton ressenti du jour vaut plus que n'importe quelle montre. Trente secondes, promis.",
                 "Combien de temps tu as demain ? Je dimensionne la séance pile pour ce créneau.",
                 "Jambes lourdes ou toutes neuves ? Je dois le savoir pour ajuster demain.",
                 "Le bilan du soir t'attend : sans lui, je planifie demain à l'aveugle."]


def rappel(d):
    """(titre, message) du rappel de 22 h pour la date d : rotation sans répétition d'un jour sur l'autre."""
    k = d.toordinal()
    return RAPPEL_TITRES[k % len(RAPPEL_TITRES)], RAPPEL_TEXTES[(k * 5 + 1) % len(RAPPEL_TEXTES)]
