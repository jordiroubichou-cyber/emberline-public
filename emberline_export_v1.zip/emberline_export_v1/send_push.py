#!/usr/bin/env python3
"""Notifications Emberline : 7 h, 14 h et 21 h (heure de Paris), drôles et toujours différentes ; plus deux rappels :
20 h, la mobilité du jour si elle n'est pas encore faite (MOB_HOUR), et 22 h, le bilan du soir s'il n'est pas rempli (BILAN_HOUR).

Appelé à chaque passage du workflow horaire : n'envoie que si l'heure de Paris est 7 h, 14 h ou 21 h
(réglable avec NOTIF_HOURS, ex. « 7,14,21 »). Les textes viennent de notif_bank.py et tournent sans
répétition : chaque liste est parcourue dans un ordre mélangé, sans repasser par un même texte avant
d'avoir utilisé tous les autres. Titres, messages et relances ont des longueurs différentes, donc
une même combinaison ne revient quasiment jamais.

Données du jour : dist/notif_data.json (écrit par notif_export.py pendant build_dashboard.py).
Abonnements : push_subscriptions.json (bouton « Activer les notifications ») et/ou secret PUSH_SUBSCRIPTION.
Secrets : VAPID_PRIVATE_KEY (obligatoire), VAPID_SUBJECT (défaut mailto:<MAIL_TO>), DASHBOARD_URL.
Usage : python send_push.py [--dist dist] [--slot matin|aprem|soir] [--mobilite] [--test] [--preview N]
Ne fait jamais échouer le workflow."""
import argparse, json, math, os, random, re, string, sys
from datetime import date, datetime, timedelta
from pathlib import Path

import notif_bank as B
import profil as PF
import site_config as SC

PF.load(Path(__file__).resolve().parent)                 # prénom, genre et sports du profil (Paramètres de l'app)

try:
    from zoneinfo import ZoneInfo
    def now_paris(): return datetime.now(ZoneInfo("Europe/Paris"))
except Exception:
    def now_paris(): return datetime.now()

SLOTS = {"matin": B.MATIN, "aprem": B.APREM, "soir": B.SOIR}
EPOCH = date(2026, 1, 1)
SPORT_FR = {"run": "une sortie course", "trail": "un trail", "bike": "une sortie vélo", "swim": "une séance natation",
            "strength": "une séance muscu", "walk": "une marche", "other": "une séance"}


# ---------------------------------------------------------------- rotation sans répétition
def pick(pool, key, n):
    """Élément n° n d'un parcours sans fin de `pool` : chaque tour est un mélange différent (graine = clé + tour),
    et le premier élément d'un tour n'est jamais le dernier du tour précédent."""
    L = len(pool)
    if L == 1:
        return pool[0]
    def order(cycle):
        o = list(range(L)); random.Random(f"{key}|{cycle}").shuffle(o); return o
    cycle, i = divmod(n, L)
    o = order(cycle)
    if cycle > 0 and o[0] == order(cycle - 1)[-1]:
        o[0], o[1] = o[1], o[0]
    return pool[o[i]]


def fields_of(t):
    return {f for _, f, _, _ in string.Formatter().parse(t) if f}


# ---------------------------------------------------------------- données du jour
def fmt_note(x):
    return f"{x:.1f}".replace(".", ",")


def load_data(dist, today):
    d = {}
    try:
        d = json.loads((dist / "notif_data.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        print("Notifications : notif_data.json absent, messages génériques.")
    note = d.get("note")
    note = note if isinstance(note, (int, float)) and math.isfinite(note) else None
    cards = d.get("cards") or []
    acts = [a for a in d.get("acts") or [] if isinstance(a, list) and len(a) == 2]
    done = [s for dd, s in acts if dd == today.isoformat()]
    past = sorted(dd for dd, _ in acts if dd <= today.isoformat())
    jours = (today - date.fromisoformat(past[-1])).days if past else None
    F = {}
    if note is not None:
        F["note"] = fmt_note(note)
        F["label"] = "En feu" if note >= 17 else "Bouillant" if note >= 14 else "Ça chauffe" if note >= 11 else "Tiède" if note >= 8 else "Refroidi"
    if cards:
        c0 = cards[0]
        F["seance"] = (c0.get("title") or "").strip() or None
        F["cat"] = (c0.get("cat") or "").lower() or None
        if len(cards) > 1:
            F["seance"] = f"{F['seance']} (+ {(cards[1].get('title') or '').strip()})" if len(F["seance"] or "") < 45 else F["seance"]
    if isinstance(d.get("week_n"), int):
        F["nb"] = str(d["week_n"])
    if isinstance(d.get("week_km"), (int, float)):
        F["km"] = f"{d['week_km']:.0f}"
    if done:
        uniq = list(dict.fromkeys(done))
        F["fait"] = " + ".join(SPORT_FR.get(s, "une séance") for s in uniq[:2])
    if jours is not None and jours >= 1:
        F["jours"] = str(jours)
    F = {k: v for k, v in F.items() if v}
    return F, {"nodata": not d, "note": note, "cards": bool(cards), "pain": bool(d.get("pain")), "fresh": bool(d.get("fresh")),
               "done": bool(done), "jours": jours}


def context(slot, info, n):
    if info.get("nodata"):
        return "neutre" if slot == "matin" else "afaire"
    if slot == "matin":
        if info["fresh"]: return "datee"
        if not info["cards"]: return "repos"
        if info["pain"] and n % 2 == 0: return "douleur"           # un jour sur deux quand une douleur est active
        s = info["note"]
        if s is None: return "neutre"
        return "feu" if s >= 17 else "bouillant" if s >= 14 else "chauffe" if s >= 11 else "tiede" if s >= 8 else "froid"
    if slot == "aprem":
        if info["done"]: return "fait"
        return "afaire" if info["cards"] else "repos"
    if info["done"]: return "fait"
    if (info["jours"] or 0) >= 3: return "flemme"
    return "afaire"


def compose(slot, F, info, n):
    ctx = context(slot, info, n)
    pool = [t for t in SLOTS[slot][ctx] if fields_of(t) <= F.keys()]
    if not pool:                                                    # données manquantes : textes sans champ
        ctx = "neutre" if slot == "matin" else ("afaire" if slot != "soir" else "afaire")
        pool = [t for t in SLOTS[slot].get(ctx, []) if not fields_of(t)] or ["Ton bilan du jour est prêt. Ton coach t'attend dans l'app."]
    body = pick(pool, f"{slot}.{ctx}", n).format(**F)
    body = body[:1].upper() + body[1:]
    if len(body) < 150:
        body += " " + pick(B.RELANCES[slot], f"{slot}.relance", n)
    title = pick(B.TITRES[slot], f"{slot}.titre", n)
    return title, body, ctx


# ---------------------------------------------------------------- envoi
def load_subs(path):
    subs, sources = [], []
    raw = os.environ.get("PUSH_SUBSCRIPTION", "").strip()
    if raw: sources.append(("secret PUSH_SUBSCRIPTION", raw))
    if path.exists(): sources.append((str(path), path.read_text(encoding="utf-8")))
    for name, txt in sources:
        try:
            data = json.loads(txt)
        except ValueError:
            print(f"Notifications : {name} illisible (JSON invalide), ignoré."); continue
        for s in (data if isinstance(data, list) else [data]):
            if isinstance(s, dict) and s.get("endpoint") and (s.get("keys") or {}).get("p256dh"):
                subs.append({"endpoint": s["endpoint"], "keys": s["keys"]})
    return list({s["endpoint"]: s for s in subs}.values())


def send(title, body, tag, hash_=""):
    title, body = PF.text(title), PF.text(body)              # prénom du profil, accords au féminin si besoin
    key = SC.vapid_private(Path(__file__).resolve().parent)         # clé privée (secret GitHub, sinon emberline.json)
    if not key:
        print("Notifications : clé privée VAPID absente (secret VAPID_PRIVATE_KEY ou emberline.json), rien envoyé."); return
    if "BEGIN" in key:                                          # clé PEM : pywebpush la charge le plus sûrement depuis un fichier
        import tempfile
        tf = tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False); tf.write(key); tf.close(); key = tf.name
    subs = load_subs(Path(os.environ.get("PUSH_SUBS_FILE", "push_subscriptions.json")))
    if not subs:
        print("Notifications : aucun appareil abonné (bouton « Activer les notifications » dans l'app), rien envoyé."); return
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        print("Notifications : module pywebpush manquant (pip install pywebpush)."); return
    subject = SC.vapid_subject(Path(__file__).resolve().parent) or ("mailto:" + os.environ.get("MAIL_TO", "").strip())
    if subject in ("", "mailto:"):
        subject = "mailto:emberline@example.org"             # une adresse de contact est exigée par le protocole, mais n'est pas utilisée pour t'écrire
    payload = json.dumps({"title": title, "body": body, "url": (os.environ.get("DASHBOARD_URL", "") or "./") + hash_, "tag": tag}, ensure_ascii=False)
    ok = 0
    for s in subs:
        host = re.sub(r"^https?://([^/]+).*", r"\1", s["endpoint"])
        try:
            webpush(subscription_info=s, data=payload, vapid_private_key=key, vapid_claims={"sub": subject},
                    ttl=6 * 3600, headers={"Urgency": "high"}, timeout=30)
            ok += 1
        except WebPushException as e:
            code = getattr(e.response, "status_code", None)
            print(f"Notification refusée par {host} ({code})" + (" : abonnement expiré, réactive les notifications dans l'app." if code in (404, 410) else ""))
        except Exception as e:
            print(f"Notification non envoyée ({host}) : {type(e).__name__} : {e}")
    print(f"Notifications : {ok}/{len(subs)} appareil(s).")


def mobilite(now, dist, n, force=False):
    """20 h (MOB_HOUR) : rappel de la mobilité du jour, sauf si elle est déjà faite. (titre, message) ou None."""
    if not PF.ok("mob"):                                     # mobilité décochée dans Paramètres : pas de rappel
        return None
    try:
        if not force and now.hour != int(os.environ.get("MOB_HOUR", "20")):
            return None
        try:
            d = json.loads((Path(dist) / "notif_data.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        m = d.get("mob") or {}
        if m.get("done") and not force:
            print("Notifications : mobilité du jour déjà faite, pas de rappel.")
            return None
        today = now.date().isoformat()
        done = [s for dd, s in (d.get("acts") or []) if dd == today and s not in ("other", None)]
        F = {}
        if m.get("title"): F["mob"] = "« " + m["title"].strip() + " »"
        F["cible"] = B.MOB_CIBLE.get(m.get("key") or "", "tout ton corps")
        if done: F["fait"] = " + ".join(SPORT_FR.get(s, "une séance") for s in list(dict.fromkeys(done))[:2])
        st = d.get("statut")
        ctx = "malade" if st == "malade" else "vacances" if st == "vacances" else "seance" if done else "repos"
        pool = [t for t in B.MOBILITE[ctx] if fields_of(t) <= F.keys()] or [t for t in B.MOBILITE["repos"] if fields_of(t) <= F.keys()]
        body = pick(pool, f"mob.{ctx}", n).format(**F)
        if len(body) < 95:
            body += " " + pick(B.MOB_RELANCES, "mob.relance", n)
        return pick(B.MOB_TITRES, "mob.titre", n), body
    except Exception as e:          # noqa: BLE001 : jamais bloquant
        print(f"Rappel de mobilité ignoré ({type(e).__name__} : {e}).")
        return None


def bilan_du_soir(now):
    """22 h (BILAN_HOUR) : rappel du bilan du soir, seulement s'il n'est pas encore rempli dans ressenti.json. None sinon."""
    try:
        if now.hour != int(os.environ.get("BILAN_HOUR", "22")):
            return None
        import ressenti
        entries, _ = ressenti.load(Path(__file__).resolve().parent)
        return None if now.date().isoformat() in entries else ressenti.rappel(now.date())
    except Exception as e:          # noqa: BLE001 : jamais bloquant
        print(f"Rappel du bilan du soir ignoré ({type(e).__name__} : {e}).")
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dist", type=Path, default=Path("dist"))
    ap.add_argument("--slot", choices=list(SLOTS), help="force un créneau (sinon : selon l'heure de Paris)")
    ap.add_argument("--test", action="store_true", help="envoie tout de suite un message du créneau le plus proche")
    ap.add_argument("--mobilite", action="store_true", help="envoie tout de suite le rappel de mobilité (avec --test : préfixe [Test])")
    ap.add_argument("--preview", type=int, default=0, help="affiche les messages des N prochains jours, sans rien envoyer")
    a = ap.parse_args()
    now = now_paris(); today = now.date()
    hours = [int(h) for h in re.findall(r"\d+", os.environ.get("NOTIF_HOURS", "7,14,21"))][:3] or [7, 14, 21]
    by_hour = dict(zip(hours, SLOTS))                               # 1re heure = matin, 2e = après-midi, 3e = soir
    F, info = load_data(a.dist, today)

    if a.preview:
        for k in range(a.preview):
            n = (today - EPOCH).days + k
            for sl in SLOTS:
                t, b, c = compose(sl, F, info, n)
                print(f"J+{k} {sl:5} [{c}] {t} | {b}")
            r = mobilite(now, a.dist, n, force=True)
            if r: print(f"J+{k} mob   {r[0]} | {r[1]}")
        return

    if a.mobilite:
        r = mobilite(now, a.dist, (today - EPOCH).days, force=True)
        if r:
            print(f"Notifications : rappel de mobilité · {r[0]} · {r[1]}")
            send(("[Test] " if a.test else "") + r[0], r[1], "emberline-mobilite", "#mob")
        return

    slot = a.slot
    if not slot and a.test:
        slot = min(by_hour.items(), key=lambda kv: abs(kv[0] - now.hour))[1]
    if not slot:
        slot = by_hour.get(now.hour)
    if not slot and not a.test:
        r = mobilite(now, a.dist, (today - EPOCH).days)
        if r:
            print(f"Notifications : rappel de mobilité · {r[0]} · {r[1]}")
            send(r[0], r[1], "emberline-mobilite", "#mob")
            return
        r = bilan_du_soir(now)
        if r:
            print(f"Notifications : rappel du bilan du soir · {r[0]} · {r[1]}")
            send(r[0], r[1], "emberline-bilan")
            return
    if not slot:
        print(f"Notifications : {now:%H:%M} à Paris, pas une heure de notification ({', '.join(f'{h} h' for h in hours)}).")
        return
    n = (today - EPOCH).days
    title, body, ctx = compose(slot, F, info, n)
    if a.test:
        title = "[Test] " + title
    print(f"Notifications : créneau {slot} ({ctx}) · {title} · {body}")
    send(title, body, f"emberline-{slot}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Notifications : erreur inattendue ({type(e).__name__} : {e}).")
    sys.exit(0)
