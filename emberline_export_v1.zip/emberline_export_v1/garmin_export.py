#!/usr/bin/env python3
"""Envoie des entraînements Emberline sur Garmin Connect et les programme dans le calendrier (ils arrivent sur la montre
à sa prochaine synchronisation). Lancé par le workflow « Export Garmin » quand on appuie sur « Envoyer à Garmin » dans le dashboard.

Usage : python garmin_export.py --keys run,swim [--date 2026-11-08] [--dry-run]
  clés : run, swim, bike, strength-push, strength-pull, strength-legs, coach (= séance du coach du jour),
         strength:<push|pull|legs>:<n> (une séance précise du programme de musculation).
Les entraînements sont lus dans garmin/workouts/<date du jour>/ (générés à chaque mise à jour du dashboard) ;
s'ils manquent, ils sont recalculés à partir des données du dépôt.
Code de sortie 1 si au moins un envoi échoue (le dashboard affiche alors l'erreur)."""
import argparse
import json, os, re, sys
from datetime import date, datetime, timedelta
from pathlib import Path

import garmin_workouts as GW

HERE = Path(__file__).resolve().parent
ROOT = HERE / "garmin" / "workouts"
try:
    from zoneinfo import ZoneInfo
    TODAY = datetime.now(ZoneInfo("Europe/Paris")).date()
except Exception:
    TODAY = date.today()


def log(msg):
    print(msg, flush=True)
    s = os.environ.get("GITHUB_STEP_SUMMARY")
    if s:
        with open(s, "a", encoding="utf-8") as f:
            f.write(msg + "\n\n")


# ------------------------------------------------------------------ séances à envoyer
_A = None


def analysis():
    """Recalcule l'analyse du jour (même code que build_dashboard.py), seulement si un fichier manque."""
    global _A
    if _A is None:
        import config, goals as goals_mod, pain as pain_mod, coach_memory, plan_adapt
        from analysis import build_analysis
        from garmin_data import load_all
        src = HERE / "garmin"
        acts, days, _ = load_all(src)
        try:
            meta = json.loads((src / "sync_status.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            meta = {}
        G, _, _ = goals_mod.load_goals(HERE, config.GOALS)
        P, _ = pain_mod.load(HERE)
        _A = build_analysis(acts, days, TODAY.isoformat(), G, config.ATHLETE, config.PERIODS, events=getattr(config, "EVENTS", []),
                            meta=meta, coach_mem=coach_memory.load(src / "coach_memory.json"), pains=P,
                            plan_mem=plan_adapt.load(src / "plan_memory.json"))
    return _A


def resolve(keys):
    """Liste de (clé, entraînement)."""
    day = ROOT / TODAY.isoformat()
    man = {}
    try:
        man = json.loads((day / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    out = []
    for k in keys:
        if k == "coach":
            ck = man.get("coach") or GW.coach_keys(analysis())
            out += resolve(ck)
            continue
        m = re.fullmatch(r"strength:(push|pull|legs):(\d+)", k)
        if m:
            M = analysis()["suggest"]["muscu"]; T = M["types"][m.group(1)]; n = int(m.group(2))
            if T["today_n"] == n and (day / f"strength-{m.group(1)}.json").exists():
                k = f"strength-{m.group(1)}"
            else:
                out.append((k, GW.from_strength(T, T["sessions"][n - 1])))
                continue
        f = day / f"{k}.json"
        if f.exists():
            out.append((k, json.loads(f.read_text(encoding="utf-8"))))
            continue
        W = GW.build(analysis())
        if k not in W:
            raise SystemExit(f"Séance inconnue : {k}")
        out.append((k, W[k]))
    return out


# ------------------------------------------------------------------ Garmin Connect
def api(client, path, method="GET", payload=None):
    """Appel brut à l'API Garmin Connect, compatible avec les versions récentes de garminconnect
    (transport client.client._run_request(méthode, chemin)) et les anciennes (client.garth.connectapi)."""
    kw = {"json": payload} if payload is not None else {}
    t = getattr(client, "client", None)
    if t is not None and hasattr(t, "_run_request"):                 # garminconnect récent
        r = t._run_request(method, path, **kw)
        if r is None or getattr(r, "status_code", 200) == 204 or not getattr(r, "content", b"x"):
            return None
        try:
            return r.json()
        except ValueError:
            return None
    g = getattr(client, "garth", None)
    if g is not None and hasattr(g, "connectapi"):                   # anciennes versions (garth)
        return g.connectapi(path, method=method, **kw)
    if method == "GET":
        return client.connectapi(path)
    raise RuntimeError("version de garminconnect non prise en charge pour l'envoi d'entraînements")


def clean_old(client, names):
    """Supprime les entraînements Emberline du même nom (renvoi de la même séance) et ceux de plus de 14 jours."""
    try:
        lst = api(client, "/workout-service/workouts?start=0&limit=200", method="GET") or []
    except Exception as e:
        log(f"Liste des entraînements indisponible ({type(e).__name__}) : pas de nettoyage.")
        return
    if isinstance(lst, dict):
        lst = lst.get("workouts") or []
    limit = datetime.now() - timedelta(days=14)
    n = 0
    for w in lst:
        name = str(w.get("workoutName", ""))
        if not name.startswith(GW.PREFIX):
            continue
        created = str(w.get("createdDate") or w.get("updateDate") or "")[:10]
        old = bool(re.fullmatch(r"\d{4}-\d\d-\d\d", created)) and datetime.fromisoformat(created) < limit
        if name in names or old:
            try:
                api(client, f"/workout-service/workout/{w['workoutId']}", method="DELETE"); n += 1
            except Exception:
                pass
    if n:
        log(f"Nettoyage : {n} ancien(s) entraînement(s) Emberline supprimé(s).")


SENT = Path("garmin") / "workouts" / "sent.json"


def remember(wid, when, key, w):
    """Identifiant Garmin de l'entraînement envoyé -> date et séance prévues (rapprochement exact avec l'activité faite,
    qui porte cet identifiant : associatedWorkoutId). 60 jours conservés."""
    try:
        d = json.loads(SENT.read_text(encoding="utf-8")) if SENT.exists() else {}
    except (OSError, ValueError):
        d = {}
    d[str(wid)] = {"d": when, "k": key, "name": str(w.get("workoutName") or "")[len(GW.PREFIX):],
                   "s": {"running": "run", "cycling": "bike", "swimming": "swim", "strength_training": "strength"}.get((w.get("sportType") or {}).get("sportTypeKey"), "")}
    lim = (datetime.fromisoformat(when) - timedelta(days=60)).date().isoformat()
    d = {k: v for k, v in d.items() if v.get("d", "") >= lim}
    try:
        SENT.parent.mkdir(parents=True, exist_ok=True); SENT.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def send(client, w, when):
    res = api(client, "/workout-service/workout", method="POST", payload=w) or {}
    wid = res.get("workoutId")
    if not wid:
        raise RuntimeError(f"réponse inattendue de Garmin : {str(res)[:200]}")
    api(client, f"/workout-service/schedule/{wid}", method="POST", payload={"date": when})
    return wid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--keys", required=True)
    ap.add_argument("--date", default="")
    ap.add_argument("--dry-run", action="store_true", help="prépare et affiche les entraînements sans rien envoyer")
    a = ap.parse_args()
    when = a.date or TODAY.isoformat()
    if not re.fullmatch(r"\d{4}-\d\d-\d\d", when):
        raise SystemExit("Date invalide (format AAAA-MM-JJ).")
    keys = [k.strip() for k in re.split(r"[,\s]+", a.keys) if k.strip()]
    items = resolve(keys)
    if not items:
        raise SystemExit("Aucune séance à envoyer.")
    for k, w in items:
        log(f"**{w['workoutName']}** ({w['sportType']['sportTypeKey']}) : " + " | ".join(GW.summary(w)))
    if a.dry_run:
        log("Mode test : rien n'a été envoyé.")
        return
    from sync_garmin import get_client
    client = get_client()
    clean_old(client, {w["workoutName"] for _, w in items})
    bad = 0
    for k, w in items:
        try:
            wid = send(client, w, when)
            remember(wid, when, k, w)
            log(f"✓ {w['workoutName']} envoyé et programmé le {when} (id {wid}).")
        except Exception as e:
            bad += 1
            body = ""
            r = getattr(e, "response", None) or getattr(getattr(e, "error", None), "response", None)
            if r is not None:
                try: body = r.text[:300]
                except Exception: pass
            log(f"✗ {w['workoutName']} : {type(e).__name__} : {e} {body}")
    if bad:
        sys.exit(1)
    log("Synchronise ta montre (ou ouvre Garmin Connect) : la séance apparaît dans le calendrier du jour.")


if __name__ == "__main__":
    main()
