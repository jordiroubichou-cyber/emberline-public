"""Analyse des données d'entraînement : 100 % déterministe (aucune IA, aucun appel externe, bibliothèque standard).

Même date + mêmes données = exactement la même sortie.

Sections :
  1. Constantes et seuils ajustables (TH, W_STRAIN)
  2. Helpers
  3. Statistiques par période
  4. Prédictions de temps et allures cibles
  5. Piliers et note /20 (fenêtre de 28 jours, et par période 1S/1M/3M : pillars_period)
  6. Corrélations
  7. État physiologique : axes (VFC, sommeil, charge, stress/Body Battery, 3 derniers jours),
     indice de fatigue (strain_index), plafonds, facteur d'ajustement de forme (FAF), diagnostic, cas croisés
  8. Synthèses par période
  9. Entraînement du jour : choix de la discipline et de la séance, modulation par le FAF ;
     musculation = 30 séances Push/Pull/Legs (ppl_program.py), FAF propre à chaque type selon la veille
 10. Fonction principale build_analysis()

Les textes viennent de phrases_bank.py et les séances de sessions_library.py.

FORMULES (transparentes) :
  * Chaque axe produit un score de disponibilité c dans [0, 1] (1 = frais). Axes absents : ignorés, poids renormalisés.
  * ready = somme(poids x c) / somme(poids) avec W_STRAIN ; strain_index = round(100 x (1 - ready)).
  * FAF = clamp(0,5 + 0,65 x ready, 0,5, 1,15), puis plafonné par les règles de veto (VFC très basse, ACWR > 1,5, ...).
  * Sans données exploitables (moins de 2 axes) : profil données_insuffisantes et FAF par défaut prudent.
"""
import math
import re
from datetime import date, timedelta

import bilan_bank as BB
import pain as PAIN
import muscu_pain as MP
import petit_plus as PP_LIB
import phrases_bank as PB
import plan_adapt as PA
import planner as PLN
import preparation as PREP
import coach_memory as CM
import coach_croise as CC
import extras as EX
import profil as PF
import ressenti as RS
import ppl_program as PPL
import sessions_library as SL
import zones_forme as ZF

# =============================================================================================
# 1. CONSTANTES ET SEUILS AJUSTABLES
# =============================================================================================
SPORTS = ["run", "trail", "bike", "swim", "strength", "walk", "other"]
SPORT_FR = {"run": "Course", "trail": "Trail", "bike": "Vélo", "swim": "Natation",
            "strength": "Musculation", "walk": "Marche", "other": "Autre"}
PLAB = {"1S": "1 semaine glissante", "1M": "1 mois glissant", "3M": "3 mois glissants"}

TH = dict(
    acwr_low=0.8, acwr_mid=1.3, acwr_high=1.5,                      # zones du ratio aigu/chronique (7 j / 28 j)
    hrv_hi=1.03, hrv_lo=0.92, hrv_vlo=0.85, hrv_vlo_today=0.80,     # VFC / base : haute, basse, très basse
    sleep_poor_score=55, sleep_poor_h=5.5, sleep_target_h=7.5,      # sommeil
    sleep_debt_warn=1.5, sleep_debt_cap=3.0,                        # dette de sommeil sur 3 nuits (h)
    stress_high=60, bb_low=35, bb_vlow=25, bb_charge_low=40,        # stress moyen et Body Battery
    readiness_vlow=30, readiness_low=45,                            # score de readiness Garmin
    deep_low_pct=13, rem_low_pct=20,                                # repères du sommeil profond et du REM (% de la nuit)
    strain_acute=70, strain_incomplete=50, strain_fresh=30,         # seuils de l'indice de fatigue
    faf_min=0.5, faf_max=1.15, faf_default=0.85,                    # bornes du facteur d'ajustement de forme
    hard_share_high=30, hard_share_low=10,                          # part du temps de course en qualité sur 21 jours (%)
    long_gap_days=10, aero_vol_ratio_min=0.7,                       # déficit aérobie : sortie longue, volume / cible
)
W_STRAIN = {"hrv": 0.30, "sleep": 0.25, "load": 0.25, "sb": 0.0, "recent": 0.20, "feel": 0.55}   # feel : bilan du soir (ressenti.py), absent = ignoré ;
# révision v5 : le ressenti pèse ≈ 35 % de l'indice quand il est renseigné (les mesures subjectives réagissent mieux que les marqueurs objectifs,
# Saw et al. 2016) ; stress et Body Battery (algorithmes Garmin qui recomptent VFC, sommeil et charge) sont affichés mais ne comptent plus.
FAF_BANDS = [(1.0, "haut", "Plein régime"), (0.85, "normal", "Normal"), (0.7, "prudent", "Prudent"), (0.0, "recup", "Récupération")]
FAM_LVL = {"recup": 1, "z2": 2, "aerobe": 3, "vo2": 5, "spec": 4, "trail": 3, "force": 3, "gainage": 2, "plyo": 3, "mobilite": 1, "long": 3, "taper": 2, "brick": 4}
DISC_FR = {"run": "Course à pied", "swim": "Natation", "bike": "Vélo", "strength": "Musculation"}


# =============================================================================================
# 1 bis. ROBUSTESSE : fraîcheur des données, recalage des seuils, fiabilité des prédictions, repères
# =============================================================================================
TH_DEFAULT = dict(TH)          # seuils d'origine : recalés sur ton historique à chaque génération (calibrate)

def pctl(xs, q):
    xs = sorted(xs)
    if not xs: return None
    k = (len(xs) - 1) * q
    lo, hi = int(math.floor(k)), int(math.ceil(k))
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)

def calibrate(days, T):
    """Recale quelques seuils sur TON historique (percentiles personnels) quand il y a assez de données ; sinon valeurs par défaut.
    Les seuils sont remis à leurs valeurs d'origine avant chaque calcul : résultat déterministe."""
    TH.clear(); TH.update(TH_DEFAULT)
    info = {"calibrated": False, "lines": [], "n_hrv": 0, "n_sleep": 0}
    cl = lambda v, a, b: max(a, min(b, v))
    iso_T = T.isoformat()
    ds = sorted(d for d in days if d <= iso_T)
    hv = [(d, days[d].get("hrv")) for d in ds if days[d].get("hrv")]
    ratios = []
    for i, (d, v) in enumerate(hv):
        prev = [x for dd, x in hv[:i] if (date.fromisoformat(d) - date.fromisoformat(dd)).days <= 60]
        if len(prev) >= 14: ratios.append(v / mean(prev))
    info["n_hrv"] = len(ratios)
    if len(ratios) >= 25:
        lo_ = cl(round(pctl(ratios, 0.15), 2), 0.88, 0.95)
        TH["hrv_lo"] = lo_
        TH["hrv_vlo"] = cl(round(pctl(ratios, 0.05), 2), 0.80, min(0.88, lo_ - 0.03))
        TH["hrv_hi"] = cl(round(pctl(ratios, 0.80), 2), 1.02, 1.08)
        info["lines"].append(f"VFC « basse » sous {TH['hrv_lo'] * 100:.0f} % de ta base (réglage d'origine : {TH_DEFAULT['hrv_lo'] * 100:.0f} %), « haute » au-dessus de {TH['hrv_hi'] * 100:.0f} %")
    sc = [days[d]["sc"] for d in ds if days[d].get("sc")]
    info["n_sleep"] = len(sc)
    if len(sc) >= 25:
        TH["sleep_poor_score"] = int(cl(round(pctl(sc, 0.15)), 50, 65))
        info["lines"].append(f"Sommeil « mauvais » sous {TH['sleep_poor_score']}/100 (d'origine : {TH_DEFAULT['sleep_poor_score']})")
    lo28 = (T - timedelta(days=28)).isoformat()
    sh28 = [days[d]["sh"] for d in ds if d >= lo28 and days[d].get("sh")]
    if len(sh28) >= 14:                                    # v5 (audit I3) : besoin de sommeil individuel, pas de cible unique (Walsh et al. 2021)
        TH["sleep_target_h"] = round(cl(sum(sh28) / len(sh28), 6.5, 8.0), 2)
        info["lines"].append(f"Sommeil de référence : {f1(TH['sleep_target_h'])} h, ta moyenne des 28 dernières nuits (d'origine : {f1(TH_DEFAULT['sleep_target_h'])} h pour tous)")
    stv = [days[d]["st"] for d in ds if days[d].get("st")]
    if len(stv) >= 25:
        TH["stress_high"] = int(cl(round(pctl(stv, 0.85)), 45, 65))
        info["lines"].append(f"Stress « élevé » au-dessus de {TH['stress_high']} (d'origine : {TH_DEFAULT['stress_high']})")
    tr = [days[d]["tr"] for d in ds if days[d].get("tr")]
    if len(tr) >= 25:
        TH["readiness_low"] = int(cl(round(pctl(tr, 0.20)), 35, 55)); TH["readiness_vlow"] = max(20, TH["readiness_low"] - 15)
        info["lines"].append(f"Readiness « basse » sous {TH['readiness_low']} (d'origine : {TH_DEFAULT['readiness_low']})")
    info["calibrated"] = bool(info["lines"])
    return info

def data_freshness(acts, days, T, meta=None):
    """Âge des dernières données (récupération, activités) et état de la dernière synchronisation."""
    meta = meta or {}
    wd = [d for d, v in days.items() if any(v.get(k) is not None for k in ("hrv", "sc", "rhr", "bbx", "st", "tr")) and d <= T.isoformat()]
    lw = max(wd) if wd else None
    la = max((x["d"] for x in acts if x["d"] <= T.isoformat()), default=None)
    age_w = None if lw is None else max(0, (T - date.fromisoformat(lw)).days)
    age_a = None if la is None else max(0, (T - date.fromisoformat(la)).days)
    sync_age = None
    if meta.get("synced_at"):
        try: sync_age = max(0, (T - date.fromisoformat(str(meta["synced_at"])[:10])).days)
        except ValueError: sync_age = None
    sync_ok = meta.get("ok", True) is not False
    level = None
    if age_w is None or age_w >= 4 or (sync_age is not None and sync_age >= 4): level = "alert"
    elif age_w >= 2 or (sync_age is not None and sync_age >= 2) or not sync_ok: level = "warn"
    msg = None
    if level:
        bits = []
        if age_w is None: bits.append("aucune donnée de récupération (sommeil, VFC…) n'a été trouvée")
        elif age_w >= 2: bits.append(f"dernières données de récupération : {date.fromisoformat(lw).strftime('%d/%m/%Y')} ({age_w} jours)")
        if sync_age is not None and sync_age >= 2: bits.append(f"dernière synchronisation Garmin réussie il y a {sync_age} jours")
        if not sync_ok: bits.append("la dernière synchronisation était incomplète" + (f" ({meta['reason']})" if meta.get("reason") else "") + " : les données précédentes ont été conservées")
        msg = "Attention, données datées : " + " · ".join(bits) + ". Les analyses ci-dessous peuvent être en retard sur la réalité."
    return {"level": level, "message": msg, "last_wellness": lw, "age_wellness": age_w, "last_activity": la, "age_activity": age_a,
            "sync_age": sync_age, "sync_ok": sync_ok}

RACE_RE = re.compile(r"course|race|corrida|\b10 ?k\b|semi|marathon|dossard|compet|trail", re.I)

def prediction_check(acts, T, goals):
    """Compare ce que la prédiction annonçait la veille d'une course (10 km, semi, marathon) au temps réellement couru."""
    iso_T = T.isoformat()
    a_sorted = sorted(acts, key=lambda x: x["d"])
    first = a_sorted[0]["d"] if a_sorted else iso_T
    items = []
    for x in a_sorted:
        if x["s"] != "run" or x["d"] >= iso_T or not (x["m"] > 0 and x["km"] > 0): continue
        for key, label, D, dmin, dmax in DISTS:
            if abs(x["km"] - D) / D > 0.04: continue
            if x.get("multi") or not (x.get("race") or ZF.RACE_NAME_RE.search(x["nm"] or "")): continue
            prior = [a for a in a_sorted if a["d"] < x["d"]]
            if len(prior) < 8 or (date.fromisoformat(x["d"]) - date.fromisoformat(first)).days < 42: continue
            vo2 = next((a["vo2"] for a in reversed(prior) if a["vo2"]), None)
            pr = next((r for r in predictions(prior, date.fromisoformat(x["d"]) - timedelta(days=1), goals, vo2) if r["key"] == key), None)
            if not pr or not pr["ret"]: continue
            actual = x["m"] * 60 * (D / x["km"]) ** 1.06          # ramené à la distance exacte
            items.append({"date": x["d"], "label": label, "name": x["nm"] or label, "actual": actual, "pred": pr["ret"],
                          "err": (actual - pr["ret"]) / pr["ret"] * 100})
            break
    items = items[-6:]
    if not items:
        return {"n": 0, "bias": None, "items": [], "note": "Aucune course de référence détectée (10 km, semi ou marathon nommé « 10 km », « semi », « marathon »… ou saisi dans config.RACES)."}
    bias = sum(i["err"] for i in items) / len(items)
    verdict = ("bien calibrées" if abs(bias) < 1.5 else f"trop optimistes de {abs(bias):.1f} % en moyenne" if bias > 0 else f"trop prudentes de {abs(bias):.1f} % en moyenne").replace(".", ",")
    return {"n": len(items), "bias": bias, "items": items, "note": f"Sur {len(items)} course(s) de référence, les prédictions de la veille étaient {verdict}."}

def build_events(cfg_events, pcheck, T):
    """Repères affichés sur les graphiques : événements de config.py (vacances, blessure…) + courses détectées."""
    out = []
    for e in (cfg_events or []):
        try:
            d = date.fromisoformat(str(e["date"])[:10])
        except (KeyError, ValueError, TypeError):
            continue
        if (T - d).days < 0 or (T - d).days > 400: continue
        out.append({"date": d.isoformat(), "label": str(e.get("label", "Repère"))[:24], "kind": e.get("kind", "autre")})
    for i in (pcheck or {}).get("items", []):
        if (T - date.fromisoformat(i["date"])).days <= 400:
            out.append({"date": i["date"], "label": f"Course {i['label']}", "kind": "course"})
    return sorted(out, key=lambda e: e["date"])


# =============================================================================================
# 2. HELPERS
# =============================================================================================
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))

def mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None

def f1(x, n=1): return f"{x:.{n}f}".replace(".", ",")

def hms(s):
    s = int(round(s)); h, r = divmod(s, 3600); m, sec = divmod(r, 60)
    return f"{h}h{m:02d}'{sec:02d}" if h else f"{m}'{sec:02d}"

def pace(p):
    """allure en min/km (float) -> 4'12"""
    if not p: return "–"
    m = int(p); s = int(round((p - m) * 60))
    if s == 60: m, s = m + 1, 0
    return f"{m}'{s:02d}"

def pct(a, b): return None if not b else (a - b) / b * 100

def sgn(v, n=0): return "" if v is None else f"{v:+.{n}f} %".replace(".", ",")

def wavg(parts):
    """parts = [(poids, valeur|None)] -> moyenne pondérée des valeurs disponibles"""
    p = [(w, v) for w, v in parts if v is not None]
    return sum(w * v for w, v in p) / sum(w for w, _ in p) if p else None

def slope(pts):
    """pente de la régression linéaire (x, y)"""
    n = len(pts)
    if n < 3: return None
    mx = sum(p[0] for p in pts) / n; my = sum(p[1] for p in pts) / n
    sxx = sum((p[0] - mx) ** 2 for p in pts)
    return sum((p[0] - mx) * (p[1] - my) for p in pts) / sxx if sxx else None

def _series(days, T, key, n, off=0):
    """valeurs de `key` sur n jours se terminant à T - off (du plus ancien au plus récent), None si absent"""
    return [days.get((T - timedelta(days=off + i)).isoformat(), {}).get(key) for i in range(n - 1, -1, -1)]

def _last(days, T, key, back=3):
    for i in range(back):
        v = days.get((T - timedelta(days=i)).isoformat(), {}).get(key)
        if v is not None: return v
    return None


# =============================================================================================
# 3. STATISTIQUES PAR PÉRIODE
# =============================================================================================
def acwr(acts, d_end):
    """Ratio de charge aiguë (7 j) / chronique (28 j). None si l'historique ne couvre pas 28 jours (ratio non fiable)."""
    T = date.fromisoformat(d_end)
    if not acts or (T - date.fromisoformat(min(a["d"] for a in acts))).days < 27: return None
    dl = {}
    for a in acts: dl[a["d"]] = dl.get(a["d"], 0) + a["ld"]
    day = lambda i: (T - timedelta(days=i)).isoformat()
    s7 = sum(dl.get(day(i), 0) for i in range(7)); s28 = sum(dl.get(day(i), 0) for i in range(28))
    return (s7 / 7) / (s28 / 28) if s28 > 0 else None

def rec_mean(days, T, n, key, off=0):
    return mean(_series(days, T, key, n, off))

REC_KEYS = ("sc", "sh", "hrv", "rhr", "bbx", "bbn", "tr", "st", "stp", "deep", "rem")

def period_stats(acts, days, T, n, off=0):
    a = (T - timedelta(days=off + n - 1)).isoformat(); b = (T - timedelta(days=off)).isoformat()
    L = [x for x in acts if a <= x["d"] <= b]
    S = {"n": len(L), "h": sum(x["m"] for x in L) / 60, "ld": sum(x["ld"] for x in L), "sp": {}}
    for s in SPORTS:
        Ls = [x for x in L if x["s"] == s]
        S["sp"][s] = {"n": len(Ls), "h": sum(x["m"] for x in Ls) / 60, "km": sum(x["km"] for x in Ls),
                      "el": sum(x["el"] for x in Ls), "ld": sum(x["ld"] for x in Ls),
                      "pw": mean([x["pw"] for x in Ls if x["pw"]])}
    runs = [x for x in L if x["s"] in ("run", "trail")]
    km = sum(x["km"] for x in runs); mn = sum(x["m"] for x in runs)
    efr = [x for x in runs if x["s"] == "run" and x["hr"] and x["km"] >= 3 and x["m"] > 0]
    hrr = [x for x in runs if x["hr"] and x["m"] > 0]
    S["run"] = {"n": len(runs), "km": km, "h": mn / 60, "pace": (mn / km if km else None),
                "el": sum(x["el"] for x in runs), "longest": max([x["km"] for x in runs] or [0]),
                "hr": (sum(x["hr"] * x["m"] for x in hrr) / sum(x["m"] for x in hrr)) if hrr else None,
                "ef": (sum(x["km"] * 1000 for x in efr) / sum(x["hr"] * x["m"] for x in efr)) if efr else None,
                "ld": sum(x["ld"] for x in runs)}
    S["rec"] = {k: rec_mean(days, T, n, k, off) for k in REC_KEYS}
    S["acwr"] = acwr(acts, b)
    return S


# =============================================================================================
# 4. PRÉDICTIONS ET ALLURES CIBLES
# =============================================================================================
def daniels_time(vdot, D_km):
    """Temps (s) pour une distance donnée à partir d'une VO2max (équations de Daniels)."""
    D = D_km * 1000
    def f(t):
        v = D / t
        vo2 = -4.60 + 0.182258 * v + 0.000104 * v * v
        pc = 0.8 + 0.1894393 * math.exp(-0.012778 * t) + 0.2989558 * math.exp(-0.1932605 * t)
        return vo2 / pc - vdot
    lo, hi = 5.0, 900.0
    if f(lo) < 0 or f(hi) > 0: return None
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if f(mid) > 0 else (lo, mid)
    return (lo + hi) / 2 * 60

DISTS = [("10k", "10 km", 10.0, 5, 25), ("semi", "Semi-marathon", 21.0975, 8, 30), ("marathon", "Marathon", 42.195, 10, 35)]

def predictions(acts, T, goals, vo2, span=None, ath=None):
    """Révision v5 (audit C3) : une seule méthode, affichée en fourchette.
    Forme actuelle (zones_forme.fitness) : course récente, sinon relation FC-allure lue à ta FC seuil, sinon VO2max de la montre corrigée ;
    puis passage aux autres distances avec un exposant de Riegel augmenté quand le volume et la sortie longue sont faibles.
    Clés conservées pour l'affichage : riegel = borne basse, daniels = borne haute, ret = temps retenu. span est ignoré : la forme
    se mesure à la date du jour (la note par période garde la même estimation)."""
    goals = [g for g in goals if g.get("sport", "run") == "run"]      # seuls les objectifs de course à pied fixent un temps cible
    fit = ZF.fitness(acts, T, ath, vo2)
    km4, long42 = ZF.volume_markers(acts, T)
    out = []
    for key, label, D, dmin, dmax in DISTS:
        pr = ZF.predict(fit, D, km4, long42)
        out.append({"key": key, "label": label, "dist": D, "riegel": pr["lo"] if pr else None, "daniels": pr["hi"] if pr else None,
                    "ret": pr["t"] if pr else None, "lo": pr["lo"] if pr else None, "hi": pr["hi"] if pr else None, "k": pr["k"] if pr else None,
                    "target": None, "gap": None, "src": fit.get("label") if fit.get("t10") else None, "method": fit.get("src")})
    up = [g for g in goals if g.get("date") is None or str(g["date"])[:10] >= T.isoformat()]
    for r in out:
        r["target"] = next((g["target_s"] for g in up if abs(g["dist"] - r["dist"]) < 0.5 and g["target_s"]), None)
        r["gap"] = (r["ret"] - r["target"]) if (r["ret"] and r["target"]) else None
    if out:
        out[0]["fit"] = {"thr": fit.get("thr"), "src": fit.get("src"), "unc": fit.get("unc"), "km4": round(km4, 1), "long42": round(long42, 1)}
    return out

def zones(preds, goals, fit=None, ath=None):
    """Révision v5 (audit I2) : zones cardiaques ancrées sur la FC seuil (Friel) et allures tirées de ta forme actuelle,
    pas de ton objectif. Les allures d'objectif restent affichées à part, comme repère à atteindre."""
    goals = [g for g in goals if g.get("sport", "run") == "run"]
    anc = ZF.anchors(ath)
    hz = {z["z"]: z for z in ZF.run_hr_zones(anc)}
    rp = ZF.run_paces(fit) if fit else None
    from_fit = bool(rp)
    def p_goal(key):
        r = next((x for x in preds if x["key"] == key), None)
        return (r["target"] / 60 / r["dist"]) if r and r["target"] else None
    g10, gm = p_goal("10k"), p_goal("marathon")
    if not rp:                                                        # aucune mesure de forme : repli sur les objectifs (ancien comportement)
        p10 = g10 or (gm * (10 / 42.195) ** -0.06 if gm else None)
        if not p10: return None
        pm = gm or p10 * (42.195 / 10) ** 0.06
        rp = {"easy": (pm + 50 / 60, pm + 80 / 60), "mar": pm, "semi": p10 * (21.0975 / 10) ** 0.06, "thr": p10 * 1.03, "p10": p10, "vma": p10 - 12 / 60}
    fc = lambda a, b: f"FC {hz[a]['lo'] or ''}{'–' if hz[a]['lo'] else '< '}{hz[b]['hi']}"
    rm = next((x for x in preds if x["key"] == "marathon" and x.get("ret")), None)
    if rm and from_fit:                                               # v5 : même allure marathon que la prédiction (volume et sortie longue compris)
        rp = dict(rp, mar_pot=rp["mar"], mar=rm["ret"] / 60 / rm["dist"])
    e0, e1 = rp["easy"]
    lst = [{"n": "Récupération", "p": f"plus lent que {pace(e1)} · FC < {hz['Z1']['hi']}", "u": "décrassage, lendemain de séance dure"},
           {"n": "Endurance fondamentale", "p": f"{pace(e0)}–{pace(e1)} · FC {hz['Z2']['lo']}–{hz['Z2']['hi']}", "u": "footings, sortie longue, volume (≈ 80 % du temps)"},
           {"n": "Allure marathon (actuelle)", "p": f"{pace(rp['mar'])} · FC {hz['Z3']['lo']}–{hz['Z3']['hi']}",
            "u": "blocs spécifiques marathon" + (f" ; {pace(rp['mar_pot'])} atteignable avec le volume et les sorties longues d'une prépa" if rp.get("mar_pot") and rp["mar_pot"] < rp["mar"] - 3 / 60 else "")},
           {"n": "Seuil", "p": f"{pace(rp['thr'])} · FC {hz['Z4']['lo']}–{hz['Z4']['hi']}", "u": "tempo, 3 × 10', 4 × 2000 m"},
           {"n": "Allure 10 km (actuelle)", "p": f"{pace(rp['p10'])} · FC {hz['Z5a']['lo']}–{hz['Z5a']['hi']}", "u": "séances spécifiques 10 km"},
           {"n": "VMA / intervalles courts", "p": f"{pace(rp['vma'])} · FC > {hz['Z5b']['lo']}", "u": "200–600 m, 30/30"}]
    goal_txt = " · ".join(x for x in (f"10 km {pace(g10)}" if g10 else "", f"marathon {pace(gm)}" if gm else "") if x)
    return {"p10": rp["p10"], "semi": rp["semi"], "mar": rp["mar"], "thr": rp["thr"], "easy": rp["easy"], "vma": rp["vma"],
            "goal10": g10, "goalm": gm, "goal_txt": goal_txt, "hr": hz, "anc": anc, "src": (fit or {}).get("label") if from_fit else None, "list": lst}


# =============================================================================================
# 5. PILIERS ET NOTE /20
# =============================================================================================
def score_label(v):
    return "Excellent" if v >= 17 else "Très bon" if v >= 14 else "Solide" if v >= 11 else "À consolider" if v >= 8 else "À reconstruire"

def score_tone(v):
    """Couleur unique de la note /20, alignée sur score_label : Très bon et + = vert, À consolider / Solide = orange, sinon rouge."""
    return "gray" if v is None else "green" if v >= 14 else "orange" if v >= 8 else "red"

def pillar_tone(v):
    return "gray" if v is None else "green" if v >= 3 else "orange" if v >= 2 else "red"

def sleep_comp(sc, sh, deep_pct, rem_pct):
    """Disponibilité liée au sommeil, 0..1 : score (55 %), durée (30 %), phases profond/REM (15 %)."""
    stages = mean([clamp(deep_pct / TH["deep_low_pct"]) if deep_pct is not None else None,
                   clamp(rem_pct / TH["rem_low_pct"]) if rem_pct is not None else None])
    return wavg([(0.55, clamp((sc - 50) / 40) if sc is not None else None),
                 (0.30, clamp((sh - 5.5) / 2.5) if sh else None), (0.15, stages)])

def stage_pcts(deep, rem, sh):
    if not sh: return None, None
    return (deep / (sh * 60) * 100 if deep else None), (rem / (sh * 60) * 100 if rem else None)

PREP_PRIO_W = {"A": 1.0, "B": 0.6, "C": 0.3}


def prep_weight(o):
    """Poids d'un objectif dans le pilier : priorité (A principal, B intermédiaire, C préparatoire) x proximité de l'échéance."""
    return PREP_PRIO_W.get(o.get("prio"), 0.5) / (1 + max(o.get("days_left", 0), 0) / 60.0)


def prep_lead(prep):
    """Objectif qui pèse le plus dans le pilier (variables des phrases du coach) : nom, jours restants en toutes lettres, score /100."""
    ok = [o for o in (prep or []) if o.get("score") is not None]
    if not ok: return None
    o = max(ok, key=lambda x: (prep_weight(x), -x["days_left"]))
    dl = o["days_left"]
    short = re.split(r" (?:de|du|des|d') ?", o["name"].strip(), maxsplit=1)[0] or o["name"]      # « Marathon de Biarritz » -> « Marathon » : phrase plus naturelle et moins répétitive
    return {"oname": short, "odays": "quelques heures" if dl <= 0 else "1 jour" if dl == 1 else f"{dl} jours", "oscore": str(o["score"])}


def prep_pillar(prep):
    """Pilier « Préparation aux objectifs » : moyenne des états de préparation (preparation.evaluer : performance estimée et volume,
    fatigue dont le poids grandit à l'approche de la course) pondérée par la priorité et la proximité de chaque objectif.
    Même note que le paragraphe « Préparation aux objectifs » (0-100 ramené à /4), indépendante de la période choisie."""
    ok = [o for o in (prep or []) if o.get("score") is not None]
    if not prep:
        return {"key": "pred", "name": "Préparation aux objectifs", "score": None, "lines": ["Aucun objectif à venir : pilier non noté (ajoute un objectif avec « Objectifs »)"]}
    if not ok:
        return {"key": "pred", "name": "Préparation aux objectifs", "score": None, "lines": ["Pas assez d'activités récentes pour évaluer la préparation : pilier non noté"]}
    ws = [prep_weight(o) for o in ok]
    score = sum(w * o["score"] for w, o in zip(ws, ok)) / sum(ws) / 100.0 * 4
    lines = []
    for o in sorted(ok, key=lambda x: x["days_left"])[:4]:
        det = []
        if o.get("perf") is not None: det.append(f"performance {o['perf']}/100")
        if o.get("form") is not None: det.append(f"forme {o['form']}/100 (" + (f"pèse {round(o['w_form'] * 100)} % du score" if o["w_form"] > 0 else "sans effet pour l'instant") + ")")
        lines.append(f"{o['name']} · {o['date_fr']} (J-{o['days_left']}, {o.get('role') or 'objectif'}) : {o['score']}/100, {o['label'].lower()}" + (f" — {', '.join(det)}" if det else ""))
    if len(ok) > 1: lines.append("Pondération : les objectifs prioritaires et proches de l'échéance pèsent davantage")
    return {"key": "pred", "name": "Préparation aux objectifs", "score": score, "lines": lines}


def load_pillar(acts, T, wl, cv, n):
    """Pilier « Charge d'entraînement » (v5) : répartition de l'intensité en course (part du temps en facile, repère 75-80 %),
    forme d'entraînement (charge des 42 derniers jours face aux 7 derniers) et régularité des semaines. Le ratio aigu/chronique
    n'entre plus dans la note (métrique très critiquée, Impellizzeri et al. 2020)."""
    sp = ZF.intensity_split(acts, T, n=n)
    tid = None if not sp else clamp((sp["easy"] - 0.50) / 0.25)
    fm = form_balance(acts, T)
    fs = None if fm is None else clamp(1 - max(0.0, abs(fm - (-0.05)) - 0.15) / 0.30)
    lsc = wavg([(.45, tid), (.30, fs), (.25, clamp(1 - cv / 0.4) if cv is not None else None)])
    lines = [(f"Répartition de l'intensité en course : {sp['easy'] * 100:.0f} % facile, {sp['grey'] * 100:.0f} % zone grise, {sp['hard'] * 100:.0f} % dur "
              f"(repère : 75-80 % facile)") if sp else "Répartition de l'intensité : pas assez de sorties",
             f"Forme d'entraînement : {fm * 100:+.0f} % (charge 42 j face aux 7 derniers jours ; repère -20 à +10 %)" if fm is not None else "Forme d'entraînement : historique insuffisant",
             f"Charge par semaine ({len(wl)} dernière(s)) : {', '.join(f'{v:.0f}' for v in wl[::-1])}",
             f"Régularité de la charge : {'n/a' if cv is None else f'variation {cv * 100:.0f} %'}"]
    if sp and sp["n_fast_easy"]:
        lines.append(f"{sp['n_fast_easy']} sortie(s) « endurance » courue(s) trop vite (au-dessus de {ZF.anchors()['lthr_run'] * 90 // 100} bpm)")
    return {"key": "load", "name": "Charge d'entraînement", "score": None if lsc is None else 4 * lsc, "lines": lines}


def form_balance(acts, T):
    """(CTL - ATL) / CTL : moyennes exponentielles de la charge sur 42 et 7 jours (modèle forme-fatigue de Banister).
    Négatif = fatigue récente au-dessus de l'habitude. None si moins de 28 jours d'historique."""
    if not acts: return None
    first = date.fromisoformat(min(a["d"] for a in acts))
    if (T - first).days < 27: return None
    dl = {}
    for a in acts: dl[a["d"]] = dl.get(a["d"], 0) + (a.get("ld") or 0)
    seed = sum(dl.get((first + timedelta(days=i)).isoformat(), 0.0) for i in range(28)) / 28.0
    atl = ctl = seed                                         # amorçage sur la moyenne des 28 premiers jours : pas de fausse fatigue en début d'historique
    d = first
    while d <= T:
        v = dl.get(d.isoformat(), 0.0)
        atl += (v - atl) * (1 - math.exp(-1 / 7)); ctl += (v - ctl) * (1 - math.exp(-1 / 42))
        d += timedelta(days=1)
    return None if ctl <= 0 else (ctl - atl) / ctl


def _cplt(sw, cw, div, ath):
    """Pilier « complémentaire » sur 4 : musculation, croisé (vélo, natation) et diversité ; une discipline non pratiquée
    (Paramètres) sort du calcul et les autres sont repondérées."""
    P = [(.4, clamp(sw / ath["strength_per_week"])) if ath.get("strength_per_week") else None,
         (.4, clamp(cw / ath["cross_per_week"])) if ath.get("cross_per_week") else None, (.2, div)]
    P = [x for x in P if x]
    return 4 * sum(w * v for w, v in P) / sum(w for w, _ in P)


def pillars(acts, days, T, goals, ath, preds, vo2, prep=None):
    iso = lambda n: (T - timedelta(days=n)).isoformat()
    S28 = period_stats(acts, days, T, 28)
    runs = [x for x in acts if x["s"] in ("run", "trail")]
    P = []
    P.append(prep_pillar(prep))
    km4 = S28["run"]["km"] / 4
    reg = sum(1 for i in range(4) if len([x for x in runs if iso(7 * i + 6) <= x["d"] <= iso(7 * i)]) >= 3) / 4
    long6 = max([x["km"] for x in runs if x["d"] >= iso(41)] or [0])
    sc = wavg([(.35, clamp(km4 / ath["weekly_km_target"])), (.2, reg), (.25, clamp(long6 / ath["long_run_target_km"])),
               (.2, clamp((vo2 - 45) / 12) if vo2 else None)])
    est = " · ".join(f"{r['label'].replace('Semi-marathon', 'Semi')} {hms(r['ret'])}" for r in preds if r["ret"])
    P.append({"key": "run", "name": "Progrès en course à pied", "score": None if sc is None else 4 * sc,
              "lines": [f"Volume : {f1(km4)} km/sem sur 4 semaines (cible {ath['weekly_km_target']})",
                        f"Régularité : {int(reg * 4)}/4 semaines avec au moins 3 sorties",
                        f"Sortie longue max (6 sem.) : {f1(long6)} km (cible {ath['long_run_target_km']})",
                        f"VO2max : {vo2:.0f}" if vo2 else "VO2max : n/a", f"Temps estimés : {est}" if est else "Temps estimés : n/a"]})
    ac = S28["acwr"]
    acs = None if ac is None else clamp(1 if TH["acwr_low"] <= ac <= TH["acwr_mid"] else (ac - 0.5) / 0.3 if ac < TH["acwr_low"] else (1.8 - ac) / 0.5)
    wl = [sum(x["ld"] for x in acts if iso(7 * i + 6) <= x["d"] <= iso(7 * i)) for i in range(4)]
    m = mean(wl); cv = (math.sqrt(sum((v - m) ** 2 for v in wl) / 4) / m) if m else None
    lsc = wavg([(.7, acs), (.3, clamp(1 - cv / 0.4) if cv is not None else None)])
    P.append({"key": "load", "name": "Charge d'entraînement", "score": None if lsc is None else 4 * lsc,
              "lines": [f"Ratio aigu/chronique : {f1(ac, 2)} (zone idéale 0,8–1,3)" if ac else "Ratio aigu/chronique : n/a",
                        f"Charge des 4 dernières semaines : {', '.join(f'{v:.0f}' for v in wl[::-1])}",
                        f"Régularité de la charge : {'n/a' if cv is None else f'variation {cv * 100:.0f} %'}"]})
    r14 = period_stats(acts, days, T, 14)["rec"]
    hb = rec_mean(days, T, 60, "hrv", 14); rb = rec_mean(days, T, 60, "rhr", 14)
    hrvr = r14["hrv"] / hb if r14["hrv"] and hb else None
    rhrd = r14["rhr"] - rb if r14["rhr"] is not None and rb is not None else None
    dp, rp = stage_pcts(r14["deep"], r14["rem"], r14["sh"])
    slp = sleep_comp(r14["sc"], r14["sh"], dp, rp)
    rs = wavg([(1, slp), (1, clamp((hrvr - 0.85) / 0.15) if hrvr else None), (1, clamp(1 - rhrd / 6) if rhrd is not None else None)])      # Body Battery et readiness : affichés seulement (v5)
    rl = [f"Sommeil : {r14['sc']:.0f}/100, {f1(r14['sh'])} h" if r14["sc"] is not None and r14["sh"] else "Sommeil : n/a"]
    if dp is not None and rp is not None: rl.append(f"Phases : profond {dp:.0f} % · REM {rp:.0f} % de la nuit")
    rl += [f"VFC : {r14['hrv']:.0f} ms ({(hrvr - 1) * 100:+.0f} % vs base 60 j)" if hrvr else "VFC : n/a",
           f"FC repos : {r14['rhr']:.0f} bpm ({'stable' if abs(rhrd) < 0.5 else f'{rhrd:+.1f}'.replace('.', ',')} vs base)" if rhrd is not None else "FC repos : n/a",
           f"Body Battery max : {r14['bbx']:.0f} · Readiness : {r14['tr']:.0f}" if r14["bbx"] and r14["tr"] else "Body Battery / Readiness : n/a"]
    P.append({"key": "rec", "name": "Récupération et état physique", "score": None if rs is None else 4 * rs, "lines": rl})
    sw = S28["sp"]["strength"]["n"] / 4; cw = (S28["sp"]["bike"]["n"] + S28["sp"]["swim"]["n"]) / 4
    div = sum(1 for s in ("run", "bike", "swim", "strength") if S28["sp"][s]["n"] > 0 or (s == "run" and S28["sp"]["trail"]["n"] > 0)) / 4
    P.append({"key": "cross", "name": "Musculation, multisport et cross-training",
              "score": _cplt(sw, cw, div, ath),
              "lines": [f"Musculation : {f1(sw)} séance(s)/sem (cible {ath['strength_per_week']})",
                        f"Vélo + natation : {f1(cw)} séance(s)/sem (cible {f1(ath['cross_per_week'])})",
                        f"Disciplines pratiquées sur 28 jours : {int(div * 4)}/4"]})
    ctx = {"km4": km4, "reg": reg, "long6": long6, "acwr": ac, "hrvr": hrvr, "rhrd": rhrd, "r14": r14}
    return P, ctx

def pillars_period(acts, days, T, goals, ath, vo2_all, n, prep=None, ress=None):
    """Mêmes 5 piliers, calculés sur une période glissante de n jours (7, 30 ou 90) : la note /20 évolue avec la période.
    Volume et sorties/semaine ramenés à la semaine, ratio de charge moyenné sur la période, base VFC/FC repos = 60 jours AVANT la période."""
    iso = lambda k: (T - timedelta(days=k)).isoformat()
    S = period_stats(acts, days, T, n)
    W, nb = n / 7.0, max(1, min(12, n // 7))
    win = [x for x in acts if iso(n - 1) <= x["d"] <= iso(0)]
    runs = [x for x in win if x["s"] in ("run", "trail")]
    vo2 = next((x["vo2"] for x in reversed(win) if x["vo2"]), None) or vo2_all
    preds = predictions(acts, T, goals, vo2, span=n, ath=ath)
    P = [prep_pillar(prep)]
    kmw = S["run"]["km"] / W
    reg = sum(1 for i in range(nb) if len([x for x in runs if iso(7 * i + 6) <= x["d"] <= iso(7 * i)]) >= 3) / nb
    long_ = max([x["km"] for x in runs] or [0])
    sc = wavg([(.35, clamp(kmw / ath["weekly_km_target"])), (.2, reg), (.25, clamp(long_ / ath["long_run_target_km"])),
               (.2, clamp((vo2 - 45) / 12) if vo2 else None)])
    est = " · ".join(f"{r['label'].replace('Semi-marathon', 'Semi')} {hms(r['ret'])}" for r in preds if r["ret"])
    P.append({"key": "run", "name": "Progrès en course à pied", "score": None if sc is None else 4 * sc,
              "lines": [f"Volume : {f1(kmw)} km/sem sur la période (cible {ath['weekly_km_target']})",
                        f"Régularité : {int(round(reg * nb))}/{nb} semaine(s) avec au moins 3 sorties",
                        f"Sortie la plus longue : {f1(long_)} km (cible {ath['long_run_target_km']})",
                        f"VO2max : {vo2:.0f}" if vo2 else "VO2max : n/a", f"Temps estimés : {est}" if est else "Temps estimés : n/a"]})
    ac = mean([acwr(acts, iso(k)) for k in range(0, n, 1 if n <= 30 else 3)])          # valeur descriptive (affichage), hors calcul de la note
    wl = [sum(x["ld"] for x in acts if iso(7 * i + 6) <= x["d"] <= iso(7 * i)) for i in range(nb)]
    m = mean(wl); cv = (math.sqrt(sum((v - m) ** 2 for v in wl) / len(wl)) / m) if (m and len(wl) >= 2) else None
    P.append(load_pillar(acts, T, wl, cv, max(n, 14)))
    r_ = S["rec"]
    hb = rec_mean(days, T, 60, "hrv", n) or rec_mean(days, T, max(60, n), "hrv")
    rb = rec_mean(days, T, 60, "rhr", n) or rec_mean(days, T, max(60, n), "rhr")
    hrvr = r_["hrv"] / hb if r_["hrv"] and hb else None
    rhrd = r_["rhr"] - rb if r_["rhr"] is not None and rb is not None else None
    dp, rp = stage_pcts(r_["deep"], r_["rem"], r_["sh"])
    slp = sleep_comp(r_["sc"], r_["sh"], dp, rp)
    rper = RS.period(ress, T, n) if ress else None          # bilans du soir de la période (au moins 4) : le ressenti compte pour ≈ 35 %
    feel = (rper["score"] - 1) / 4 if (rper and rper["n"] >= 4 and rper["score"] is not None) else None
    rs = wavg([(1, slp), (1, clamp((hrvr - 0.85) / 0.15) if hrvr else None), (1, clamp(1 - rhrd / 6) if rhrd is not None else None),
               (1.6, feel)])      # v5 : le ressenti pèse ≈ 35 % ; Body Battery et readiness sont affichés mais ne comptent plus
    rl = [f"Sommeil : {r_['sc']:.0f}/100, {f1(r_['sh'])} h" if r_["sc"] is not None and r_["sh"] else "Sommeil : n/a"]
    if dp is not None and rp is not None: rl.append(f"Phases : profond {dp:.0f} % · REM {rp:.0f} % de la nuit")
    rl += [f"VFC : {r_['hrv']:.0f} ms ({(hrvr - 1) * 100:+.0f} % vs base 60 j)" if hrvr else "VFC : n/a",
           f"FC repos : {r_['rhr']:.0f} bpm ({'stable' if abs(rhrd) < 0.5 else f'{rhrd:+.1f}'.replace('.', ',')} vs base)" if rhrd is not None else "FC repos : n/a",
           f"Body Battery max : {r_['bbx']:.0f} · Readiness : {r_['tr']:.0f}" if r_["bbx"] and r_["tr"] else "Body Battery / Readiness : n/a"]
    if feel is not None: rl.append(f"Ressenti du soir : {f1(rper['score'])}/5 en moyenne ({rper['n']} bilans)")
    P.append({"key": "rec", "name": "Récupération et état physique", "score": None if rs is None else 4 * rs, "lines": rl})
    sw = S["sp"]["strength"]["n"] / W; cw = (S["sp"]["bike"]["n"] + S["sp"]["swim"]["n"]) / W
    div = sum(1 for s_ in ("run", "bike", "swim", "strength") if S["sp"][s_]["n"] > 0 or (s_ == "run" and S["sp"]["trail"]["n"] > 0)) / 4
    P.append({"key": "cross", "name": "Musculation, multisport et cross-training",
              "score": _cplt(sw, cw, div, ath),
              "lines": [f"Musculation : {f1(sw)} séance(s)/sem (cible {ath['strength_per_week']})",
                        f"Vélo + natation : {f1(cw)} séance(s)/sem (cible {f1(ath['cross_per_week'])})",
                        f"Disciplines pratiquées sur la période : {int(div * 4)}/4"]})
    ok = [p["score"] for p in P if p["score"] is not None]
    total = sum(ok) / (4 * len(ok)) * 20 if ok else None
    for p_ in P: p_["tone"] = pillar_tone(p_["score"])
    return {"score": total, "label": score_label(total) if total is not None else "", "tone": score_tone(total), "n_scored": len(ok), "pillars": P,
            "acwr_mean": ac, "form": form_balance(acts, T), "hrvr": hrvr, "rhrd": rhrd, "preds": preds, "prep_lead": prep_lead(prep)}      # valeurs de la période, réutilisées par synthesis()


# =============================================================================================
# 6. CORRÉLATIONS
# =============================================================================================
def pearson(xs, ys):
    pts = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    n = len(pts)
    if n < 10: return None, n
    mx = sum(p[0] for p in pts) / n; my = sum(p[1] for p in pts) / n
    sxx = sum((p[0] - mx) ** 2 for p in pts); syy = sum((p[1] - my) ** 2 for p in pts)
    sxy = sum((p[0] - mx) * (p[1] - my) for p in pts)
    if sxx == 0 or syy == 0: return None, n
    return sxy / math.sqrt(sxx * syy), n

def correlations(acts, days, T):
    ds = [(T - timedelta(days=i)).isoformat() for i in range(89, -1, -1)]
    dl = {}
    for a in acts: dl[a["d"]] = dl.get(a["d"], 0) + a["ld"]
    prev = lambda d, k=1: (date.fromisoformat(d) - timedelta(days=k)).isoformat()
    g = lambda d, k: days.get(d, {}).get(k)
    load1 = lambda d: dl.get(prev(d), 0) if (prev(d) in dl or d in days) else None
    load3 = lambda d: sum(dl.get(prev(d, k), 0) for k in (1, 2, 3))
    defs = [("Charge de la veille", "VFC de la nuit", [load1(d) for d in ds], [g(d, "hrv") for d in ds], "neg",
             "la VFC baisse après les grosses journées d'entraînement", "la VFC ne baisse pas après les grosses journées : bonne tolérance à la charge"),
            ("Charge de la veille", "score de sommeil", [load1(d) for d in ds], [g(d, "sc") for d in ds], "neg",
             "le sommeil se dégrade après les grosses charges", "le sommeil résiste aux grosses charges"),
            ("Charge des 3 derniers jours", "readiness", [load3(d) for d in ds], [g(d, "tr") for d in ds], "neg",
             "la readiness baisse quand la charge s'accumule", "la readiness reste stable malgré la charge"),
            ("Score de sommeil", "readiness du lendemain", [g(prev(d), "sc") for d in ds], [g(d, "tr") for d in ds], "pos",
             "une bonne nuit se traduit par une meilleure readiness le lendemain", "la readiness dépend peu du sommeil de la veille"),
            ("Sommeil profond", "VFC de la nuit", [g(d, "deep") for d in ds], [g(d, "hrv") for d in ds], "pos",
             "plus de sommeil profond va avec une VFC plus haute", "la VFC dépend peu du sommeil profond"),
            ("Stress moyen de la veille", "VFC de la nuit", [g(prev(d), "st") for d in ds], [g(d, "hrv") for d in ds], "neg",
             "un stress élevé la veille réduit la VFC", "le stress de la veille pèse peu sur la VFC")]
    out = []
    for a, b, xs, ys, sign, txt_hit, txt_no in defs:
        r, n = pearson(xs, ys)
        if r is None: continue
        strength = "net" if abs(r) >= 0.5 else "modéré" if abs(r) >= 0.3 else "faible"
        expected = (r < 0) if sign == "neg" else (r > 0)
        rs = f"{r:.2f}".replace(".", ",")
        out.append({"a": a, "b": b, "r": round(r, 2), "n": n, "strength": strength,
                    "text": (f"{txt_hit} (lien {strength}, r = {rs}, {n} jours)." if abs(r) >= 0.3 and expected
                             else f"{txt_no} (lien {strength}, r = {rs}, {n} jours)." if abs(r) < 0.3
                             else f"relation inattendue entre {a.lower()} et {b} (r = {rs}, {n} jours) : à surveiller.")})
    return out


# =============================================================================================
# 7. ÉTAT PHYSIOLOGIQUE : axes, strain_index, FAF, diagnostic, cas croisés
# =============================================================================================
ANA_RE, PCT_VMA_RE, TEMPO_RE = ZF.ANA_RE, ZF.PCT_VMA_RE, ZF.TEMPO_RE        # reconnaissance commune (zones_forme.py), 30"/30" compris
LEGS_RE = re.compile(r"jambe|leg|squat|cuisse|fessier|mollet", re.I)

def run_kind(x):
    """easy / long / tempo / ana : d'abord la structure réelle (séries détaillées, v6), sinon le nom, la FC et la distance."""
    xd = x.get("x") or {}
    st = xd.get("st") or {}
    if st.get("kind") == "intervals":
        return "ana" if (st.get("rep_t") or 999) <= 150 else "tempo"
    z = xd.get("zones")
    if z and sum(z) > 0 and (z[3] + z[4]) >= 1200: return "tempo"            # ≥ 20 min en zones 4-5 : séance de qualité
    nm = x.get("nm") or ""
    if PCT_VMA_RE.search(nm): return "tempo"
    if ANA_RE.search(nm): return "ana"
    if TEMPO_RE.search(nm): return "tempo"
    k = ZF.run_class(x)
    if k == "hard": return "tempo"                       # dure sans structure (FC ≥ 95 % de la FC seuil) : comptée comme séance de qualité
    if x["km"] >= 16: return "long"
    return "easy"

def intensity(a):
    """facile / modéré / dur pour une séance (toutes disciplines)."""
    xd = a.get("x") or {}
    if (a.get("cmp") or {}).get("code") == "harder" and a["s"] in ("run", "trail", "bike", "swim"): return "dur"   # plus intense que prévu
    z = xd.get("zones")
    if z and sum(z) >= 600 and a["s"] in ("run", "trail", "bike", "swim"):
        hi = z[3] + z[4]
        if (xd.get("st") or {}).get("kind") == "intervals" or hi >= 900: return "dur"
        if hi >= 300 or z[2] >= 1200: return "modéré"
        if a["s"] != "trail" and a["m"] < 100: return "facile"
    if a["s"] in ("run", "trail"):                       # v5 : nature de la sortie d'après la FC seuil, plus d'après le Training Effect
        k = ZF.run_class(a)
        if k in ("struct", "hard") or (k == "long" and a["km"] >= 20): return "dur"
        if k in ("grey", "long"): return "modéré"
        return "facile"
    anc = ZF.anchors()
    if a["s"] == "bike" and a.get("hr"):
        if (a["hr"] >= 0.92 * anc["lthr_bike"] and a["m"] >= 30) or a["ld"] >= 180: return "dur"
        if a["hr"] >= 0.84 * anc["lthr_bike"] or a["ld"] >= 90: return "modéré"
        return "facile"
    if a["ld"] >= 150 or (a.get("te") or 0) >= 4.2: return "dur"
    if a["ld"] >= 70 or (a.get("te") or 0) >= 3.0: return "modéré"
    return "facile"

def leg_stress(a):
    """séance qui sollicite fortement les jambes (impact ou charge musculaire)"""
    xd = a.get("x") or {}
    if a["s"] == "strength" and (xd.get("str") or {}).get("groups"):
        return (xd["str"]["groups"].get("legs") or 0) >= 4            # séries réellement faites sur les jambes (v6)
    if a["s"] in ("run", "trail") and ((xd.get("trail") or {}).get("dn") or 0) >= 500: return True   # descente : charge excentrique
    if a["s"] in ("run", "trail"): return run_kind(a) != "easy" or a["km"] >= 12
    if a["s"] == "bike": return a["ld"] >= 120
    if a["s"] == "strength": return bool(LEGS_RE.search(a.get("nm") or ""))
    return False

def hrv_axis(days, T):
    """VFC du jour vs base (moyenne des jours T-66 à T-7), tendance sur 7 jours et pente."""
    cur = _last(days, T, "hrv", 2)
    base_vals = [v for v in _series(days, T, "hrv", 60, off=7) if v is not None]
    base = mean(base_vals) if len(base_vals) >= 6 else None
    s7 = _series(days, T, "hrv", 7)
    last7 = [v for v in s7 if v is not None]
    m7 = mean(last7)
    r7 = m7 / base if (m7 and base) else None
    rt = cur / base if (cur and base) else None
    pts = [(i, v) for i, v in enumerate(s7) if v is not None]
    sl = slope(pts) if len(pts) >= 4 and base else None
    state = None
    if r7 is not None or rt is not None:
        x = r7 if r7 is not None else rt
        state = ("très_basse" if x <= TH["hrv_vlo"] else                 # v5 : moyenne glissante sur 7 jours (Plews et al. 2013-2014) ;
                 "basse" if (x <= TH["hrv_lo"] or (rt is not None and rt <= TH["hrv_vlo_today"])) else      # une nuit isolée très basse = « basse »
                 "haute" if x >= TH["hrv_hi"] else "stable")
    comp = None
    if r7 is not None or rt is not None:
        parts = [(0.6, r7 - 1 if r7 is not None else None), (0.4, rt - 1 if rt is not None else None)]
        comp = clamp(0.65 + wavg(parts) * 3.5)
    return {"val": cur, "base": base, "r7": r7, "rt": rt, "slope_pct_day": (sl / base * 100) if (sl is not None and base) else None, "state": state, "comp": comp}

def sleep_axis(days, T):
    sc = _last(days, T, "sc", 2); sh = _last(days, T, "sh", 2)
    deep = _last(days, T, "deep", 2); rem = _last(days, T, "rem", 2)
    dp, rp = stage_pcts(deep, rem, sh)
    sh3 = [v for v in _series(days, T, "sh", 3) if v is not None]
    debt = sum(max(0.0, TH["sleep_target_h"] - v) for v in sh3) if sh3 else None
    return {"score": sc, "h": sh, "deep": deep, "rem": rem, "deep_pct": dp, "rem_pct": rp, "debt": debt, "comp": sleep_comp(sc, sh, dp, rp)}

def load_axis(acts, T):
    ac = acwr(acts, T.isoformat())
    dl = {}
    for a in acts: dl[a["d"]] = dl.get(a["d"], 0) + a["ld"]
    day = lambda i: (T - timedelta(days=i)).isoformat()
    l7 = sum(dl.get(day(i), 0) for i in range(7)); lp7 = sum(dl.get(day(i), 0) for i in range(7, 14))
    # v5 (audit I5) : la fatigue de charge vient du modèle forme-fatigue (moyennes exponentielles 42 j / 7 j) ; le ratio aigu/chronique
    # reste calculé pour l'affichage mais ne déclenche plus ni plafond ni profil
    fm = form_balance(acts, T)
    zone = comp = None
    if fm is not None:
        zone = "surmenage" if fm < -0.35 else "surcharge" if fm < -0.18 else "zone_douce" if fm <= 0.20 else "sous_entraînement"
        comp = clamp(0.75 + fm)
    return {"acwr": ac, "form": fm, "zone": zone, "l7": l7, "lp7": lp7, "comp": comp}

def stress_bb_axis(days, T):
    st = mean(_series(days, T, "st", 3)); bbx = _last(days, T, "bbx", 2); bbc = _last(days, T, "bbc", 2)
    c_st = clamp((60 - st) / 40) if st is not None else None
    c_bb = wavg([(.6, clamp((bbx - 40) / 50) if bbx is not None else None), (.4, clamp(bbc / 70) if bbc is not None else None)])
    return {"stress": st, "bb": bbx, "bb_charge": bbc, "readiness": _last(days, T, "tr", 2), "comp": wavg([(.5, c_st), (.5, c_bb)])}

def recent_axis(acts, T):
    """Les 3 derniers jours : discipline et intensité de chaque séance (aujourd'hui, hier, avant-hier)."""
    iso = lambda i: (T - timedelta(days=i)).isoformat()
    w = (0.5, 1.0, 0.6)
    days3, load_w = [], 0.0
    for i in range(3):
        L = [x for x in acts if x["d"] == iso(i)]
        for x in L: x["_i"] = intensity(x)
        days3.append(L); load_w += w[i] * sum(x["ld"] for x in L)
    chronic = sum(x["ld"] for x in acts if iso(27) <= x["d"] <= iso(0)) / 28
    ratio = load_w / (chronic * sum(w)) if chronic > 0 else None
    flat = [x for L in days3 for x in L]
    hard72 = [x for x in flat if x["_i"] == "dur"]
    comp = None
    if ratio is not None:
        comp = clamp(1 - 0.3 * ratio - 0.15 * max(0.0, ratio - 1) - (0.15 if len(hard72) >= 2 else 0.0))
    return {"days": days3, "ratio": ratio, "n_hard72": len(hard72),
            "hard_24h": any(x["_i"] == "dur" for L in days3[:2] for x in L),
            "legs_24h": any(leg_stress(x) for L in days3[:2] for x in L), "legs72": sum(1 for x in flat if leg_stress(x)),
            "run_hard24": any(x["s"] in ("run", "trail") and x["_i"] == "dur" for L in days3[:2] for x in L),
            "bike_hard24": any(x["s"] == "bike" and x["_i"] == "dur" for L in days3[:2] for x in L), "comp": comp}

def veto_caps(hrv, sl, ld, sb, rc):
    """Plafonds du FAF : liste de (nom, plafond, explication)."""
    caps = []
    r7, rt = hrv["r7"], hrv["rt"]
    # v5 : la VFC est lue en moyenne sur 7 jours ; une nuit isolée très basse ne coupe que 10 % (Plews et al. 2013-2014)
    if r7 is not None and r7 <= TH["hrv_vlo"]:
        caps.append(("VFC très basse sur 7 jours", 0.80, f"VFC moyenne sur 7 jours à {(r7 - 1) * 100:+.0f} % de ta base"))
    elif r7 is not None and r7 <= TH["hrv_lo"]:
        caps.append(("VFC basse sur 7 jours", 0.90, f"VFC sur 7 jours à {(r7 - 1) * 100:+.0f} % de ta base"))
    elif rt is not None and rt <= TH["hrv_vlo_today"]:
        caps.append(("VFC basse cette nuit (isolée)", 0.90, f"VFC de la nuit à {(rt - 1) * 100:+.0f} % de ta base, moyenne sur 7 jours normale"))
    fm = ld.get("form")
    if fm is not None and fm < -0.35: caps.append(("Charge récente très au-dessus de l'habitude", 0.85, f"forme d'entraînement à {fm * 100:+.0f} %"))
    elif fm is not None and fm < -0.25: caps.append(("Charge récente au-dessus de l'habitude", 0.90, f"forme d'entraînement à {fm * 100:+.0f} %"))
    if (sl["score"] is not None and sl["score"] < TH["sleep_poor_score"]) or (sl["h"] is not None and sl["h"] < TH["sleep_poor_h"]):
        caps.append(("Sommeil dégradé", 0.80, "score ou durée de sommeil trop bas"))
    elif sl["debt"] is not None and sl["debt"] >= TH["sleep_debt_cap"]:
        caps.append(("Dette de sommeil", 0.85, f"{f1(sl['debt'])} h de déficit sur 3 nuits"))
    # v5 (audit A3) : Body Battery, stress et readiness Garmin recomptent VFC, sommeil et charge : affichés, sans plafond
    if rc["n_hard72"] >= 2: caps.append(("Deux séances dures en 72 h", 0.95, "pas de nouvelle séance dure"))
    return caps

def faf_band(faf):
    for lo, key, label in FAF_BANDS:
        if faf >= lo: return key, label

def cross_cases(hrv, sl, ld, sb):
    """Détection de cas croisés (signaux contradictoires ou combinés)."""
    out = []
    st, sc, tr = hrv["state"], sl["score"], sb["readiness"]
    if st == "haute" and (sc is not None and sc < 65): out.append("hrv_haute_sommeil_mauvais")
    if st in ("basse", "très_basse") and (sc is not None and sc >= 80): out.append("hrv_basse_sommeil_bon")
    if ld["zone"] == "zone_douce" and st in ("basse", "très_basse"): out.append("acwr_douce_hrv_basse")
    if ld["zone"] in ("surcharge", "surmenage") and st == "haute": out.append("acwr_haut_hrv_haute")
    if sb["stress"] is not None and sb["bb"] is not None and sb["stress"] > 45 and sb["bb"] < 50: out.append("stress_haut_bb_bas")
    if sl["h"] is not None and sl["h"] < 6.0 and sb["bb"] is not None and sb["bb"] >= 70: out.append("sommeil_court_bb_ok")
    if ld["zone"] in ("surcharge", "surmenage") and sc is not None and sc >= 80: out.append("charge_haute_sommeil_bon")
    if tr is not None and st is not None and ((tr >= 65 and st in ("basse", "très_basse")) or (tr <= 35 and st == "haute")): out.append("readiness_hrv_divergence")
    if sl["deep_pct"] is not None and sl["deep_pct"] < TH["deep_low_pct"] - 3: out.append("sommeil_profond_bas")
    if sl["rem_pct"] is not None and sl["rem_pct"] < TH["rem_low_pct"] - 4: out.append("rem_bas")
    return out

def training_needs(acts, T, ath, km4):
    """Besoins aérobie / anaérobie à partir des 21 derniers jours de course."""
    iso = lambda n: (T - timedelta(days=n)).isoformat()
    runs = [x for x in acts if x["s"] in ("run", "trail")]
    for x in runs: x["_k"] = run_kind(x)
    r21 = [x for x in runs if x["d"] >= iso(20)]
    n_ana = sum(1 for x in r21 if x["_k"] == "ana"); n_tempo = sum(1 for x in r21 if x["_k"] == "tempo")
    sp21 = ZF.intensity_split(acts, T, n=21)                # v5 : même mesure que le pilier « Charge » (FC seuil, zone grise comprise)
    hs = (sp21["grey"] + sp21["hard"]) * 100 if sp21 else 0.0
    last = lambda L: max([x["d"] for x in L], default=None)
    dq, dlong = last([x for x in runs if x["_k"] in ("ana", "tempo")]), last([x for x in runs if x["_k"] == "long"])
    since = lambda d: (T - date.fromisoformat(d)).days if d else 99
    ds = {"run": since(last(runs)), "bike": since(last([x for x in acts if x["s"] == "bike"])),
          "swim": since(last([x for x in acts if x["s"] == "swim"])), "strength": since(last([x for x in acts if x["s"] == "strength"]))}
    vol = km4 / ath["weekly_km_target"]
    deficit_aero = (vol < TH["aero_vol_ratio_min"]) or (hs > TH["hard_share_high"] and len(r21) >= 4) or (since(dlong) >= TH["long_gap_days"] and vol < 1.0)
    deficit_ana = (n_ana == 0) and vol >= TH["aero_vol_ratio_min"]
    return {"n_ana": n_ana, "n_tempo": n_tempo, "hard_share": hs, "ds_q": since(dq), "ds_long": since(dlong), "ds": ds, "vol_ratio": vol,
            "n_runs21": len(r21), "deficit_aero": deficit_aero, "deficit_ana": deficit_ana}

def physio_state(acts, days, T, ath, km4, ress=None):
    """ress : bilan du soir précédent (ressenti.evaluate) ; None ou sans réponse = analyse inchangée."""
    hrv, sl, ld, sb, rc = hrv_axis(days, T), sleep_axis(days, T), load_axis(acts, T), stress_bb_axis(days, T), recent_axis(acts, T)
    rs = ress if (ress and (ress.get("cur") or set(ress.get("flags") or []) & {"malade", "vacances", "reprise"})) else None
    if rs:      # ce que la montre ne mesure pas : séance d'hier ressentie dure, jambes lourdes, journée physique
        if rs["hard_yday"]:
            if not any(x.get("_i") == "dur" for x in rc["days"][1]): rc["n_hard72"] += 1
            rc["hard_24h"] = True
        if "jambes" in rs["flags"]: rc["legs_24h"], rc["legs72"] = True, max(rc["legs72"], 2)
        elif rs["legs"]: rc["legs_24h"] = True
    comps = {"hrv": hrv["comp"], "sleep": sl["comp"], "load": ld["comp"], "sb": sb["comp"], "recent": rc["comp"], "feel": rs["comp"] if rs else None}
    n_axes = sum(1 for k in ("hrv", "sleep", "load", "sb") if comps[k] is not None)
    poor = n_axes < 2
    ready = None if poor else wavg([(W_STRAIN[k], comps[k]) for k in comps])
    strain = None if ready is None else int(round((1 - ready) * 100))
    caps = veto_caps(hrv, sl, ld, sb, rc) + (list(rs["caps"]) if rs else [])
    # v6 : efficacité aérobie en baisse (séances détaillées) — signal faible, retenu seulement s'il est confirmé par un autre axe
    try:
        import detail_analysis as DA
        fs = DA.fatigue_signal(acts, T)
    except Exception:  # noqa: BLE001
        fs = None
    if fs and fs.get("flag") and caps:
        caps.append(("Efficacité aérobie en baisse", 0.92, f"FC plus haute à allure égale ({fs['ef_delta']:+.0f} % sur 7 jours), confirmée par : {caps[0][0].lower()}"))
    ready_phys = None if poor else wavg([(W_STRAIN[k], comps[k]) for k in comps if k != "feel"])
    base = TH["faf_default"] if ready is None else TH["faf_min"] + 0.65 * ready
    faf = round(max(TH["faf_min"], min(TH["faf_max"], min([base] + [c[1] for c in caps]))), 2)
    tn = training_needs(acts, T, ath, km4)
    cross = cross_cases(hrv, sl, ld, sb)
    # --- profil dominant (ordre de priorité) ---
    muscular = rc["legs72"] >= 2 or any(x["s"] in ("run", "trail") and x["km"] >= 18 for x in rc["days"][1])
    hrv_low = hrv["state"] in ("basse", "très_basse")
    tags = []
    if poor:
        profile = "données_insuffisantes"
    elif strain >= TH["strain_acute"] or (ld.get("form") is not None and ld["form"] < -0.45) or (hrv["state"] == "très_basse" and ((sl["comp"] if sl["comp"] is not None else 1) < 0.5 or (sb["comp"] if sb["comp"] is not None else 1) < 0.4)):
        profile = "fatigue_aiguë"
    elif muscular and not hrv_low:
        profile = "surcharge_musculaire"
    elif strain >= TH["strain_incomplete"] or hrv_low or (sl["debt"] or 0) >= TH["sleep_debt_warn"]:
        profile = "récupération_incomplète"
    elif (ld.get("form") is not None and -0.25 <= ld["form"] <= 0.0 and (hrv["r7"] or 0) >= 1.0 and (sl["comp"] or 0) >= 0.6 and ld["lp7"] > 0 and ld["l7"] >= 1.05 * ld["lp7"]):
        profile = "assimilation_réussie"
    elif strain <= TH["strain_fresh"] and (ld.get("form") is None or -0.25 <= ld["form"] <= 0.25) and hrv["state"] in (None, "haute", "stable"):
        profile = "déficit_aérobie" if tn["deficit_aero"] else "déficit_anaérobie" if tn["deficit_ana"] else "forme_optimale"
        if profile != "forme_optimale": tags.append("forme_optimale")
    else:
        profile = "déficit_aérobie" if tn["deficit_aero"] else "déficit_anaérobie" if tn["deficit_ana"] else "maintien"
    if rs:      # le ressenti corrige le profil quand la montre ne voit rien venir
        fl, good = set(rs["flags"]), ("forme_optimale", "maintien", "déficit_aérobie", "déficit_anaérobie", "assimilation_réussie", "données_insuffisantes")
        if "malade" in fl and profile != "fatigue_aiguë": profile = "récupération_incomplète"; tags.append("malade")
        elif "jambes" in fl and profile in good and not hrv_low: profile = "surcharge_musculaire"; tags.append("jambes_ressenties")
        elif "energie" in fl and ("stress" in fl or "motivation" in fl) and profile in good: profile = "récupération_incomplète"; tags.append("fatigue_ressentie")
        rs["cross"] = RS.cross(rs, ready_phys)
    return {"hrv": hrv, "sleep": sl, "load": ld, "sb": sb, "recent": rc, "comps": comps, "ready": ready, "strain": strain,
            "caps": caps, "faf": faf, "faf_base": round(base, 2), "needs": tn, "cross": cross, "profile": profile, "tags": tags, "poor": poor, "ress": rs,
            "tid": ZF.intensity_split(acts, T)}

def phrase_vars(st):
    """Variables injectables dans les banques de phrases (None si la donnée manque)."""
    hrv, sl, ld, sb = st["hrv"], st["sleep"], st["load"], st["sb"]
    p = hrv["rt"] if hrv["rt"] is not None else hrv["r7"]
    g = lambda v, n=0: None if v is None else f"{v:.{n}f}"
    return {"hrv_val": g(hrv["val"]), "hrv_baseline": g(hrv["base"]), "hrv_pct": None if p is None else f"{(p - 1) * 100:+.0f} %",
            "sleep_score": g(sl["score"]), "sleep_h": None if sl["h"] is None else f1(sl["h"]), "deep_pct": g(sl["deep_pct"]), "rem_pct": g(sl["rem_pct"]),
            "load_7d": g(ld["l7"]), "acwr": None if ld.get("form") is None else f"{ld['form'] * 100:+.0f} %", "strain_index": st["strain"],
            "body_battery": g(sb["bb"]), "bb_charge": g(sb["bb_charge"]), "stress_avg": g(sb["stress"]), "faf": f1(st["faf"], 2),
            "readiness": g(sb["readiness"])}


# =============================================================================================
# 8. SYNTHÈSES PAR PÉRIODE
# =============================================================================================
CROSS_GOOD = {"acwr_haut_hrv_haute", "charge_haute_sommeil_bon"}

def synthesis(key, n, S, Sp, st, ctx, preds, goals, ath, T, D, PP=None, acts=()):
    """Synthèse de la période. Tout est calculé sur la fenêtre choisie (n jours) et la fenêtre est rappelée dans le texte ;
    seuls les signaux « Aujourd'hui » (diagnostic, cas croisés, dette de sommeil) restent ceux du jour."""
    PP = PP or {}
    iso = lambda k: (T - timedelta(days=k)).isoformat()
    win = f"sur {PLAB[key]}"
    lc = lambda t: t[0].lower() + t[1:] if len(t) > 1 and t[1].islower() else t      # « Aujourd'hui : les… » (sans majuscule parasite)
    L = lambda rule, salt, **v: PB.pick(PB.LINES[rule], D, f"{key}:{salt}", v)
    r = S["run"]
    preds = PP.get("preds") or preds
    rp = Sp["run"] if Sp else {"km": 0, "pace": None, "ef": None}
    weeks = n / 7
    d_h = pct(S["h"], Sp["h"]) if Sp else None
    d_km = pct(r["km"], rp["km"]) if Sp else None
    head = (f"Sur {PLAB[key]} : {S['n']} séance(s), {f1(S['h'])} h d'entraînement"
            f"{' (' + sgn(d_h) + ' vs période précédente)' if d_h is not None else ''}. "
            f"Course : {r['n']} sortie(s), {f1(r['km'])} km"
            f"{' à ' + pace(r['pace']) + '/km' if r['pace'] else ''}"
            f"{' (' + sgn(d_km) + ')' if d_km is not None else ''}.")
    good, bad, focus = [], [], []
    kmw = r["km"] / weeks
    if kmw >= 0.9 * ath["weekly_km_target"]: good.append(L("vol_good", "vol", kmw=f1(kmw), target=ath["weekly_km_target"]))
    elif kmw < 0.5 * ath["weekly_km_target"]: bad.append(L("vol_bad", "vol", kmw=f1(kmw), target=ath["weekly_km_target"]))
    if d_km is not None and d_km >= 10 and rp["km"] > 0: good.append(L("delta_up", "dkm", d=f"{d_km:.0f}"))
    if d_km is not None and d_km <= -25 and rp["km"] > 0: bad.append(L("delta_down", "dkm", d=f"{abs(d_km):.0f}"))
    rpw = r["n"] / weeks
    if rpw >= 3: good.append(L("regular_good", "reg", rpw=f1(rpw)))
    elif rpw < 2: bad.append(L("regular_bad", "reg", rpw=f1(rpw)))
    if rp["pace"] and r["pace"] and (rp["pace"] - r["pace"]) / rp["pace"] >= 0.02: good.append(L("pace_good", "pace", d=f"{(rp['pace'] - r['pace']) * 60:.0f}"))
    if r["ef"] and rp["ef"] and r["ef"] / rp["ef"] >= 1.02: good.append(L("ef_good", "ef", d=f"{(r['ef'] / rp['ef'] - 1) * 100:.0f}"))
    if r["ef"] and rp["ef"] and r["ef"] / rp["ef"] <= 0.97: bad.append(L("ef_bad", "ef", d=f"{(r['ef'] / rp['ef'] - 1) * 100:.0f}"))
    fm = PP.get("form")                                    # v5 : forme d'entraînement (modèle forme-fatigue), plus le ratio aigu/chronique
    if fm is not None:
        rule = ("acwr_surmenage" if fm < -0.35 else "acwr_surcharge" if fm < -0.18 else "acwr_douce" if fm <= 0.20 else "acwr_sous")
        (good if rule == "acwr_douce" else bad).append(L(rule, "acwr", acwr=f"{fm * 100:+.0f} %").rstrip(".") + ".")
    rc = S["rec"]
    r7 = PP.get("hrvr")
    if r7 is not None:
        pc = f"{(r7 - 1) * 100:+.0f} %"
        hw = f" · VFC moyenne {win}, base : 60 jours précédents"
        if r7 >= 1.0: good.append(L("hrv_good", "hrv", pct=pc).rstrip(".") + hw + ".")
        elif r7 <= TH["hrv_lo"]: bad.append(L("hrv_bad", "hrv", pct=pc).rstrip(".") + hw + ".")
    if rc["sc"] is not None:
        if rc["sc"] >= 80: good.append(L("sleep_good", "sleep", score=f"{rc['sc']:.0f}"))
        elif rc["sc"] < 70: bad.append(L("sleep_bad", "sleep", score=f"{rc['sc']:.0f}"))
    if (st["sleep"]["debt"] or 0) >= TH["sleep_debt_warn"]: bad.append("Aujourd'hui : " + lc(L("sleep_debt", "debt", debt=f1(st["sleep"]["debt"]))))
    dp, rp_ = stage_pcts(rc["deep"], rc["rem"], rc["sh"])
    if dp is not None and rp_ is not None:
        if dp >= TH["deep_low_pct"] and rp_ >= TH["rem_low_pct"]: good.append(L("stages_good", "stages", deep_pct=f"{dp:.0f}", rem_pct=f"{rp_:.0f}"))
        elif dp < TH["deep_low_pct"] - 2 or rp_ < TH["rem_low_pct"] - 3: bad.append(L("stages_bad", "stages", deep_pct=f"{dp:.0f}", rem_pct=f"{rp_:.0f}"))
    if rc["st"] is not None:
        if rc["st"] >= 50: bad.append(L("stress_bad", "stress", stress=f"{rc['st']:.0f}"))
        elif rc["st"] <= 30: good.append(L("stress_good", "stress", stress=f"{rc['st']:.0f}"))
    if rc["bbx"] is not None:
        if rc["bbx"] < 60: bad.append(L("bb_bad", "bb", bb=f"{rc['bbx']:.0f}"))
        elif rc["bbx"] >= 80: good.append(L("bb_good", "bb", bb=f"{rc['bbx']:.0f}"))
    rhrd = PP.get("rhrd")
    if rhrd is not None and rhrd >= 3: bad.append(f"FC de repos en hausse de {f1(rhrd)} bpm {win} par rapport à la base des 60 jours précédents : la récupération est à surveiller.")
    wr = [x for x in acts if iso(n - 1) <= x["d"] <= iso(0) and x["s"] in ("run", "trail")]
    if len(wr) >= 3:
        easy = sum(x["m"] for x in wr if run_kind(x) in ("easy", "long")); hard = sum(x["m"] for x in wr if run_kind(x) in ("ana", "tempo"))
        hs_v = hard / (easy + hard) * 100 if (easy + hard) else 0.0; hs = f"{hs_v:.0f}"
        pw_ = f" · intensité {win}, {len(wr)} sorties"
        if hs_v > TH["hard_share_high"]: bad.append(L("polar_bad", "polar", hs=hs).rstrip(".") + pw_ + ".")
        elif hs_v < TH["hard_share_low"]: bad.append(L("polar_low", "polar", hs=hs).rstrip(".") + pw_ + ".")
        else: good.append(L("polar_good", "polar", hs=hs).rstrip(".") + pw_ + ".")
    sw = S["sp"]["strength"]["n"] / weeks
    if sw >= 1.5: good.append(L("str_good", "str", sw=f1(sw)))
    else: bad.append(L("str_bad", "str", sw=f1(sw), target=ath["strength_per_week"]))
    cross = S["sp"]["bike"]["n"] + S["sp"]["swim"]["n"]
    if cross >= 1: good.append(L("cross_good", "cross", bike=S["sp"]["bike"]["n"], swim=S["sp"]["swim"]["n"]))
    else: bad.append(L("cross_bad", "cross"))
    v = phrase_vars(st)         # signaux du jour : identiques pour toutes les périodes, annoncés « Aujourd'hui »
    for c in st["cross"][:3]:
        (good if c in CROSS_GOOD else bad).append("Aujourd'hui : " + lc(PB.pick(PB.CROSS[c], D, f"cross:{c}", v)))
    head += " Aujourd'hui : " + lc(PB.pick(PB.DIAG[st["profile"]]["head"], D, "diag.head", v))
    for p in preds:
        if p["ret"] and p["target"]:
            g = p["gap"]
            focus.append(f"{p['label']} : prédiction {hms(p['ret'])} pour {hms(p['target'])} visé ({'objectif à portée' if g <= 0 else hms(g) + ' à gagner'}) · base : sorties et VO2max {win}.")
        elif p["ret"]:
            focus.append(f"{p['label']} : prédiction {hms(p['ret'])} · base : sorties et VO2max {win}.")
    nxt = next((g for g in goals if date.fromisoformat(g["date"]) >= T), None)
    if nxt: focus.append(f"Prochaine échéance : {nxt['label']} dans {(date.fromisoformat(nxt['date']) - T).days} jours.")
    if r["longest"]: focus.append(f"Sortie la plus longue : {f1(r['longest'])} km · D+ cumulé {r['el']} m.")
    return {"head": head, "good": good or ["Pas de point fort marquant sur cette période."],
            "bad": bad or ["Aucun point faible notable sur cette période."], "focus": focus}


# =============================================================================================
# 8 bis. « LE MOT DU COACH » : paragraphe de synthèse humoristique (bibliothèque bilan_bank.py)
# =============================================================================================
def bilan_signals(key, n, PP, st, S, Sp, goals, T, fresh=None):
    """Résume en quelques signaux (période + état du jour) ce dont bilan_bank.compose() a besoin."""
    weeks = n / 7.0
    f = lambda v, d=1: None if v is None else f1(v, d)
    pil = {p["key"]: {"score": p["score"], "name": p["name"]} for p in PP.get("pillars", [])}
    r, rc = S["run"], S["rec"]
    # objectif : prochaine course avec prédiction ET temps visé, sinon n'importe quelle prédiction chiffrée
    preds = [p for p in (PP.get("preds") or []) if p.get("ret")]
    nxt = next((g for g in goals if date.fromisoformat(g["date"]) >= T), None)
    pick = next((p for p in preds if p.get("target") and nxt and abs(p["dist"] - nxt["dist"]) < 0.5 and nxt.get("sport", "run") == "run"), None) or next((p for p in preds if p.get("target")), None)
    goal = {}
    if pick:
        gap = pick["ret"] - pick["target"]
        goal = {"ret": pick["ret"], "target": pick["target"], "glabel": pick["label"].replace(" ", "\u00a0"), "gret": hms(pick["ret"]), "gtarget": hms(pick["target"]),
                "ggap": hms(abs(gap)), "gpct": f"{abs(gap) / pick['target'] * 100:.0f}"}
    hrvr = PP.get("hrvr")
    hrv_p = None if hrvr is None else f"{(hrvr - 1) * 100:+.0f} %"
    v0 = phrase_vars(st)
    vars_ = {"strain": v0["strain_index"], "faf": v0["faf"], "hrv_pct": v0["hrv_pct"], "sleep_score": v0["sleep_score"], "sleep_h": v0["sleep_h"],
             "acwr": v0["acwr"], "bb": v0["body_battery"], "sleep_debt": f((st["sleep"]["debt"] or 0), 1), "hrv_pct_p": hrv_p,
             "stress": None if rc["st"] is None else f"{rc['st']:.0f}"}
    pvars = {"pred": dict(PP.get("prep_lead") or {}),
             "run": {"kmw": f(r["km"] / weeks), "long_km": f(r["longest"])},
             "load": {"acwr": None if PP.get("form") is None else f"{PP['form'] * 100:+.0f} %"},
             "rec": {"sleep_h": f(rc["sh"]), "hrv_pct": hrv_p},
             "cross": {"sw": f(S["sp"]["strength"]["n"] / weeks), "cw": f((S["sp"]["bike"]["n"] + S["sp"]["swim"]["n"]) / weeks)}}
    mod = None
    if (st["sleep"]["debt"] or 0) >= TH["sleep_debt_warn"]: mod = "debt"
    elif hrvr is not None and hrvr <= TH["hrv_lo"]: mod = "hrv_low"
    elif rc["st"] is not None and rc["st"] >= 50: mod = "stress"
    elif hrvr is not None and hrvr >= TH["hrv_hi"] and st["profile"] not in BB.STATE_KO: mod = "hrv_good"
    elif rc["bbx"] is not None and rc["bbx"] < 60:
        mod = "bb_low"; vars_["bb"] = f"{rc['bbx']:.0f}"
    trend, dkm = None, None
    if Sp and Sp["run"]["km"] > 0:
        d = pct(r["km"], Sp["run"]["km"])
        trend = "up" if d >= 10 else "down" if d <= -15 else "flat"
        dkm = f"{abs(d):.0f}"
        vars_["dkm"] = dkm
    ac_m = PP.get("acwr_mean")
    fr = fresh or {}
    if fr.get("level"):
        vars_["sdays"] = str(fr.get("age_wellness") if fr.get("age_wellness") is not None else fr.get("sync_age") or "plusieurs")
        vars_["sdate"] = None if not fr.get("last_wellness") else date.fromisoformat(fr["last_wellness"]).strftime("%d/%m")
    return {"stale": fr.get("level"), "score": PP.get("score"), "profile": st["profile"], "pillars": pil, "load_dir": None if PP.get("form") is None else ("high" if PP["form"] < -0.18 else "low"), "pillar_vars": pvars, "goal": goal, "vars": vars_, "mod": mod,
            "trend": trend, "days_to_race": None if not nxt else (date.fromisoformat(nxt["date"]) - T).days,
            "vars_race": {"rlabel": None if not nxt else nxt["label"]}}


def bilan_text(key, n, PP, st, S, Sp, goals, T, D, fresh=None, mem=None, cross=None, feel=None):
    """Paragraphe du coach pour une période ; ne fait jamais échouer l'analyse (texte vide en cas d'erreur).
    cross (coach_croise.preparer) : évolution de la période vue depuis les autres + règle « Grosbichou » si la période est en baisse."""
    try:
        sig = bilan_signals(key, n, PP, st, S, Sp, goals, T, fresh)
        sig["vars"].update(sig.pop("vars_race"))
        if cross and key in cross:
            sig["neg"] = CC.baisse(key, cross)
            sig["nick_force"] = CC.GROS if sig["neg"] else None
            sig["evol"] = CC.evolution(key, cross, str(D))
        if feel: sig["feel"] = feel                 # bilan du soir (ressenti.feel_blocks)
        out = BB.compose(sig, D, key, mem)
        if mem is not None: mem.record_today(key, out["text"])
        return out
    except Exception as e:          # noqa: BLE001 : le dashboard doit toujours se générer
        return {"text": "", "short": "", "parts": [], "scenario": {}, "error": f"{type(e).__name__}: {e}"}


# =============================================================================================
# 9. ENTRAÎNEMENT DU JOUR
# =============================================================================================
STR_TYPES = {"push": re.compile(r"pecto|pect|épaule|epaule|push|triceps|poussée", re.I),
             "pull": re.compile(r"\bdos\b|pull|biceps|tirage|traction", re.I),
             "legs": re.compile(r"jambe|leg|squat|cuisse|fessier|mollet", re.I)}
# indices des séances de la famille « force » (sessions_library) par type de rotation
STR_LABEL = {"push": "Push (pecs, épaules, triceps)", "pull": "Pull (dos, biceps)", "legs": "Legs (jambes)"}

def strength_plan(acts, T, rc, prof):
    """Prochaine séance de force. v5 (audit I14) : rotation pondérée pour un coureur, sans abandonner le programme Push/Pull/Legs :
    jambes une séance sur deux (charges lourdes + pliométrie), le haut du corps alterne Push et Pull entre les deux.
    Une séance au nom générique (« Musculation ») compte comme la suivante de cette rotation. Les jambes sont reportées si elles
    sont déjà sollicitées ou si une sortie longue est possible demain."""
    seen, generic, hist = [], 0, []
    nxt_of = lambda h: (min(("push", "pull"), key=lambda t: max([i for i, k in enumerate(h) if k == t], default=-1)) if (h and h[-1] == "legs") else "legs")
    for a in [a for a in acts if a["s"] == "strength"][-9:]:
        k = next((k for k, rx in STR_TYPES.items() if rx.search(a.get("nm") or "")), None)
        if k:
            seen.append(k); hist.append(k); generic = 0
        elif hist:
            hist.append(nxt_of(hist)); generic += 1
    nxt = nxt_of(hist) if hist else ["push", "pull", "legs"][T.toordinal() % 3]
    upper = min(("push", "pull"), key=lambda t: max([i for i, k in enumerate(hist) if k == t], default=-1))
    tomorrow_long = (T + timedelta(days=1)).weekday() in tuple(CFG_ATH().get("long_days") or (5, 6))
    legs_busy = rc["legs_24h"] or rc["legs72"] >= 2 or tomorrow_long or prof in ("surcharge_musculaire", "fatigue_aiguë", "récupération_incomplète")
    skipped = False
    if nxt == "legs" and legs_busy:
        skipped = True
        nxt = upper
    return nxt, skipped, (seen, generic)


def CFG_ATH():
    try:
        import config as _C
        return _C.ATHLETE
    except Exception:                                    # noqa: BLE001
        return {}


def strength_hist(acts, T):
    """Séances de musculation récentes : liste de (jours écoulés, type push|pull|legs|None), la plus récente d'abord.
    Une séance au nom générique compte comme la suivante de la rotation (même règle que strength_plan)."""
    order, pos, out = ["push", "pull", "legs"], None, []
    for a in [a for a in acts if a["s"] == "strength"][-9:]:
        k = next((k for k, rx in STR_TYPES.items() if rx.search(a.get("nm") or "")), None)
        if k: pos = order.index(k)
        elif pos is not None: pos = (pos + 1) % 3; k = order[pos]
        out.append(((T - date.fromisoformat(a["d"])).days, k))
    return out[::-1]

def big_swim(x): return x["s"] == "swim" and (x["m"] >= 45 or x["km"] >= 2.0 or x["ld"] >= 70)
def mid_swim(x): return x["s"] == "swim" and (x["m"] >= 30 or x["km"] >= 1.2)
def big_bike(x): return x["s"] == "bike" and (x["ld"] >= 120 or x["km"] >= 60 or x["m"] >= 120)
def mid_bike(x): return x["s"] == "bike" and (x["ld"] >= 70 or x["m"] >= 75)

def type_loads(st, acts, T, guard=None):
    """FAF propre à chaque type de séance (Push / Pull / Legs) : le FAF global, plafonné selon ce qui a été fait hier et avant-hier.
    Jambes : grosse sortie vélo ou course exigeante, ou jambes déjà travaillées en musculation -> séance allégée.
    Pecs, dos, épaules : grosse séance de natation, ou même groupe musculaire travaillé il y a moins de 48 h -> allégé.
    Retourne {type: {"faf", "why": [textes]}}."""
    rc, prof, faf = st["recent"], st["profile"], st["faf"]
    recent = rc["days"][0] + rc["days"][1]        # aujourd'hui (si déjà fait) et hier
    d2 = rc["days"][2]
    hist = strength_hist(acts, T)
    cap = {t: [] for t in ("push", "pull", "legs")}          # (plafond, texte)
    def add(t, c, txt): cap[t].append((c, txt))
    if guard: add("legs", guard[0], guard[1])        # course proche ou récupération après course (plan_adapt.legs_guard)
    # --- jambes ---
    if any(k == "legs" and d <= 1 for d, k in hist): add("legs", 0.50, "jambes déjà travaillées en musculation il y a moins de 48 h")
    elif any(k == "legs" and d == 2 for d, k in hist): add("legs", 0.80, "séance de jambes il y a 2 jours")
    if any(big_bike(x) for x in recent): add("legs", 0.65, "grosse sortie vélo hier : jambes à ménager")
    elif any(mid_bike(x) for x in recent): add("legs", 0.80, "sortie vélo conséquente hier")
    if any(x["s"] in ("run", "trail") and leg_stress(x) for x in recent): add("legs", 0.65, "course exigeante ou longue hier : jambes à ménager")
    elif any(leg_stress(x) for x in d2): add("legs", 0.90, "séance éprouvante pour les jambes il y a 2 jours")
    if rc["legs72"] >= 2: add("legs", 0.65, "deux séances à forte contrainte pour les jambes en 72 h")
    if prof == "surcharge_musculaire": add("legs", 0.60, "profil de surcharge musculaire")
    # --- haut du corps ---
    if any(big_swim(x) for x in recent):
        add("pull", 0.65, "grosse séance de natation hier : dos et épaules déjà sollicités")
        add("push", 0.70, "grosse séance de natation hier : épaules déjà sollicitées")
    elif any(mid_swim(x) for x in recent):
        add("pull", 0.85, "séance de natation hier : dos et épaules un peu sollicités")
        add("push", 0.90, "séance de natation hier : épaules un peu sollicitées")
    elif any(big_swim(x) for x in d2): add("pull", 0.90, "grosse natation il y a 2 jours")
    for t in ("push", "pull"):
        if any(k == t and d <= 1 for d, k in hist): add(t, 0.60, f"{t.capitalize()} déjà travaillé il y a moins de 48 h")
        elif any(k == t and d == 2 for d, k in hist): add(t, 0.85, f"{t.capitalize()} travaillé il y a 2 jours")
    if prof == "fatigue_aiguë":
        for t in cap: add(t, 0.60, "fatigue aiguë : séance courte et sans échec musculaire")
    out = {}
    for t, L in cap.items():
        f = round(max(TH["faf_min"], min([faf] + [c for c, _ in L])), 2)
        why = [txt[0].upper() + txt[1:] for c, txt in sorted(L) if c <= faf][:3]
        if not why: why = ["Aucune contrainte particulière liée aux derniers jours : volume complet selon ta forme."] if f >= 0.95 else [f"Volume ajusté à ton FAF de {f1(f, 2)}."]
        out[t] = {"faf": f, "why": why}
    return out

def choose_default(nxt, loads):
    """Type proposé par défaut : le prochain de la rotation s'il est assez frais (FAF du type >= 0,8), sinon le suivant, sinon le plus frais."""
    order = ["push", "pull", "legs"]
    pref = [order[(order.index(nxt) + k) % 3] for k in range(3)]
    for t in pref:
        if loads[t]["faf"] >= 0.8: return t
    return max(pref, key=lambda t: (loads[t]["faf"], -pref.index(t)))

def muscu_block(acts, T, st, guard=None, force=None):
    nxt, skipped, (seen, generic) = strength_plan(acts, T, st["recent"], st["profile"])
    loads = type_loads(st, acts, T, guard)
    t = force if force in loads else choose_default(nxt, loads)        # type prévu dans « Cette semaine » (Push le lundi, Pull le jeudi)
    lab = lambda x: PPL.TYPES[x][0]
    reason = (f"Rotation pour coureur (jambes une séance sur deux, Push et Pull en alternance) : après « {lab(seen[-1])} », le suivant est {lab(nxt)}." if seen else f"Rotation de départ : {lab(nxt)}.")
    if skipped: reason += " Les jambes sont reportées : elles ont été sollicitées ces derniers jours, ou une sortie longue est possible demain."
    if force in loads: reason = f"{lab(t)} : séance prévue aujourd'hui dans ta semaine."
    elif t != nxt: reason += f" {lab(nxt)} est allégé par tes derniers jours, donc {lab(t)} passe en premier."
    reason += f" {lab(t)} proposé à {PPL.level_of(loads[t]['faf']).lower()} (FAF du type {f1(loads[t]['faf'], 2)})."
    out = PPL.muscu_payload(T, loads, t, reason)
    try:                                                  # v6 : charges conseillées d'après les séries réellement soulevées
        import detail_analysis as DA
        cache = {}
        for ty in (out.get("types") or {}).values():
            for se in ty.get("sessions") or []:
                for e in se.get("ex") or []:
                    if e["name"] not in cache: cache[e["name"]] = DA.kg_hint(e["name"], acts, T)
                    h = cache[e["name"]]
                    if h: e["kg"] = h["txt"]; e["note"] = (str(e.get("note") or "") + (" · " if e.get("note") else "") + "Charge : " + h["txt"]).strip()
    except Exception:  # noqa: BLE001
        pass
    return out

def strength_card_blocks(m):
    t = m["default"]; T_ = m["types"][t]; s = T_["sessions"][T_["today_n"] - 1]
    ex = "\n".join(f"{e['i']}. {e['name']} : {e['sets']} × {e['reps']} {e['unit']} · repos {e['rest']}" for e in s["ex"])
    bl = [["Objectif", T_["sub"]], ["Échauffement", " ".join(T_["warmup"]["phases"])], ["Exercices", ex],
          ["Adaptation à ta forme", T_["effort"] + " " + " ".join(T_["why"])], ["Progression", m["guide"][0]]]
    if s.get("pain"):
        bl.insert(3, ["Adaptation douleur", s["pain"]["msg"] + " " + " ".join(s["pain"]["warm"]) + " " + s["pain"]["prog"]])
    return s, bl

WEEK_BONUS, WEEK_OFF, WEEK_VETO = 0.6, 0.25, 0.7   # (VETO : contre-indication du jour à partir de laquelle la forme l'emporte sur la semaine)
# classement : discipline prévue aujourd'hui dans la semaine type (+), autre endurance non prévue ce jour-là (−)


def plan_day(st, T, goals, D, acts, plan_mem=None):
    """Choisit la famille de séance par discipline (selon profil, FAF, 3 derniers jours) et classe les disciplines."""
    faf, prof, rc, tn = st["faf"], st["profile"], st["recent"], st["needs"]
    quality_ok = faf >= 0.95 and not rc["hard_24h"] and rc["n_hard72"] < 2 and prof not in ("fatigue_aiguë", "récupération_incomplète", "surcharge_musculaire")
    mid_ok = faf >= 0.8 and prof != "fatigue_aiguë"
    nxt = next((g for g in goals if date.fromisoformat(g["date"]) >= T), None)
    left = (date.fromisoformat(nxt["date"]) - T).days if nxt else 999
    stype, skipped, seen = strength_plan(acts, T, rc, prof)

    def family(disc):
        if disc == "strength": return "force"      # musculation = programme Push/Pull/Legs, volume modulé par le FAF de chaque type
        if faf < 0.65 or prof == "fatigue_aiguë": return "recup"
        if prof == "surcharge_musculaire": return "recup" if disc == "run" else "z2"
        if prof == "récupération_incomplète": return "recup" if faf < 0.75 else "z2"
        if prof == "déficit_anaérobie": f = "vo2" if quality_ok else ("aerobe" if mid_ok and not rc["hard_24h"] else "z2")
        elif prof == "déficit_aérobie": f = "aerobe" if (mid_ok and faf >= 0.9 and not rc["hard_24h"] and tn["ds_q"] >= 3) else "z2"      # v5 (A4) : règle explicite, plus de tirage
        elif prof == "assimilation_réussie": f = "spec" if quality_ok else ("aerobe" if mid_ok and not rc["hard_24h"] else "z2")
        elif prof == "forme_optimale": f = ("vo2" if tn["n_ana"] <= tn["n_tempo"] else "aerobe") if quality_ok else ("aerobe" if mid_ok and not rc["hard_24h"] else "z2")
        elif prof == "maintien": f = "aerobe" if (mid_ok and not rc["hard_24h"] and tn["ds_q"] >= 3) else "z2"
        else: f = "z2"
        # contraintes : jamais deux fois la même contrainte de suite
        if f in ("vo2", "spec", "aerobe") and rc["hard_24h"]: f = "z2"
        if disc == "run" and f in ("vo2", "spec") and (rc["legs_24h"] or rc["run_hard24"]): f = "aerobe" if mid_ok and not rc["hard_24h"] else "z2"
        if disc == "run" and legs_loaded: f = "recup"
        if disc == "run" and f == "spec" and nxt and nxt.get("sport") == "trail" and left <= 60: f = "trail"
        return f

    legs_loaded = rc["legs72"] >= 2 or rc["n_hard72"] >= 2         # v5 (audit I6) : contrainte « jambes » appliquée quel que soit le profil

    def cap_level(disc):
        """Plafond d'intensité assimilable aujourd'hui (1 récupération … 5 séance très intense), d'après le profil, le FAF et les 3 derniers jours.
        Chaque contrainte est un plafond : la plus basse s'applique (une VFC basse ne peut pas donner une séance plus longue qu'un jour neutre)."""
        lvl = 5 if quality_ok else (3 if mid_ok and not rc["hard_24h"] else 2)
        if faf < 0.65 or prof == "fatigue_aiguë": lvl = 1
        if prof == "surcharge_musculaire": lvl = min(lvl, 1 if disc == "run" else 2)
        if prof == "récupération_incomplète": lvl = min(lvl, 1 if faf < 0.75 else 2)
        if rc["hard_24h"]: lvl = min(lvl, 2)
        if disc == "run" and (rc["legs_24h"] or rc["run_hard24"]): lvl = min(lvl, 3)
        if disc == "run" and legs_loaded: lvl = min(lvl, 1)
        return lvl

    fam = {d: family(d) for d in ("run", "swim", "bike", "strength")}
    # stratégie de préparation (planner.py) : objectifs -> phase -> famille de séance, réconciliée avec l'état de forme ci-dessus (plafond)
    try:
        try:
            review = PA.revue(plan_mem, acts, T)           # bilan des séances conseillées / faites (tâche de fond, jamais bloquant)
        except Exception:                                  # noqa: BLE001
            review = None
        plan = PLN.planifier(acts, T, goals, st, dict(fam), {d: cap_level(d) for d in ("run", "swim", "bike")}, D, review)
    except Exception:                      # le moteur de planification ne doit jamais empêcher le dashboard de se générer
        plan = None
    if plan:
        for d in ("run", "swim", "bike"): fam[d] = plan["fam"][d]
    base = {"run": 1.0, "bike": 0.8, "swim": 0.75, "strength": 0.65}
    base = {d: v for d, v in base.items() if PF.ok(d)} or base          # sports choisis dans Paramètres : les autres ne sont jamais proposés
    try:
        sched = EX.today_sched(acts, T, goals, CFG_ATH(), plan, faf, plan_mem)   # séances prévues aujourd'hui dans « Cette semaine »
    except Exception:                                  # noqa: BLE001
        sched = []
    ph = ((plan or {}).get("phase") or {})
    gmain = EX._main_goal(goals, T) or {}
    free = any(ph.get(d) in ("recuperation", "jour_j") for d in ("run", "bike", "swim")) or "brick" in fam.values() \
        or (gmain and gmain.get("sport") not in ("run", "trail"))     # après une course, enchaînement, triathlon, swimrun, vélo : le planificateur décide
    if free: sched = []
    wk_day = {it["s"] for it in sched}
    score = {}
    for d in base:
        s = base[d] + 0.12 * min(tn["ds"][d], 4)
        if d == "run":
            if rc["run_hard24"]: s -= 0.9
            elif tn["ds"]["run"] <= 1: s -= 0.2
            if prof in ("surcharge_musculaire", "fatigue_aiguë"): s -= 0.6
        elif d == "bike":
            if rc["bike_hard24"]: s -= 0.7
            if prof == "surcharge_musculaire": s += 0.15
        elif d == "swim":
            if tn["ds"]["swim"] <= 1: s -= 0.3
            if prof in ("surcharge_musculaire", "fatigue_aiguë", "récupération_incomplète"): s += 0.3
        else:
            if tn["ds"]["strength"] <= 1: s -= 1.0
            elif tn["ds"]["strength"] == 2: s -= 0.4
            if tn["ds"]["strength"] >= 4 and faf >= 0.85: s += 0.3
            if fam["strength"] == "plyo" and rc["legs_24h"]: s -= 0.5
        if plan: s += plan["bonus"].get(d, 0.0)
        if d in wk_day: s += WEEK_BONUS                # fidélité au schéma de « Cette semaine » ; forme, fatigue et douleurs gardent le dernier mot
        elif wk_day and d in ("run", "bike", "swim"): s -= WEEK_OFF
        score[d] = s + (PB.h(D, "rank." + d) % 1000) / 1e5     # départage déterministe
    order = sorted(score, key=score.get, reverse=True)
    # « Cette semaine » fait foi : la discipline prévue passe devant, sauf contre-indication nette (séance dure la veille, surcharge, douleur)
    def pen(d):                                        # contre-indications du jour seules (sans les bonus de plan ni de semaine)
        if d == "run": return (-0.9 if rc["run_hard24"] else 0) + (-0.6 if prof in ("surcharge_musculaire", "fatigue_aiguë") else 0)
        if d == "bike": return -0.7 if rc["bike_hard24"] else 0
        if d == "swim": return 0
        return (-1.0 if tn["ds"]["strength"] <= 1 else 0) + (-0.5 if fam["strength"] == "plyo" and rc["legs_24h"] else 0)
    ok_wk = [d for d in order if d in wk_day and pen(d) > -WEEK_VETO]
    if ok_wk: order = ok_wk + [d for d in order if d not in ok_wk]
    rec = [order[0]]
    sec = order[1] if len(order) > 1 else order[0]
    lv = lambda d: FAM_LVL[fam[d]]
    if ok_wk:
        if len(ok_wk) > 1: rec.append(ok_wk[1])         # deux séances prévues ce jour-là (footing + musculation) : les deux sont conseillées
    elif sec != order[0] and score[sec] >= score[order[0]] - 0.45 and (sec == "strength" or lv(order[0]) <= 2 or lv(sec) <= 2) and not (lv(order[0]) >= 4 and lv(sec) >= 3):
        rec.append(sec)
    # famille de course et type de musculation de la semaine, plafonnés par la forme du jour (jamais plus intense que le plafond)
    st_wk = None
    for it in sched:
        if it["s"] == "run" and it.get("fam") in FAM_LVL and "run" in rec and ok_wk:
            # le planificateur garde la main sur le dosage (quota de séances clés, progressivité, phase) : on n'échange qu'une séance clé
            # contre la séance clé prévue ce jour-là, autorisée dans la phase et sous le plafond de forme
            f, cur, phase_r = it["fam"], fam["run"], ph.get("run") or "developpement"
            if it.get("report") and f in PLN.ALLOWED.get(phase_r, set()) and FAM_LVL.get(f, 1) <= cap_level("run"):
                fam["run"] = f                               # v6 : séance clé du mardi non réalisée -> reportée aujourd'hui (forme suffisante)
            elif FAM_LVL.get(cur, 1) >= 3 and FAM_LVL.get(f, 1) >= 3 and f in PLN.ALLOWED.get(phase_r, set()) and FAM_LVL.get(f, 1) <= cap_level("run") \
                    and not (f == "long" and plan and not (plan.get("long_cap") or {}).get("run")):
                fam["run"] = f
        if it["s"] == "strength" and it.get("st") in ("push", "pull", "legs") and "strength" in rec: stype = st_wk = it["st"]
    return fam, rec, {"stype": stype, "skipped": skipped, "seen": seen, "plan": plan, "order": order, "sched": sched, "st_wk": st_wk}

DISC_LABEL_FR = {"run": "course à pied", "bike": "vélo", "swim": "natation", "strength": "musculation"}


def _easier(f, level):
    """Famille plus douce : niveau 2 = récupération, niveau 1 = endurance au plus."""
    if level >= 2: return "recup"
    return f if f in ("recup", "z2", "taper") else "z2"


def _pain_filter(lst, e):
    """Séances de la famille compatibles avec les douleurs : écarte celles à éviter, favorise celles conseillées (si au moins une existe)."""
    txt = lambda s: (s["name"] + " " + s["main"]).lower()
    ok = [s for s in lst if not any(x in txt(s) for x in e["avoid"])] if e["avoid"] else lst
    ok = ok if len(ok) >= 2 else lst
    pf = [s for s in ok if any(x in txt(s) for x in e["prefer"])] if e["prefer"] else []
    return pf or ok


def _pain_note(e):
    """Résumé court d'une discipline touchée : volume et douleurs concernées (le détail est dans chaque partie de la séance)."""
    labs = [f"{it['lab']} ({it['int']}/10)" for it in sorted(e["items"], key=lambda x: (-x["sev"], x["lab"]))]
    txt = ("Douleurs concernées : " + ", ".join(labs) + ".") if labs else ""
    if e["vol"] < 0.99: txt = f"Volume ramené à {round(e['vol'] * 100)} % du volume prévu. " + txt
    return txt.strip()


def _pain_blocks(blocks, e):
    """Insère l'adaptation douleur DANS chaque partie de la séance concernée (échauffement, corps, retour au calme) :
    chaque partie reçoit un conseil propre à cette partie et à la discipline, jamais d'une autre discipline."""
    if not e["items"]: return blocks
    its = sorted(e["items"], key=lambda x: (-x["sev"], x["lab"]))[:3]
    cap = lambda s: s[0].upper() + s[1:]
    lim = {"light": "la douleur doit rester ≤ 3/10 et disparaître sous 24 h", "moderate": "si la douleur dépasse 3/10, arrête ou passe en souple", "acute": "arrête dès la première gêne"}
    add = {"Échauffement": [f"🩹 {cap(i['z'])} : {i['warm']}" for i in its],
           "Corps de séance": [f"🩹 {cap(i['z'])} : {i['tip'].rstrip('.')} ({lim[i['lv']]})." for i in its],
           "Retour au calme": [f"🩹 {cap(i['z'])} : {i['relief']}" for i in its]}
    out = []
    for b in blocks:
        out.append([b[0], b[1] + " " + " ".join(add[b[0]])] if b[0] in add else b)
    return out


LOWER, UPPER = {"hanche", "cuisse", "genou", "tibia", "mollet", "cheville", "pied"}, {"epaule", "coude", "poignet"}


def muscu_pain(m, pn):
    """Musculation et douleurs : évite le type de séance qui sollicite la zone douloureuse (douleur modérée ou aiguë), puis annote chaque
    séance du programme (muscu_pain.py) : une douleur n'est mentionnée que si les exercices de la séance sollicitent sa zone."""
    if not pn["any"]: return m
    hit = [a for a in pn["actives"] if a["level"] in ("moderate", "acute")]
    bad = set()
    for a in hit:
        if a["region"] in LOWER or a["region"] == "lombaires": bad.add("legs")
        if a["region"] in UPPER: bad |= {"push", "pull"}
    if m["default"] in bad:
        order = ["push", "pull", "legs"]
        alt = next((t for t in order[order.index(m["default"]) + 1:] + order[:order.index(m["default"])] if t not in bad), None)
        if alt:
            m = dict(m, default=alt, reason=m["reason"] + f" Douleur en cours : {m['types'][m['default']]['label']} est remplacé par {m['types'][alt]['label']} pour épargner la zone.")
    e = pn["effects"]["strength"]
    note = MP.annotate(m, pn)
    if note or e["excluded"]:
        m = dict(m, pain=("Séance à éviter aujourd'hui : " + e["reason"] + ". " if e["excluded"] else "") + note)
    return m


def suggestions(acts, days, T, goals, ath, Z, preds, ctx, st, D, pn=None, plan_mem=None):
    v = phrase_vars(st)
    faf, prof = st["faf"], st["profile"]
    rs = st.get("ress")                                   # bilan d'hier soir (ressenti.py) : statut, créneau, textes
    stt = (rs or {}).get("statut") or {}
    sick, vac, rep = stt.get("cur") == "malade", stt.get("cur") == "vacances", stt.get("reprise")
    dispo = rs.get("dispo") if rs else None
    if sick: dispo = 30 if dispo is None or dispo > 30 else dispo          # malade : récupération courte, 30 min au plus
    low_e = bool(rs and rs.get("cur") and (rs["cur"].get("energie") or 3) <= 2)
    allowed = set(stt.get("sports") or [])
    if "trail" in allowed: allowed.add("run")
    stat_vol = 0.5 if sick else 0.7 if vac else (rep["vol"] if rep else 1.0)
    fam, rec, extra = plan_day(st, T, goals, D, acts, plan_mem)
    plan = extra.get("plan")
    if sick:                                     # malade : récupération seulement (et mobilité)
        for d in ("run", "swim", "bike"): fam[d] = "recup"
        rec = [d for d in ("bike", "run", "swim") if d in fam][:1]
    elif vac or rep:                             # vacances : pas de séance maximale ; reprise : intensité plafonnée par paliers
        cap = 3 if vac else rep["lvl"]
        for d in ("run", "swim", "bike"):
            if FAM_LVL.get(fam[d], 2) > cap: fam[d] = "aerobe" if cap >= 3 else "z2" if cap == 2 else "recup"
    if vac:
        order = extra.get("order") or rec
        rec = [d for d in rec if d in allowed] or [d for d in order if d in allowed][:1]
    pn = pn if pn is not None else PAIN.evaluer([], T)
    fx, subst = pn["effects"], None
    if pn["any"]:
        removed = [d for d in rec if fx[d]["excluded"]]
        rec = [d for d in rec if not fx[d]["excluded"]]
        if removed and not any(d in ("run", "bike", "swim") for d in rec):     # discipline d'endurance retirée : discipline portée la moins touchée à la place
            ok = [d for d in PAIN.substitute_order(pn) if d in ("run", "bike", "swim")] or PAIN.substitute_order(pn)
            subst = ok[0] if ok else None
            rec = ([subst] if subst else []) + [d for d in rec if d != subst][:1]
        for d in ("run", "swim", "bike"):
            if fx[d]["easy"]: fam[d] = _easier(fam[d], fx[d]["easy"])
            if d == subst and fam[d] not in ("recup", "z2"): fam[d] = "z2"
    band, band_label = faf_band(faf)
    css = ZF.swim_css(acts, T, ath.get("swim_css_s_100m"))
    try:
        import detail_analysis as DA
        _sw = [(a.get("x") or {}).get("swim") for a in acts if a["s"] == "swim" and (a.get("x") or {}).get("swim") and a["d"] >= (T - timedelta(days=120)).isoformat()]
        _c = DA.css_from(_sw)
        if _c: css = {"css": _c, "src": "séries détaillées", "n": len(_sw)}
    except Exception:  # noqa: BLE001
        pass
    ath_z = dict(ath, swim_css_s_100m=css["css"])
    zv = SL.zone_vars(Z, ath_z, faf)
    # v5 : créneau habituel (config) quand le bilan du soir ne donne pas de créneau : 1 h 30 en semaine, 3 h le jour long du week-end
    dispo_src = "soir" if dispo is not None else None
    if dispo is None and not sick:
        dm = ath.get("day_minutes") or (60, 90)
        dispo = (ath.get("long_day_minutes") or 180) if PLN.long_day(T, ath) else dm[1]
        dispo_src = "habituel"
    rides = [x for x in acts if x.get("s") == "bike" and (x.get("m") or 0) >= 30 and (x.get("km") or 0) > 0 and x.get("d", "") >= (T - timedelta(days=120)).isoformat()]
    bike_kmh = None
    if len(rides) >= 2:
        bike_kmh = max(18.0, min(38.0, sum(x["km"] for x in rides) / sum(x["m"] for x in rides) * 60))
    if not PF.all_on():                          # sports choisis dans Paramètres
        rec = [d for d in rec if PF.ok(d)] or [d for d in ("run", "bike", "swim", "strength") if PF.ok(d)][:1] or rec
    cards = []
    muscu = muscu_pain(muscu_block(acts, T, st, plan.get("legs_guard") if plan else None, extra.get("st_wk")), pn)
    for d in ("run", "swim", "bike", "strength"):
        if not PF.ok(d): continue                 # discipline non pratiquée (Paramètres) : pas de carte
        if d == "strength" and vac and "strength" not in allowed:
            cards.append({"id": d, "cat": DISC_FR[d], "title": f"{DISC_FR[d]} : en pause pendant les vacances", "meta": "Vacances · non disponible", "rec": False, "vac": True,
                          "why": "Pas de salle ni de matériel là où tu es.", "blocks": [["Pourquoi", "Tu ne l'as pas cochée dans les sports possibles en vacances (bilan du soir)."]], "blocked": True, "_dur": 0})
            continue
        if d == "strength":      # musculation : séance du programme Push/Pull/Legs (30 séances), voir muscu_block()
            ps, blocks = strength_card_blocks(muscu)
            tl = muscu["types"][muscu["default"]]
            if fx["strength"]["excluded"] and pn["any"]:
                cards.append({"id": d, "cat": DISC_FR[d], "title": f"{DISC_FR[d]} : à éviter aujourd'hui", "meta": "Douleur · " + fx["strength"]["reason"], "rec": False,
                              "why": "Repos de la zone douloureuse.", "blocks": [["Pourquoi", muscu.get("pain", "")]], "blocked": True, "_dur": 0})
                continue
            why = PB.pick(PB.CUES[band], D, "cue.strength", dict(v, dur=ps["min"], dur_base=ps["min"])) if d in rec else ""
            why = (why + " " if why else "") + muscu["reason"]
            if plan and d in rec and plan["phase"].get("strength") == "affutage": why += " Affûtage en cours : séance de force réduite, sans fatigue résiduelle."
            if vac or rep:
                blocks = list(blocks) + [["Situation", ("Vacances : " if vac else f"Reprise, jour {rep['jour']} sur {rep['total']} : ") + f"fais environ {round(stat_vol * 100)} % des séries prévues, sans aller à l'échec."]]
            if dispo and ps["min"] > dispo + 5:
                blocks = list(blocks) + [["Créneau", f"Séance de {ps['min']} min pour un créneau de {RS.dispo_fr(dispo)} indiqué hier soir : enchaîne les exercices dans l'ordre et arrête-toi à l'heure."]]
            cards.append({"id": d, "cat": DISC_FR[d], "title": f"{tl['label']} {ps['n']:02d} · {ps['title']}",
                          "meta": f"{ps['min']} min · {len(ps['ex'])} exercices · {tl['level']}", "rec": d in rec, "why": why, "blocks": blocks, "_dur": ps["min"]})
            continue
        if (d, fam[d]) not in SL.LIB: fam[d] = "z2"
        if vac and d not in allowed:             # vacances : sport non disponible là où tu es
            alt = [DISC_LABEL_FR[x] for x in ("run", "swim", "bike", "strength") if x in allowed]
            cards.append({"id": d, "cat": DISC_FR[d], "title": f"{DISC_FR[d]} : en pause pendant les vacances", "meta": "Vacances · non disponible", "rec": False, "vac": True,
                          "why": "Pas possible là où tu es en ce moment.", "blocks": [["Pourquoi", "Tu ne l'as pas coché dans les sports possibles en vacances (bilan du soir)."],
                          ["À la place", ("Sports possibles : " + ", ".join(alt) + ".") if alt else "Aucun sport disponible : marche, baignade ou vélo de balade pour le plaisir, et mobilité."]], "blocked": True, "_dur": 0})
            continue
        if pn["any"] and fx[d]["excluded"]:      # discipline à éviter : repos de la zone, pas de séance proposée
            e = fx[d]
            alt = [DISC_LABEL_FR[x] for x in PAIN.substitute_order(pn) if x != d]
            cards.append({"id": d, "cat": DISC_FR[d], "title": f"{DISC_FR[d]} : à éviter aujourd'hui", "meta": "Douleur · " + e["reason"], "rec": False,
                          "why": "Repos de la zone douloureuse : cette discipline la sollicite trop pour le moment.",
                          "blocks": [["Pourquoi", f"La douleur « {e['reason']} » rend cette discipline inadaptée aujourd'hui."],
                                     ["À la place", ("Reste actif avec : " + ", ".join(alt) + " (séance facile, sans douleur).") if alt else "Repos complet aujourd'hui."],
                                     ["Adaptation douleur", _pain_note(e)]], "blocked": True, "_dur": 0})
            continue
        lst = SL.LIB[(d, fam[d])]
        if sick: lst = [s_ for s_ in lst if not s_["n0"]] or lst          # malade : récupération continue, sans répétitions
        if pn["any"] and (fx[d]["avoid"] or fx[d]["prefer"]): lst = _pain_filter(lst, fx[d])
        vol, note = 1.0, ""
        if plan and fam[d] == "long":      # sortie longue : durée croissante avec l'avancement de la préparation, plafonnée par la distance de l'objectif
            cap = plan["long_cap"].get(d) or 10 ** 9
            ls = sorted([s_ for s_ in lst if s_["min"] <= cap] or lst[:1], key=lambda s_: s_["min"])
            want = set(plan.get("tags", {}).get(d) or ())
            fit = [s_ for s_ in ls if not s_["tags"] or s_["tags"] & want] if want else ls     # séances propres à une autre épreuve écartées
            ls = fit if len(fit) >= 3 else ls
            sess = ls[int(round(plan["prog"].get(d, 0.3) * (len(ls) - 1)))]
            # v5 : la sortie longue progresse depuis ta plus longue sortie récente (+8 % visés, +10 % au plus), plus selon un calendrier fixe
            if d == "run":
                lmax = ZF.last_longest(acts, T, "run", 30)
                tgt = max(10.0, 1.08 * lmax) if lmax >= 6 else 10.0
                up_ = [s_ for s_ in ls if SL.est_km("run", "long", s_["min"], Z) >= tgt]
                sess = min(up_, key=lambda s_: s_["min"]) if up_ else max(ls, key=lambda s_: s_["min"])
            elif d == "bike":
                lmin = ZF.last_longest(acts, T, "bike", 30)
                tgt = max(90.0, min(1.15 * lmin, cap)) if lmin else 120.0
                up_ = [s_ for s_ in ls if s_["min"] >= tgt]
                sess = min(up_, key=lambda s_: s_["min"]) if up_ else max(ls, key=lambda s_: s_["min"])
        else:
            want = plan.get("tags", {}).get(d) if plan else None
            sess = SL.pick(lst, want, PB.h("", f"sess.{d}.{fam[d]}") + T.toordinal())      # décalage fixe + n° du jour ; séances de l'épreuve visée en priorité
        pvol = fx[d]["vol"] if pn["any"] else 1.0                # part « douleur » du volume
        vol_f = min(plan["vol"].get(d, 1.0) if plan else 1.0, stat_vol)     # part « forme / plan / statut » du volume (plafonds : le plus bas s'applique)
        spike = ""
        if fam[d] == "long":
            vol_f = stat_vol                                     # v5 : la sortie longue choisie selon l'avancement n'est pas rabotée par la phase
            if d == "run":                                       # garde-fou : pas plus de 10 % au-delà de la plus longue sortie des 30 derniers jours
                lmax = ZF.last_longest(acts, T, "run", 30)
                km_est = SL.est_km("run", "long", sess["min"], Z)
                if lmax >= 6 and km_est > 1.10 * lmax:
                    vol_f = min(vol_f, max(0.5, 1.10 * lmax / km_est))
                    spike = (f"Garde-fou de progression : au plus {SL.fmt_km(round(1.10 * lmax * 2) / 2)} aujourd'hui, soit 10 % de plus que ta plus longue sortie "
                             f"des 30 derniers jours ({SL.fmt_km(round(lmax * 2) / 2)}) ; au-delà, le risque de blessure de surcharge augmente nettement.")
        if d in ("run", "bike", "swim") and FAM_LVL.get(fam[d], 1) >= 4 and fam[d] not in ("long", "taper"):
            try:
                import detail_analysis as DA
                pg = DA.progression(acts, T, d, fam[d])
            except Exception:  # noqa: BLE001
                pg = None
            try:
                _fs = DA.fatigue_signal(acts, T)
            except Exception:  # noqa: BLE001
                _fs = None
            if pg and pg["out"] == "margin" and faf >= 0.9 and not (_fs and _fs.get("flag")):
                vol_f = min(vol_f * 1.1, 1.15)
                note = (note + f" Dernières séries ({pg['label']}) tenues avec marge : une répétition de plus.").strip()
            elif pg and pg["out"] == "struggle":
                vol_f = min(vol_f, 0.95)
                note = (note + f" Dernières séries ({pg['label']}) difficiles en fin de séance : même volume, allure tenue avant d'ajouter.").strip()
        if plan and vol_f < 1.0 and plan["phase"].get(d) in ("affutage", "reprise", "recuperation", "jour_j"):
            note = f"Phase « {PLN.PHASE_FR[plan['phase'][d]].lower()} » : volume à {round(vol_f * 100)} % du volume de référence."
        if spike: note = (note + " " + spike).strip()
        r0 = SL.render(sess, zv, faf, vol=vol_f, note=note)       # séance sans douleur : sert à attribuer chaque adaptation à sa cause
        r = SL.render(sess, zv, faf, vol=vol_f * pvol, note=note) if pvol < 1.0 else r0
        cren, r0_form, r0_pre_name = "", r0, r0["name"]
        long_exc = (d == "bike" and fam[d] == "long" and plan and plan["phase"].get("bike") == "specifique"
                    and "fondo" in (plan.get("tags", {}).get("bike") or []) and dispo_src == "habituel")
        if long_exc:
            r["blocks"].append(["Créneau exceptionnel", f"Sortie de {r['dur']} min, au-delà de ton créneau habituel de 3 h : à caler un week-end. "
                                "Pour une épreuve de 8 à 10 h, 3 ou 4 sorties de 4 à 5 h en mai sont nécessaires."])
        if dispo and r["dur"] > dispo + 2 and not long_exc:                       # créneau indiqué hier soir : séance plus courte de la même famille, sinon volume réduit
            old = r["dur"]
            if r0["dur"] > dispo * 1.25 and fam[d] != "long":
                short = [s_ for s_ in lst if s_["min"] <= dispo * 1.1]
                if not short:                                    # aucune séance assez courte : la plus courte de la famille, réduite ensuite
                    mn = min(s_["min"] for s_ in lst)
                    short = [s_ for s_ in lst if s_["min"] == mn and mn < sess["min"]]
                if short:
                    sess = SL.pick(short, plan.get("tags", {}).get(d) if plan else None, PB.h("", f"sess.{d}.{fam[d]}") + T.toordinal())
                    r0 = r0_form = SL.render(sess, zv, faf, vol=vol_f, note=note)
                    r = SL.render(sess, zv, faf, vol=vol_f * pvol, note=note) if pvol < 1.0 else r0
            if r["dur"] > dispo + 2:
                k = dispo / r["dur"]
                r0 = SL.render(sess, zv, faf, vol=vol_f * k, note=note)
                r = SL.render(sess, zv, faf, vol=vol_f * pvol * k, note=note) if pvol < 1.0 else r0
            if r["dur"] < old:
                how = "séance plus courte de la même famille" if r0_form["name"] != r0_pre_name else "volume réduit"
                if r0_form["name"] != r0_pre_name and r0["dur"] < r0_form["dur"]: how += ", volume réduit"
                cren = (f"Créneau de {RS.dispo_fr(dispo)} indiqué hier soir" if dispo_src == "soir" else f"Créneau habituel de {RS.dispo_fr(dispo)}") + f" : {how} ({old} min prévues, {r['dur']} min retenues)."
        form = bool(r0["dur"] != r0["dur_base"] or (r0["n"] and r0["n"] != r0["n0"]) or note or cren)
        if cren:            # l'adaptation « forme et plan » est décrite avant la réduction due au créneau (expliquée dans son propre bloc)
            ad = next((b for b in r0_form["blocks"] if b[0] == "Adaptation du jour"), None)
            r["blocks"] = [(ad if b[0] == "Adaptation du jour" else b) for b in r["blocks"] if b[0] != "Adaptation du jour" or ad]
        else:
            r["blocks"] = [b if b[0] != "Adaptation du jour" else r0["blocks"][-1] for b in r["blocks"]]     # ce bloc ne décrit que la forme et le plan
        pnote = _pain_note(fx[d]) if pn["any"] else ""
        if pnote:
            if r["dur"] != r0["dur"]: pnote += f" Durée ramenée de {r0['dur']} à {r['dur']} min."
            r["blocks"] = _pain_blocks(r["blocks"], fx[d])
            r["blocks"].append(["Adaptation douleur", pnote])
        if cren: r["blocks"].append(["Créneau", cren])
        tid = st.get("tid")
        if d == "run" and fam[d] in ("recup", "z2", "long") and tid and (tid["easy"] < 0.70 or tid["n_fast_easy"]) and Z and Z.get("hr"):
            fe = tid["fast_easy"][-2:]
            ex = (" Récemment : " + ", ".join(f"« {x['nm']} » le {x['d'][8:]}/{x['d'][5:7]} à {x['hr']:.0f} bpm" for x in fe) + ".") if fe else ""
            r["blocks"].append(["Intensité", f"Sur 28 jours, {tid['easy'] * 100:.0f} % de ton temps de course est en facile (repère 75-80 %).{ex} "
                                f"Aujourd'hui, garde la FC sous {Z['hr']['Z2']['hi']} bpm, même si l'allure te paraît lente : c'est ce qui rend les séances dures efficaces."])
        if sick: r["blocks"].append(["Situation", "Malade : récupération très facile seulement, 30 minutes au plus, à arrêter au moindre doute. Sinon, repos et mobilité douce."])
        elif vac: r["blocks"].append(["Situation", "Vacances : volume réduit à 70 % de la normale et pas de séance maximale, pour entretenir la forme sans fatigue."])
        elif rep: r["blocks"].append(["Situation", f"Reprise après {rep['len']} jour(s) {'malade' if rep['from'] == 'malade' else 'de vacances'} : jour {rep['jour']} sur {rep['total']}, volume à {rep['pct']} %, "
                                      + {2: "endurance seulement." , 3: "endurance active autorisée.", 4: "travail spécifique autorisé, sans séance maximale."}[rep["lvl"]]])
        if sick or vac or rep: form = True
        why = ""
        if d in rec:
            why = PB.pick(PB.CUES[band], D, f"cue.{d}", dict(v, dur=r["dur"], dur_base=r["dur_base"]))
            if plan:
                jt = PLN.justification(plan, d, fam[d])
                if jt: why = (why + " " if why else "") + jt
        cat = "Trail" if fam[d] == "trail" else DISC_FR[d]
        meta = r["meta"]
        if (cren or sick or vac or rep) and re.search(r"\b\d+ min\b", r["name"]):       # titre cohérent avec la durée retenue (« Sortie plate 60 min » ramenée à 20 min)
            r["name"] = re.sub(r"\b\d+ min\b", f"{r['dur']} min", r["name"], count=1)
        if d in ("run", "bike"):
            km = SL.est_km(d, fam[d], r["dur"], Z, bike_kmh)
            if km: meta += f" · ≈\u202f{SL.fmt_km(km)} estimés"
        if pnote and d in rec: why = (why + " " if why else "") + "Séance adaptée à ta douleur en cours."
        cards.append({"id": d, "cat": cat, "title": r["name"], "meta": meta, "form": form, "pain": bool(pnote), "rec": d in rec, "why": why, "blocks": r["blocks"], "_dur": r["dur"], "fam": fam[d]})
    rest = dispo == 0 or (sick and low_e) or (vac and not allowed)     # repos choisi, malade sans énergie, vacances sans sport : aucune séance
    if rest:
        for c in cards: c["rec"] = False
        rec = []
    elif sick or vac:                            # séance conseillée choisie plus haut (récupération / sport disponible)
        for c in cards: c["rec"] = c["id"] in rec and not c.get("blocked")
        rec = [c["id"] for c in cards if c["rec"]]
    if dispo and not rest:                       # créneau : pas de séance complémentaire qui ne tient pas dedans
        ch_ = [c for c in cards if c["rec"]]
        if len(ch_) >= 2 and ch_[0]["_dur"] + ch_[1]["_dur"] > dispo + 10:
            for c in ch_[1:]: c["rec"] = False
            rec = [ch_[0]["id"]]
        if ch_ and ch_[0]["id"] == "strength" and ch_[0]["_dur"] > dispo + 10:     # musculation trop longue : la meilleure séance d'endurance qui tient
            alt = next((c for c in cards if c["id"] != "strength" and not c.get("blocked") and c["_dur"] <= dispo + 5), None)
            if alt:
                ch_[0]["rec"], alt["rec"] = False, True
                rec = [alt["id"]]
    rc, hrv, sl, ld, sb = st["recent"], st["hrv"], st["sleep"], st["load"], st["sb"]
    context = []
    if rs: context.append(RS.context_line(rs))
    for i, lab in enumerate(["Aujourd'hui", "Hier", "Avant-hier"]):
        L = rc["days"][i]
        context.append(f"{lab} : " + (" + ".join(f"{SPORT_FR[x['s']].lower()} {f1(x['km']) + ' km' if x['km'] else str(round(x['m'])) + ' min'} ({x['_i']}, charge {x['ld']:.0f})" for x in L) if L else "repos"))
    if hrv["val"] is not None and hrv["base"]:
        sl_txt = ""
        if hrv["slope_pct_day"] is not None:
            sl_txt = ", tendance en hausse" if hrv["slope_pct_day"] > 0.8 else ", tendance en baisse" if hrv["slope_pct_day"] < -0.8 else ", tendance stable"
        m7 = f", moyenne 7 jours à {(hrv['r7'] - 1) * 100:+.0f} %{sl_txt}" if hrv["r7"] else ""
        context.append(f"VFC : {hrv['val']:.0f} ms pour une base de {hrv['base']:.0f} ms ({v['hrv_pct']}){m7}")
    else:
        context.append("VFC : non disponible (ou historique insuffisant pour calculer une base)")
    if sl["score"] is not None or sl["h"] is not None:
        ph = f" · profond {sl['deep_pct']:.0f} %, REM {sl['rem_pct']:.0f} %" if sl["deep_pct"] is not None and sl["rem_pct"] is not None else ""
        scs = f"score {sl['score']:.0f}/100" if sl["score"] is not None else "score n/a"
        context.append(f"Sommeil : {scs} · {f1(sl['h']) + ' h' if sl['h'] else 'durée n/a'}{ph}")
    else:
        context.append("Sommeil : non synchronisé")
    zl = {"sous_entraînement": "fraîcheur, charge en baisse", "zone_douce": "charge habituelle", "surcharge": "fatigue de charge", "surmenage": "forte fatigue de charge"}
    context.append(f"Charge : forme d'entraînement {ld['form'] * 100:+.0f} % ({zl[ld['zone']]}) · {ld['l7']:.0f} sur 7 jours" if ld.get("form") is not None else "Charge : historique insuffisant")
    tid = st.get("tid")
    if tid:
        context.append(f"Intensité en course sur 28 jours : {tid['easy'] * 100:.0f} % facile, {tid['grey'] * 100:.0f} % zone grise, {tid['hard'] * 100:.0f} % dur (repère 75-80 % facile)")
    if sb["stress"] is not None and sb["bb"] is not None:
        context.append(f"Stress moyen {sb['stress']:.0f} · Body Battery max {sb['bb']:.0f}" + (f", recharge {sb['bb_charge']:.0f}" if sb["bb_charge"] is not None else ""))
    else:
        context.append("Stress / Body Battery : partiels")
    context.append(f"Indice de fatigue {st['strain']}/100 · FAF {f1(faf, 2)} ({band_label.lower()})" if st["strain"] is not None else f"FAF {f1(faf, 2)} (par défaut, données insuffisantes)")
    tn = st["needs"]
    needs = []
    too_hard = tn["hard_share"] > TH["hard_share_high"] and tn["n_runs21"] >= 4
    hs_txt = f"{(tid['grey'] + tid['hard']) * 100:.0f} % du temps de course au-dessus de l'endurance sur 28 jours" if tid else f"{tn['hard_share']:.0f} % du temps de course en qualité sur 21 jours"
    if tn["n_ana"] == 0 and not too_hard: needs.append("Anaérobie : aucune séance de vitesse (VMA) sur 21 jours.")
    if tn["n_tempo"] == 0 and not too_hard: needs.append("Seuil : aucune séance tempo ou seuil sur 21 jours.")
    if tn["ds_long"] >= TH["long_gap_days"]:
        needs.append(f"Endurance longue : dernière sortie longue il y a {tn['ds_long']} jours." if tn["ds_long"] < 99 else "Endurance longue : aucune sortie longue (16 km ou plus) enregistrée.")
    if too_hard: needs.append(f"Intensité mal répartie : {hs_txt} (visé : environ 20 %)" + (", sans séance de vitesse (VMA)" if tn["n_ana"] == 0 else "") + " : privilégier l'endurance facile.")
    if tn["vol_ratio"] < TH["aero_vol_ratio_min"]: needs.append(f"Volume : {tn['vol_ratio'] * 100:.0f} % de la cible hebdomadaire de course.")
    if not needs: needs.append("Équilibre aérobie / anaérobie correct sur 21 jours : poursuivre la rotation endurance, seuil, vitesse.")
    for c in st["cross"][:3]: needs.append(PB.pick(PB.CROSS[c], D, f"needs.cross.{c}", v))
    if plan:
        up = [o for o in plan["objs"] if o["days_left"] >= 0]
        if up:
            main = next((o for o in up if o["prio"] == "A"), up[0])
            nxt_o = min(up, key=lambda o: o["days_left"])
            line = f"Préparation : {main['label']} dans {main['days_left']} jours ({PLN.PHASE_FR[main['phase']].lower()})"
            if nxt_o is not main: line += f" ; prochaine échéance : {nxt_o['label']} dans {nxt_o['days_left']} jours (objectif {nxt_o['role']})"
            else:
                autre = next((o for o in up if o is not main and o["prio"] == "A"), None)
                if autre: line += f" ; puis {autre['label']} dans {autre['days_left']} jours (objectif principal)"
            needs.append(line + ".")
    needs.append(PB.pick(PB.DIAG[prof]["advice"], D, "diag.advice", v))
    for name, cap, txt in sorted(st["caps"], key=lambda c: c[1])[:2]: needs.append(f"Plafond du FAF à {f1(cap, 2)} : {name.lower()} ({txt}).")
    for key, msg in (("hrv", "VFC non disponible : le diagnostic repose sur les autres indicateurs."), ("sleep", "Sommeil non disponible : le diagnostic repose sur les autres indicateurs.")):
        if st["comps"][key] is None: needs.append(msg)
    if rs: needs.extend(RS.needs_lines(rs))
    needs = PF.prune(needs)                      # sports non pratiqués (Paramètres) : pas de conseil qui les propose
    brief = coach_brief(rc, hrv, sl, ld, sb, tid, st, tn, faf, band_label, too_hard, plan, prof, D, v)
    if brief and brief.get("points"): brief["points"] = PF.prune(brief["points"])
    rtxt = (RS.seance_text(rs, D) + " ") if rs else ""
    plan_log = PA.log_from_cards(cards, fam, ((plan or {}).get("review") or {}).get("adj"))          # séances conseillées aujourd'hui, conservées pour le bilan hebdomadaire (voir plan_adapt.py)
    chosen = [c for c in cards if c["rec"]]
    if not chosen:
        if sick:
            decision, head = "Malade et énergie au plus bas : repos complet aujourd'hui, seulement la mobilité douce.", "repos : malade"
        elif vac and not allowed:
            decision, head = "Vacances sans sport disponible : repos actif (marche, baignade, balade à vélo) et mobilité.", "vacances : repos actif"
        elif dispo == 0:
            decision, head = "Repos choisi hier soir : aucune séance aujourd'hui, une mobilité douce de 15 minutes suffit.", "repos choisi"
        else:
            decision, head = "Aucune séance d'endurance n'est conseillée aujourd'hui : repos de la zone douloureuse (marche, mobilité douce).", "repos de la zone douloureuse"
        why = PB.pick(PB.DIAG[prof]["head"], D, "diag.head", v) + " " + rtxt + decision
        for c in cards: c.pop("_dur", None)
        return {"context": context, "needs": needs, "brief": brief, "why": why, "rec": rec, "headline": head, "cards": cards, "hard_share": tn["hard_share"], "muscu": muscu, "plan": plan, "plan_log": plan_log,
                "pain": {"any": pn["any"], "panel": pn["panel"], "alerts": pn["alerts"]}}
    decision = f"Séance retenue : {chosen[0]['title']} ({chosen[0]['cat'].lower()}, {chosen[0]['_dur']} min), adaptée au FAF de {f1(faf, 2)}."
    if sick: decision += " Avec la mobilité douce du jour, c'est tout pour aujourd'hui."
    if len(chosen) > 1: decision += f" En complément : {chosen[1]['title']} ({chosen[1]['cat'].lower()}, {chosen[1]['_dur']} min)."
    why = PB.pick(PB.DIAG[prof]["head"], D, "diag.head", v) + " " + rtxt + decision
    headline = " + ".join(f"{c['cat']} : {c['title']}" for c in chosen)
    for c in cards: c.pop("_dur", None)
    return {"context": context, "needs": needs, "brief": brief, "why": why, "rec": rec, "headline": headline, "cards": cards, "hard_share": tn["hard_share"], "muscu": muscu, "plan": plan, "plan_log": plan_log,
            "pain": {"any": pn["any"], "panel": pn["panel"], "alerts": pn["alerts"]}}


# =============================================================================================
# 10. POINT D'ENTRÉE
# =============================================================================================
def sanitize(acts, days):
    """Garde-fou d'entrée : valeurs numériques absentes ou invalides -> 0 pour les champs de volume ; activités sans date valide ignorées ;
    valeurs de bien-être non numériques (texte, NaN, infini) -> absentes. Les données de la montre ne doivent jamais faire échouer l'analyse."""
    def num(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
    out = []
    for x in acts or []:
        if not isinstance(x, dict): continue
        try:
            date.fromisoformat(str(x.get("d"))[:10])
        except ValueError:
            continue
        y = dict(x)
        for k in ("km", "m", "hr", "el", "ld"):
            if not num(y.get(k)): y[k] = 0
        for k in ("te", "vo2", "pw", "cal"):
            if y.get(k) is not None and not num(y.get(k)): y[k] = None
        y.setdefault("s", "other")
        out.append(y)
    dd = {}
    for k, v in (days or {}).items():
        if isinstance(v, dict): dd[k] = {kk: (vv if (vv is None or num(vv)) else None) for kk, vv in v.items()}
    return out, dd


def coach_brief(rc, hrv, sl, ld, sb, tid, st, tn, faf, band_label, too_hard, plan, prof, D, v):
    """Version courte de « Contexte des derniers jours » et « Besoins identifiés » pour l'app : quelques repères chiffrés
    (tuiles) et au plus quatre points à retenir. Mêmes données que les listes complètes, qui restent consultables."""
    facts = []
    for i, lab in ((1, "Hier"), (2, "Avant-hier")):
        L = rc["days"][i]
        if L:
            x = max(L, key=lambda y: y["ld"] or 0)
            facts.append([lab, f"{SPORT_FR[x['s']].lower()} " + (f"{f1(x['km'])} km" if x["km"] else f"{round(x['m'])} min"),
                          (x["_i"] + (f" · +{len(L) - 1} séance" + ("s" if len(L) > 2 else "") if len(L) > 1 else "")), "hard" if x["_i"] == "dur" else ""])
        else:
            facts.append([lab, "repos", "", ""])
    if hrv["val"] is not None and hrv["base"]:
        pct = (hrv["val"] / hrv["base"] - 1) * 100
        facts.append(["VFC", f"{hrv['val']:.0f} ms", f"{pct:+.0f} % / ta base".replace("-", "−"), "bad" if pct <= -10 else "good" if pct >= 5 else ""])
    if sl["h"] is not None or sl["score"] is not None:
        facts.append(["Sommeil", f"{f1(sl['h'])} h" if sl["h"] else "—", f"score {sl['score']:.0f}" if sl["score"] is not None else "",
                      "bad" if (sl["score"] or 100) < 60 or (sl["h"] or 9) < 6 else ""])
    if ld.get("form") is not None:
        zl = {"sous_entraînement": "en baisse", "zone_douce": "habituelle", "surcharge": "élevée", "surmenage": "très élevée"}
        facts.append(["Charge 7 j", f"{ld['l7']:.0f}", zl.get(ld["zone"], ""), "bad" if ld["zone"] in ("surcharge", "surmenage") else ""])
    if sb["stress"] is not None:
        facts.append(["Stress", f"{sb['stress']:.0f}", f"Body Battery {sb['bb']:.0f}" if sb["bb"] is not None else "", "bad" if sb["stress"] >= 40 else ""])
    capn = " ".join(n.lower() for n, c, t in st["caps"])        # une tuile est signalée dès qu'elle explique un plafond du jour (cohérence avec « Ce qui limite »)
    for f in facts:
        if (f[0] == "Sommeil" and "sommeil" in capn) or (f[0] == "VFC" and "vfc" in capn) or (f[0] == "Stress" and "stress" in capn) or (f[0] == "Charge 7 j" and "charge" in capn):
            f[3] = "bad"
    pts = []
    adv = PB.pick(PB.DIAG[prof]["advice"], D, "diag.advice", v)
    if adv: pts.append(["Aujourd'hui", adv])
    caps = sorted(st["caps"], key=lambda c: c[1])
    if caps: pts.append(["Ce qui limite", " · ".join(n[0].upper() + n[1:] for n, c, t in caps[:2])])
    bal = []
    if too_hard: bal.append("trop d'intensité" + (" et aucune séance de vitesse" if tn["n_ana"] == 0 else ""))
    elif tn["n_ana"] == 0 and tn["n_tempo"] == 0: bal.append("ni vitesse ni seuil depuis 3 semaines")
    if tn["ds_long"] >= TH["long_gap_days"]: bal.append("pas de sortie longue récente" if tn["ds_long"] < 99 else "aucune sortie longue")
    if tn["vol_ratio"] < TH["aero_vol_ratio_min"]: bal.append(f"{tn['vol_ratio'] * 100:.0f} % du volume de course visé")
    if bal: pts.append(["Équilibre", bal[0][0].upper() + ", ".join(bal)[1:] + "."])
    if plan:
        up = [o for o in plan["objs"] if o["days_left"] >= 0]
        if up:
            o = min(up, key=lambda x: x["days_left"])
            pts.append(["Objectif", f"{o['label']} dans {o['days_left']} jours · {PLN.PHASE_FR[o['phase']].lower()}"])
    return {"facts": facts[:6], "points": pts[:4], "state": {"faf": faf, "label": band_label, "strain": st["strain"]}}


def build_analysis(acts, days, today, goals, ath, periods, events=None, meta=None, coach_mem=None, pains=None, plan_mem=None, ress=None):
    """ress : bilans du soir ({date: entrée}, ressenti.load) ; None ou vide = analyse identique à celle sans questionnaire."""
    T = date.fromisoformat(today)
    acts, days = sanitize(acts, days)
    calib = calibrate(days, T)                     # seuils personnalisés (avant tout calcul)
    fresh = data_freshness(acts, days, T, meta)
    pcheck = prediction_check(acts, T, goals)
    vo2 = next((x["vo2"] for x in reversed(acts) if x["vo2"]), None)
    first = min([x["d"] for x in acts] + list(days.keys()) + [today])
    preds = predictions(acts, T, goals, vo2, ath=ath)
    fit = ZF.fitness(acts, T, ath, vo2)
    Z = zones(preds, goals, fit, ath)
    P, ctx = pillars(acts, days, T, goals, ath, preds, vo2)
    try:
        rse = RS.evaluate(ress, T, acts) if ress else None          # bilan d'hier soir (jamais bloquant)
    except Exception as e:          # noqa: BLE001
        rse = None; print(f"Bilan du soir ignoré ({type(e).__name__}: {e})")
    st = physio_state(acts, days, T, ath, ctx["km4"], rse)
    try:
        prep = PREP.evaluer(acts, T, goals, preds, st)           # état de préparation par objectif à venir (ordre chronologique)
    except Exception as e:          # noqa: BLE001 : le dashboard doit toujours se générer
        prep = []; print(f"Préparation aux objectifs non calculée ({type(e).__name__}: {e})")
    P[0] = prep_pillar(prep)                                     # le 1er pilier (« Préparation aux objectifs ») reprend le score de chaque objectif
    ok = [p for p in P if p["score"] is not None]
    total = sum(p["score"] for p in ok) / (4 * len(ok)) * 20 if ok else None
    pillars_p = {key: pillars_period(acts, days, T, goals, ath, vo2, n, prep, ress) for key, n in periods.items()}      # note /20 et piliers par période
    stats, synth, bilan = {}, {}, {}
    mem = CM.Memoire(coach_mem, T) if coach_mem is not None else None        # mémoire anti-redondance (None : rotation seule)
    for key, n in periods.items():
        S = period_stats(acts, days, T, n)
        has_prev = (T - timedelta(days=2 * n - 1)).isoformat() >= first
        Sp = period_stats(acts, days, T, n, off=n) if has_prev else None
        stats[key] = {"cur": S, "prev": Sp}
        synth[key] = synthesis(key, n, S, Sp, st, ctx, preds, goals, ath, T, today, pillars_p[key], acts)
    # « Le mot du coach » : chaque période garde SA note (pillars_p) ; son évolution est lue à la lumière des deux autres périodes
    # (coach_croise). La note de la période précédente de même durée ne sert qu'au commentaire, jamais à la note du jour.
    prev_sc = {}
    for key, n in periods.items():
        if (T - timedelta(days=2 * n - 1)).isoformat() >= first:
            try:
                prev_sc[key] = pillars_period(acts, days, T - timedelta(days=n), goals, ath, vo2, n, prep, ress)["score"]
            except Exception:           # noqa: BLE001 : commentaire facultatif
                prev_sc[key] = None
    try:
        cross = CC.preparer(pillars_p, stats, acts, T, prev_sc)
    except Exception as e:              # noqa: BLE001 : le mot du coach reste disponible sans l'évolution croisée
        cross = None; print(f"Évolution croisée du coach indisponible ({type(e).__name__}: {e})")
    rper = {}
    if ress:
        for key, n in periods.items():
            try:
                rper[key] = RS.period(ress, T, n, acts)
            except Exception:           # noqa: BLE001
                rper[key] = None
    for key, n in periods.items():
        feel = RS.feel_blocks(key, st.get("ress"), rper.get(key)) if ress else None
        bilan[key] = bilan_text(key, n, pillars_p[key], st, stats[key]["cur"], stats[key]["prev"], goals, T, today, fresh, mem, cross, feel)
    gl = [dict(g, left=(date.fromisoformat(g["date"]) - T).days) for g in goals]
    for g in gl:
        r = next((p for p in preds if abs(p["dist"] - g["dist"]) < 0.5 and g.get("sport", "run") == "run"), None)
        g["pred"] = r["ret"] if r else None
    try:
        pn = PAIN.evaluer(pains or [], T)          # douleurs actives -> modulation des séances (jamais bloquant)
    except Exception:                          # noqa: BLE001
        pn = PAIN.evaluer([], T)
    sug = suggestions(acts, days, T, goals, ath, Z, preds, ctx, st, today, pn, plan_mem)
    band, band_label = faf_band(st["faf"])
    v = phrase_vars(st)
    rnd = lambda x: None if x is None else (round(x, 3) if isinstance(x, float) else x)
    coach = {"profile": st["profile"], "profile_label": PB.PROFILE_LABEL[st["profile"]], "tags": st["tags"],
             "head": PB.pick(PB.DIAG[st["profile"]]["head"], today, "diag.head", v), "strain_index": st["strain"],
             "form_index": None if st["strain"] is None else 100 - st["strain"], "faf": st["faf"], "faf_base": st["faf_base"],
             "faf_band": band, "faf_label": band_label, "caps": [{"name": c[0], "cap": c[1], "text": c[2]} for c in st["caps"]],
             "comps": {k: (None if c is None else round(c, 2)) for k, c in st["comps"].items()}, "cross": st["cross"],
             "hrv": {k: rnd(x) for k, x in st["hrv"].items() if k != "comp"},
             "sleep": {k: rnd(x) for k, x in st["sleep"].items() if k != "comp"},
             "acwr": rnd(st["load"]["acwr"]), "acwr_zone": st["load"]["zone"], "stress": rnd(st["sb"]["stress"]), "body_battery": st["sb"]["bb"],
             "feel": None if not st.get("ress") else st["ress"]["comp"], "statut": (st.get("ress") or {}).get("statut")}
    return {"today": today, "vo2": vo2, "score": total, "score_label": score_label(total) if total is not None else "",
            "pillars": P, "pillars_p": pillars_p, "prev_sc": prev_sc, "preds": preds, "zones": Z, "stats": stats, "synth": synth, "bilan": bilan, "petit_plus": PP_LIB.du_jour(T), "prep": prep, "goals": gl, "fresh": fresh, "calib": calib, "pred_check": pcheck, "events": build_events(events, pcheck, T),
            "corr": correlations(acts, days, T), "suggest": sug, "pain": {"any": pn["any"], "panel": pn["panel"], "alerts": pn["alerts"]},
            "ctx": {"hrvr": ctx["hrvr"], "acwr": ctx["acwr"], "km4": ctx["km4"], "long6": ctx["long6"]}, "coach": coach,
            "ress": RS.front(ress or {}, st.get("ress"), rper, T),
            "extras": EX.build(acts, T, gl, ath, (sug or {}).get("plan"), st.get("faf"), st.get("strain"), bool((pn or {}).get("any")), ress, plan_mem, sug)}
