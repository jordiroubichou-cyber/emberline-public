"""garmin_details.py — collecte et normalisation des données DÉTAILLÉES de chaque activité Garmin (Emberline v6).

Pour chaque activité (une seule fois, résultat mis en cache par activityId) :
  get_activity                résumé complet : Training Effect, charge, dynamique de course, natation, workoutId…
  get_activity_splits         tours ; en natation, longueurs (nage, mouvements, SWOLF) et repos
  get_activity_typed_splits   intervalles typés (actif, récupération, échauffement…) ; en trail, montées ClimbPro
  get_activity_hr_in_timezones  temps dans chaque zone FC
  get_activity_details        séries temporelles (FC, vitesse, altitude, cadence, puissance…) et tracé GPS
  get_activity_weather        température, humidité, vent
  get_activity_gear           chaussures, vélo
  get_activity_exercise_sets  musculation : exercices, séries, répétitions, charges
Une fois par jour : VO2max, statut d'entraînement, endurance et côtes, prédictions de course, records, seuil lactique, FTP.

Règles :
  - tolérance totale : méthode absente, champ absent ou renommé, 404, format changé → la donnée manque, rien ne casse ;
  - respect de Garmin : pause entre les appels, budget d'activités par exécution, arrêt au premier 429 (reprise ensuite) ;
  - stockage compact : garmin/details/<activityId>.json.gz (séries rééchantillonnées toutes les 5 s, tracé simplifié) ;
  - confidentialité : GPS_MODE de config.py — "crop" (300 m coupés au début et à la fin), "full" ou "off".
"""
import gzip
import json
import math
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

SCHEMA = 1                 # version du format normalisé ; une version plus récente redemande l'activité
PAUSE_S = 1.1              # pause entre deux appels
RETRY_MAX = 3              # tentatives par activité avant abandon
RESAMPLE_S = 5             # pas des séries temporelles (s)
POLY_MAX = 300             # points du tracé conservés au maximum
CROP_M = 300               # mètres coupés au début et à la fin du tracé en mode "crop"


class RateLimited(Exception):
    pass


# ------------------------------------------------------------------------------------------------- utilitaires
def family_of(type_key):
    t = (type_key or "").lower()
    if any(x in t for x in ("yoga", "pilates", "stretch", "mobility", "breath")): return "other"
    if "trail" in t: return "trail"
    if "multi" in t or "triathlon" in t or "transition" in t: return "multi"
    if "run" in t or "treadmill" in t: return "run"
    if any(x in t for x in ("cycl", "bik", "ride", "virtual_ride", "indoor_cycling")): return "bike"
    if "swim" in t: return "swim"
    if any(x in t for x in ("strength", "fitness_equipment", "hiit", "weight")): return "strength"
    return "other"


def num(v):
    if isinstance(v, bool) or v is None: return None
    if isinstance(v, (int, float)):
        return None if (isinstance(v, float) and (math.isnan(v) or math.isinf(v))) else float(v)
    if isinstance(v, str):
        try: return float(v.replace(",", "."))
        except ValueError: return None
    return None


def pick(d, *keys):
    """Première valeur numérique parmi plusieurs noms possibles (insensible à la casse)."""
    if not isinstance(d, dict): return None
    low = {str(k).lower(): v for k, v in d.items()}
    for k in keys:
        x = num(low.get(k.lower()))
        if x is not None: return x
    return None


def pick_s(d, *keys):
    if not isinstance(d, dict): return None
    low = {str(k).lower(): v for k, v in d.items()}
    for k in keys:
        v = low.get(k.lower())
        if isinstance(v, str) and v: return v
        if isinstance(v, dict):
            for kk in ("typeKey", "key", "desc", "name"):
                if isinstance(v.get(kk), str): return v[kk]
    return None


def find(o, key, depth=0):
    """Recherche récursive d'une clé (insensible à la casse) ; renvoie la première valeur non vide."""
    if depth > 6: return None
    if isinstance(o, dict):
        for k, v in o.items():
            if str(k).lower() == key and v not in (None, "", [], {}): return v
        for v in o.values():
            r = find(v, key, depth + 1)
            if r is not None: return r
    elif isinstance(o, list):
        for v in o[:50]:
            r = find(v, key, depth + 1)
            if r is not None: return r
    return None


def rnd(x, n=1):
    return None if x is None else round(x, n)


def clean(d):
    return {k: v for k, v in d.items() if v not in (None, "", [], {})}


# ------------------------------------------------------------------------------------------------- appels
def detail_calls(fam, aid):
    calls = [("get_activity", (aid,), {}), ("get_activity_splits", (aid,), {}), ("get_activity_typed_splits", (aid,), {}),
             ("get_activity_hr_in_timezones", (aid,), {}), ("get_activity_details", (aid,), {"maxchart": 4000, "maxpoly": 4000}),
             ("get_activity_weather", (aid,), {}), ("get_activity_gear", (aid,), {})]
    if fam in ("strength", "other"):
        calls.append(("get_activity_exercise_sets", (aid,), {}))
    if fam == "swim":
        calls = [c for c in calls if c[0] != "get_activity_weather"] + [("get_activity_split_summaries", (aid,), {})]
    return calls


def global_calls(d):
    d0 = (date.fromisoformat(d) - timedelta(days=28)).isoformat()
    return [("get_max_metrics", (d,)), ("get_training_status", (d,)), ("get_endurance_score", (d0, d)),
            ("get_hill_score", (d0, d)), ("get_race_predictions", ()), ("get_personal_record", ()),
            ("get_lactate_threshold", ()), ("get_cycling_ftp", ()), ("get_heart_rate_zones", ())]


def _is_429(e):
    s = f"{type(e).__name__} {e}".lower()
    return "toomanyrequests" in s or "429" in s or "rate limit" in s


def _call(client, name, *args, **kw):
    fn = getattr(client, name, None)
    if fn is None: return None, "absent"
    try:
        if kw:
            try: return fn(*args, **kw), None
            except TypeError: return fn(*args), None               # ancienne signature sans maxchart/maxpoly
        return fn(*args), None
    except Exception as e:  # noqa: BLE001
        if _is_429(e): raise RateLimited(str(e)[:120])
        s = str(e).lower()
        return None, ("404" if ("404" in s or "notfound" in s.replace(" ", "")) else f"{type(e).__name__}")
    finally:
        time.sleep(PAUSE_S)


# ------------------------------------------------------------------------------------------------- normalisation
def _lap(l):
    d = pick(l, "distance"); t = pick(l, "duration", "elapsedDuration"); v = pick(l, "averageSpeed", "avgSpeed")
    if v is None and d and t: v = d / t
    out = clean({
        "i": pick(l, "lapIndex", "messageIndex"), "d": rnd(d), "t": rnd(t), "mt": rnd(pick(l, "movingDuration")),
        "v": rnd(v, 3), "vmax": rnd(pick(l, "maxSpeed"), 3), "gap": rnd(pick(l, "avgGradeAdjustedSpeed", "averageGradeAdjustedSpeed"), 3),
        "hr": rnd(pick(l, "averageHR", "averageHeartRate")), "hrmax": rnd(pick(l, "maxHR", "maxHeartRate")),
        "cad": rnd(pick(l, "averageRunCadence", "averageRunningCadenceInStepsPerMinute", "averageBikeCadence",
                        "averageBikingCadenceInRevPerMinute", "averageSwimCadence", "averageSwimCadenceInStrokesPerMinute")),
        "pw": rnd(pick(l, "averagePower", "avgPower")), "np": rnd(pick(l, "normalizedPower", "normPower")),
        "up": rnd(pick(l, "elevationGain")), "dn": rnd(pick(l, "elevationLoss")),
        "gct": rnd(pick(l, "groundContactTime", "avgGroundContactTime")), "vo": rnd(pick(l, "verticalOscillation", "avgVerticalOscillation")),
        "sl": rnd(pick(l, "strideLength", "avgStrideLength")), "vr": rnd(pick(l, "verticalRatio", "avgVerticalRatio")),
        "it": pick_s(l, "intensityType", "type"), "step": pick(l, "wktStepIndex", "workoutStepIndex"),
        "stroke": pick_s(l, "swimStroke"), "swolf": rnd(pick(l, "averageSWOLF", "averageSwolf", "avgSwolf")),
        "strokes": pick(l, "totalNumberOfStrokes", "strokes"), "spl": rnd(pick(l, "averageStrokes", "avgStrokes")),
        "len": pick(l, "numberOfActiveLengths", "activeLengths"), "temp": rnd(pick(l, "averageTemperature", "avgTemperature")),
    })
    lens = l.get("lengthDTOs") if isinstance(l, dict) else None
    if isinstance(lens, list) and lens:
        out["lens"] = [clean({"d": rnd(pick(x, "distance")), "t": rnd(pick(x, "duration", "elapsedDuration"), 2),
                              "stroke": pick_s(x, "swimStroke"), "strokes": pick(x, "totalNumberOfStrokes", "strokes"),
                              "swolf": rnd(pick(x, "averageSWOLF", "averageSwolf", "swolf"))}) for x in lens if isinstance(x, dict)]
    return out


def norm_splits(raw):
    L = raw.get("lapDTOs") if isinstance(raw, dict) else raw
    return [_lap(x) for x in (L or []) if isinstance(x, dict)]


def norm_typed(raw):
    L = (raw.get("splits") or raw.get("splitDTOs")) if isinstance(raw, dict) else raw
    out = []
    for x in L or []:
        if not isinstance(x, dict): continue
        r = _lap(x); r["ty"] = pick_s(x, "type", "splitType")
        g = pick(x, "averageGrade", "avgGrade")
        if g is not None: r["grade"] = rnd(g)
        out.append(clean(r))
    return out


def norm_zones(raw):
    L = raw if isinstance(raw, list) else (raw or {}).get("zones") if isinstance(raw, dict) else None
    out = []
    for z in L or []:
        n, s = pick(z, "zoneNumber", "zone"), pick(z, "secsInZone", "seconds")
        if n is not None and s is not None:
            out.append({"z": int(n), "s": round(s), "lo": pick(z, "zoneLowBoundary", "low")})
    return out


def _decode_series(raw):
    """activityDetailMetrics + metricDescriptors -> {clé: [valeurs]}."""
    desc = raw.get("metricDescriptors") or []
    rows = raw.get("activityDetailMetrics") or []
    idx = {}
    for d in desc:
        k, i = d.get("key"), d.get("metricsIndex")
        if isinstance(k, str) and isinstance(i, int): idx[k] = i
    cols = {k: [] for k in idx}
    for r in rows:
        m = r.get("metrics") if isinstance(r, dict) else None
        if not isinstance(m, list): continue
        for k, i in idx.items():
            cols[k].append(num(m[i]) if i < len(m) else None)
    return cols


SER_KEYS = {  # nom compact : clés Garmin possibles
    "hr": ("directHeartRate",), "v": ("directSpeed", "directEnhancedSpeed"), "alt": ("directElevation", "directEnhancedElevation"),
    "cad": ("directDoubleCadence", "directRunCadence", "directBikeCadence", "directSwimCadence"),   # course : pas/min (double cadence) d'abord
    "pw": ("directPower",), "gap": ("directGradeAdjustedSpeed",), "d": ("sumDistance",), "temp": ("directAirTemperature",),
    "vo": ("directVerticalOscillation",), "gct": ("directGroundContactTime",), "sl": ("directStrideLength",),
    "resp": ("directRespirationRate",), "perf": ("directPerformanceCondition",), "stam": ("directCurrentStamina", "directPotentialStamina"),
}


def norm_series(raw, start_ms=None):
    if not isinstance(raw, dict): return {}, []
    cols = _decode_series(raw)
    if not cols: return {}, _poly(raw)
    tt = cols.get("sumDuration") or cols.get("sumElapsedDuration")
    ts = cols.get("directTimestamp")
    n = max((len(v) for v in cols.values()), default=0)
    if tt and any(x is not None for x in tt): T = tt
    elif ts and any(x is not None for x in ts):
        t0 = next(x for x in ts if x is not None); T = [(x - t0) / 1000 if x is not None else None for x in ts]
    else: T = list(range(n))
    out = {"t": []}
    picks = {}
    for k, alts in SER_KEYS.items():
        for a in alts:
            if a in cols and any(x is not None for x in cols[a]): picks[k] = cols[a]; break
    for k in picks: out[k] = []
    nxt = 0.0
    for i in range(n):
        t = T[i] if i < len(T) else None
        if t is None or t < nxt: continue
        nxt = t + RESAMPLE_S
        out["t"].append(round(t))
        for k, col in picks.items():
            v = col[i] if i < len(col) else None
            out[k].append(None if v is None else round(v, 3 if k in ("v", "gap") else 1))
    if "cad" in out and "directDoubleCadence" not in cols and picks.get("cad") is cols.get("directRunCadence"):
        pass  # cadence de course déjà en pas/min (Garmin) ; la double cadence est prioritaire si présente
    lat = cols.get("directLatitude"); lon = cols.get("directLongitude"); dd = cols.get("sumDistance")
    pts = [(lat[i], lon[i], (dd[i] if dd and i < len(dd) else None)) for i in range(min(len(lat or []), len(lon or [])))
           if lat[i] is not None and lon[i] is not None] if lat and lon else []
    poly = _poly(raw) or [(a, b, c) for a, b, c in pts]
    return {k: v for k, v in out.items() if v and any(x is not None for x in v)}, poly


def _poly(raw):
    pl = ((raw or {}).get("geoPolylineDTO") or {}).get("polyline") if isinstance(raw, dict) else None
    out = []
    for p in pl or []:
        a, b = pick(p, "lat", "latitude"), pick(p, "lon", "longitude")
        if a is not None and b is not None: out.append((a, b, pick(p, "distanceInMeters", "distance")))
    return out


def _hav(a, b):
    R = 6371000.0
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def _rdp(pts, eps):
    if len(pts) < 3: return pts
    a, b = pts[0], pts[-1]
    def dist(p):
        if a == b: return _hav(p, a)
        x0, y0, x1, y1, x, y = a[1], a[0], b[1], b[0], p[1], p[0]
        num_ = abs((y1 - y0) * x - (x1 - x0) * y + x1 * y0 - y1 * x0); den = math.hypot(y1 - y0, x1 - x0)
        return num_ / den * 111000 if den else 0
    i, dm = max(((i, dist(p)) for i, p in enumerate(pts[1:-1], 1)), key=lambda t: t[1])
    if dm > eps:
        return _rdp(pts[:i + 1], eps)[:-1] + _rdp(pts[i:], eps)
    return [a, b]


def privacy_track(poly, mode="crop"):
    """Tracé conservé selon GPS_MODE : 'off' -> rien ; 'crop' -> 300 m coupés aux deux bouts ; simplifié à ~300 points."""
    if mode == "off" or len(poly) < 4: return []
    pts = [(p[0], p[1]) for p in poly]
    if mode == "crop":
        cum = [0.0]
        for i in range(1, len(pts)): cum.append(cum[-1] + _hav(pts[i - 1], pts[i]))
        tot = cum[-1]
        if tot < 3 * CROP_M: return []                          # trop court pour masquer départ et arrivée : rien de gardé
        pts = [p for p, c in zip(pts, cum) if CROP_M <= c <= tot - CROP_M]
    eps = 3.0
    s = _rdp(pts, eps)
    while len(s) > POLY_MAX and eps < 200:
        eps *= 1.6; s = _rdp(pts, eps)
    return [[round(a, 5), round(b, 5)] for a, b in s]


def norm_summary(raw):
    """Résumé complet : tous les nombres de summaryDTO (Training Effect, charge, dynamique, natation…) + métadonnées utiles."""
    if not isinstance(raw, dict): return {}, None, None
    sm = raw.get("summaryDTO") or raw
    m = {}
    for k, v in (sm.items() if isinstance(sm, dict) else []):
        x = num(v)
        kl = k.lower()
        if x is not None and "latitude" not in kl and "longitude" not in kl and not kl.endswith("id") and not kl.endswith("pk"):
            m[k] = round(x, 3)
    for k in ("trainingEffectLabel", "aerobicTrainingEffectMessage", "anaerobicTrainingEffectMessage"):
        if isinstance(sm.get(k) if isinstance(sm, dict) else None, str): m[k] = sm[k]
    wid = find(raw, "workoutid") or find(raw, "associatedworkoutid")
    pool = find(raw, "poollength")
    tk = ((raw.get("activityTypeDTO") or {}).get("typeKey")) if isinstance(raw.get("activityTypeDTO"), dict) else None
    if pool is not None: m["poolLength"] = num(pool)
    if tk: m["typeKey"] = tk
    return m, (int(wid) if num(wid) is not None else None), tk


def norm_weather(raw):
    if not isinstance(raw, dict): return {}
    tF = pick(raw, "temp"); aF = pick(raw, "apparentTemp"); dF = pick(raw, "dewPoint"); w = pick(raw, "windSpeed")
    c = lambda f: None if f is None else round((f - 32) * 5 / 9, 1)
    return clean({"temp": c(tF), "feel": c(aF), "dew": c(dF), "hum": pick(raw, "relativeHumidity"),
                  "wind": rnd(w * 1.609 if w is not None else None), "wdir": pick_s(raw, "windDirectionCompassPoint"),
                  "sky": pick_s(raw, "weatherTypeDTO")})


def norm_gear(raw):
    out = []
    for g in (raw if isinstance(raw, list) else []):
        if isinstance(g, dict):
            out.append(clean({"uuid": g.get("uuid"), "name": g.get("displayName") or g.get("customMakeModel"),
                              "type": pick_s(g, "gearTypeName", "gearType"), "model": g.get("customMakeModel")}))
    return out


def norm_sets(raw):
    L = (raw or {}).get("exerciseSets") if isinstance(raw, dict) else raw
    out = []
    for s in L or []:
        if not isinstance(s, dict): continue
        ex = (s.get("exercises") or [{}])
        ex = max(ex, key=lambda e: num(e.get("probability")) or 0) if ex else {}
        w = pick(s, "weight")
        if w is not None and w > 400: w = w / 1000                 # Garmin renvoie souvent la charge en grammes
        out.append(clean({"ty": pick_s(s, "setType"), "t": rnd(pick(s, "duration")), "reps": pick(s, "repetitionCount"),
                          "kg": rnd(w), "cat": ex.get("category"), "ex": ex.get("name"), "p": num(ex.get("probability")), "at": s.get("startTime")}))
    return out


def normalize(raw, fam, gps_mode="crop"):
    """Toutes les réponses brutes d'une activité -> format compact Emberline (SCHEMA)."""
    summ, wid, tk = norm_summary(raw.get("get_activity"))
    series, poly = norm_series(raw.get("get_activity_details"))
    if fam in ("run", "trail") and series.get("cad") and summ.get("averageRunCadence"):   # cadence de course en foulées/min : ramenée en pas/min
        cv = sorted(c for c in series["cad"] if c); med = cv[len(cv) // 2] if cv else None
        if med and med * 1.5 < summ["averageRunCadence"]: series["cad"] = [round(c * 2, 1) if c else c for c in series["cad"]]
    rec = {"v": SCHEMA, "fam": fam, "type": tk, "wid": wid, "m": summ,
           "laps": norm_splits(raw.get("get_activity_splits")), "typed": norm_typed(raw.get("get_activity_typed_splits")),
           "zones": norm_zones(raw.get("get_activity_hr_in_timezones")), "ser": series,
           "trk": privacy_track(poly, gps_mode), "wx": norm_weather(raw.get("get_activity_weather")),
           "gear": norm_gear(raw.get("get_activity_gear")), "sets": norm_sets(raw.get("get_activity_exercise_sets"))}
    return {k: v for k, v in rec.items() if v not in (None, [], {}) or k in ("v", "fam")}


# ------------------------------------------------------------------------------------------------- cache et collecte
def _idx_path(out): return out / "details" / "index.json"


def load_index(out):
    try: return json.loads(_idx_path(out).read_text(encoding="utf-8"))
    except (OSError, ValueError): return {"v": 1, "acts": {}, "log": []}


def save_index(out, ix):
    p = _idx_path(out); p.parent.mkdir(parents=True, exist_ok=True)
    ix["log"] = ix.get("log", [])[-60:]
    p.write_text(json.dumps(ix, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def load_detail(out, aid):
    p = out / "details" / f"{aid}.json.gz"
    try: return json.loads(gzip.decompress(p.read_bytes()).decode("utf-8"))
    except (OSError, ValueError, EOFError): return None


def save_detail(out, aid, rec):
    p = out / "details" / f"{aid}.json.gz"; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(gzip.compress(json.dumps(rec, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), 9))


def fetch_activity(client, aid, fam, gps_mode):
    raw, errs = {}, {}
    for name, args, kw in detail_calls(fam, aid):
        r, e = _call(client, name, *args, **kw)
        if e: errs[name] = e
        else: raw[name] = r
    rec = normalize(raw, fam, gps_mode)
    rec["err"] = errs
    return rec, errs


def collect(client, activities, out, gps_mode="crop", budget_old=6, max_new=12, log=print):
    """Détaille les activités pas encore en cache : d'abord les nouvelles (jusqu'à max_new), puis l'historique (budget_old).
    S'arrête proprement au premier 429. Met à jour garmin/details/index.json et renvoie un petit bilan."""
    out = Path(out); ix = load_index(out); A = ix.setdefault("acts", {})
    todo = []
    for a in activities or []:
        aid = a.get("activityId")
        if aid is None: continue
        k = str(aid); e = A.get(k) or {}
        if e.get("ok") and e.get("v", 0) >= SCHEMA: continue
        if e.get("tries", 0) >= RETRY_MAX: continue
        todo.append((a.get("startTimeLocal") or "", k, family_of(((a.get("activityType") or {}).get("typeKey")) or ""), a))
    todo.sort(reverse=True)
    today = date.today().isoformat(); recent = (date.today() - timedelta(days=3)).isoformat()
    new = [x for x in todo if x[0][:10] >= recent][:max_new]
    old = [x for x in todo if x[0][:10] < recent][:budget_old]
    done, stopped = 0, None
    for st, k, fam, a in new + old:
        e = A.setdefault(k, {}); e.update(d=st[:10], fam=fam, tries=e.get("tries", 0) + 1, at=today)
        try:
            rec, errs = fetch_activity(client, int(k), fam, gps_mode)
        except RateLimited as ex:
            stopped = f"429 : {ex}"; e["tries"] -= 1; break
        core = [n for n in ("get_activity_splits", "get_activity_details") if n not in errs]
        ok = bool(core) or bool(rec.get("laps") or rec.get("ser"))
        if ok:
            save_detail(out, k, rec); e.update(ok=True, v=SCHEMA, n_err=len(errs)); done += 1
        else:
            e.update(ok=False, last=",".join(f"{a}:{b}" for a, b in errs.items())[:200])
    known = [str(a.get("activityId")) for a in activities or [] if a.get("activityId") is not None]
    cov = sum(1 for k in A if (A[k] or {}).get("ok"))
    ix["log"].append({"at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%MZ"), "new": done, "stop": stopped})
    ix["coverage"] = {"detailed": cov, "known": max(len(A), len(known))}
    save_index(out, ix)
    log(f"Détails : {done} activité(s) détaillée(s), {cov}/{max(len(A), len(known))} au total" + (f" — arrêt ({stopped})" if stopped else ""))
    return {"done": done, "stopped": stopped, "coverage": ix["coverage"]}


# ------------------------------------------------------------------------------------------------- indicateurs globaux
def _g(o, *keys):
    for k in keys:
        v = find(o, k.lower())
        x = num(v)
        if x is not None: return x
    return None


def norm_global(raw):
    """Extraction tolérante des indicateurs Garmin quotidiens (les clés varient selon les montres et les versions)."""
    mm, ts = raw.get("get_max_metrics"), raw.get("get_training_status")
    rp, lt = raw.get("get_race_predictions"), raw.get("get_lactate_threshold")
    run_vo2 = bike_vo2 = None
    if isinstance(mm, list) and mm:
        g = (mm[0] or {}).get("generic") or {}; c = (mm[0] or {}).get("cycling") or {}
        run_vo2 = pick(g, "vo2MaxPreciseValue", "vo2MaxValue"); bike_vo2 = pick(c, "vo2MaxPreciseValue", "vo2MaxValue")
    out = {"vo2_run": run_vo2 if run_vo2 is not None else _g(mm, "vo2MaxPreciseValue"), "vo2_bike": bike_vo2,
           "status": None, "acute": _g(ts, "dailyTrainingLoadAcute", "acuteTrainingLoad"),
           "chronic": _g(ts, "dailyTrainingLoadChronic", "chronicTrainingLoad"),
           "acwr": _g(ts, "dailyAcuteChronicWorkloadRatio", "acwrPercent"),
           "lo_aer": _g(ts, "monthlyLoadAerobicLow"), "hi_aer": _g(ts, "monthlyLoadAerobicHigh"), "anaer": _g(ts, "monthlyLoadAnaerobic"),
           "endur": _g(raw.get("get_endurance_score"), "overallScore", "enduranceScore"),
           "hill": _g(raw.get("get_hill_score"), "overallScore", "hillScore"),
           "p5k": _g(rp, "time5K"), "p10k": _g(rp, "time10K"), "phalf": _g(rp, "timeHalfMarathon"), "pmar": _g(rp, "timeMarathon"),
           "lt_hr": _g(lt, "heartRate", "lactateThresholdHeartRate"), "lt_v": _g(lt, "speed", "lactateThresholdSpeed"),
           "ftp": _g(raw.get("get_cycling_ftp"), "functionalThresholdPower", "ftp")}
    if out.get("vo2_run") is None or out.get("vo2_bike") is None:   # diagnostic du 19/11 : get_max_metrics vide, VO2max dans le statut d'entraînement
        mv = (ts or {}).get("mostRecentVO2Max") if isinstance(ts, dict) else None
        if isinstance(mv, dict):
            if out.get("vo2_run") is None: out["vo2_run"] = pick(mv.get("generic") or {}, "vo2MaxPreciseValue", "vo2MaxValue")
            if out.get("vo2_bike") is None: out["vo2_bike"] = pick(mv.get("cycling") or {}, "vo2MaxPreciseValue", "vo2MaxValue")
    out["heat"] = _g(ts, "heatAcclimationPercentage")
    lb = find(ts, "trainingbalancefeedbackphrase")
    if isinstance(lb, str): out["balance"] = lb
    for k, key in (("lo_min", "monthlyLoadAerobicLowTargetMin"), ("lo_max", "monthlyLoadAerobicLowTargetMax"), ("hi_min", "monthlyLoadAerobicHighTargetMin"),
                   ("hi_max", "monthlyLoadAerobicHighTargetMax"), ("an_min", "monthlyLoadAnaerobicTargetMin"), ("an_max", "monthlyLoadAnaerobicTargetMax")):
        out[k] = _g(ts, key)
    st = find(ts, "trainingstatusfeedbackphrase") or find(ts, "trainingstatus")
    if isinstance(st, str): out["status"] = st
    prs = []
    for r in (raw.get("get_personal_record") or []) if isinstance(raw.get("get_personal_record"), list) else []:
        if isinstance(r, dict) and pick(r, "value") is not None:
            prs.append(clean({"type": pick(r, "typeId"), "val": pick(r, "value"), "d": (r.get("prStartTimeGmtFormatted") or r.get("actStartDateTimeInGMTFormatted") or "")[:10]}))
    if prs: out["prs"] = prs
    if out["lt_v"] is not None and out["lt_v"] < 1: out["lt_v"] = out["lt_v"] * 10   # certaines versions renvoient la vitesse en dm/s
    return clean(out)


def collect_global(client, out, log=print):
    """Une fois par jour : indicateurs globaux dans garmin/daily_metrics.json.gz (400 jours conservés)."""
    out = Path(out); p = out / "details" / "daily_metrics.json.gz"
    try: data = json.loads(gzip.decompress(p.read_bytes()).decode("utf-8"))
    except (OSError, ValueError, EOFError): data = {}
    d = date.today().isoformat()
    if d in data: return data
    raw = {}
    try:
        for name, args in global_calls(d):
            r, e = _call(client, name, *args)
            if not e: raw[name] = r
    except RateLimited as ex:
        log(f"Indicateurs globaux : arrêt (429 : {ex})")
    g = norm_global(raw)
    if g:
        data[d] = g
        keep = sorted(data)[-400:]; data = {k: data[k] for k in keep}
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(gzip.compress(json.dumps(data, separators=(",", ":")).encode("utf-8"), 9))
        log(f"Indicateurs globaux : {len(g)} valeur(s) pour {d}")
    return data


def load_all_details(out):
    """Pour l'analyse : {activityId (str): détail normalisé} + indicateurs globaux. Ne lève jamais d'exception."""
    out = Path(out); res = {}
    try:
        for p in (out / "details").glob("*.json.gz"):
            if p.name.startswith("daily_metrics"): continue
            try: res[p.name.split(".")[0]] = json.loads(gzip.decompress(p.read_bytes()).decode("utf-8"))
            except (OSError, ValueError, EOFError): continue
    except OSError:
        pass
    try: glob_ = json.loads(gzip.decompress((out / "details" / "daily_metrics.json.gz").read_bytes()).decode("utf-8"))
    except (OSError, ValueError, EOFError): glob_ = {}
    return res, glob_, load_index(out).get("coverage") or {}


# ------------------------------------------------------------------------------------------------- état des données (app)
def data_status(out, meta, acts, today):
    """Résumé affiché dans l'app (« État des données ») : dernière synchro, part des séances détaillées, limite Garmin.
    Ne contient aucune donnée personnelle (dates, nombres, messages d'état)."""
    out = Path(out); ix = load_index(out); A = ix.get("acts") or {}
    try: T = date.fromisoformat(str(today)[:10])
    except ValueError: T = date.today()
    d42 = (T - timedelta(days=42)).isoformat()
    rec = [a for a in acts or [] if a.get("d", "") >= d42]
    det = sum(1 for a in rec if a.get("x"))
    pend = sum(1 for e in A.values() if not (e or {}).get("ok") and (e or {}).get("tries", 0) < RETRY_MAX)
    fail = sum(1 for e in A.values() if not (e or {}).get("ok") and (e or {}).get("tries", 0) >= RETRY_MAX)
    log = (ix.get("log") or [])[-1:] or [{}]
    last = log[0]
    lim = [x for x in (ix.get("log") or [])[-10:] if x.get("stop")]
    return {"sync": {"at": (meta or {}).get("synced_at"), "ok": (meta or {}).get("ok", True), "reason": (meta or {}).get("reason") or "",
                     "kept": bool((meta or {}).get("kept_previous"))},
            "det": {"recent": len(rec), "recent_det": det, "all": (ix.get("coverage") or {}).get("detailed", 0),
                    "known": (ix.get("coverage") or {}).get("known", 0), "pending": pend, "failed": fail,
                    "last_at": last.get("at"), "last_new": last.get("new"), "limited": bool(last.get("stop")), "limited_n": len(lim)}}
