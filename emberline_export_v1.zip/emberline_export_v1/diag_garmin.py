"""diag_garmin.py — diagnostic des données détaillées disponibles sur Garmin Connect (Emberline v6).

Appelle chaque méthode de détail sur UNE activité récente par sport (course, trail, vélo, natation, musculation, autre)
et les indicateurs globaux, puis écrit diag_garmin.json : la STRUCTURE des réponses (clés, types, exemples de valeurs),
anonymisée. Rien n'est écrit dans garmin/ et rien n'est envoyé ailleurs.

Anonymisation :
  - aucune coordonnée GPS (latitude, longitude, tracé, lieu) ;
  - aucun identifiant (activityId, userProfileId, uuid…), aucun nom (activité, appareil, équipement, personne), aucun e-mail ;
  - les nombres sont arrondis, les textes libres coupés à 24 caractères et les listes réduites à leurs 3 premiers éléments.

Lancement : onglet Actions > « Diagnostic Garmin » > Run workflow, puis télécharger l'artefact diag-garmin (diag_garmin.json).
En local : python diag_garmin.py --days 30
"""
import argparse
import json
import re
import time
from datetime import date, timedelta
from pathlib import Path

import garmin_details as GD
from sync_garmin import get_client

SECRET_KEYS = re.compile(r"(^|_)(lat|lon|lng|latitude|longitude|polyline|location|locationname|city|country|address|"
                         r"owner|user|profile|displayname|fullname|email|uuid|deviceid|serial|unitid|"
                         r"activityname|name|description|comment|imageurl|url)($|_)|latitude|longitude|ownerid|"
                         r"profileid|activityid|workoutid|gearpk|uuid|startlatitude|endlatitude|startlongitude|endlongitude",
                         re.I)
KEEP_NAME_KEYS = {"typekey", "sporttypekey", "swimstroke", "category", "exercisename", "intensitytype", "steptypekey",
                  "metricskey", "key", "type", "unit", "settype", "gearTypeName".lower(), "conditiontypekey"}


def shape(o, depth=0, key=""):
    """Structure anonymisée d'une réponse : types, clés et quelques valeurs d'exemple."""
    if depth > 7:
        return "…"
    if isinstance(o, dict):
        out = {}
        for k, v in o.items():
            kl = str(k).lower()
            if SECRET_KEYS.search(kl) and kl not in KEEP_NAME_KEYS:
                out[k] = f"<masqué:{type(v).__name__}>"
            else:
                out[k] = shape(v, depth + 1, kl)
        return out
    if isinstance(o, list):
        if key == "metrics":                                   # valeurs brutes (dont latitude et longitude) : seulement leur nombre
            return {"_liste": len(o), "_exemples": []}
        if key in ("metricdescriptors",):
            return [shape(x, depth + 1) for x in o]          # liste des métriques disponibles : utile en entier
        return {"_liste": len(o), "_exemples": [shape(x, depth + 1, key) for x in o[:3]]}
    if isinstance(o, bool) or o is None:
        return o
    if isinstance(o, (int, float)):
        return round(float(o), 2)
    if isinstance(o, str):
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", o):
            return "<date>"
        return o[:24]
    return type(o).__name__


def call(client, name, *args, **kw):
    fn = getattr(client, name, None)
    if fn is None:
        return {"_absent": True}
    t0 = time.time()
    try:
        r = fn(*args, **kw)
        return {"_ok": True, "_s": round(time.time() - t0, 2), "_taille_json": len(json.dumps(r, default=str)), "reponse": shape(r)}
    except Exception as e:  # noqa: BLE001
        return {"_ok": False, "_erreur": f"{type(e).__name__}: {str(e)[:120]}"}
    finally:
        time.sleep(1.2)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--out", default="diag_garmin.json")
    a = p.parse_args()
    client = get_client()
    try:
        import garminconnect
        ver = getattr(garminconnect, "__version__", "?")
    except Exception:  # noqa: BLE001
        ver = "?"
    end = date.today(); start = end - timedelta(days=a.days)
    acts = client.get_activities_by_date(start.isoformat(), end.isoformat()) or []
    picked = {}
    for x in sorted(acts, key=lambda x: x.get("startTimeLocal") or "", reverse=True):
        fam = GD.family_of((x.get("activityType") or {}).get("typeKey", ""))
        picked.setdefault(fam, x)
    out = {"version_garminconnect": ver, "date": end.isoformat(),
           "methodes_disponibles": sorted(m for m in dir(client) if m.startswith(("get_", "download_"))),
           "activites": {}, "global": {}}
    for fam, x in picked.items():
        aid = x.get("activityId")
        rec = {"type": (x.get("activityType") or {}).get("typeKey"), "resume_liste": shape(x), "appels": {}}
        for name, args, kw in GD.detail_calls(fam, aid):
            rec["appels"][name] = call(client, name, *args, **kw)
        out["activites"][fam] = rec
    d = end.isoformat()
    for name, args in GD.global_calls(d):
        out["global"][name] = call(client, name, *args)
    Path(a.out).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Diagnostic écrit dans {a.out} : {len(picked)} sport(s) ({', '.join(picked)}), "
          f"{sum(len(r['appels']) for r in out['activites'].values())} appels d'activité, {len(out['global'])} appels globaux.")


if __name__ == "__main__":
    main()
